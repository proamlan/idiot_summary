import{c as n}from"./settings-storage-QQ57jQ2p.js";/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],r=n("Check",l);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]],d=n("Globe",c);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],u=n("Settings",p);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]],f=n("Sparkles",s);function _(e){try{return new URL(e).hostname.replace(/^www\./,"")}catch{return e}}function x(e){try{return new Date(e).toLocaleDateString(void 0,{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"})}catch{return e}}function $(e,a){const t=[];return t.push(`# ${e.title||"Summary"}`),t.push(`> Source: [${a}](${a})
`),e.big_idea&&t.push(`## The Big Idea
${e.big_idea}
`),e.simple_explanation&&t.push(`## Explain Like I'm 12
${e.simple_explanation}
`),e.key_points&&e.key_points.length>0&&(t.push("## The Important Stuff"),e.key_points.forEach((o,i)=>{t.push(`${i+1}. **${o.point}**: ${o.explanation}`)}),t.push("")),e.why_it_matters&&t.push(`## Why Should I Care?
${e.why_it_matters}
`),e.real_world_example&&t.push(`## Real-World Example
${e.real_world_example}
`),e.important_numbers&&e.important_numbers.length>0&&(t.push("## Numbers That Matter"),e.important_numbers.forEach(o=>{t.push(`- **${o.value}**: ${o.context}`)}),t.push("")),e.difficult_terms&&e.difficult_terms.length>0&&(t.push("## Things That Might Confuse You"),e.difficult_terms.forEach(o=>{t.push(`- **${o.term}**: ${o.simple_definition}${o.example?` *(e.g. ${o.example})*`:""}`)}),t.push("")),e.claims_and_caveats&&e.claims_and_caveats.length>0&&(t.push("## Claims, Facts & Opinions"),e.claims_and_caveats.forEach(o=>{t.push(`- [${o.type.toUpperCase()}] **${o.claim}**
  *Caveat/Context:* ${o.caveat}`)}),t.push("")),e.bottom_line&&t.push(`## The Bottom Line
${e.bottom_line}
`),t.push("---"),t.push("*Generated with Idiot Summary — AI-powered simple explanations.*"),t.join(`
`)}async function g(e){try{if(navigator.clipboard&&window.isSecureContext)return await navigator.clipboard.writeText(e),!0;const a=document.createElement("textarea");a.value=e,a.style.position="fixed",a.style.left="-999999px",a.style.top="-999999px",document.body.appendChild(a),a.focus(),a.select();const t=document.execCommand("copy");return document.body.removeChild(a),t}catch(a){return console.error("Failed to copy text:",a),!1}}export{r as C,d as G,u as S,f as a,$ as b,g as c,_ as e,x as f};
