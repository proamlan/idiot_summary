var mw = Object.defineProperty;
var ty = (p) => {
  throw TypeError(p);
};
var bw = (p, t, e) => t in p ? mw(p, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : p[t] = e;
var _ = (p, t, e) => bw(p, typeof t != "symbol" ? t + "" : t, e), mg = (p, t, e) => t.has(p) || ty("Cannot " + e);
var i = (p, t, e) => (mg(p, t, "read from private field"), e ? e.call(p) : t.get(p)), g = (p, t, e) => t.has(p) ? ty("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(p) : t.set(p, e), u = (p, t, e, s) => (mg(p, t, "write to private field"), s ? s.call(p, e) : t.set(p, e), e), m = (p, t, e) => (mg(p, t, "access private method"), e);
var rt = (p, t, e, s) => ({
  set _(n) {
    u(p, t, n, e);
  },
  get _() {
    return i(p, t, s);
  }
});
const bs = typeof process == "object" && process + "" == "[object process]" && !process.versions.nw && !(process.versions.electron && process.type && process.type !== "browser"), Yi = [1 / 0, 1 / 0, -1 / 0, -1 / 0], va = new Float32Array(Yi), xg = [1e-3, 0, 0, 1e-3, 0, 0], Re = "http://www.w3.org/2000/svg", ms = {
  ANY: 1,
  DISPLAY: 2,
  PRINT: 4,
  ANNOTATIONS_FORMS: 16,
  ANNOTATIONS_STORAGE: 32,
  ANNOTATIONS_DISABLE: 64,
  IS_EDITING: 128,
  OPLIST: 256
}, tr = {
  DISABLE: 0,
  ENABLE: 1,
  ENABLE_FORMS: 2,
  ENABLE_STORAGE: 3
}, ml = "pdfjs_internal_id_", dc = "pdfjs_internal_editor_", X = {
  DISABLE: -1,
  NONE: 0,
  FREETEXT: 3,
  HIGHLIGHT: 9,
  STAMP: 13,
  INK: 15,
  POPUP: 16,
  SIGNATURE: 101,
  COMMENT: 102
}, tt = {
  RESIZE: 1,
  CREATE: 2,
  FREETEXT_SIZE: 11,
  FREETEXT_COLOR: 12,
  FREETEXT_OPACITY: 13,
  INK_COLOR: 21,
  INK_THICKNESS: 22,
  INK_OPACITY: 23,
  INK_COLOR_AND_OPACITY: 24,
  HIGHLIGHT_COLOR: 31,
  HIGHLIGHT_THICKNESS: 32,
  HIGHLIGHT_FREE: 33,
  HIGHLIGHT_SHOW_ALL: 34,
  DRAW_STEP: 41
}, yw = {
  PRINT: 4,
  MODIFY_CONTENTS: 8,
  COPY: 16,
  MODIFY_ANNOTATIONS: 32,
  FILL_INTERACTIVE_FORMS: 256,
  COPY_FOR_ACCESSIBILITY: 512,
  ASSEMBLE: 1024,
  PRINT_HIGH_QUALITY: 2048
}, qt = {
  FILL: 0,
  STROKE: 1,
  FILL_STROKE: 2,
  INVISIBLE: 3,
  FILL_STROKE_MASK: 3,
  ADD_TO_PATH_FLAG: 4
}, bf = {
  GRAYSCALE_1BPP: 1,
  RGB_24BPP: 2,
  RGBA_32BPP: 3
}, It = {
  TEXT: 1,
  LINK: 2,
  FREETEXT: 3,
  LINE: 4,
  SQUARE: 5,
  CIRCLE: 6,
  POLYGON: 7,
  POLYLINE: 8,
  HIGHLIGHT: 9,
  UNDERLINE: 10,
  SQUIGGLY: 11,
  STRIKEOUT: 12,
  STAMP: 13,
  CARET: 14,
  INK: 15,
  POPUP: 16,
  FILEATTACHMENT: 17,
  SOUND: 18,
  MOVIE: 19,
  WIDGET: 20,
  SCREEN: 21,
  PRINTERMARK: 22,
  TRAPNET: 23,
  WATERMARK: 24,
  THREED: 25,
  REDACT: 26,
  RICHMEDIA: 27
}, fl = {
  SOLID: 1,
  DASHED: 2,
  BEVELED: 3,
  INSET: 4,
  UNDERLINE: 5
}, eg = {
  ERRORS: 0,
  WARNINGS: 1,
  INFOS: 5
}, an = {
  dependency: 1,
  setLineWidth: 2,
  setLineCap: 3,
  setLineJoin: 4,
  setMiterLimit: 5,
  setDash: 6,
  setRenderingIntent: 7,
  setFlatness: 8,
  setGState: 9,
  save: 10,
  restore: 11,
  transform: 12,
  moveTo: 13,
  lineTo: 14,
  curveTo: 15,
  curveTo2: 16,
  curveTo3: 17,
  closePath: 18,
  rectangle: 19,
  stroke: 20,
  closeStroke: 21,
  fill: 22,
  eoFill: 23,
  fillStroke: 24,
  eoFillStroke: 25,
  closeFillStroke: 26,
  closeEOFillStroke: 27,
  endPath: 28,
  clip: 29,
  eoClip: 30,
  beginText: 31,
  endText: 32,
  setCharSpacing: 33,
  setWordSpacing: 34,
  setHScale: 35,
  setLeading: 36,
  setFont: 37,
  setTextRenderingMode: 38,
  setTextRise: 39,
  moveText: 40,
  setLeadingMoveText: 41,
  setTextMatrix: 42,
  nextLine: 43,
  showText: 44,
  showSpacedText: 45,
  nextLineShowText: 46,
  nextLineSetSpacingShowText: 47,
  setCharWidth: 48,
  setCharWidthAndBounds: 49,
  setStrokeColorSpace: 50,
  setFillColorSpace: 51,
  setStrokeColor: 52,
  setStrokeColorN: 53,
  setFillColor: 54,
  setFillColorN: 55,
  setStrokeGray: 56,
  setFillGray: 57,
  setStrokeRGBColor: 58,
  setFillRGBColor: 59,
  setStrokeCMYKColor: 60,
  setFillCMYKColor: 61,
  shadingFill: 62,
  beginInlineImage: 63,
  beginImageData: 64,
  endInlineImage: 65,
  paintXObject: 66,
  markPoint: 67,
  markPointProps: 68,
  beginMarkedContent: 69,
  beginMarkedContentProps: 70,
  endMarkedContent: 71,
  beginCompat: 72,
  endCompat: 73,
  paintFormXObjectBegin: 74,
  paintFormXObjectEnd: 75,
  beginGroup: 76,
  endGroup: 77,
  beginAnnotation: 80,
  endAnnotation: 81,
  paintImageMaskXObject: 83,
  paintImageMaskXObjectGroup: 84,
  paintImageXObject: 85,
  paintInlineImageXObject: 86,
  paintInlineImageXObjectGroup: 87,
  paintImageXObjectRepeat: 88,
  paintImageMaskXObjectRepeat: 89,
  paintSolidColorImageMask: 90,
  constructPath: 91,
  setStrokeTransparent: 92,
  setFillTransparent: 93,
  rawFillPath: 94
}, yc = {
  moveTo: 0,
  lineTo: 1,
  curveTo: 2,
  quadraticCurveTo: 3,
  closePath: 4
}, Aw = {
  NEED_PASSWORD: 1,
  INCORRECT_PASSWORD: 2
};
let sg = eg.WARNINGS;
function ww(p) {
  Number.isInteger(p) && (sg = p);
}
function Fy() {
  return sg;
}
function ig(p) {
  sg >= eg.INFOS && console.info(`Info: ${p}`);
}
function j(p) {
  sg >= eg.WARNINGS && console.warn(`Warning: ${p}`);
}
function it(p) {
  throw new Error(p);
}
function jt(p, t) {
  p || it(t);
}
function vw(p) {
  switch (p == null ? void 0 : p.protocol) {
    case "http:":
    case "https:":
    case "ftp:":
    case "mailto:":
    case "tel:":
      return !0;
    default:
      return !1;
  }
}
function Ly(p, t = null, e = null) {
  if (!p)
    return null;
  if (e && typeof p == "string") {
    if (e.addDefaultProtocol && p.startsWith("www.")) {
      const n = p.match(/\./g);
      (n == null ? void 0 : n.length) >= 2 && (p = `http://${p}`);
    }
    if (e.tryConvertEncoding)
      try {
        p = Cw(p);
      } catch {
      }
  }
  const s = t ? URL.parse(p, t) : URL.parse(p);
  return vw(s) ? s : null;
}
function Oy(p, t, e = !1) {
  const s = URL.parse(p);
  return s ? (s.hash = t, s.href) : e && Ly(p, "http://example.com") ? p.split("#", 1)[0] + `${t ? `#${t}` : ""}` : "";
}
function Tg(p) {
  return p.substring(p.lastIndexOf("/") + 1);
}
function L(p, t, e, s = !1) {
  return Object.defineProperty(p, t, {
    value: e,
    enumerable: !s,
    configurable: !0,
    writable: !1
  }), e;
}
const hl = (function() {
  function t(e, s) {
    this.message = e, this.name = s;
  }
  return t.prototype = new Error(), t.constructor = t, t;
})();
class _g extends hl {
  constructor(t, e) {
    super(t, "PasswordException"), this.code = e;
  }
}
class of extends hl {
  constructor(t, e) {
    super(t, "UnknownErrorException"), this.details = e;
  }
}
class kg extends hl {
  constructor(t) {
    super(t, "InvalidPDFException");
  }
}
class ap extends hl {
  constructor(t, e, s) {
    super(t, "ResponseException"), this.status = e, this.missing = s;
  }
}
class Sw extends hl {
  constructor(t) {
    super(t, "FormatError");
  }
}
class oa extends hl {
  constructor(t) {
    super(t, "AbortException");
  }
}
function Ew(p) {
  (typeof p != "object" || (p == null ? void 0 : p.length) === void 0) && it("Invalid argument for bytesToString");
  const t = p.length, e = 8192;
  if (t < e)
    return String.fromCharCode.apply(null, p);
  const s = [];
  for (let n = 0; n < t; n += e) {
    const r = Math.min(n + e, t), a = p.subarray(n, r);
    s.push(String.fromCharCode.apply(null, a));
  }
  return s.join("");
}
function ng(p) {
  typeof p != "string" && it("Invalid argument for stringToBytes");
  const t = p.length, e = new Uint8Array(t);
  for (let s = 0; s < t; ++s)
    e[s] = p.charCodeAt(s) & 255;
  return e;
}
class ot {
  static get isLittleEndian() {
    const t = new Uint8Array(4);
    t[0] = 1;
    const e = new Uint32Array(t.buffer, 0, 1);
    return L(this, "isLittleEndian", e[0] === 1);
  }
  static get isOffscreenCanvasSupported() {
    return L(this, "isOffscreenCanvasSupported", typeof OffscreenCanvas < "u");
  }
  static get isImageDecoderSupported() {
    return L(this, "isImageDecoderSupported", typeof ImageDecoder < "u");
  }
  static get isVideoFrameSupported() {
    return L(this, "isVideoFrameSupported", typeof VideoFrame < "u");
  }
  static get isFloat16ArraySupported() {
    return L(this, "isFloat16ArraySupported", typeof Float16Array < "u");
  }
  static get isSanitizerSupported() {
    return L(this, "isSanitizerSupported", typeof Sanitizer < "u");
  }
  static get platform() {
    const {
      platform: t,
      userAgent: e
    } = navigator;
    return L(this, "platform", {
      isAndroid: e.includes("Android"),
      isLinux: t.includes("Linux"),
      isMac: t.includes("Mac"),
      isWindows: t.includes("Win"),
      isFirefox: e.includes("Firefox")
    });
  }
  static get isCanvasFilterSupported() {
    let t;
    return this.isOffscreenCanvasSupported ? t = new OffscreenCanvas(1, 1).getContext("2d") : typeof document < "u" && (t = document.createElement("canvas").getContext("2d")), L(this, "isCanvasFilterSupported", (t == null ? void 0 : t.filter) !== void 0);
  }
  static get isAlphaColorInputSupported() {
    if (typeof document > "u")
      return L(this, "isAlphaColorInputSupported", !1);
    const t = document.createElement("input");
    return t.type = "color", t.setAttribute("alpha", ""), t.value = "#ff000080", L(this, "isAlphaColorInputSupported", t.value !== "#ff0000");
  }
  static get isBackdropFilterSupported() {
    return L(this, "isBackdropFilterSupported", typeof CSS < "u" && CSS.supports("backdrop-filter", "blur(1px)"));
  }
}
var Xn, yf, Pg;
class I {
  static get hexNums() {
    return L(this, "hexNums", Array.from({
      length: 256
    }, (t, e) => e.toString(16).padStart(2, "0")));
  }
  static makeHexColor(t, e, s) {
    return `#${this.hexNums[t]}${this.hexNums[e]}${this.hexNums[s]}`;
  }
  static get identity0to256Map() {
    return L(this, "identity0to256Map", Uint8Array.from({
      length: 256
    }, (t, e) => e));
  }
  static transform(t, e) {
    return [t[0] * e[0] + t[2] * e[1], t[1] * e[0] + t[3] * e[1], t[0] * e[2] + t[2] * e[3], t[1] * e[2] + t[3] * e[3], t[0] * e[4] + t[2] * e[5] + t[4], t[1] * e[4] + t[3] * e[5] + t[5]];
  }
  static multiplyByDOMMatrix(t, e) {
    return [t[0] * e.a + t[2] * e.b, t[1] * e.a + t[3] * e.b, t[0] * e.c + t[2] * e.d, t[1] * e.c + t[3] * e.d, t[0] * e.e + t[2] * e.f + t[4], t[1] * e.e + t[3] * e.f + t[5]];
  }
  static applyTransform(t, e, s = 0) {
    const n = t[s], r = t[s + 1];
    t[s] = n * e[0] + r * e[2] + e[4], t[s + 1] = n * e[1] + r * e[3] + e[5];
  }
  static applyTransformToBezier(t, e, s = 0) {
    const n = e[0], r = e[1], a = e[2], o = e[3], l = e[4], h = e[5];
    for (let c = 0; c < 6; c += 2) {
      const d = t[s + c], f = t[s + c + 1];
      t[s + c] = d * n + f * a + l, t[s + c + 1] = d * r + f * o + h;
    }
  }
  static applyInverseTransform(t, e) {
    const s = t[0], n = t[1], r = e[0] * e[3] - e[1] * e[2];
    t[0] = (s * e[3] - n * e[2] + e[2] * e[5] - e[4] * e[3]) / r, t[1] = (-s * e[1] + n * e[0] + e[4] * e[1] - e[5] * e[0]) / r;
  }
  static axialAlignedBoundingBox(t, e, s) {
    const n = e[0], r = e[1], a = e[2], o = e[3], l = e[4], h = e[5], c = t[0], d = t[1], f = t[2], b = t[3];
    let y = n * c + l, A = y, w = n * f + l, v = w, S = o * d + h, E = S, C = o * b + h, x = C;
    if (r !== 0 || a !== 0) {
      const T = r * c, k = r * f, M = a * d, P = a * b;
      y += M, v += M, w += P, A += P, S += T, x += T, C += k, E += k;
    }
    s[0] = Math.min(s[0], y, w, Math.min(A, v)), s[1] = Math.min(s[1], S, C, Math.min(E, x)), s[2] = Math.max(s[2], y, w, Math.max(A, v)), s[3] = Math.max(s[3], S, C, Math.max(E, x));
  }
  static inverseTransform(t) {
    const e = t[0] * t[3] - t[1] * t[2];
    return [t[3] / e, -t[1] / e, -t[2] / e, t[0] / e, (t[2] * t[5] - t[4] * t[3]) / e, (t[4] * t[1] - t[5] * t[0]) / e];
  }
  static singularValueDecompose2dScale(t, e) {
    const s = t[0], n = t[1], r = t[2], a = t[3], o = s ** 2 + n ** 2, l = s * r + n * a, h = r ** 2 + a ** 2, c = (o + h) / 2, d = Math.sqrt(c ** 2 - (o * h - l ** 2));
    e[0] = Math.sqrt(c + d || 1), e[1] = Math.sqrt(c - d || 1);
  }
  static normalizeRect(t) {
    const e = t.slice(0);
    return t[0] > t[2] && (e[0] = t[2], e[2] = t[0]), t[1] > t[3] && (e[1] = t[3], e[3] = t[1]), e;
  }
  static intersect(t, e) {
    const s = Math.max(Math.min(t[0], t[2]), Math.min(e[0], e[2])), n = Math.min(Math.max(t[0], t[2]), Math.max(e[0], e[2]));
    if (s > n)
      return null;
    const r = Math.max(Math.min(t[1], t[3]), Math.min(e[1], e[3])), a = Math.min(Math.max(t[1], t[3]), Math.max(e[1], e[3]));
    return r > a ? null : [s, r, n, a];
  }
  static pointBoundingBox(t, e, s) {
    s[0] = Math.min(s[0], t), s[1] = Math.min(s[1], e), s[2] = Math.max(s[2], t), s[3] = Math.max(s[3], e);
  }
  static rectBoundingBox(t, e, s, n, r) {
    r[0] = Math.min(r[0], t, s), r[1] = Math.min(r[1], e, n), r[2] = Math.max(r[2], t, s), r[3] = Math.max(r[3], e, n);
  }
  static bezierBoundingBox(t, e, s, n, r, a, o, l, h) {
    h[0] = Math.min(h[0], t, o), h[1] = Math.min(h[1], e, l), h[2] = Math.max(h[2], t, o), h[3] = Math.max(h[3], e, l), m(this, Xn, Pg).call(this, t, s, r, o, e, n, a, l, 3 * (-t + 3 * (s - r) + o), 6 * (t - 2 * s + r), 3 * (s - t), h), m(this, Xn, Pg).call(this, t, s, r, o, e, n, a, l, 3 * (-e + 3 * (n - a) + l), 6 * (e - 2 * n + a), 3 * (n - e), h);
  }
}
Xn = new WeakSet(), yf = function(t, e, s, n, r, a, o, l, h, c) {
  if (h <= 0 || h >= 1)
    return;
  const d = 1 - h, f = h * h, b = f * h, y = d * (d * (d * t + 3 * h * e) + 3 * f * s) + b * n, A = d * (d * (d * r + 3 * h * a) + 3 * f * o) + b * l;
  c[0] = Math.min(c[0], y), c[1] = Math.min(c[1], A), c[2] = Math.max(c[2], y), c[3] = Math.max(c[3], A);
}, Pg = function(t, e, s, n, r, a, o, l, h, c, d, f) {
  if (Math.abs(h) < 1e-12) {
    Math.abs(c) >= 1e-12 && m(this, Xn, yf).call(this, t, e, s, n, r, a, o, l, -d / c, f);
    return;
  }
  const b = c ** 2 - 4 * d * h;
  if (b < 0)
    return;
  const y = Math.sqrt(b), A = 2 * h;
  m(this, Xn, yf).call(this, t, e, s, n, r, a, o, l, (-c + y) / A, f), m(this, Xn, yf).call(this, t, e, s, n, r, a, o, l, (-c - y) / A, f);
}, g(I, Xn);
function Cw(p) {
  return decodeURIComponent(escape(p));
}
let bg = null, ey = null;
function xw(p) {
  return bg || (bg = /([\u00a0\u00b5\u037e\u0eb3\u2000-\u200a\u202f\u2126\ufb00-\ufb04\ufb06\ufb20-\ufb36\ufb38-\ufb3c\ufb3e\ufb40\ufb41\ufb43\ufb44\ufb46-\ufba1\ufba4-\ufba9\ufbae-\ufbb1\ufbd3-\ufbdc\ufbde-\ufbe7\ufbea-\ufbf8\ufbfc\ufbfd\ufc00-\ufc5d\ufc64-\ufcf1\ufcf5-\ufd3d\ufd88\ufdf4\ufdfa\ufdfb\ufe71\ufe77\ufe79\ufe7b\ufe7d]+)|(\ufb05+)/gu, ey = /* @__PURE__ */ new Map([["ﬅ", "ſt"]])), p.replaceAll(bg, (t, e, s) => e ? e.normalize("NFKC") : ey.get(s));
}
function Ry() {
  if (typeof crypto.randomUUID == "function")
    return crypto.randomUUID();
  const p = new Uint8Array(32);
  return crypto.getRandomValues(p), Ew(p);
}
function Tw(p, t, e) {
  if (!Array.isArray(e) || e.length < 2)
    return !1;
  const [s, n, ...r] = e;
  if (!p(s) && !Number.isInteger(s) || !t(n))
    return !1;
  const a = r.length;
  let o = !0;
  switch (n.name) {
    case "XYZ":
      if (a < 2 || a > 3)
        return !1;
      break;
    case "Fit":
    case "FitB":
      return a === 0;
    case "FitH":
    case "FitBH":
    case "FitV":
    case "FitBV":
      if (a > 1)
        return !1;
      break;
    case "FitR":
      if (a !== 4)
        return !1;
      o = !1;
      break;
    default:
      return !1;
  }
  for (const l of r)
    if (!(typeof l == "number" || o && l === null))
      return !1;
  return !0;
}
const gc = () => [], op = () => /* @__PURE__ */ new Map(), Mg = () => /* @__PURE__ */ Object.create(null), _w = () => /* @__PURE__ */ new Set();
typeof Iterator.prototype.join != "function" && (Iterator.prototype.join = function(p) {
  return [...this].join(p);
});
function vt(p, t, e) {
  return Math.min(Math.max(p, t), e);
}
const ya = class ya {
};
_(ya, "CSS", 96), _(ya, "PDF", 72), _(ya, "PDF_TO_CSS_UNITS", ya.CSS / ya.PDF);
let la = ya;
class Lb extends hl {
  constructor(t, e = 0) {
    super(t, "RenderingCancelledException"), this.extraDelay = e;
  }
}
function mc(p) {
  if (p.startsWith("#")) {
    const e = p.slice(1);
    return [parseInt(e.slice(0, 2), 16), parseInt(e.slice(2, 4), 16), parseInt(e.slice(4, 6), 16), e.length >= 8 ? parseInt(e.slice(6, 8), 16) / 255 : 1];
  }
  if (p.startsWith("rgb(")) {
    const [e, s, n] = p.slice(4, -1).split(",").map((r) => parseInt(r, 10));
    return [e, s, n, 1];
  }
  if (p.startsWith("rgba(")) {
    const e = p.slice(5, -1).split(",");
    return [parseInt(e[0], 10), parseInt(e[1], 10), parseInt(e[2], 10), parseFloat(e[3])];
  }
  const t = p.match(/^color\(srgb\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)(?:\s*\/\s*([\d.]+|none))?\)$/);
  return t ? [Math.round(parseFloat(t[1]) * 255), Math.round(parseFloat(t[2]) * 255), Math.round(parseFloat(t[3]) * 255), t[4] !== void 0 && t[4] !== "none" ? parseFloat(t[4]) : 1] : null;
}
function nf(p) {
  const t = mc(p);
  return t ? t.slice(0, 3) : (j(`Not a valid color format: "${p}"`), [0, 0, 0]);
}
function wt(p) {
  const {
    a: t,
    b: e,
    c: s,
    d: n,
    e: r,
    f: a
  } = p.getTransform();
  return [t, e, s, n, r, a];
}
function Zi(p) {
  const {
    a: t,
    b: e,
    c: s,
    d: n,
    e: r,
    f: a
  } = p.getTransform().invertSelf();
  return [t, e, s, n, r, a];
}
class ws {
  constructor() {
    const {
      pixelRatio: t
    } = ws;
    this.sx = t, this.sy = t;
  }
  get scaled() {
    return this.sx !== 1 || this.sy !== 1;
  }
  get symmetric() {
    return this.sx === this.sy;
  }
  limitCanvas(t, e, s, n, r = -1) {
    let a = 1 / 0, o = 1 / 0, l = 1 / 0;
    s = ws.capPixels(s, r), s > 0 && (a = Math.sqrt(s / (t * e))), n !== -1 && (o = n / t, l = n / e);
    const h = Math.min(a, o, l);
    return this.sx > h || this.sy > h ? (this.sx = h, this.sy = h, !0) : !1;
  }
  static get pixelRatio() {
    return globalThis.devicePixelRatio || 1;
  }
  static capPixels(t, e) {
    if (e >= 0) {
      const s = Math.ceil(window.screen.availWidth * window.screen.availHeight * this.pixelRatio ** 2 * (1 + e / 100));
      return t > 0 ? Math.min(t, s) : s;
    }
    return t;
  }
}
function kw(p, t) {
  t = vt(t ?? 1, 0, 1);
  const e = 255 * (1 - t);
  return p.map((s) => Math.round(s * t + e));
}
function sy(p, t) {
  const e = p[0] / 255, s = p[1] / 255, n = p[2] / 255, r = Math.max(e, s, n), a = Math.min(e, s, n), o = (r + a) / 2;
  if (r === a)
    t[0] = t[1] = 0;
  else {
    const l = r - a;
    switch (t[1] = o < 0.5 ? l / (r + a) : l / (2 - r - a), r) {
      case e:
        t[0] = ((s - n) / l + (s < n ? 6 : 0)) * 60;
        break;
      case s:
        t[0] = ((n - e) / l + 2) * 60;
        break;
      case n:
        t[0] = ((e - s) / l + 4) * 60;
        break;
    }
  }
  t[2] = o;
}
function Dg(p, t) {
  const e = p[0], s = p[1], n = p[2], r = (1 - Math.abs(2 * n - 1)) * s, a = r * (1 - Math.abs(e / 60 % 2 - 1)), o = n - r / 2;
  switch (Math.floor(e / 60)) {
    case 0:
      t[0] = r + o, t[1] = a + o, t[2] = o;
      break;
    case 1:
      t[0] = a + o, t[1] = r + o, t[2] = o;
      break;
    case 2:
      t[0] = o, t[1] = r + o, t[2] = a + o;
      break;
    case 3:
      t[0] = o, t[1] = a + o, t[2] = r + o;
      break;
    case 4:
      t[0] = a + o, t[1] = o, t[2] = r + o;
      break;
    case 5:
    case 6:
      t[0] = r + o, t[1] = o, t[2] = a + o;
      break;
  }
}
function Ig(p) {
  return p <= 0.03928 ? p / 12.92 : ((p + 0.055) / 1.055) ** 2.4;
}
function iy(p, t, e) {
  Dg(p, e), e.map(Ig);
  const s = 0.2126 * e[0] + 0.7152 * e[1] + 0.0722 * e[2];
  Dg(t, e), e.map(Ig);
  const n = 0.2126 * e[0] + 0.7152 * e[1] + 0.0722 * e[2];
  return s > n ? (s + 0.05) / (n + 0.05) : (n + 0.05) / (s + 0.05);
}
const ny = /* @__PURE__ */ new Map();
function Pw(p, t) {
  const e = p[0] + p[1] * 256 + p[2] * 65536 + t[0] * 16777216 + t[1] * 4294967296 + t[2] * 1099511627776;
  let s = ny.get(e);
  if (s)
    return s;
  const n = new Float32Array(9), r = n.subarray(0, 3), a = n.subarray(3, 6);
  sy(p, a);
  const o = n.subarray(6, 9);
  sy(t, o);
  const l = o[2] < 0.5, h = l ? 12 : 4.5;
  if (a[2] = l ? Math.sqrt(a[2]) : 1 - Math.sqrt(1 - a[2]), iy(a, o, r) < h) {
    let c, d;
    l ? (c = a[2], d = 1) : (c = 0, d = a[2]);
    const f = 5e-3;
    for (; d - c > f; ) {
      const b = a[2] = (c + d) / 2;
      l === iy(a, o, r) < h ? c = b : d = b;
    }
    a[2] = l ? d : c;
  }
  return Dg(a, r), s = I.makeHexColor(Math.round(r[0] * 255), Math.round(r[1] * 255), Math.round(r[2] * 255)), ny.set(e, s), s;
}
function Ny(p) {
  const t = new Path2D();
  if (!p)
    return t;
  for (let e = 0, s = p.length; e < s; )
    switch (p[e++]) {
      case yc.moveTo:
        t.moveTo(p[e++], p[e++]);
        break;
      case yc.lineTo:
        t.lineTo(p[e++], p[e++]);
        break;
      case yc.curveTo:
        t.bezierCurveTo(p[e++], p[e++], p[e++], p[e++], p[e++], p[e++]);
        break;
      case yc.quadraticCurveTo:
        t.quadraticCurveTo(p[e++], p[e++], p[e++], p[e++]);
        break;
      case yc.closePath:
        t.closePath();
        break;
      default:
        j(`Unrecognized drawing path operator: ${p[e - 1]}`);
        break;
    }
  return t;
}
class rf {
  constructor({
    viewBox: t,
    userUnit: e,
    scale: s,
    rotation: n,
    offsetX: r = 0,
    offsetY: a = 0,
    dontFlip: o = !1
  }) {
    this.viewBox = t, this.userUnit = e, this.scale = s, this.rotation = n, this.offsetX = r, this.offsetY = a, s *= e;
    const l = (t[2] + t[0]) / 2, h = (t[3] + t[1]) / 2;
    let c, d, f, b;
    switch (n %= 360, n < 0 && (n += 360), n) {
      case 180:
        c = -1, d = 0, f = 0, b = 1;
        break;
      case 90:
        c = 0, d = 1, f = 1, b = 0;
        break;
      case 270:
        c = 0, d = -1, f = -1, b = 0;
        break;
      case 0:
        c = 1, d = 0, f = 0, b = -1;
        break;
      default:
        throw new Error("PageViewport: Invalid rotation, must be a multiple of 90 degrees.");
    }
    o && (f = -f, b = -b);
    let y, A, w, v;
    c === 0 ? (y = Math.abs(h - t[1]) * s + r, A = Math.abs(l - t[0]) * s + a, w = (t[3] - t[1]) * s, v = (t[2] - t[0]) * s) : (y = Math.abs(l - t[0]) * s + r, A = Math.abs(h - t[1]) * s + a, w = (t[2] - t[0]) * s, v = (t[3] - t[1]) * s), this.transform = [c * s, d * s, f * s, b * s, y - c * s * l - f * s * h, A - d * s * l - b * s * h], this.width = w, this.height = v;
  }
  get rawDims() {
    const t = this.viewBox;
    return L(this, "rawDims", {
      pageWidth: t[2] - t[0],
      pageHeight: t[3] - t[1],
      pageX: t[0],
      pageY: t[1]
    });
  }
  clone({
    scale: t = this.scale,
    rotation: e = this.rotation,
    offsetX: s = this.offsetX,
    offsetY: n = this.offsetY,
    dontFlip: r = !1
  } = {}) {
    return new rf({
      viewBox: this.viewBox.slice(),
      userUnit: this.userUnit,
      scale: t,
      rotation: e,
      offsetX: s,
      offsetY: n,
      dontFlip: r
    });
  }
  convertToViewportPoint(t, e) {
    const s = [t, e];
    return I.applyTransform(s, this.transform), s;
  }
  convertToPdfPoint(t, e) {
    const s = [t, e];
    return I.applyInverseTransform(s, this.transform), s;
  }
}
class qc {
  static textContent(t) {
    const e = [], s = {
      items: e,
      styles: /* @__PURE__ */ Object.create(null)
    };
    function n(r) {
      var l;
      if (!r)
        return;
      let a = null;
      const o = r.name;
      if (o === "#text")
        a = r.value;
      else if (qc.shouldBuildText(o))
        (l = r == null ? void 0 : r.attributes) != null && l.textContent ? a = r.attributes.textContent : r.value && (a = r.value);
      else return;
      if (a !== null && e.push({
        str: a
      }), !!r.children)
        for (const h of r.children)
          n(h);
    }
    return n(t), s;
  }
  static shouldBuildText(t) {
    return !(t === "textarea" || t === "input" || t === "option" || t === "select");
  }
}
const Mw = /url\(|image-set\(/i, Dw = /^on/i;
var sd, Fg;
class Ob {
  static get _allowedHtmlElements() {
    return L(this, "_allowedHtmlElements", /* @__PURE__ */ new Set(["a", "b", "br", "button", "div", "i", "img", "input", "label", "li", "ol", "option", "p", "select", "span", "sub", "sup", "textarea", "ul"]));
  }
  static get _allowedSvgElements() {
    return L(this, "_allowedSvgElements", /* @__PURE__ */ new Set(["ellipse", "line", "path", "rect", "svg"]));
  }
  static get _allowedRichTextElements() {
    return L(this, "_allowedRichTextElements", /* @__PURE__ */ new Set(["a", "b", "br", "div", "i", "li", "ol", "p", "span", "sub", "sup", "ul"]));
  }
  static get _allowedRichTextAttributes() {
    return L(this, "_allowedRichTextAttributes", /* @__PURE__ */ new Set(["class", "dir", "style"]));
  }
  static get _allowedRichTextStyles() {
    return L(this, "_allowedRichTextStyles", /* @__PURE__ */ new Set(["color", "font", "fontFamily", "fontSize", "fontStretch", "fontStyle", "fontWeight", "kerningMode", "letterSpacing", "lineHeight", "margin", "marginBottom", "marginLeft", "marginRight", "marginTop", "orphans", "paddingLeft", "paddingRight", "breakAfter", "breakBefore", "breakInside", "tabInterval", "tabStop", "textAlign", "textDecoration", "textIndent", "transform", "verticalAlign", "widows"]));
  }
  static setupStorage(t, e, s, n, r) {
    const a = n.getValue(e, {
      value: null
    });
    switch (s.name) {
      case "textarea":
        if (a.value !== null && (t.textContent = a.value), r === "print")
          break;
        t.addEventListener("input", (o) => {
          n.setValue(e, {
            value: o.target.value
          });
        });
        break;
      case "input":
        if (s.attributes.type === "radio" || s.attributes.type === "checkbox") {
          if (a.value === s.attributes.xfaOn ? t.setAttribute("checked", !0) : a.value === s.attributes.xfaOff && t.removeAttribute("checked"), r === "print")
            break;
          t.addEventListener("change", (o) => {
            n.setValue(e, {
              value: o.target.checked ? o.target.getAttribute("xfaOn") : o.target.getAttribute("xfaOff")
            });
          });
        } else {
          if (a.value !== null && t.setAttribute("value", a.value), r === "print")
            break;
          t.addEventListener("input", (o) => {
            n.setValue(e, {
              value: o.target.value
            });
          });
        }
        break;
      case "select":
        if (a.value !== null) {
          t.setAttribute("value", a.value);
          for (const o of s.children)
            o.attributes.value === a.value ? o.attributes.selected = !0 : Object.hasOwn(o.attributes, "selected") && delete o.attributes.selected;
        }
        t.addEventListener("input", (o) => {
          const l = o.target.options, h = l.selectedIndex === -1 ? "" : l[l.selectedIndex].value;
          n.setValue(e, {
            value: h
          });
        });
        break;
    }
  }
  static setAttributes({
    html: t,
    element: e,
    storage: s = null,
    intent: n,
    linkService: r
  }) {
    const {
      attributes: a
    } = e, o = t instanceof HTMLAnchorElement;
    a.type === "radio" && (a.name = `${a.name}-${n}`);
    for (const [l, h] of Object.entries(a))
      if (!(h == null || Dw.test(l)) && !(n === "richText" && !this._allowedRichTextAttributes.has(l)))
        switch (l) {
          case "class":
            h.length && t.setAttribute(l, h.join(" "));
            break;
          case "dataId":
            break;
          case "id":
            t.setAttribute("data-element-id", h);
            break;
          case "style":
            if (n === "richText") {
              const c = this._allowedRichTextStyles;
              for (const [d, f] of Object.entries(h))
                c.has(d) && !Mw.test(f) && (t.style[d] = f);
            } else
              Object.assign(t.style, h);
            break;
          case "textContent":
            t.textContent = h;
            break;
          default:
            (!o || l !== "href" && l !== "newWindow") && t.setAttribute(l, h);
        }
    o && (r == null || r.addLinkAttributes(t, a.href, a.newWindow)), s && a.dataId && this.setupStorage(t, a.dataId, e, s);
  }
  static render(t) {
    var d, f, b;
    const e = t.annotationStorage, s = t.linkService, n = t.xfaHtml, r = t.intent || "display", a = m(this, sd, Fg).call(this, n.name, (d = n.attributes) == null ? void 0 : d.xmlns, r) ?? document.createElement("div");
    n.attributes && this.setAttributes({
      html: a,
      element: n,
      intent: r,
      linkService: s
    });
    const o = r !== "richText", l = t.div;
    if (l.append(a), t.viewport) {
      const y = `matrix(${t.viewport.transform.join(",")})`;
      l.style.transform = y;
    }
    o && l.setAttribute("class", "xfaLayer xfaFont");
    const h = [];
    if (n.children.length === 0) {
      if (n.value) {
        const y = document.createTextNode(n.value);
        a.append(y), o && qc.shouldBuildText(n.name) && h.push(y);
      }
      return {
        textDivs: h
      };
    }
    const c = [[n, -1, a]];
    for (; c.length > 0; ) {
      const [y, A, w] = c.at(-1);
      if (A + 1 === y.children.length) {
        c.pop();
        continue;
      }
      const v = y.children[++c.at(-1)[1]];
      if (v === null)
        continue;
      const {
        name: S
      } = v;
      if (S === "#text") {
        const C = document.createTextNode(v.value);
        h.push(C), w.append(C);
        continue;
      }
      const E = m(this, sd, Fg).call(this, S, (f = v.attributes) == null ? void 0 : f.xmlns, r);
      if (E) {
        if (w.append(E), v.attributes && this.setAttributes({
          html: E,
          element: v,
          storage: e,
          intent: r,
          linkService: s
        }), ((b = v.children) == null ? void 0 : b.length) > 0)
          c.push([v, -1, E]);
        else if (v.value) {
          const C = document.createTextNode(v.value);
          o && qc.shouldBuildText(S) && h.push(C), E.append(C);
        }
      }
    }
    for (const y of l.querySelectorAll(".xfaNonInteractive input, .xfaNonInteractive textarea"))
      y.setAttribute("readOnly", !0);
    return {
      textDivs: h
    };
  }
  static update(t) {
    const e = `matrix(${t.viewport.transform.join(",")})`;
    t.div.style.transform = e, t.div.hidden = !1;
  }
  static getPageViewport(t, {
    scale: e = 1,
    rotation: s = 0
  }) {
    const {
      width: n,
      height: r
    } = t.attributes.style;
    return new rf({
      viewBox: [0, 0, parseInt(n, 10), parseInt(r, 10)],
      userUnit: 1,
      scale: e,
      rotation: s
    });
  }
}
sd = new WeakSet(), Fg = function(t, e, s) {
  return s === "richText" ? !e && this._allowedRichTextElements.has(t) ? document.createElement(t) : null : e ? e === Re && this._allowedSvgElements.has(t) ? document.createElementNS(Re, t) : null : this._allowedHtmlElements.has(t) ? document.createElement(t) : null;
}, g(Ob, sd);
async function Rb(p, t = "text") {
  if (jc(p, document.baseURI)) {
    const e = await fetch(p);
    if (!e.ok)
      throw new Error(e.statusText);
    switch (t) {
      case "blob":
        return e.blob();
      case "bytes":
        return e.bytes();
      case "json":
        return e.json();
    }
    return e.text();
  }
  return new Promise((e, s) => {
    const n = new XMLHttpRequest();
    n.open("GET", p, !0), n.responseType = t === "bytes" ? "arraybuffer" : t, n.onreadystatechange = () => {
      if (n.readyState === XMLHttpRequest.DONE) {
        if (n.status === 200 || n.status === 0) {
          switch (t) {
            case "bytes":
              e(new Uint8Array(n.response));
              return;
            case "blob":
            case "json":
              e(n.response);
              return;
          }
          e(n.responseText);
          return;
        }
        s(new Error(n.statusText));
      }
    }, n.send(null);
  });
}
function rg(p) {
  const t = p.length;
  let e = 0;
  for (; e < t && p[e].trim() === ""; )
    e++;
  return p.substring(e, e + 5).toLowerCase() === "data:";
}
function Nb(p) {
  return typeof p == "string" && /\.pdf$/i.test(p);
}
function Iw(p) {
  return [p] = p.split(/[#?]/, 1), Tg(p);
}
function Fw(p, t = "document.pdf") {
  if (typeof p != "string")
    return t;
  if (rg(p))
    return j('getPdfFilenameFromUrl: ignore "data:"-URL for performance reasons.'), t;
  const s = ((o) => {
    try {
      return new URL(o);
    } catch {
    }
    try {
      return new URL(decodeURIComponent(o));
    } catch {
    }
    try {
      return new URL(o, "https://foo.bar");
    } catch {
    }
    try {
      return new URL(decodeURIComponent(o), "https://foo.bar");
    } catch {
    }
    return null;
  })(p);
  if (!s)
    return t;
  const n = (o) => {
    try {
      let l = decodeURIComponent(o);
      return l.includes("/") && (l = Tg(l), l.length === 4 && r.test(l)) ? o : l;
    } catch {
      return o;
    }
  }, r = /\.pdf$/i, a = Tg(s.pathname);
  if (r.test(a))
    return n(a);
  if (s.searchParams.size > 0) {
    const o = (h) => [...h].findLast((c) => r.test(c)), l = o(s.searchParams.values()) ?? o(s.searchParams.keys());
    if (l)
      return n(l);
  }
  if (s.hash) {
    const {
      hash: o
    } = s;
    let l = -1;
    for (const {
      index: h
    } of o.matchAll(/\.pdf\b/gi))
      l = h;
    if (l > 0) {
      let h = l;
      for (; h > 0 && !"/?#=".includes(o[h - 1]); )
        h--;
      if (h < l)
        return n(o.slice(h, l + 4));
    }
  }
  return t;
}
function jc(p, t) {
  const e = t ? URL.parse(p, t) : URL.parse(p);
  return /https?:/.test((e == null ? void 0 : e.protocol) ?? "");
}
function di(p) {
  p.preventDefault();
}
function te(p) {
  p.preventDefault(), p.stopPropagation();
}
var id;
class lp {
  static toDateObject(t) {
    if (t instanceof Date)
      return t;
    if (!t || typeof t != "string")
      return null;
    i(this, id) || u(this, id, new RegExp("^D:(\\d{4})(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?([Z|+\\-])?(\\d{2})?'?(\\d{2})?'?"));
    const e = i(this, id).exec(t);
    if (!e)
      return null;
    const s = parseInt(e[1], 10);
    let n = parseInt(e[2], 10);
    n = n >= 1 && n <= 12 ? n - 1 : 0;
    let r = parseInt(e[3], 10);
    r = r >= 1 && r <= 31 ? r : 1;
    let a = parseInt(e[4], 10);
    a = a >= 0 && a <= 23 ? a : 0;
    let o = parseInt(e[5], 10);
    o = o >= 0 && o <= 59 ? o : 0;
    let l = parseInt(e[6], 10);
    l = l >= 0 && l <= 59 ? l : 0;
    const h = e[7] || "Z";
    let c = parseInt(e[8], 10);
    c = c >= 0 && c <= 23 ? c : 0;
    let d = parseInt(e[9], 10) || 0;
    return d = d >= 0 && d <= 59 ? d : 0, h === "-" ? (a += c, o += d) : h === "+" && (a -= c, o -= d), new Date(Date.UTC(s, n, r, a, o, l));
  }
}
id = new WeakMap(), g(lp, id);
function Lw(p) {
  const t = document.createElement("span");
  t.style.visibility = "hidden", t.style.colorScheme = "only light", document.body.append(t);
  for (const e of p.keys()) {
    t.style.color = e;
    const s = window.getComputedStyle(t).color;
    p.set(e, nf(s));
  }
  t.remove();
}
function nl(p, t, e = !1, s = !0) {
  if (t instanceof rf) {
    const {
      pageWidth: n,
      pageHeight: r
    } = t.rawDims, {
      style: a
    } = p, o = `round(down, var(--total-scale-factor) * ${n}px, var(--scale-round-x))`, l = `round(down, var(--total-scale-factor) * ${r}px, var(--scale-round-y))`;
    !e || t.rotation % 180 === 0 ? (a.width = o, a.height = l) : (a.width = l, a.height = o);
  }
  s && p.setAttribute("data-main-rotation", t.rotation);
}
const Lg = /* @__PURE__ */ new Set(["image/apng", "image/avif", "image/bmp", "image/gif", "image/jpeg", "image/png", "image/svg+xml", "image/webp", "image/x-icon"]);
class Ow {
  static get isDarkMode() {
    var t;
    return L(this, "isDarkMode", !!((t = window == null ? void 0 : window.matchMedia) != null && t.call(window, "(prefers-color-scheme: dark)").matches));
  }
}
class Rw {
  static get commentForegroundColor() {
    const t = document.createElement("span");
    t.classList.add("comment", "sidebar");
    const {
      style: e
    } = t;
    e.width = e.height = "0", e.display = "none", e.color = "var(--comment-fg-color)", document.body.append(t);
    const {
      color: s
    } = window.getComputedStyle(t);
    return t.remove(), L(this, "commentForegroundColor", nf(s));
  }
}
function By({
  html: p,
  dir: t,
  className: e
}, s) {
  const n = document.createDocumentFragment();
  if (typeof p == "string") {
    const r = document.createElement("p");
    r.dir = t || "auto";
    const a = p.split(/\r\n?|\n/);
    for (let o = 0, l = a.length; o < l; ++o) {
      const h = a[o];
      r.append(document.createTextNode(h)), o < l - 1 && r.append(document.createElement("br"));
    }
    n.append(r);
  } else
    Ob.render({
      xfaHtml: p,
      div: n,
      intent: "richText"
    });
  n.firstElementChild.classList.add("richText", e), s.append(n);
}
var er, sr, ks, Ps, nd, ir, wl, vl, rd, mp, Hy, me, Uy, zy, pl, vc;
const sn = class sn {
  constructor(t) {
    g(this, me);
    g(this, er, null);
    g(this, sr, null);
    g(this, ks);
    g(this, Ps, null);
    g(this, nd, null);
    g(this, ir, null);
    g(this, wl, null);
    g(this, vl, null);
    u(this, ks, t), i(sn, rd) || u(sn, rd, Object.freeze({
      freetext: "pdfjs-editor-remove-freetext-button",
      highlight: "pdfjs-editor-remove-highlight-button",
      ink: "pdfjs-editor-remove-ink-button",
      stamp: "pdfjs-editor-remove-stamp-button",
      signature: "pdfjs-editor-remove-signature-button"
    }));
  }
  render() {
    const t = u(this, er, document.createElement("div"));
    t.classList.add("editToolbar", "hidden"), t.setAttribute("role", "toolbar");
    const e = i(this, ks)._uiManager._signal;
    e instanceof AbortSignal && !e.aborted && (t.addEventListener("contextmenu", di, {
      signal: e
    }), t.addEventListener("pointerdown", m(sn, mp, Hy), {
      signal: e
    }));
    const s = u(this, Ps, document.createElement("div"));
    s.className = "buttons", t.append(s);
    const n = i(this, ks).toolbarPosition;
    if (n) {
      const {
        style: r
      } = t, a = i(this, ks)._uiManager.direction === "ltr" ? 1 - n[0] : n[0];
      r.insetInlineEnd = `${100 * a}%`, r.top = `calc(${100 * n[1]}% + var(--editor-toolbar-vert-offset))`;
    }
    return t;
  }
  get div() {
    return i(this, er);
  }
  hide() {
    var t;
    i(this, er).classList.add("hidden"), (t = i(this, sr)) == null || t.hideDropdown();
  }
  show() {
    var t, e;
    i(this, er).classList.remove("hidden"), (t = i(this, nd)) == null || t.shown(), (e = i(this, ir)) == null || e.shown();
  }
  addDeleteButton() {
    const {
      editorType: t,
      _uiManager: e
    } = i(this, ks), s = document.createElement("button");
    s.classList.add("basic", "deleteButton"), s.tabIndex = 0, s.setAttribute("data-l10n-id", i(sn, rd)[t]), m(this, me, pl).call(this, s) && s.addEventListener("click", (n) => {
      e.delete();
    }, {
      signal: e._signal
    }), i(this, Ps).append(s);
  }
  async addAltText(t) {
    const e = await t.render();
    m(this, me, pl).call(this, e), i(this, Ps).append(e, i(this, me, vc)), u(this, nd, t);
  }
  addComment(t, e = null) {
    if (i(this, ir))
      return;
    const s = t.renderForToolbar();
    if (!s)
      return;
    m(this, me, pl).call(this, s);
    const n = u(this, wl, i(this, me, vc));
    e ? (i(this, Ps).insertBefore(s, e), i(this, Ps).insertBefore(n, e)) : i(this, Ps).append(s, n), u(this, ir, t), t.toolbar = this;
  }
  addColorPicker(t) {
    if (i(this, sr))
      return;
    u(this, sr, t);
    const e = t.renderButton();
    m(this, me, pl).call(this, e), i(this, Ps).append(e, i(this, me, vc));
  }
  async addEditSignatureButton(t) {
    const e = u(this, vl, await t.renderEditButton(i(this, ks)));
    e && (m(this, me, pl).call(this, e), i(this, Ps).append(e, i(this, me, vc)));
  }
  removeButton(t) {
    var e, s;
    switch (t) {
      case "comment":
        (e = i(this, ir)) == null || e.removeToolbarCommentButton(), u(this, ir, null), (s = i(this, wl)) == null || s.remove(), u(this, wl, null);
        break;
    }
  }
  async addButton(t, e) {
    switch (t) {
      case "colorPicker":
        e && this.addColorPicker(e);
        break;
      case "altText":
        e && await this.addAltText(e);
        break;
      case "editSignature":
        e && await this.addEditSignatureButton(e);
        break;
      case "delete":
        this.addDeleteButton();
        break;
      case "comment":
        e && this.addComment(e);
        break;
    }
  }
  async addButtonBefore(t, e, s) {
    if (!e && t === "comment")
      return;
    const n = i(this, Ps).querySelector(s);
    n && t === "comment" && this.addComment(e, n);
  }
  updateEditSignatureButton(t) {
    i(this, vl) && (i(this, vl).title = t);
  }
  remove() {
    var t;
    i(this, er).remove(), (t = i(this, sr)) == null || t.destroy(), u(this, sr, null);
  }
};
er = new WeakMap(), sr = new WeakMap(), ks = new WeakMap(), Ps = new WeakMap(), nd = new WeakMap(), ir = new WeakMap(), wl = new WeakMap(), vl = new WeakMap(), rd = new WeakMap(), mp = new WeakSet(), Hy = function(t) {
  t.stopPropagation();
}, me = new WeakSet(), Uy = function(t) {
  i(this, ks)._focusEventsAllowed = !1, te(t);
}, zy = function(t) {
  i(this, ks)._focusEventsAllowed = !0, te(t);
}, pl = function(t) {
  const e = i(this, ks)._uiManager._signal;
  return !(e instanceof AbortSignal) || e.aborted ? !1 : (t.addEventListener("focusin", m(this, me, Uy).bind(this), {
    capture: !0,
    signal: e
  }), t.addEventListener("focusout", m(this, me, zy).bind(this), {
    capture: !0,
    signal: e
  }), t.addEventListener("contextmenu", di, {
    signal: e
  }), !0);
}, vc = function() {
  const t = document.createElement("div");
  return t.className = "divider", t;
}, g(sn, mp), g(sn, rd, null);
let Og = sn;
var ad, Sa, yi, Kn, Gy, $y, Rg;
class Nw {
  constructor(t) {
    g(this, Kn);
    g(this, ad, null);
    g(this, Sa, null);
    g(this, yi);
    u(this, yi, t);
  }
  show(t, e, s) {
    const [n, r] = m(this, Kn, $y).call(this, e, s), {
      style: a
    } = i(this, Sa) || u(this, Sa, m(this, Kn, Gy).call(this));
    t.append(i(this, Sa)), a.insetInlineEnd = `${100 * n}%`, a.top = `calc(${100 * r}% + var(--editor-toolbar-vert-offset))`;
  }
  hide() {
    i(this, Sa).remove();
  }
}
ad = new WeakMap(), Sa = new WeakMap(), yi = new WeakMap(), Kn = new WeakSet(), Gy = function() {
  const t = u(this, Sa, document.createElement("div"));
  t.className = "editToolbar", t.setAttribute("role", "toolbar"), t.dir = i(this, yi).direction;
  const e = i(this, yi)._signal;
  e instanceof AbortSignal && !e.aborted && t.addEventListener("contextmenu", di, {
    signal: e
  });
  const s = u(this, ad, document.createElement("div"));
  return s.className = "buttons", t.append(s), i(this, yi).hasCommentManager() && m(this, Kn, Rg).call(this, "commentButton", "pdfjs-comment-floating-button", "pdfjs-comment-floating-button-label", () => {
    i(this, yi).commentSelection("floating_button");
  }), m(this, Kn, Rg).call(this, "highlightButton", "pdfjs-highlight-floating-button1", "pdfjs-highlight-floating-button-label", () => {
    i(this, yi).highlightSelection("floating_button");
  }), t;
}, $y = function(t, e) {
  let s = 0, n = 0;
  for (const r of t) {
    const a = r.y + r.height;
    if (a < s)
      continue;
    const o = r.x + (e ? r.width : 0);
    if (a > s) {
      n = o, s = a;
      continue;
    }
    e ? o > n && (n = o) : o < n && (n = o);
  }
  return [e ? 1 - n : n, s];
}, Rg = function(t, e, s, n) {
  const r = document.createElement("button");
  r.classList.add("basic", t), r.tabIndex = 0, r.setAttribute("data-l10n-id", e);
  const a = document.createElement("span");
  r.append(a), a.className = "visuallyHidden", a.setAttribute("data-l10n-id", s);
  const o = i(this, yi)._signal;
  o instanceof AbortSignal && !o.aborted && (r.addEventListener("contextmenu", di, {
    signal: o
  }), r.addEventListener("click", n, {
    signal: o
  })), i(this, ad).append(r);
};
const Bw = "0a475cb6-573c-46ed-869d-fa7c5839d995", yg = Object.freeze({
  internal: Bw
});
function jy(p, t, e) {
  for (const s of e)
    t.addEventListener(s, p[s].bind(p));
}
var Ea, Ca, Sl, xa;
const ut = class ut {
  static initializeAndAddPointerId(t) {
    (i(ut, Ca) || u(ut, Ca, /* @__PURE__ */ new Set())).add(t);
  }
  static setPointer(t, e) {
    i(ut, Ea) || u(ut, Ea, e), i(ut, xa) ?? u(ut, xa, t);
  }
  static setTimeStamp(t) {
    u(ut, Sl, t);
  }
  static isSamePointerId(t) {
    return i(ut, Ea) === t;
  }
  static isSamePointerIdOrRemove(t) {
    var e;
    return i(ut, Ea) === t ? !0 : ((e = i(ut, Ca)) == null || e.delete(t), !1);
  }
  static isSamePointerType(t) {
    return i(ut, xa) === t;
  }
  static isInitializedAndDifferentPointerType(t) {
    return i(ut, xa) !== null && !ut.isSamePointerType(t);
  }
  static isSameTimeStamp(t) {
    return i(ut, Sl) === t;
  }
  static isUsingMultiplePointers() {
    var t;
    return ((t = i(ut, Ca)) == null ? void 0 : t.size) >= 1;
  }
  static clearPointerType() {
    u(ut, xa, null);
  }
  static clearPointerIds() {
    u(ut, Ea, NaN), u(ut, Ca, null);
  }
  static clearTimeStamp() {
    u(ut, Sl, NaN);
  }
};
Ea = new WeakMap(), Ca = new WeakMap(), Sl = new WeakMap(), xa = new WeakMap(), g(ut, Ea, NaN), g(ut, Ca, null), g(ut, Sl, NaN), g(ut, xa, null);
let Ae = ut;
var bp;
class Hw {
  constructor() {
    g(this, bp, 0);
  }
  get id() {
    return `${dc}${rt(this, bp)._++}`;
  }
}
bp = new WeakMap();
var El, od, we, Cl, Af;
const Kb = class Kb {
  constructor() {
    g(this, Cl);
    g(this, El, Ry());
    g(this, od, 0);
    g(this, we, null);
  }
  static get _isSVGFittingCanvas() {
    const t = `data:image/svg+xml;charset=UTF-8,<svg viewBox="0 0 1 1" width="1" height="1" xmlns="${Re}"><rect width="1" height="1" style="fill:red;"/></svg>`, s = new OffscreenCanvas(1, 3).getContext("2d", {
      willReadFrequently: !0
    }), n = new Image();
    n.src = t;
    const r = n.decode().then(() => (s.drawImage(n, 0, 0, 1, 1, 0, 0, 1, 3), new Uint32Array(s.getImageData(0, 0, 1, 1).data.buffer)[0] === 0));
    return L(this, "_isSVGFittingCanvas", r);
  }
  async getFromFile(t) {
    const {
      lastModified: e,
      name: s,
      size: n,
      type: r
    } = t;
    return m(this, Cl, Af).call(this, `${e}_${s}_${n}_${r}`, t);
  }
  async getFromUrl(t) {
    return m(this, Cl, Af).call(this, t, t);
  }
  async getFromBlob(t, e) {
    const s = await e;
    return m(this, Cl, Af).call(this, t, s);
  }
  async getFromId(t) {
    i(this, we) || u(this, we, /* @__PURE__ */ new Map());
    const e = i(this, we).get(t);
    if (!e)
      return null;
    if (e.bitmap)
      return e.refCounter += 1, e;
    if (e.file)
      return this.getFromFile(e.file);
    if (e.blobPromise) {
      const {
        blobPromise: s
      } = e;
      return delete e.blobPromise, this.getFromBlob(e.id, s);
    }
    return this.getFromUrl(e.url);
  }
  getFromCanvas(t, e) {
    i(this, we) || u(this, we, /* @__PURE__ */ new Map());
    let s = i(this, we).get(t);
    if (s != null && s.bitmap)
      return s.refCounter += 1, s;
    const n = new OffscreenCanvas(e.width, e.height);
    return n.getContext("2d").drawImage(e, 0, 0), s = {
      bitmap: n.transferToImageBitmap(),
      id: `image_${i(this, El)}_${rt(this, od)._++}`,
      refCounter: 1,
      isSvg: !1
    }, i(this, we).set(t, s), i(this, we).set(s.id, s), s;
  }
  getSvgUrl(t) {
    const e = i(this, we).get(t);
    return e != null && e.isSvg ? e.svgUrl : null;
  }
  deleteId(t) {
    var n;
    i(this, we) || u(this, we, /* @__PURE__ */ new Map());
    const e = i(this, we).get(t);
    if (!e || (e.refCounter -= 1, e.refCounter !== 0))
      return;
    const {
      bitmap: s
    } = e;
    if (!e.url && !e.file) {
      const r = new OffscreenCanvas(s.width, s.height);
      r.getContext("bitmaprenderer").transferFromImageBitmap(s), e.blobPromise = r.convertToBlob();
    }
    (n = s.close) == null || n.call(s), e.bitmap = null;
  }
  isValidId(t) {
    return t.startsWith(`image_${i(this, El)}_`);
  }
};
El = new WeakMap(), od = new WeakMap(), we = new WeakMap(), Cl = new WeakSet(), Af = async function(t, e) {
  i(this, we) || u(this, we, /* @__PURE__ */ new Map());
  let s = i(this, we).get(t);
  if (s === null)
    return null;
  if (s != null && s.bitmap)
    return s.refCounter += 1, s;
  try {
    s || (s = {
      bitmap: null,
      id: `image_${i(this, El)}_${rt(this, od)._++}`,
      refCounter: 0,
      isSvg: !1
    });
    let n;
    if (typeof e == "string" ? (s.url = e, n = await Rb(e, "blob")) : e instanceof File ? n = s.file = e : e instanceof Blob && (n = e), n.type === "image/svg+xml") {
      const r = Kb._isSVGFittingCanvas, a = new FileReader(), o = new Image(), l = new Promise((h, c) => {
        o.onload = () => {
          s.bitmap = o, s.isSvg = !0, h();
        }, a.onload = async () => {
          const d = s.svgUrl = a.result;
          o.src = await r ? `${d}#svgView(preserveAspectRatio(none))` : d;
        }, o.onerror = a.onerror = c;
      });
      a.readAsDataURL(n), await l;
    } else
      s.bitmap = await createImageBitmap(n);
    s.refCounter = 1;
  } catch (n) {
    j(n), s = null;
  }
  return i(this, we).set(t, s), s && i(this, we).set(s.id, s), s;
};
let Ng = Kb;
var $t, nr, ld, Ft;
class Uw {
  constructor(t = 128) {
    g(this, $t, []);
    g(this, nr, !1);
    g(this, ld);
    g(this, Ft, -1);
    u(this, ld, t);
  }
  add({
    cmd: t,
    undo: e,
    post: s,
    mustExec: n,
    type: r = NaN,
    overwriteIfSameType: a = !1,
    keepUndo: o = !1
  }) {
    if (n && t(), i(this, nr))
      return;
    const l = {
      cmd: t,
      undo: e,
      post: s,
      type: r
    };
    if (i(this, Ft) === -1) {
      i(this, $t).length > 0 && (i(this, $t).length = 0), u(this, Ft, 0), i(this, $t).push(l);
      return;
    }
    if (a && i(this, $t)[i(this, Ft)].type === r) {
      o && (l.undo = i(this, $t)[i(this, Ft)].undo), i(this, $t)[i(this, Ft)] = l;
      return;
    }
    const h = i(this, Ft) + 1;
    h === i(this, ld) ? i(this, $t).splice(0, 1) : (u(this, Ft, h), h < i(this, $t).length && i(this, $t).splice(h)), i(this, $t).push(l);
  }
  undo() {
    if (i(this, Ft) === -1)
      return;
    u(this, nr, !0);
    const {
      undo: t,
      post: e
    } = i(this, $t)[i(this, Ft)];
    t(), e == null || e(), u(this, nr, !1), u(this, Ft, i(this, Ft) - 1);
  }
  redo() {
    if (i(this, Ft) < i(this, $t).length - 1) {
      u(this, Ft, i(this, Ft) + 1), u(this, nr, !0);
      const {
        cmd: t,
        post: e
      } = i(this, $t)[i(this, Ft)];
      t(), e == null || e(), u(this, nr, !1);
    }
  }
  hasSomethingToUndo() {
    return i(this, Ft) !== -1;
  }
  hasSomethingToRedo() {
    return i(this, Ft) < i(this, $t).length - 1;
  }
  cleanType(t) {
    if (i(this, Ft) !== -1) {
      for (let e = i(this, Ft); e >= 0; e--)
        if (i(this, $t)[e].type !== t) {
          i(this, $t).splice(e + 1, i(this, Ft) - e), u(this, Ft, e);
          return;
        }
      i(this, $t).length = 0, u(this, Ft, -1);
    }
  }
  destroy() {
    u(this, $t, null);
  }
}
$t = new WeakMap(), nr = new WeakMap(), ld = new WeakMap(), Ft = new WeakMap();
var uc, Vy, Wy;
const ze = class ze {
  constructor(t) {
    var s;
    this.callbacks = /* @__PURE__ */ new Map();
    const {
      isMac: e
    } = ot.platform;
    for (const [n, r, a = {}] of t) {
      const o = n.some((l) => l.startsWith("mac+"));
      for (const l of n) {
        let h = l;
        if (o) {
          const f = l.startsWith("mac+");
          if (e !== f)
            continue;
          f && (h = l.slice(4));
        }
        const [c, d] = m(s = ze, uc, Vy).call(s, h);
        c !== null && this.callbacks.getOrInsertComputed(c, gc).push({
          callback: r,
          options: a,
          modifiers: d
        });
      }
    }
  }
  exec(t, e) {
    var c;
    let s = this.callbacks.get(e.key);
    if (!s) {
      if (/^[a-z]$/i.test(e.key))
        return;
      const d = m(c = ze, uc, Wy).call(c, e.code);
      if (d === null || d === e.key || (s = this.callbacks.get(d), !s))
        return;
    }
    const n = (e.altKey ? ze.ALT : 0) | (e.ctrlKey ? ze.CTRL : 0) | (e.metaKey ? ze.META : 0) | (e.shiftKey ? ze.SHIFT : 0), r = s.find((d) => d.modifiers === n);
    if (!r)
      return;
    const {
      callback: a,
      options: {
        bubbles: o = !1,
        args: l = [],
        checker: h = null
      }
    } = r;
    h && !h(t, e) || (a.bind(t, ...l, e)(), o || te(e));
  }
};
uc = new WeakSet(), Vy = function(t) {
  let e = null, s = 0;
  for (let n of t.split("+")) {
    if (n = n.trim(), !n)
      continue;
    const r = n.toUpperCase(), a = ze[r];
    if (a) {
      s |= a;
      continue;
    }
    if (e !== null) {
      j(`KeyboardManager: multiple keys in shortcut "${t}"`);
      break;
    }
    e = r === "SPACE" ? " " : n;
  }
  return e === null && j(`KeyboardManager: no key found in shortcut "${t}"`), [e, s];
}, Wy = function(t) {
  var s;
  const e = /^(?:Key([A-Z])|(?:Digit|Numpad)(\d))$/.exec(t);
  return e ? ((s = e[1]) == null ? void 0 : s.toLowerCase()) ?? e[2] : null;
}, g(ze, uc), _(ze, "ALT", 1), _(ze, "CTRL", 2), _(ze, "META", 4), _(ze, "SHIFT", 8);
let rl = ze;
const yp = class yp {
  get _colors() {
    const t = /* @__PURE__ */ new Map([["CanvasText", null], ["Canvas", null]]);
    return Lw(t), L(this, "_colors", t);
  }
  convert(t) {
    const e = nf(t);
    if (!window.matchMedia("(forced-colors: active)").matches)
      return e;
    for (const [s, n] of this._colors)
      if (n.every((r, a) => r === e[a]))
        return yp._colorsMapping.get(s);
    return e;
  }
  getHexCode(t) {
    const e = this._colors.get(t);
    return e ? I.makeHexColor(...e) : t;
  }
};
_(yp, "_colorsMapping", /* @__PURE__ */ new Map([["CanvasText", [0, 0, 0]], ["Canvas", [255, 255, 255]]]));
let Bg = yp;
var xl, Ze, Tl, _t, Lt, _l, kl, Pl, ve, Ml, $e, ne, rr, ar, or, lr, Ai, Ms, Ta, hd, cd, Dl, dd, wi, hr, Il, cr, vi, Ap, on, Fl, ud, dr, _a, Ll, ur, fd, Xt, ft, ln, fr, pr, pd, Ol, gd, gr, Si, hn, md, bd, Ds, R, wf, Hg, Xy, Yy, Sc, Ky, qy, Qy, Ug, Jy, Zy, tA, eA, Pe, tn, sA, iA, zg, nA, Ec, Gg;
const bl = class bl {
  constructor(t, e, s, n, r, a, o, l, h, c, d, f, b, y, A, w, v) {
    g(this, R);
    g(this, xl, new AbortController());
    g(this, Ze, null);
    g(this, Tl, null);
    g(this, _t, /* @__PURE__ */ new Map());
    g(this, Lt, /* @__PURE__ */ new Map());
    g(this, _l, null);
    g(this, kl, null);
    g(this, Pl, null);
    g(this, ve, null);
    g(this, Ml, null);
    g(this, $e, new Uw());
    g(this, ne, null);
    g(this, rr, null);
    g(this, ar, null);
    g(this, or, 0);
    g(this, lr, /* @__PURE__ */ new Set());
    g(this, Ai, null);
    g(this, Ms, null);
    g(this, Ta, /* @__PURE__ */ new Set());
    _(this, "_editorUndoBar", null);
    g(this, hd, !1);
    g(this, cd, !1);
    g(this, Dl, !1);
    g(this, dd, null);
    g(this, wi, null);
    g(this, hr, null);
    g(this, Il, null);
    g(this, cr, !1);
    g(this, vi, null);
    g(this, Ap, new Hw());
    g(this, on, !1);
    g(this, Fl, !1);
    g(this, ud, !1);
    g(this, dr, null);
    g(this, _a, null);
    g(this, Ll, null);
    g(this, ur, null);
    g(this, fd, null);
    g(this, Xt, X.NONE);
    g(this, ft, /* @__PURE__ */ new Set());
    g(this, ln, null);
    g(this, fr, null);
    g(this, pr, null);
    g(this, pd, null);
    g(this, Ol, null);
    g(this, gd, {
      isEditing: !1,
      isEmpty: !0,
      hasSomethingToUndo: !1,
      hasSomethingToRedo: !1,
      hasSelectedEditor: !1,
      hasSelectedText: !1
    });
    g(this, gr, [0, 0]);
    g(this, Si, null);
    g(this, hn, null);
    g(this, md, null);
    g(this, bd, null);
    g(this, Ds, null);
    const S = this._signal = i(this, xl).signal;
    u(this, hn, t), u(this, md, e), u(this, bd, s), u(this, Pl, n), u(this, ne, r), u(this, fr, a), u(this, Ol, l), this._eventBus = o;
    const E = {
      signal: S,
      ...yg
    };
    o.on("editingaction", this.onEditingAction.bind(this), E), o.on("pagechanging", this.onPageChanging.bind(this), E), o.on("scalechanging", this.onScaleChanging.bind(this), E), o.on("rotationchanging", this.onRotationChanging.bind(this), E), o.on("setpreference", this.onSetPreference.bind(this), E), o.on("switchannotationeditorparams", (C) => this.updateParams(C.type, C.value), E), window.addEventListener("pointerdown", () => {
      u(this, Fl, !0);
    }, {
      capture: !0,
      signal: S
    }), window.addEventListener("pointerup", () => {
      u(this, Fl, !1);
    }, {
      capture: !0,
      signal: S
    }), window.addEventListener("beforeunload", this.endCurrentEditing.bind(this), {
      capture: !0,
      signal: S
    }), m(this, R, Ky).call(this), m(this, R, eA).call(this), m(this, R, Ug).call(this), u(this, ve, l.annotationStorage), u(this, dd, l.filterFactory), u(this, pr, h), u(this, Il, c || null), u(this, hd, d), u(this, cd, f), u(this, Dl, b), u(this, fd, y || null), this.viewParameters = {
      realScale: la.PDF_TO_CSS_UNITS,
      rotation: 0
    }, this.isShiftKeyDown = !1, this._editorUndoBar = A || null, this._supportsPinchToZoom = w !== !1, this._keepToolbarInPage = v === !0, r == null || r.setSidebarUiManager(this);
  }
  static get _keyboardManager() {
    const t = bl.prototype, e = (a) => i(a, hn).contains(document.activeElement) && document.activeElement.tagName !== "BUTTON" && a.hasSomethingToControl(), s = (a, {
      target: o
    }) => {
      if (o instanceof HTMLInputElement) {
        const {
          type: l
        } = o;
        return l !== "text" && l !== "number";
      }
      return !0;
    }, n = this.TRANSLATE_SMALL, r = this.TRANSLATE_BIG;
    return L(this, "_keyboardManager", new rl([[["ctrl+a", "mac+meta+a"], t.selectAll, {
      checker: s
    }], [["ctrl+z", "mac+meta+z"], t.undo, {
      checker: s
    }], [["ctrl+y", "ctrl+shift+z", "mac+meta+shift+z", "ctrl+shift+Z", "mac+meta+shift+Z"], t.redo, {
      checker: s
    }], [["Backspace", "alt+Backspace", "ctrl+Backspace", "shift+Backspace", "mac+Backspace", "mac+alt+Backspace", "mac+ctrl+Backspace", "Delete", "ctrl+Delete", "shift+Delete", "mac+Delete"], t.delete, {
      checker: s
    }], [["Enter"], t.addNewEditorFromKeyboard, {
      checker: (a, {
        target: o
      }) => !(o instanceof HTMLButtonElement) && i(a, hn).contains(o) && !a.isEnterHandled
    }], [["Space"], t.addNewEditorFromKeyboard, {
      checker: (a, {
        target: o
      }) => !(o instanceof HTMLButtonElement) && i(a, hn).contains(document.activeElement)
    }], [["Escape"], t.unselectAll], [["ArrowLeft"], t.translateSelectedEditors, {
      args: [-n, 0],
      checker: e
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t.translateSelectedEditors, {
      args: [-r, 0],
      checker: e
    }], [["ArrowRight"], t.translateSelectedEditors, {
      args: [n, 0],
      checker: e
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t.translateSelectedEditors, {
      args: [r, 0],
      checker: e
    }], [["ArrowUp"], t.translateSelectedEditors, {
      args: [0, -n],
      checker: e
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t.translateSelectedEditors, {
      args: [0, -r],
      checker: e
    }], [["ArrowDown"], t.translateSelectedEditors, {
      args: [0, n],
      checker: e
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t.translateSelectedEditors, {
      args: [0, r],
      checker: e
    }]]));
  }
  destroy() {
    var t, e, s, n, r, a, o, l, h;
    (t = i(this, Ds)) == null || t.resolve(), u(this, Ds, null), (e = i(this, xl)) == null || e.abort(), u(this, xl, null), this._signal = null;
    for (const c of i(this, Lt).values())
      c.destroy();
    i(this, Lt).clear(), i(this, _t).clear(), i(this, Ta).clear(), (s = i(this, ur)) == null || s.clear(), u(this, Ze, null), i(this, ft).clear(), i(this, $e).destroy(), (n = i(this, Pl)) == null || n.destroy(), (r = i(this, ne)) == null || r.destroy(), (a = i(this, fr)) == null || a.destroy(), (o = i(this, vi)) == null || o.hide(), u(this, vi, null), (l = i(this, Ll)) == null || l.destroy(), u(this, Ll, null), u(this, Tl, null), i(this, wi) && (clearTimeout(i(this, wi)), u(this, wi, null)), i(this, Si) && (clearTimeout(i(this, Si)), u(this, Si, null)), (h = this._editorUndoBar) == null || h.destroy(), u(this, Ol, null);
  }
  combinedSignal(t) {
    return AbortSignal.any([this._signal, t.signal]);
  }
  get mlManager() {
    return i(this, fd);
  }
  get useNewAltTextFlow() {
    return i(this, cd);
  }
  get useNewAltTextWhenAddingImage() {
    return i(this, Dl);
  }
  get hcmFilter() {
    return L(this, "hcmFilter", i(this, pr) ? i(this, dd).addHCMFilter(i(this, pr).foreground, i(this, pr).background) : "none");
  }
  get direction() {
    return L(this, "direction", getComputedStyle(i(this, hn)).direction);
  }
  get _highlightColors() {
    return L(this, "_highlightColors", i(this, Il) ? new Map(i(this, Il).split(",").map((t) => (t = t.split("=").map((e) => e.trim()), t[1] = t[1].toUpperCase(), t))) : null);
  }
  get highlightColors() {
    const {
      _highlightColors: t
    } = this;
    if (!t)
      return L(this, "highlightColors", null);
    const e = /* @__PURE__ */ new Map(), s = !!i(this, pr);
    for (const [n, r] of t) {
      const a = n.endsWith("_HCM");
      if (s && a) {
        e.set(n.replace("_HCM", ""), r);
        continue;
      }
      !s && !a && e.set(n, r);
    }
    return L(this, "highlightColors", e);
  }
  get highlightColorNames() {
    return L(this, "highlightColorNames", this.highlightColors ? new Map(Array.from(this.highlightColors, (t) => t.reverse())) : null);
  }
  getNonHCMColor(t) {
    if (!this._highlightColors)
      return t;
    const e = this.highlightColorNames.get(t);
    return this._highlightColors.get(e) || t;
  }
  getNonHCMColorName(t) {
    return this.highlightColorNames.get(t) || t;
  }
  setCurrentDrawingSession(t) {
    t ? (this.unselectAll(), this.disableUserSelect(!0)) : this.disableUserSelect(!1), u(this, ar, t);
  }
  setMainHighlightColorPicker(t) {
    u(this, Ll, t);
  }
  editAltText(t, e = !1) {
    var s;
    (s = i(this, Pl)) == null || s.editAltText(this, t, e);
  }
  hasCommentManager() {
    return !!i(this, ne);
  }
  editComment(t, e, s, n) {
    var r;
    (r = i(this, ne)) == null || r.showDialog(this, t, e, s, n);
  }
  selectComment(t, e) {
    const s = i(this, Lt).get(t), n = s == null ? void 0 : s.getEditorByUID(e);
    n == null || n.toggleComment(!0, !0);
  }
  updateComment(t) {
    var e;
    (e = i(this, ne)) == null || e.updateComment(t.getData());
  }
  updatePopupColor(t) {
    var e;
    (e = i(this, ne)) == null || e.updatePopupColor(t);
  }
  removeComment(t) {
    var e;
    (e = i(this, ne)) == null || e.removeComments([t.uid]);
  }
  deleteComment(t, e) {
    const s = () => {
      t.comment = e;
    }, n = () => {
      var r;
      (r = this._editorUndoBar) == null || r.show(s, "comment"), this.toggleComment(null), t.comment = null;
    };
    this.addCommands({
      cmd: n,
      undo: s,
      mustExec: !0
    });
  }
  toggleComment(t, e, s = void 0) {
    var n;
    (n = i(this, ne)) == null || n.toggleCommentPopup(t, e, s);
  }
  makeCommentColor(t, e) {
    var s;
    return t && ((s = i(this, ne)) == null ? void 0 : s.makeCommentColor(t, e)) || null;
  }
  getCommentDialogElement() {
    var t;
    return ((t = i(this, ne)) == null ? void 0 : t.dialogElement) || null;
  }
  async waitForEditorsRendered(t) {
    if (i(this, Lt).has(t - 1))
      return;
    const {
      resolve: e,
      promise: s
    } = Promise.withResolvers(), n = (r) => {
      r.pageNumber === t && (this._eventBus.off("editorsrendered", n), e());
    };
    this._eventBus.on("editorsrendered", n, yg), await s;
  }
  getSignature(t) {
    var e;
    (e = i(this, fr)) == null || e.getSignature({
      uiManager: this,
      editor: t
    });
  }
  get signatureManager() {
    return i(this, fr);
  }
  switchToMode(t, e) {
    this._eventBus.on("annotationeditormodechanged", e, {
      once: !0,
      signal: this._signal,
      ...yg
    }), this._eventBus.dispatch("showannotationeditorui", {
      source: this,
      mode: t
    });
  }
  setPreference(t, e) {
    this._eventBus.dispatch("setpreference", {
      source: this,
      name: t,
      value: e
    });
  }
  onSetPreference({
    name: t,
    value: e
  }) {
    switch (t) {
      case "enableNewAltTextWhenAddingImage":
        u(this, Dl, e);
        break;
    }
  }
  onPageChanging({
    pageNumber: t
  }) {
    u(this, or, t - 1);
  }
  deletePage(t) {
    for (const e of this.getEditors(t))
      e.remove();
    i(this, Lt).delete(t), i(this, or) === t && u(this, or, 0);
  }
  focusMainContainer() {
    i(this, hn).focus();
  }
  findParent(t, e) {
    for (const s of i(this, Lt).values()) {
      const {
        x: n,
        y: r,
        width: a,
        height: o
      } = s.div.getBoundingClientRect();
      if (t >= n && t <= n + a && e >= r && e <= r + o)
        return s;
    }
    return null;
  }
  disableUserSelect(t = !1) {
    i(this, md).classList.toggle("noUserSelect", t);
  }
  addShouldRescale(t) {
    i(this, Ta).add(t);
  }
  removeShouldRescale(t) {
    i(this, Ta).delete(t);
  }
  onScaleChanging({
    scale: t
  }) {
    var e;
    this.commitOrRemove(), this.viewParameters.realScale = t * la.PDF_TO_CSS_UNITS;
    for (const s of i(this, Ta))
      s.onScaleChanging();
    (e = i(this, ar)) == null || e.onScaleChanging();
  }
  onRotationChanging({
    pagesRotation: t
  }) {
    this.commitOrRemove(), this.viewParameters.rotation = t;
  }
  highlightSelection(t = "", e = !1) {
    const s = document.getSelection();
    if (!s || s.isCollapsed)
      return;
    const {
      anchorNode: n,
      anchorOffset: r,
      focusNode: a,
      focusOffset: o
    } = s, l = s.toString(), c = m(this, R, wf).call(this, s).closest(".textLayer"), d = this.getSelectionBoxes(c);
    if (!d)
      return;
    s.empty();
    const f = m(this, R, Hg).call(this, c), b = i(this, Xt) === X.NONE, y = () => {
      const A = f == null ? void 0 : f.createAndAddNewEditor({
        x: 0,
        y: 0
      }, !1, {
        methodOfCreation: t,
        boxes: d,
        anchorNode: n,
        anchorOffset: r,
        focusNode: a,
        focusOffset: o,
        text: l
      });
      b && this.showAllEditors("highlight", !0, !0), e && (A == null || A.editComment());
    };
    if (b) {
      this.switchToMode(X.HIGHLIGHT, y);
      return;
    }
    y();
  }
  commentSelection(t = "") {
    this.highlightSelection(t, !0);
  }
  endCurrentEditing() {
    var t;
    this.commitOrRemove(), (t = this.currentLayer) == null || t.endDrawingSession(!1);
  }
  getAndRemoveDataFromAnnotationStorage(t) {
    if (!i(this, ve))
      return null;
    const e = `${dc}${t}`, s = i(this, ve).getRawValue(e);
    return s && i(this, ve).remove(e), s;
  }
  addToAnnotationStorage(t) {
    !t.isEmpty() && i(this, ve) && !i(this, ve).has(t.id) && i(this, ve).setValue(t.id, t);
  }
  a11yAlert(t, e = null) {
    const s = i(this, bd);
    s && (s.setAttribute("data-l10n-id", t), e ? s.setAttribute("data-l10n-args", JSON.stringify(e)) : s.removeAttribute("data-l10n-args"));
  }
  blur() {
    if (this.isShiftKeyDown = !1, i(this, cr) && (u(this, cr, !1), m(this, R, Sc).call(this, "main_toolbar")), !this.hasSelection)
      return;
    const {
      activeElement: t
    } = document;
    for (const e of i(this, ft))
      if (e.div.contains(t)) {
        u(this, _a, [e, t]), e._focusEventsAllowed = !1;
        break;
      }
  }
  focus() {
    if (!i(this, _a))
      return;
    const [t, e] = i(this, _a);
    u(this, _a, null), e.addEventListener("focusin", () => {
      t._focusEventsAllowed = !0;
    }, {
      once: !0,
      signal: this._signal
    }), e.focus();
  }
  addEditListeners() {
    m(this, R, Ug).call(this), this.setEditingState(!0);
  }
  removeEditListeners() {
    m(this, R, Jy).call(this), this.setEditingState(!1);
  }
  dragOver(t) {
    for (const {
      type: e
    } of t.dataTransfer.items)
      for (const s of i(this, Ms))
        if (s.isHandlingMimeForPasting(e)) {
          t.dataTransfer.dropEffect = "copy", t.preventDefault();
          return;
        }
  }
  drop(t) {
    for (const e of t.dataTransfer.items)
      for (const s of i(this, Ms))
        if (s.isHandlingMimeForPasting(e.type)) {
          s.paste(e, this.currentLayer), t.preventDefault();
          return;
        }
  }
  copy(t) {
    var s;
    if (t.preventDefault(), (s = i(this, Ze)) == null || s.commitOrRemove(), !this.hasSelection)
      return;
    const e = [];
    for (const n of i(this, ft)) {
      const r = n.serialize(!0);
      r && e.push(r);
    }
    e.length !== 0 && t.clipboardData.setData("application/pdfjs", JSON.stringify(e));
  }
  cut(t) {
    this.copy(t), this.delete();
  }
  async paste(t) {
    t.preventDefault();
    const {
      clipboardData: e
    } = t;
    for (const r of e.items)
      for (const a of i(this, Ms))
        if (a.isHandlingMimeForPasting(r.type)) {
          a.paste(r, this.currentLayer);
          return;
        }
    let s = e.getData("application/pdfjs");
    if (!s)
      return;
    try {
      s = JSON.parse(s);
    } catch (r) {
      j(`paste: "${r.message}".`);
      return;
    }
    if (!Array.isArray(s))
      return;
    this.unselectAll();
    const n = this.currentLayer;
    try {
      const r = [];
      for (const l of s) {
        const h = await n.deserialize(l);
        if (!h)
          return;
        r.push(h);
      }
      const a = () => {
        for (const l of r)
          m(this, R, zg).call(this, l);
        m(this, R, Gg).call(this, r);
      }, o = () => {
        for (const l of r)
          l.remove();
      };
      this.addCommands({
        cmd: a,
        undo: o,
        mustExec: !0
      });
    } catch (r) {
      j(`paste: "${r.message}".`);
    }
  }
  keydown(t) {
    !this.isShiftKeyDown && t.key === "Shift" && (this.isShiftKeyDown = !0), i(this, Xt) !== X.NONE && !this.isEditorHandlingKeyboard && bl._keyboardManager.exec(this, t);
  }
  keyup(t) {
    this.isShiftKeyDown && t.key === "Shift" && (this.isShiftKeyDown = !1, i(this, cr) && (u(this, cr, !1), m(this, R, Sc).call(this, "main_toolbar")));
  }
  onEditingAction({
    name: t
  }) {
    switch (t) {
      case "undo":
      case "redo":
      case "delete":
      case "selectAll":
        this[t]();
        break;
      case "highlightSelection":
        this.highlightSelection("context_menu");
        break;
      case "commentSelection":
        this.commentSelection("context_menu");
        break;
    }
  }
  updatePageIndex(t, e) {
    for (const n of i(this, kl).get(t) || [])
      n.pageIndex = e;
    const s = i(this, _l).get(t);
    s && (s.pageIndex = e, i(this, Lt).set(e, s), i(this, on) ? s.enable() : s.disable());
  }
  startUpdatePages() {
    u(this, _l, new Map(i(this, Lt))), i(this, Lt).clear();
    const t = u(this, kl, /* @__PURE__ */ new Map()), e = (s) => {
      t.getOrInsertComputed(s.pageIndex, gc).push(s);
    };
    for (const s of i(this, _t).values())
      e(s);
    for (const [s, n] of i(this, ve))
      s.startsWith(dc) && !i(this, _t).has(s) && Number.isInteger(n == null ? void 0 : n.pageIndex) && e(n);
  }
  endUpdatePages() {
    u(this, _l, null), u(this, kl, null);
  }
  clonePage(t, e) {
    for (const s of this.getEditors(t)) {
      const n = s.serialize(s.mode !== X.HIGHLIGHT);
      n && (n.pageIndex = e, n.id = this.getId(), n.isClone = !0, delete n.popupRef, i(this, ve).setValue(n.id, n));
    }
  }
  findClonesForPage(t) {
    const e = [], {
      pageIndex: s
    } = t;
    for (const [n, r] of i(this, ve))
      r.pageIndex === s && r.isClone && (i(this, ve).remove(n), e.push(t.deserialize(r).then((a) => {
        a && (a.isClone = !0, t.addOrRebuild(a));
      })));
    return Promise.all(e);
  }
  setEditingState(t) {
    t ? (m(this, R, qy).call(this), m(this, R, Zy).call(this), m(this, R, Pe).call(this, {
      isEditing: i(this, Xt) !== X.NONE,
      isEmpty: m(this, R, Ec).call(this),
      hasSomethingToUndo: i(this, $e).hasSomethingToUndo(),
      hasSomethingToRedo: i(this, $e).hasSomethingToRedo(),
      hasSelectedEditor: !1
    })) : (m(this, R, Qy).call(this), m(this, R, tA).call(this), m(this, R, Pe).call(this, {
      isEditing: !1
    }), this.disableUserSelect(!1));
  }
  registerEditorTypes(t) {
    if (!i(this, Ms)) {
      u(this, Ms, t);
      for (const e of i(this, Ms))
        m(this, R, tn).call(this, e.defaultPropertiesToUpdate);
    }
  }
  getId() {
    return i(this, Ap).id;
  }
  get currentLayer() {
    return i(this, Lt).get(i(this, or));
  }
  getLayer(t) {
    return i(this, Lt).get(t);
  }
  get currentPageIndex() {
    return i(this, or);
  }
  addLayer(t) {
    i(this, Lt).set(t.pageIndex, t), i(this, on) ? t.enable() : t.disable();
  }
  removeLayer(t) {
    i(this, Lt).delete(t.pageIndex);
  }
  async updateMode(t, e = null, s = !1, n = !1, r = !1, a = !1) {
    var o, l, h, c, d, f;
    if (i(this, Xt) !== t && !(i(this, Ds) && (await i(this, Ds).promise, !i(this, Ds)))) {
      if (u(this, Ds, Promise.withResolvers()), (o = i(this, ar)) == null || o.commitOrRemove(), i(this, Xt) === X.POPUP && ((l = i(this, ne)) == null || l.hideSidebar()), (h = i(this, ne)) == null || h.destroyPopup(), u(this, Xt, t), t === X.NONE) {
        this.setEditingState(!1), m(this, R, iA).call(this);
        for (const b of i(this, _t).values())
          b.hideStandaloneCommentButton();
        (c = this._editorUndoBar) == null || c.hide(), this.toggleComment(null), i(this, Ds).resolve();
        return;
      }
      for (const b of i(this, _t).values())
        b.addStandaloneCommentButton();
      t === X.SIGNATURE && await ((d = i(this, fr)) == null ? void 0 : d.loadSignatures()), s && Ae.clearPointerType(), this.setEditingState(!0), await m(this, R, sA).call(this), this.unselectAll();
      for (const b of i(this, Lt).values())
        b.updateMode(t);
      if (t === X.POPUP) {
        i(this, Tl) || u(this, Tl, await i(this, Ol).getAnnotationsByType(new Set(i(this, Ms).map((A) => A._editorType))));
        const b = /* @__PURE__ */ new Set(), y = [];
        for (const A of i(this, _t).values()) {
          const {
            annotationElementId: w,
            hasComment: v,
            deleted: S
          } = A;
          w && b.add(w), v && !S && y.push(A.getData());
        }
        for (const A of i(this, Tl)) {
          const {
            id: w,
            popupRef: v,
            contentsObj: S
          } = A;
          v && (S != null && S.str) && !b.has(w) && !i(this, lr).has(w) && y.push(A);
        }
        (f = i(this, ne)) == null || f.showSidebar(y);
      }
      if (!e) {
        n && this.addNewEditorFromKeyboard(), i(this, Ds).resolve();
        return;
      }
      for (const b of i(this, _t).values())
        b.uid === e ? (this.setSelected(b), a ? b.editComment() : r ? b.enterInEditMode() : b.focus()) : b.unselect();
      i(this, Ds).resolve();
    }
  }
  addNewEditorFromKeyboard() {
    this.currentLayer.canCreateNewEmptyEditor() && this.currentLayer.addNewEditor();
  }
  updateToolbar(t) {
    t.mode !== i(this, Xt) && this._eventBus.dispatch("switchannotationeditormode", {
      source: this,
      ...t
    });
  }
  updateParams(t, e) {
    if (i(this, Ms)) {
      switch (t) {
        case tt.CREATE:
          this.currentLayer.addNewEditor(e);
          return;
        case tt.HIGHLIGHT_SHOW_ALL:
          this._eventBus.dispatch("reporttelemetry", {
            source: this,
            details: {
              type: "editing",
              data: {
                type: "highlight",
                action: "toggle_visibility"
              }
            }
          }), (i(this, pd) || u(this, pd, /* @__PURE__ */ new Map())).set(t, e), this.showAllEditors("highlight", e);
          break;
      }
      if (this.hasSelection)
        for (const s of i(this, ft))
          s.updateParams(t, e);
      else
        for (const s of i(this, Ms))
          s.updateDefaultParams(t, e);
    }
  }
  showAllEditors(t, e, s = !1) {
    var r;
    for (const a of i(this, _t).values())
      a.editorType === t && a.show(e);
    (((r = i(this, pd)) == null ? void 0 : r.get(tt.HIGHLIGHT_SHOW_ALL)) ?? !0) !== e && m(this, R, tn).call(this, [[tt.HIGHLIGHT_SHOW_ALL, e]]);
  }
  enableWaiting(t = !1) {
    if (i(this, ud) !== t) {
      u(this, ud, t);
      for (const e of i(this, Lt).values())
        t ? e.disableClick() : e.enableClick(), e.div.classList.toggle("waiting", t);
    }
  }
  *getEditors(t) {
    for (const e of i(this, _t).values())
      e.pageIndex === t && (yield e);
  }
  getEditor(t) {
    return i(this, _t).get(t);
  }
  addEditor(t) {
    i(this, _t).set(t.id, t);
  }
  removeEditor(t) {
    var e, s;
    t.div.contains(document.activeElement) && (i(this, wi) && clearTimeout(i(this, wi)), u(this, wi, setTimeout(() => {
      this.focusMainContainer(), u(this, wi, null);
    }, 0))), i(this, _t).delete(t.id), t.annotationElementId && ((e = i(this, ur)) == null || e.delete(t.annotationElementId)), this.unselect(t), (!t.annotationElementId || !i(this, lr).has(t.annotationElementId)) && ((s = i(this, ve)) == null || s.remove(t.id));
  }
  addDeletedAnnotationElement(t) {
    i(this, lr).add(t.annotationElementId), this.addChangedExistingAnnotation(t), t.deleted = !0;
  }
  isDeletedAnnotationElement(t) {
    return i(this, lr).has(t);
  }
  removeDeletedAnnotationElement(t) {
    i(this, lr).delete(t.annotationElementId), this.removeChangedExistingAnnotation(t), t.deleted = !1;
  }
  setActiveEditor(t) {
    i(this, Ze) !== t && (u(this, Ze, t), t && m(this, R, tn).call(this, t.propertiesToUpdate));
  }
  updateUI(t) {
    i(this, R, nA) === t && m(this, R, tn).call(this, t.propertiesToUpdate);
  }
  updateUIForDefaultProperties(t) {
    m(this, R, tn).call(this, t.defaultPropertiesToUpdate);
  }
  toggleSelected(t) {
    if (i(this, ft).has(t)) {
      i(this, ft).delete(t), t.unselect(), m(this, R, Pe).call(this, {
        hasSelectedEditor: this.hasSelection
      });
      return;
    }
    i(this, ft).add(t), t.select(), m(this, R, tn).call(this, t.propertiesToUpdate), m(this, R, Pe).call(this, {
      hasSelectedEditor: !0
    });
  }
  setSelected(t) {
    var e, s;
    this.updateToolbar({
      mode: t.mode,
      editId: t.uid
    }), (e = i(this, ar)) == null || e.commitOrRemove();
    for (const n of i(this, ft))
      n !== t && n.unselect();
    (s = i(this, ne)) == null || s.destroyPopup(), i(this, ft).clear(), i(this, ft).add(t), t.select(), m(this, R, tn).call(this, t.propertiesToUpdate), m(this, R, Pe).call(this, {
      hasSelectedEditor: !0
    });
  }
  get firstSelectedEditor() {
    return i(this, ft).values().next().value;
  }
  unselect(t) {
    t.unselect(), i(this, ft).delete(t), m(this, R, Pe).call(this, {
      hasSelectedEditor: this.hasSelection
    });
  }
  get hasSelection() {
    return i(this, ft).size !== 0;
  }
  get isEnterHandled() {
    return i(this, ft).size === 1 && this.firstSelectedEditor.isEnterHandled;
  }
  undo() {
    var t;
    i(this, $e).undo(), m(this, R, Pe).call(this, {
      hasSomethingToUndo: i(this, $e).hasSomethingToUndo(),
      hasSomethingToRedo: i(this, $e).hasSomethingToRedo(),
      isEmpty: m(this, R, Ec).call(this)
    }), (t = this._editorUndoBar) == null || t.hide();
  }
  redo() {
    i(this, $e).redo(), m(this, R, Pe).call(this, {
      hasSomethingToUndo: i(this, $e).hasSomethingToUndo(),
      hasSomethingToRedo: i(this, $e).hasSomethingToRedo(),
      isEmpty: m(this, R, Ec).call(this)
    });
  }
  addCommands(t) {
    i(this, $e).add(t), m(this, R, Pe).call(this, {
      hasSomethingToUndo: !0,
      hasSomethingToRedo: !1,
      isEmpty: m(this, R, Ec).call(this)
    });
  }
  cleanUndoStack(t) {
    i(this, $e).cleanType(t);
  }
  delete() {
    var r;
    this.commitOrRemove();
    const t = (r = this.currentLayer) == null ? void 0 : r.endDrawingSession(!0);
    if (!this.hasSelection && !t)
      return;
    const e = t ? [t] : [...i(this, ft)], s = () => {
      var a;
      (a = this._editorUndoBar) == null || a.show(n, e.length === 1 ? e[0].editorType : e.length);
      for (const o of e)
        o.remove();
    }, n = () => {
      for (const a of e)
        m(this, R, zg).call(this, a);
    };
    this.addCommands({
      cmd: s,
      undo: n,
      mustExec: !0
    });
  }
  commitOrRemove() {
    var t;
    (t = i(this, Ze)) == null || t.commitOrRemove();
  }
  hasSomethingToControl() {
    return i(this, Ze) || this.hasSelection;
  }
  selectAll() {
    for (const t of i(this, ft))
      t.commit();
    m(this, R, Gg).call(this, i(this, _t).values());
  }
  unselectAll() {
    var t, e;
    if (!(i(this, Ze) && (i(this, Ze).commitOrRemove(), i(this, Xt) !== X.NONE)) && !((t = i(this, ar)) != null && t.commitOrRemove()) && ((e = i(this, ne)) == null || e.destroyPopup(), !!this.hasSelection)) {
      for (const s of i(this, ft))
        s.unselect();
      i(this, ft).clear(), m(this, R, Pe).call(this, {
        hasSelectedEditor: !1
      });
    }
  }
  translateSelectedEditors(t, e, s = !1) {
    if (s || this.commitOrRemove(), !this.hasSelection)
      return;
    i(this, gr)[0] += t, i(this, gr)[1] += e;
    const [n, r] = i(this, gr), a = [...i(this, ft)], o = 1e3;
    i(this, Si) && clearTimeout(i(this, Si)), u(this, Si, setTimeout(() => {
      u(this, Si, null), i(this, gr)[0] = i(this, gr)[1] = 0, this.addCommands({
        cmd: () => {
          for (const l of a)
            i(this, _t).has(l.id) && (l.translateInPage(n, r), l.translationDone());
        },
        undo: () => {
          for (const l of a)
            i(this, _t).has(l.id) && (l.translateInPage(-n, -r), l.translationDone());
        },
        mustExec: !1
      });
    }, o));
    for (const l of a)
      l.translateInPage(t, e), l.translationDone();
  }
  setUpDragSession() {
    if (this.hasSelection) {
      this.disableUserSelect(!0), u(this, Ai, /* @__PURE__ */ new Map());
      for (const t of i(this, ft))
        i(this, Ai).set(t, {
          savedX: t.x,
          savedY: t.y,
          savedPageIndex: t.pageIndex,
          newX: 0,
          newY: 0,
          newPageIndex: -1
        });
    }
  }
  endDragSession() {
    if (!i(this, Ai))
      return !1;
    this.disableUserSelect(!1);
    const t = i(this, Ai);
    u(this, Ai, null);
    let e = !1;
    for (const [{
      x: n,
      y: r,
      pageIndex: a
    }, o] of t)
      o.newX = n, o.newY = r, o.newPageIndex = a, e || (e = n !== o.savedX || r !== o.savedY || a !== o.savedPageIndex);
    if (!e)
      return !1;
    const s = (n, r, a, o) => {
      if (i(this, _t).has(n.id)) {
        const l = i(this, Lt).get(o);
        l ? n._setParentAndPosition(l, r, a) : (n.pageIndex = o, n.x = r, n.y = a);
      }
    };
    return this.addCommands({
      cmd: () => {
        for (const [n, {
          newX: r,
          newY: a,
          newPageIndex: o
        }] of t)
          s(n, r, a, o);
      },
      undo: () => {
        for (const [n, {
          savedX: r,
          savedY: a,
          savedPageIndex: o
        }] of t)
          s(n, r, a, o);
      },
      mustExec: !0
    }), !0;
  }
  dragSelectedEditors(t, e) {
    if (i(this, Ai))
      for (const s of i(this, Ai).keys())
        s.drag(t, e);
  }
  rebuild(t) {
    if (t.parent === null) {
      const e = this.getLayer(t.pageIndex);
      e ? (e.changeParent(t), e.addOrRebuild(t)) : (this.addEditor(t), this.addToAnnotationStorage(t), t.rebuild());
    } else
      t.parent.addOrRebuild(t);
  }
  get isEditorHandlingKeyboard() {
    var t;
    return ((t = this.getActive()) == null ? void 0 : t.shouldGetKeyboardEvents()) || i(this, ft).size === 1 && this.firstSelectedEditor.shouldGetKeyboardEvents();
  }
  isActive(t) {
    return i(this, Ze) === t;
  }
  getActive() {
    return i(this, Ze);
  }
  getMode() {
    return i(this, Xt);
  }
  isEditingMode() {
    return i(this, Xt) !== X.NONE;
  }
  get imageManager() {
    return L(this, "imageManager", new Ng());
  }
  getSelectionBoxes(t) {
    if (!t)
      return null;
    const e = document.getSelection();
    for (let h = 0, c = e.rangeCount; h < c; h++)
      if (!t.contains(e.getRangeAt(h).commonAncestorContainer))
        return null;
    const {
      x: s,
      y: n,
      width: r,
      height: a
    } = t.getBoundingClientRect();
    let o;
    switch (t.getAttribute("data-main-rotation")) {
      case "90":
        o = (h, c, d, f) => ({
          x: (c - n) / a,
          y: 1 - (h + d - s) / r,
          width: f / a,
          height: d / r
        });
        break;
      case "180":
        o = (h, c, d, f) => ({
          x: 1 - (h + d - s) / r,
          y: 1 - (c + f - n) / a,
          width: d / r,
          height: f / a
        });
        break;
      case "270":
        o = (h, c, d, f) => ({
          x: 1 - (c + f - n) / a,
          y: (h - s) / r,
          width: f / a,
          height: d / r
        });
        break;
      default:
        o = (h, c, d, f) => ({
          x: (h - s) / r,
          y: (c - n) / a,
          width: d / r,
          height: f / a
        });
        break;
    }
    const l = [];
    for (let h = 0, c = e.rangeCount; h < c; h++) {
      const d = e.getRangeAt(h);
      if (!d.collapsed)
        for (const {
          x: f,
          y: b,
          width: y,
          height: A
        } of d.getClientRects())
          y === 0 || A === 0 || l.push(o(f, b, y, A));
    }
    return l.length === 0 ? null : l;
  }
  addChangedExistingAnnotation({
    annotationElementId: t,
    id: e
  }) {
    (i(this, Ml) || u(this, Ml, /* @__PURE__ */ new Map())).set(t, e);
  }
  removeChangedExistingAnnotation({
    annotationElementId: t
  }) {
    var e;
    (e = i(this, Ml)) == null || e.delete(t);
  }
  renderAnnotationElement(t) {
    var n;
    const e = (n = i(this, Ml)) == null ? void 0 : n.get(t.data.id);
    if (!e)
      return;
    const s = i(this, ve).getRawValue(e);
    s && (i(this, Xt) === X.NONE && !s.hasBeenModified || s.renderAnnotationElement(t));
  }
  setMissingCanvas(t, e, s) {
    var r;
    const n = (r = i(this, ur)) == null ? void 0 : r.get(t);
    n && (n.setCanvas(e, s), i(this, ur).delete(t));
  }
  addMissingCanvas(t, e) {
    (i(this, ur) || u(this, ur, /* @__PURE__ */ new Map())).set(t, e);
  }
};
xl = new WeakMap(), Ze = new WeakMap(), Tl = new WeakMap(), _t = new WeakMap(), Lt = new WeakMap(), _l = new WeakMap(), kl = new WeakMap(), Pl = new WeakMap(), ve = new WeakMap(), Ml = new WeakMap(), $e = new WeakMap(), ne = new WeakMap(), rr = new WeakMap(), ar = new WeakMap(), or = new WeakMap(), lr = new WeakMap(), Ai = new WeakMap(), Ms = new WeakMap(), Ta = new WeakMap(), hd = new WeakMap(), cd = new WeakMap(), Dl = new WeakMap(), dd = new WeakMap(), wi = new WeakMap(), hr = new WeakMap(), Il = new WeakMap(), cr = new WeakMap(), vi = new WeakMap(), Ap = new WeakMap(), on = new WeakMap(), Fl = new WeakMap(), ud = new WeakMap(), dr = new WeakMap(), _a = new WeakMap(), Ll = new WeakMap(), ur = new WeakMap(), fd = new WeakMap(), Xt = new WeakMap(), ft = new WeakMap(), ln = new WeakMap(), fr = new WeakMap(), pr = new WeakMap(), pd = new WeakMap(), Ol = new WeakMap(), gd = new WeakMap(), gr = new WeakMap(), Si = new WeakMap(), hn = new WeakMap(), md = new WeakMap(), bd = new WeakMap(), Ds = new WeakMap(), R = new WeakSet(), wf = function({
  anchorNode: t
}) {
  return t.nodeType === Node.TEXT_NODE ? t.parentElement : t;
}, Hg = function(t) {
  const {
    currentLayer: e
  } = this;
  if (e.hasTextLayer(t))
    return e;
  for (const s of i(this, Lt).values())
    if (s.hasTextLayer(t))
      return s;
  return null;
}, Xy = function() {
  const t = document.getSelection();
  if (!t || t.isCollapsed)
    return;
  const s = m(this, R, wf).call(this, t).closest(".textLayer"), n = this.getSelectionBoxes(s);
  n && (i(this, vi) || u(this, vi, new Nw(this)), i(this, vi).show(s, n, this.direction === "ltr"));
}, Yy = function() {
  var r, a, o;
  const t = document.getSelection();
  if (!t || t.isCollapsed) {
    i(this, ln) && ((r = i(this, vi)) == null || r.hide(), u(this, ln, null), m(this, R, Pe).call(this, {
      hasSelectedText: !1
    }));
    return;
  }
  const {
    anchorNode: e
  } = t;
  if (e === i(this, ln))
    return;
  const n = m(this, R, wf).call(this, t).closest(".textLayer");
  if (!n) {
    i(this, ln) && ((a = i(this, vi)) == null || a.hide(), u(this, ln, null), m(this, R, Pe).call(this, {
      hasSelectedText: !1
    }));
    return;
  }
  if ((o = i(this, vi)) == null || o.hide(), u(this, ln, e), m(this, R, Pe).call(this, {
    hasSelectedText: !0
  }), !(i(this, Xt) !== X.HIGHLIGHT && i(this, Xt) !== X.NONE) && (i(this, Xt) === X.HIGHLIGHT && this.showAllEditors("highlight", !0, !0), u(this, cr, this.isShiftKeyDown), !this.isShiftKeyDown)) {
    const l = i(this, Xt) === X.HIGHLIGHT ? m(this, R, Hg).call(this, n) : null;
    if (l == null || l.toggleDrawing(), i(this, Fl)) {
      const h = new AbortController(), c = this.combinedSignal(h), d = (f) => {
        f.type === "pointerup" && f.button !== 0 || (h.abort(), l == null || l.toggleDrawing(!0), f.type === "pointerup" && m(this, R, Sc).call(this, "main_toolbar"));
      };
      window.addEventListener("pointerup", d, {
        signal: c
      }), window.addEventListener("blur", d, {
        signal: c
      });
    } else
      l == null || l.toggleDrawing(!0), m(this, R, Sc).call(this, "main_toolbar");
  }
}, Sc = function(t = "") {
  i(this, Xt) === X.HIGHLIGHT ? this.highlightSelection(t) : i(this, hd) && m(this, R, Xy).call(this);
}, Ky = function() {
  document.addEventListener("selectionchange", m(this, R, Yy).bind(this), {
    signal: this._signal
  });
}, qy = function() {
  if (i(this, hr))
    return;
  u(this, hr, new AbortController());
  const t = this.combinedSignal(i(this, hr));
  window.addEventListener("focus", this.focus.bind(this), {
    signal: t
  }), window.addEventListener("blur", this.blur.bind(this), {
    signal: t
  });
}, Qy = function() {
  var t;
  (t = i(this, hr)) == null || t.abort(), u(this, hr, null);
}, Ug = function() {
  if (i(this, dr))
    return;
  u(this, dr, new AbortController());
  const t = this.combinedSignal(i(this, dr));
  window.addEventListener("keydown", this.keydown.bind(this), {
    signal: t
  }), window.addEventListener("keyup", this.keyup.bind(this), {
    signal: t
  });
}, Jy = function() {
  var t;
  (t = i(this, dr)) == null || t.abort(), u(this, dr, null);
}, Zy = function() {
  if (i(this, rr))
    return;
  u(this, rr, new AbortController());
  const t = this.combinedSignal(i(this, rr));
  document.addEventListener("copy", this.copy.bind(this), {
    signal: t
  }), document.addEventListener("cut", this.cut.bind(this), {
    signal: t
  }), document.addEventListener("paste", this.paste.bind(this), {
    signal: t
  });
}, tA = function() {
  var t;
  (t = i(this, rr)) == null || t.abort(), u(this, rr, null);
}, eA = function() {
  const t = this._signal;
  document.addEventListener("dragover", this.dragOver.bind(this), {
    signal: t
  }), document.addEventListener("drop", this.drop.bind(this), {
    signal: t
  });
}, Pe = function(t) {
  Object.entries(t).some(([s, n]) => i(this, gd)[s] !== n) && (this._eventBus.dispatch("editingstateschanged", {
    source: this,
    details: Object.assign(i(this, gd), t)
  }), i(this, Xt) === X.HIGHLIGHT && t.hasSelectedEditor === !1 && m(this, R, tn).call(this, [[tt.HIGHLIGHT_FREE, !0]]));
}, tn = function(t) {
  this._eventBus.dispatch("annotationeditorparamschanged", {
    source: this,
    details: t
  });
}, sA = async function() {
  if (!i(this, on)) {
    u(this, on, !0);
    const t = [];
    for (const e of i(this, Lt).values())
      t.push(e.enable());
    await Promise.all(t);
    for (const e of i(this, _t).values())
      e.enable();
  }
}, iA = function() {
  if (this.unselectAll(), i(this, on)) {
    u(this, on, !1);
    for (const t of i(this, Lt).values())
      t.disable();
    for (const t of i(this, _t).values())
      t.disable();
  }
}, zg = function(t) {
  const e = i(this, Lt).get(t.pageIndex);
  e ? e.addOrRebuild(t) : (this.addEditor(t), this.addToAnnotationStorage(t));
}, nA = function() {
  let t = null;
  for (t of i(this, ft))
    ;
  return t;
}, Ec = function() {
  if (i(this, _t).size === 0)
    return !0;
  if (i(this, _t).size === 1)
    for (const t of i(this, _t).values())
      return t.isEmpty();
  return !1;
}, Gg = function(t) {
  for (const e of i(this, ft))
    e.unselect();
  i(this, ft).clear();
  for (const e of t)
    e.isEmpty() || (i(this, ft).add(e), e.select());
  m(this, R, Pe).call(this, {
    hasSelectedEditor: this.hasSelection
  });
}, _(bl, "TRANSLATE_SMALL", 1), _(bl, "TRANSLATE_BIG", 10);
let al = bl;
var re, Ei, Vs, Rl, Ci, ts, Nl, xi, je, cn, ka, Ti, mr, hi, Cc, vf;
const Me = class Me {
  constructor(t) {
    g(this, hi);
    g(this, re, null);
    g(this, Ei, !1);
    g(this, Vs, null);
    g(this, Rl, null);
    g(this, Ci, null);
    g(this, ts, null);
    g(this, Nl, !1);
    g(this, xi, null);
    g(this, je, null);
    g(this, cn, null);
    g(this, ka, null);
    g(this, Ti, !1);
    u(this, je, t), u(this, Ti, t._uiManager.useNewAltTextFlow), i(Me, mr) || u(Me, mr, Object.freeze({
      added: "pdfjs-editor-new-alt-text-added-button",
      "added-label": "pdfjs-editor-new-alt-text-added-button-label",
      missing: "pdfjs-editor-new-alt-text-missing-button",
      "missing-label": "pdfjs-editor-new-alt-text-missing-button-label",
      review: "pdfjs-editor-new-alt-text-to-review-button",
      "review-label": "pdfjs-editor-new-alt-text-to-review-button-label"
    }));
  }
  static initialize(t) {
    Me._l10n ?? (Me._l10n = t);
  }
  async render() {
    const t = u(this, Vs, document.createElement("button"));
    t.className = "altText", t.tabIndex = "0";
    const e = u(this, Rl, document.createElement("span"));
    t.append(e), i(this, Ti) ? (t.classList.add("new"), t.setAttribute("data-l10n-id", i(Me, mr).missing), e.setAttribute("data-l10n-id", i(Me, mr)["missing-label"])) : (t.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-button"), e.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-button-label"));
    const s = i(this, je)._uiManager._signal;
    t.addEventListener("contextmenu", di, {
      signal: s
    }), t.addEventListener("pointerdown", (r) => r.stopPropagation(), {
      signal: s
    });
    const n = (r) => {
      r.preventDefault(), i(this, je)._uiManager.editAltText(i(this, je)), i(this, Ti) && i(this, je)._reportTelemetry({
        action: "pdfjs.image.alt_text.image_status_label_clicked",
        data: {
          label: i(this, hi, Cc)
        }
      });
    };
    return t.addEventListener("click", n, {
      capture: !0,
      signal: s
    }), t.addEventListener("keydown", (r) => {
      r.target === t && r.key === "Enter" && (u(this, Nl, !0), n(r));
    }, {
      signal: s
    }), await m(this, hi, vf).call(this), t;
  }
  finish() {
    i(this, Vs) && (i(this, Vs).focus({
      focusVisible: i(this, Nl)
    }), u(this, Nl, !1));
  }
  isEmpty() {
    return i(this, Ti) ? i(this, re) === null : !i(this, re) && !i(this, Ei);
  }
  hasData() {
    return i(this, Ti) ? i(this, re) !== null || !!i(this, cn) : this.isEmpty();
  }
  get guessedText() {
    return i(this, cn);
  }
  async setGuessedText(t) {
    i(this, re) === null && (u(this, cn, t), u(this, ka, await Me._l10n.get("pdfjs-editor-new-alt-text-generated-alt-text-with-disclaimer", {
      generatedAltText: t
    })), m(this, hi, vf).call(this));
  }
  toggleAltTextBadge(t = !1) {
    var e;
    if (!i(this, Ti) || i(this, re)) {
      (e = i(this, xi)) == null || e.remove(), u(this, xi, null);
      return;
    }
    if (!i(this, xi)) {
      const s = u(this, xi, document.createElement("div"));
      s.className = "noAltTextBadge", i(this, je).div.append(s);
    }
    i(this, xi).classList.toggle("hidden", !t);
  }
  serialize(t) {
    let e = i(this, re);
    return !t && i(this, cn) === e && (e = i(this, ka)), {
      altText: e,
      decorative: i(this, Ei),
      guessedText: i(this, cn),
      textWithDisclaimer: i(this, ka)
    };
  }
  get data() {
    return {
      altText: i(this, re),
      decorative: i(this, Ei)
    };
  }
  set data({
    altText: t,
    decorative: e,
    guessedText: s,
    textWithDisclaimer: n,
    cancel: r = !1
  }) {
    s && (u(this, cn, s), u(this, ka, n)), !(i(this, re) === t && i(this, Ei) === e) && (r || (u(this, re, t), u(this, Ei, e)), m(this, hi, vf).call(this));
  }
  toggle(t = !1) {
    i(this, Vs) && (!t && i(this, ts) && (clearTimeout(i(this, ts)), u(this, ts, null)), i(this, Vs).disabled = !t);
  }
  shown() {
    i(this, je)._reportTelemetry({
      action: "pdfjs.image.alt_text.image_status_label_displayed",
      data: {
        label: i(this, hi, Cc)
      }
    });
  }
  destroy() {
    var t, e;
    (t = i(this, Vs)) == null || t.remove(), u(this, Vs, null), u(this, Rl, null), u(this, Ci, null), (e = i(this, xi)) == null || e.remove(), u(this, xi, null);
  }
};
re = new WeakMap(), Ei = new WeakMap(), Vs = new WeakMap(), Rl = new WeakMap(), Ci = new WeakMap(), ts = new WeakMap(), Nl = new WeakMap(), xi = new WeakMap(), je = new WeakMap(), cn = new WeakMap(), ka = new WeakMap(), Ti = new WeakMap(), mr = new WeakMap(), hi = new WeakSet(), Cc = function() {
  return i(this, re) && "added" || i(this, re) === null && this.guessedText && "review" || "missing";
}, vf = async function() {
  var n, r, a;
  const t = i(this, Vs);
  if (!t)
    return;
  if (i(this, Ti)) {
    if (t.classList.toggle("done", !!i(this, re)), t.setAttribute("data-l10n-id", i(Me, mr)[i(this, hi, Cc)]), (n = i(this, Rl)) == null || n.setAttribute("data-l10n-id", i(Me, mr)[`${i(this, hi, Cc)}-label`]), !i(this, re)) {
      (r = i(this, Ci)) == null || r.remove();
      return;
    }
  } else {
    if (!i(this, re) && !i(this, Ei)) {
      t.classList.remove("done"), (a = i(this, Ci)) == null || a.remove();
      return;
    }
    t.classList.add("done"), t.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-edit-button");
  }
  let e = i(this, Ci);
  if (!e) {
    u(this, Ci, e = document.createElement("span")), e.className = "tooltip", e.setAttribute("role", "tooltip"), e.id = `alt-text-tooltip-${i(this, je).id}`;
    const o = 100, l = i(this, je)._uiManager._signal;
    l.addEventListener("abort", () => {
      clearTimeout(i(this, ts)), u(this, ts, null);
    }, {
      once: !0
    }), t.addEventListener("mouseenter", () => {
      u(this, ts, setTimeout(() => {
        u(this, ts, null), i(this, Ci).classList.add("show"), i(this, je)._reportTelemetry({
          action: "alt_text_tooltip"
        });
      }, o));
    }, {
      signal: l
    }), t.addEventListener("mouseleave", () => {
      var h;
      i(this, ts) && (clearTimeout(i(this, ts)), u(this, ts, null)), (h = i(this, Ci)) == null || h.classList.remove("show");
    }, {
      signal: l
    });
  }
  i(this, Ei) ? e.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-decorative-tooltip") : (e.removeAttribute("data-l10n-id"), e.textContent = i(this, re)), e.parentNode || t.append(e);
  const s = i(this, je).getElementForAltText();
  s == null || s.setAttribute("aria-describedby", e.id);
}, g(Me, mr, null), _(Me, "_l10n", null);
let hp = Me;
var ce, Is, Pa, At, yd, br, Fs, yr, Ar, Ma, Ad, $g;
class lf {
  constructor(t) {
    g(this, Ad);
    g(this, ce, null);
    g(this, Is, null);
    g(this, Pa, !1);
    g(this, At, null);
    g(this, yd, null);
    g(this, br, null);
    g(this, Fs, null);
    g(this, yr, null);
    g(this, Ar, !1);
    g(this, Ma, null);
    u(this, At, t);
  }
  renderForToolbar() {
    const t = u(this, Is, document.createElement("button"));
    return t.className = "comment", m(this, Ad, $g).call(this, t, !1);
  }
  renderForStandalone() {
    const t = u(this, ce, document.createElement("button"));
    t.className = "annotationCommentButton";
    const e = i(this, At).commentButtonPosition;
    if (e) {
      const {
        style: s
      } = t;
      s.insetInlineEnd = `calc(${100 * (i(this, At)._uiManager.direction === "ltr" ? 1 - e[0] : e[0])}% - var(--comment-button-dim))`, s.top = `calc(${100 * e[1]}% - var(--comment-button-dim))`;
      const n = i(this, At).commentButtonColor;
      n && (s.backgroundColor = n);
    }
    return m(this, Ad, $g).call(this, t, !0);
  }
  focusButton() {
    setTimeout(() => {
      var t;
      (t = i(this, ce) ?? i(this, Is)) == null || t.focus();
    }, 0);
  }
  onUpdatedColor() {
    if (!i(this, ce))
      return;
    const t = i(this, At).commentButtonColor;
    t && (i(this, ce).style.backgroundColor = t), i(this, At)._uiManager.updatePopupColor(i(this, At));
  }
  get commentButtonWidth() {
    var t;
    return (((t = i(this, ce)) == null ? void 0 : t.getBoundingClientRect().width) ?? 0) / i(this, At).parent.boundingClientRect.width;
  }
  get commentPopupPositionInLayer() {
    if (i(this, Ma))
      return i(this, Ma);
    if (!i(this, ce))
      return null;
    const {
      x: t,
      y: e,
      height: s
    } = i(this, ce).getBoundingClientRect(), {
      x: n,
      y: r,
      width: a,
      height: o
    } = i(this, At).parent.boundingClientRect;
    return [(t - n) / a, (e + s - r) / o];
  }
  set commentPopupPositionInLayer(t) {
    u(this, Ma, t);
  }
  hasDefaultPopupPosition() {
    return i(this, Ma) === null;
  }
  removeStandaloneCommentButton() {
    var t;
    (t = i(this, ce)) == null || t.remove(), u(this, ce, null);
  }
  removeToolbarCommentButton() {
    var t;
    (t = i(this, Is)) == null || t.remove(), u(this, Is, null);
  }
  setCommentButtonStates({
    selected: t,
    hasPopup: e
  }) {
    i(this, ce) && (i(this, ce).classList.toggle("selected", t), i(this, ce).ariaExpanded = e);
  }
  edit(t) {
    const e = this.commentPopupPositionInLayer;
    let s, n;
    if (e)
      [s, n] = e;
    else {
      [s, n] = i(this, At).commentButtonPosition;
      const {
        width: c,
        height: d,
        x: f,
        y: b
      } = i(this, At);
      s = f + s * c, n = b + n * d;
    }
    const r = i(this, At).parent.boundingClientRect, {
      x: a,
      y: o,
      width: l,
      height: h
    } = r;
    i(this, At)._uiManager.editComment(i(this, At), a + s * l, o + n * h, {
      ...t,
      parentDimensions: r
    });
  }
  finish() {
    i(this, Is) && (i(this, Is).focus({
      focusVisible: i(this, Pa)
    }), u(this, Pa, !1));
  }
  isDeleted() {
    return i(this, Ar) || i(this, Fs) === "";
  }
  isEmpty() {
    return i(this, Fs) === null;
  }
  hasBeenEdited() {
    return this.isDeleted() || i(this, Fs) !== i(this, yd);
  }
  serialize() {
    return this.data;
  }
  get data() {
    return {
      text: i(this, Fs),
      richText: i(this, br),
      date: i(this, yr),
      deleted: this.isDeleted()
    };
  }
  set data(t) {
    if (t !== i(this, Fs) && u(this, br, null), t === null) {
      u(this, Fs, ""), u(this, Ar, !0);
      return;
    }
    u(this, Fs, t), u(this, yr, /* @__PURE__ */ new Date()), u(this, Ar, !1);
  }
  restoreData({
    text: t,
    richText: e,
    date: s
  }) {
    u(this, Fs, t), u(this, br, e), u(this, yr, s), u(this, Ar, !1);
  }
  setInitialText(t, e = null) {
    u(this, yd, t), this.data = t, u(this, yr, null), u(this, br, e);
  }
  shown() {
  }
  destroy() {
    var t, e;
    (t = i(this, Is)) == null || t.remove(), u(this, Is, null), (e = i(this, ce)) == null || e.remove(), u(this, ce, null), u(this, Fs, ""), u(this, br, null), u(this, yr, null), u(this, At, null), u(this, Pa, !1), u(this, Ar, !1);
  }
}
ce = new WeakMap(), Is = new WeakMap(), Pa = new WeakMap(), At = new WeakMap(), yd = new WeakMap(), br = new WeakMap(), Fs = new WeakMap(), yr = new WeakMap(), Ar = new WeakMap(), Ma = new WeakMap(), Ad = new WeakSet(), $g = function(t, e) {
  if (!i(this, At)._uiManager.hasCommentManager())
    return null;
  t.tabIndex = "0", t.ariaHasPopup = "dialog", e ? (t.ariaControls = "commentPopup", t.setAttribute("data-l10n-id", "pdfjs-show-comment-button")) : (t.ariaControlsElements = [i(this, At)._uiManager.getCommentDialogElement()], t.setAttribute("data-l10n-id", "pdfjs-editor-add-comment-button"));
  const s = i(this, At)._uiManager._signal;
  if (!(s instanceof AbortSignal) || s.aborted)
    return t;
  t.addEventListener("contextmenu", di, {
    signal: s
  }), e && (t.addEventListener("focusin", (r) => {
    i(this, At)._focusEventsAllowed = !1, te(r);
  }, {
    capture: !0,
    signal: s
  }), t.addEventListener("focusout", (r) => {
    i(this, At)._focusEventsAllowed = !0, te(r);
  }, {
    capture: !0,
    signal: s
  })), t.addEventListener("pointerdown", (r) => r.stopPropagation(), {
    signal: s
  });
  const n = (r) => {
    r.preventDefault(), t === i(this, Is) ? this.edit() : i(this, At).toggleComment(!0);
  };
  return t.addEventListener("click", n, {
    capture: !0,
    signal: s
  }), t.addEventListener("keydown", (r) => {
    r.target === t && r.key === "Enter" && (u(this, Pa, !0), n(r));
  }, {
    signal: s
  }), t.addEventListener("pointerenter", () => {
    i(this, At).toggleComment(!1, !0);
  }, {
    signal: s
  }), t.addEventListener("pointerleave", () => {
    i(this, At).toggleComment(!1, !1);
  }, {
    signal: s
  }), t;
};
function ry(p) {
  p.preventDefault();
}
const ay = 1e-4;
function Ag(p) {
  return p.cancelable ? (te(p), !0) : (p.stopPropagation(), !1);
}
var Bl, wr, wd, vd, Sd, Ed, Cd, Da, vr, dn, Ia, _i, un, Fa, fn, Sr, Dt, aA, jg, Vg, Wg, Sf, oA, lA, Xg;
class rA {
  constructor({
    container: t,
    isPinchingDisabled: e = null,
    isPinchingStopped: s = null,
    onPinchStart: n = null,
    onPinching: r = null,
    onPinchEnd: a = null,
    onPanning: o = null,
    signal: l
  }) {
    g(this, Dt);
    g(this, Bl);
    g(this, wr, !1);
    g(this, wd, null);
    g(this, vd);
    g(this, Sd);
    g(this, Ed);
    g(this, Cd);
    g(this, Da);
    g(this, vr, !1);
    g(this, dn, null);
    g(this, Ia);
    g(this, _i, /* @__PURE__ */ new Set());
    g(this, un, null);
    g(this, Fa);
    g(this, fn, null);
    g(this, Sr, 0);
    u(this, Bl, t), u(this, wd, s), u(this, vd, e), u(this, Sd, n), u(this, Ed, r), u(this, Cd, a), u(this, Da, o), u(this, Fa, new AbortController()), u(this, Ia, AbortSignal.any([l, i(this, Fa).signal])), t.addEventListener("touchstart", m(this, Dt, aA).bind(this), {
      passive: !1,
      signal: i(this, Ia)
    });
  }
  get MIN_TOUCH_DISTANCE_TO_PINCH() {
    return 35 / ws.pixelRatio;
  }
  get MIN_TOUCH_DISTANCE_TO_SCALE() {
    return 4 / ws.pixelRatio;
  }
  destroy() {
    var t, e;
    m(this, Dt, Xg).call(this), i(this, _i).clear(), (t = i(this, Fa)) == null || t.abort(), u(this, Fa, null), (e = i(this, dn)) == null || e.abort(), u(this, dn, null);
  }
}
Bl = new WeakMap(), wr = new WeakMap(), wd = new WeakMap(), vd = new WeakMap(), Sd = new WeakMap(), Ed = new WeakMap(), Cd = new WeakMap(), Da = new WeakMap(), vr = new WeakMap(), dn = new WeakMap(), Ia = new WeakMap(), _i = new WeakMap(), un = new WeakMap(), Fa = new WeakMap(), fn = new WeakMap(), Sr = new WeakMap(), Dt = new WeakSet(), aA = function(t) {
  var s, n;
  if ((s = i(this, vd)) != null && s.call(this))
    return;
  m(this, Dt, Vg).call(this, t);
  const e = i(this, _i);
  for (const {
    identifier: r
  } of t.changedTouches)
    e.add(r);
  if (e.size === 1) {
    m(this, Dt, jg).call(this);
    return;
  }
  if (!i(this, fn)) {
    u(this, fn, new AbortController());
    const r = AbortSignal.any([i(this, Ia), i(this, fn).signal]), a = i(this, Bl), o = {
      signal: r,
      capture: !1,
      passive: !1
    };
    a.addEventListener("touchmove", m(this, Dt, oA).bind(this), o);
    const l = m(this, Dt, lA).bind(this);
    a.addEventListener("touchend", l, o), a.addEventListener("touchcancel", l, o), o.capture = !0, a.addEventListener("pointerdown", te, o), a.addEventListener("pointermove", te, o), a.addEventListener("pointercancel", ry, o), a.addEventListener("pointerup", ry, o), (n = i(this, Sd)) == null || n.call(this);
  }
  u(this, vr, Ag(t)), m(this, Dt, Sf).call(this, t);
}, jg = function() {
  if (i(this, dn))
    return;
  const t = u(this, dn, new AbortController()), e = AbortSignal.any([i(this, Ia), t.signal]), s = i(this, Bl), n = {
    capture: !0,
    signal: e,
    passive: !1
  }, r = (a) => {
    var o;
    a.pointerType === "touch" && ((o = i(this, dn)) == null || o.abort(), u(this, dn, null));
  };
  s.addEventListener("pointerdown", (a) => {
    a.pointerType === "touch" && (te(a), r(a));
  }, n), s.addEventListener("pointerup", r, n), s.addEventListener("pointercancel", r, n);
}, Vg = function(t) {
  const e = i(this, _i);
  if (e.size === 0)
    return;
  const s = u(this, _i, /* @__PURE__ */ new Set());
  for (const {
    identifier: n
  } of t.touches)
    e.has(n) && s.add(n);
}, Wg = function(t) {
  const e = i(this, _i), s = [];
  for (const n of t.touches)
    e.has(n.identifier) && s.push(n);
  return s;
}, Sf = function(t) {
  var r;
  const e = m(this, Dt, Wg).call(this, t);
  if (e.length !== 2 || (r = i(this, wd)) != null && r.call(this)) {
    u(this, un, null);
    return;
  }
  const [s, n] = e;
  u(this, un, {
    touch0X: s.screenX,
    touch0Y: s.screenY,
    touch1X: n.screenX,
    touch1Y: n.screenY,
    panX: (s.clientX + n.clientX) / 2,
    panY: (s.clientY + n.clientY) / 2,
    screenPanX: (s.screenX + n.screenX) / 2,
    screenPanY: (s.screenY + n.screenY) / 2
  });
}, oA = function(t) {
  var O, z, Nt, St;
  if (!i(this, un))
    return;
  const e = m(this, Dt, Wg).call(this, t);
  if (e.length !== 2)
    return;
  const s = i(this, vr);
  if (u(this, vr, Ag(t)), !i(this, vr))
    return;
  if (!s) {
    m(this, Dt, Sf).call(this, t);
    return;
  }
  const [n, r] = e, {
    screenX: a,
    screenY: o
  } = n, {
    screenX: l,
    screenY: h
  } = r, c = i(this, un), {
    touch0X: d,
    touch0Y: f,
    touch1X: b,
    touch1Y: y,
    panX: A,
    panY: w
  } = c, v = b - d, S = y - f, E = l - a, C = h - o, x = (n.clientX + r.clientX) / 2, T = (n.clientY + r.clientY) / 2;
  c.panX = x, c.panY = T;
  const k = x - A, M = T - w, P = (a + l) / 2, D = (o + h) / 2, H = Math.hypot(P - c.screenPanX, D - c.screenPanY);
  c.screenPanX = P, c.screenPanY = D;
  const Y = Math.hypot(E, C), Q = Math.hypot(v, S), K = i(this, wr) ? this.MIN_TOUCH_DISTANCE_TO_SCALE : this.MIN_TOUCH_DISTANCE_TO_PINCH + 2 * H;
  if (Y < ay || Q < ay || Math.abs(Q - Y) <= K) {
    (k || M) && ((O = i(this, Da)) == null || O.call(this, k, M));
    return;
  }
  c.touch0X = a, c.touch0Y = o, c.touch1X = l, c.touch1Y = h;
  const et = Math.sign(Y - Q);
  if (!i(this, wr)) {
    u(this, wr, !0), u(this, Sr, et), (k || M) && ((z = i(this, Da)) == null || z.call(this, k, M));
    return;
  }
  if (i(this, Sr)) {
    const Ss = i(this, Sr);
    if (u(this, Sr, 0), et !== Ss && Math.abs(Y - Q) <= 2 * H) {
      u(this, wr, !1), (k || M) && ((Nt = i(this, Da)) == null || Nt.call(this, k, M));
      return;
    }
  }
  (St = i(this, Ed)) == null || St.call(this, [A, w], Q, Y, k, M);
}, lA = function(t) {
  if (m(this, Dt, Vg).call(this, t), i(this, _i).size >= 2) {
    m(this, Dt, Sf).call(this, t);
    return;
  }
  const e = !!i(this, un);
  m(this, Dt, Xg).call(this), i(this, _i).size === 1 && m(this, Dt, jg).call(this), e && Ag(t);
}, Xg = function() {
  var t;
  u(this, un, null), u(this, wr, !1), u(this, Sr, 0), u(this, vr, !1), i(this, fn) && (i(this, fn).abort(), u(this, fn, null), (t = i(this, Cd)) == null || t.call(this));
};
var La, Ws, kt, ct, pn, Hl, Er, xd, de, Oa, gn, Ls, Cr, Td, Ra, es, _d, Na, mn, ki, Ul, zl, Os, xr, kd, wp, G, Yg, Gl, Ef, Cf, hA, cA, Kg, xf, qg, dA, uA, fA, Qg, pA, Jg, Zg, gA, mA, bA, tm, xc, em;
const W = class W {
  constructor(t) {
    g(this, G);
    g(this, La, null);
    g(this, Ws, null);
    g(this, kt, null);
    g(this, ct, null);
    g(this, pn, null);
    g(this, Hl, !1);
    g(this, Er, null);
    g(this, xd, "");
    g(this, de, null);
    g(this, Oa, null);
    g(this, gn, null);
    g(this, Ls, null);
    g(this, Cr, null);
    g(this, Td, "");
    g(this, Ra, !1);
    g(this, es, null);
    g(this, _d, !1);
    g(this, Na, !1);
    g(this, mn, !1);
    g(this, ki, null);
    g(this, Ul, 0);
    g(this, zl, 0);
    g(this, Os, null);
    g(this, xr, null);
    _(this, "isSelected", !1);
    _(this, "_isCopy", !1);
    _(this, "_editToolbar", null);
    _(this, "_initialOptions", /* @__PURE__ */ Object.create(null));
    _(this, "_initialData", null);
    _(this, "_isVisible", !0);
    _(this, "_uiManager", null);
    _(this, "_focusEventsAllowed", !0);
    g(this, kd, !1);
    g(this, wp, W._zIndex++);
    this.parent = t.parent, this.id = t.id, this.width = this.height = null, this.pageIndex = t.parent.pageIndex, this.name = t.name, this.div = null, this._uiManager = t.uiManager, this.annotationElementId = null, this._willKeepAspectRatio = !1, this._initialOptions.isCentered = t.isCentered, this._structTreeParentId = null, this.annotationElementId = t.annotationElementId || null, this.creationDate = t.creationDate || /* @__PURE__ */ new Date(), this.modificationDate = t.modificationDate || null, this.canAddComment = !0;
    const {
      rotation: e,
      rawDims: {
        pageWidth: s,
        pageHeight: n,
        pageX: r,
        pageY: a
      }
    } = this.parent.viewport;
    this.rotation = e, this.pageRotation = (360 + e - this._uiManager.viewParameters.rotation) % 360, this.pageDimensions = [s, n], this.pageTranslation = [r, a];
    const [o, l] = this.parentDimensions;
    this.x = t.x / o, this.y = t.y / l, this.isAttachedToDOM = !1, this.deleted = !1;
  }
  static get _resizerKeyboardManager() {
    const t = W.prototype._resizeWithKeyboard, e = al.TRANSLATE_SMALL, s = al.TRANSLATE_BIG;
    return L(this, "_resizerKeyboardManager", new rl([[["ArrowLeft"], t, {
      args: [-e, 0]
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t, {
      args: [-s, 0]
    }], [["ArrowRight"], t, {
      args: [e, 0]
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t, {
      args: [s, 0]
    }], [["ArrowUp"], t, {
      args: [0, -e]
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t, {
      args: [0, -s]
    }], [["ArrowDown"], t, {
      args: [0, e]
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t, {
      args: [0, s]
    }], [["Escape"], W.prototype._stopResizingWithKeyboard]]));
  }
  updatePageIndex(t) {
    this.pageIndex = t;
  }
  get editorType() {
    return Object.getPrototypeOf(this).constructor._type;
  }
  get mode() {
    return Object.getPrototypeOf(this).constructor._editorType;
  }
  static get isDrawer() {
    return !1;
  }
  static get _defaultLineColor() {
    return L(this, "_defaultLineColor", this._colorManager.getHexCode("CanvasText"));
  }
  static deleteAnnotationElement(t) {
    const e = new zw({
      id: t._uiManager.getId(),
      parent: t.parent,
      uiManager: t._uiManager
    });
    e.annotationElementId = t.annotationElementId, e.deleted = !0, e._uiManager.addToAnnotationStorage(e);
  }
  static initialize(t, e) {
    if (W._l10n ?? (W._l10n = t), W._l10nAlert ?? (W._l10nAlert = Object.freeze({
      highlight: "pdfjs-editor-highlight-added-alert",
      freetext: "pdfjs-editor-freetext-added-alert",
      ink: "pdfjs-editor-ink-added-alert",
      stamp: "pdfjs-editor-stamp-added-alert",
      signature: "pdfjs-editor-signature-added-alert"
    })), W._l10nResizer ?? (W._l10nResizer = Object.freeze({
      topLeft: "pdfjs-editor-resizer-top-left",
      topMiddle: "pdfjs-editor-resizer-top-middle",
      topRight: "pdfjs-editor-resizer-top-right",
      middleRight: "pdfjs-editor-resizer-middle-right",
      bottomRight: "pdfjs-editor-resizer-bottom-right",
      bottomMiddle: "pdfjs-editor-resizer-bottom-middle",
      bottomLeft: "pdfjs-editor-resizer-bottom-left",
      middleLeft: "pdfjs-editor-resizer-middle-left"
    })), W._borderLineWidth !== -1)
      return;
    const s = getComputedStyle(document.documentElement);
    W._borderLineWidth = parseFloat(s.getPropertyValue("--outline-width")) || 0;
  }
  static updateDefaultParams(t, e) {
  }
  static get defaultPropertiesToUpdate() {
    return [];
  }
  static isHandlingMimeForPasting(t) {
    return !1;
  }
  static paste(t, e) {
    it("Not implemented");
  }
  get propertiesToUpdate() {
    return [];
  }
  get _isDraggable() {
    return i(this, kd);
  }
  set _isDraggable(t) {
    var e;
    u(this, kd, t), (e = this.div) == null || e.classList.toggle("draggable", t);
  }
  get uid() {
    return this.annotationElementId || this.id;
  }
  get isEnterHandled() {
    return !0;
  }
  center() {
    const [t, e] = this.pageDimensions;
    switch (this.parentRotation) {
      case 90:
        this.x -= this.height * e / (t * 2), this.y += this.width * t / (e * 2);
        break;
      case 180:
        this.x += this.width / 2, this.y += this.height / 2;
        break;
      case 270:
        this.x += this.height * e / (t * 2), this.y -= this.width * t / (e * 2);
        break;
      default:
        this.x -= this.width / 2, this.y -= this.height / 2;
        break;
    }
    this.fixAndSetPosition();
  }
  addCommands(t) {
    this._uiManager.addCommands(t);
  }
  get currentLayer() {
    return this._uiManager.currentLayer;
  }
  setInBackground() {
    this.div.style.zIndex = 0;
  }
  setInForeground() {
    this.div.style.zIndex = i(this, wp);
  }
  setParent(t) {
    var e;
    t !== null ? (this.pageIndex = t.pageIndex, this.pageDimensions = t.pageDimensions) : (m(this, G, xc).call(this), (e = i(this, Ls)) == null || e.remove(), u(this, Ls, null)), this.parent = t;
  }
  focusin(t) {
    this._focusEventsAllowed && (i(this, Ra) ? u(this, Ra, !1) : this.parent.setSelected(this));
  }
  focusout(t) {
    var s;
    if (!this._focusEventsAllowed || !this.isAttachedToDOM)
      return;
    const e = t.relatedTarget;
    e != null && e.closest(`#${this.id}`) || (t.preventDefault(), (s = this.parent) != null && s.isMultipleSelection || this.commitOrRemove());
  }
  commitOrRemove() {
    this.isEmpty() ? this.remove() : this.commit();
  }
  commit() {
    this.isInEditMode() && this.addToAnnotationStorage();
  }
  addToAnnotationStorage() {
    this._uiManager.addToAnnotationStorage(this);
  }
  setAt(t, e, s, n) {
    const [r, a] = this.parentDimensions;
    [s, n] = this.screenToPageTranslation(s, n), this.x = (t + s) / r, this.y = (e + n) / a, this.fixAndSetPosition();
  }
  _moveAfterPaste(t, e) {
    if (this.isClone) {
      delete this.isClone;
      return;
    }
    const [s, n] = this.parentDimensions;
    this.setAt(t * s, e * n, this.width * s, this.height * n), this._onTranslated();
  }
  translate(t, e) {
    m(this, G, Yg).call(this, this.parentDimensions, t, e);
  }
  translateInPage(t, e) {
    i(this, es) || u(this, es, [this.x, this.y, this.width, this.height]), m(this, G, Yg).call(this, this.pageDimensions, t, e), this.div.scrollIntoView({
      block: "nearest"
    });
  }
  translationDone() {
    this._onTranslated(this.x, this.y);
  }
  drag(t, e) {
    i(this, es) || u(this, es, [this.x, this.y, this.width, this.height]);
    const {
      div: s,
      parentDimensions: [n, r]
    } = this;
    if (this.x += t / n, this.y += e / r, this.parent && (this.x < 0 || this.x > 1 || this.y < 0 || this.y > 1)) {
      const {
        x: d,
        y: f
      } = this.div.getBoundingClientRect();
      this.parent.findNewParent(this, d, f) && (this.x -= Math.floor(this.x), this.y -= Math.floor(this.y));
    }
    let {
      x: a,
      y: o
    } = this;
    const [l, h] = this.getBaseTranslation();
    a += l, o += h;
    const {
      style: c
    } = s;
    c.left = `${(100 * a).toFixed(2)}%`, c.top = `${(100 * o).toFixed(2)}%`, this._onTranslating(a, o);
  }
  _onTranslating(t, e) {
  }
  _onTranslated(t, e) {
  }
  get _hasBeenMoved() {
    return !!i(this, es) && (i(this, es)[0] !== this.x || i(this, es)[1] !== this.y);
  }
  get _hasBeenResized() {
    return !!i(this, es) && (i(this, es)[2] !== this.width || i(this, es)[3] !== this.height);
  }
  getBaseTranslation() {
    const [t, e] = this.parentDimensions, {
      _borderLineWidth: s
    } = W, n = s / t, r = s / e;
    switch (this.rotation) {
      case 90:
        return [-n, r];
      case 180:
        return [n, r];
      case 270:
        return [n, -r];
      default:
        return [-n, -r];
    }
  }
  get _mustFixPosition() {
    return !0;
  }
  fixAndSetPosition(t = this.rotation) {
    var y, A;
    const {
      div: {
        style: e
      },
      pageDimensions: [s, n]
    } = this;
    let {
      x: r,
      y: a,
      width: o,
      height: l
    } = this;
    o *= s, l *= n, r *= s, a *= n;
    let h = 0, c = 0;
    const d = this._uiManager._keepToolbarInPage && ((y = this._editToolbar) == null ? void 0 : y.div);
    if (d != null && d.offsetParent) {
      const w = this.parentScale, v = d.offsetLeft + this.div.clientLeft, S = d.offsetTop + this.div.clientTop, E = Math.min(0, v) / w, C = Math.min(0, S) / w, x = o - E + Math.max(0, v + d.offsetWidth - this.div.offsetWidth) / w, T = l - C + Math.max(0, S + d.offsetHeight - this.div.offsetHeight) / w;
      x <= (t % 180 ? n : s) && (o = x, h = E), T <= (t % 180 ? s : n) && (l = T, c = C), [h, c] = m(A = W, Gl, Ef).call(A, h, c, t), r += h, a += c;
    }
    if (this._mustFixPosition)
      switch (t) {
        case 0:
          r = vt(r, 0, s - o), a = vt(a, 0, n - l);
          break;
        case 90:
          r = vt(r, 0, s - l), a = vt(a, o, n);
          break;
        case 180:
          r = vt(r, o, s), a = vt(a, l, n);
          break;
        case 270:
          r = vt(r, l, s), a = vt(a, 0, n - o);
          break;
      }
    this.x = r = (r - h) / s, this.y = a = (a - c) / n;
    const [f, b] = this.getBaseTranslation();
    r += f, a += b, e.left = `${(100 * r).toFixed(2)}%`, e.top = `${(100 * a).toFixed(2)}%`, this.moveInDOM();
  }
  screenToPageTranslation(t, e) {
    var s;
    return m(s = W, Gl, Ef).call(s, t, e, this.parentRotation);
  }
  pageTranslationToScreen(t, e) {
    var s;
    return m(s = W, Gl, Ef).call(s, t, e, 360 - this.parentRotation);
  }
  get parentScale() {
    return this._uiManager.viewParameters.realScale;
  }
  get parentRotation() {
    return (this._uiManager.viewParameters.rotation + this.pageRotation) % 360;
  }
  get parentDimensions() {
    const {
      parentScale: t,
      pageDimensions: [e, s]
    } = this;
    return [e * t, s * t];
  }
  setDims() {
    const {
      div: {
        style: t
      },
      width: e,
      height: s
    } = this;
    t.width = `${(100 * e).toFixed(2)}%`, t.height = `${(100 * s).toFixed(2)}%`;
  }
  getInitialTranslation() {
    return [0, 0];
  }
  _onResized() {
  }
  static _round(t) {
    return Math.round(t * 1e4) / 1e4;
  }
  _onResizing() {
  }
  altTextFinish() {
    var t;
    (t = i(this, kt)) == null || t.finish();
  }
  get toolbarButtons() {
    return null;
  }
  async addEditToolbar() {
    if (this._editToolbar || i(this, Na))
      return this._editToolbar;
    this._editToolbar = new Og(this), this.div.append(this._editToolbar.render());
    const {
      toolbarButtons: t
    } = this;
    if (t)
      for (const [e, s] of t)
        await this._editToolbar.addButton(e, s);
    return this.hasComment || this._editToolbar.addButton("comment", this.addCommentButton()), this._editToolbar.addButton("delete"), this._editToolbar;
  }
  addCommentButtonInToolbar() {
    var t;
    (t = this._editToolbar) == null || t.addButtonBefore("comment", this.addCommentButton(), ".deleteButton");
  }
  removeCommentButtonFromToolbar() {
    var t;
    (t = this._editToolbar) == null || t.removeButton("comment");
  }
  removeEditToolbar() {
    var t, e;
    (t = this._editToolbar) == null || t.remove(), this._editToolbar = null, (e = i(this, kt)) == null || e.destroy();
  }
  addContainer(t) {
    var s;
    const e = (s = this._editToolbar) == null ? void 0 : s.div;
    e ? e.before(t) : this.div.append(t);
  }
  getClientDimensions() {
    return this.div.getBoundingClientRect();
  }
  createAltText() {
    return i(this, kt) || (hp.initialize(W._l10n), u(this, kt, new hp(this)), i(this, La) && (i(this, kt).data = i(this, La), u(this, La, null))), i(this, kt);
  }
  get altTextData() {
    var t;
    return (t = i(this, kt)) == null ? void 0 : t.data;
  }
  set altTextData(t) {
    i(this, kt) && (i(this, kt).data = t);
  }
  get guessedAltText() {
    var t;
    return (t = i(this, kt)) == null ? void 0 : t.guessedText;
  }
  async setGuessedAltText(t) {
    var e;
    await ((e = i(this, kt)) == null ? void 0 : e.setGuessedText(t));
  }
  serializeAltText(t) {
    var e;
    return (e = i(this, kt)) == null ? void 0 : e.serialize(t);
  }
  hasAltText() {
    return !!i(this, kt) && !i(this, kt).isEmpty();
  }
  hasAltTextData() {
    var t;
    return ((t = i(this, kt)) == null ? void 0 : t.hasData()) ?? !1;
  }
  focusCommentButton() {
    var t;
    (t = i(this, ct)) == null || t.focusButton();
  }
  addCommentButton() {
    return this.canAddComment ? i(this, ct) || u(this, ct, new lf(this)) : null;
  }
  addStandaloneCommentButton() {
    if (this._uiManager.hasCommentManager()) {
      if (i(this, pn)) {
        this._uiManager.isEditingMode() && i(this, pn).classList.remove("hidden");
        return;
      }
      this.hasComment && (u(this, pn, i(this, ct).renderForStandalone()), this.div.append(i(this, pn)));
    }
  }
  removeStandaloneCommentButton() {
    i(this, ct).removeStandaloneCommentButton(), u(this, pn, null);
  }
  hideStandaloneCommentButton() {
    var t;
    (t = i(this, pn)) == null || t.classList.add("hidden");
  }
  get comment() {
    if (!i(this, ct))
      return null;
    const {
      data: {
        richText: t,
        text: e,
        date: s,
        deleted: n
      }
    } = i(this, ct);
    return {
      text: e,
      richText: t,
      date: s,
      deleted: n,
      color: this.getNonHCMColor(),
      opacity: this.opacity ?? 1
    };
  }
  set comment(t) {
    i(this, ct) || u(this, ct, new lf(this)), typeof t == "object" && t !== null ? i(this, ct).restoreData(t) : i(this, ct).data = t, this.hasComment ? (this.removeCommentButtonFromToolbar(), this.addStandaloneCommentButton(), this._uiManager.updateComment(this)) : (this.addCommentButtonInToolbar(), this.removeStandaloneCommentButton(), this._uiManager.removeComment(this));
  }
  setCommentData({
    comment: t,
    popupRef: e,
    richText: s
  }) {
    if (!e || (i(this, ct) || u(this, ct, new lf(this)), i(this, ct).setInitialText(t, s), !this.annotationElementId))
      return;
    const n = this._uiManager.getAndRemoveDataFromAnnotationStorage(this.annotationElementId);
    n && this.updateFromAnnotationLayer(n);
  }
  get hasEditedComment() {
    var t;
    return (t = i(this, ct)) == null ? void 0 : t.hasBeenEdited();
  }
  get hasDeletedComment() {
    var t;
    return (t = i(this, ct)) == null ? void 0 : t.isDeleted();
  }
  get hasComment() {
    return !!i(this, ct) && !i(this, ct).isEmpty() && !i(this, ct).isDeleted();
  }
  async editComment(t) {
    i(this, ct) || u(this, ct, new lf(this)), i(this, ct).edit(t);
  }
  toggleComment(t, e = void 0) {
    this.hasComment && this._uiManager.toggleComment(this, t, e);
  }
  setSelectedCommentButton(t) {
    i(this, ct).setSelectedButton(t);
  }
  addComment(t) {
    if (this.hasEditedComment) {
      const [, , , n] = t.rect, [r] = this.pageDimensions, [a] = this.pageTranslation, o = a + r + 1, l = n - 100, h = o + 180;
      t.popup = {
        contents: this.comment.text,
        deleted: this.comment.deleted,
        rect: [o, l, h, n]
      };
    }
  }
  updateFromAnnotationLayer({
    popup: {
      contents: t,
      deleted: e
    }
  }) {
    i(this, ct).data = e ? null : t;
  }
  get parentBoundingClientRect() {
    return this.parent.boundingClientRect;
  }
  render() {
    var a;
    const t = this.div = document.createElement("div");
    t.setAttribute("data-editor-rotation", (360 - this.rotation) % 360), t.className = this.name, t.setAttribute("id", this.id), t.tabIndex = i(this, Hl) ? -1 : 0, t.setAttribute("role", "application"), this.defaultL10nId && t.setAttribute("data-l10n-id", this.defaultL10nId), this._isVisible || t.classList.add("hidden"), this.setInForeground(), m(this, G, Jg).call(this);
    const [e, s] = this.parentDimensions;
    this.parentRotation % 180 !== 0 && (t.style.maxWidth = `${(100 * s / e).toFixed(2)}%`, t.style.maxHeight = `${(100 * e / s).toFixed(2)}%`);
    const [n, r] = this.getInitialTranslation();
    return this.translate(n, r), jy(this, t, ["keydown", "pointerdown", "dblclick"]), m(this, G, Zg).call(this), this.addStandaloneCommentButton(), (a = this._uiManager._editorUndoBar) == null || a.hide(), t;
  }
  pointerdown(t) {
    const {
      isMac: e
    } = ot.platform;
    if (t.button !== 0 || t.ctrlKey && e) {
      t.preventDefault();
      return;
    }
    if (u(this, Ra, !0), this._isDraggable) {
      m(this, G, pA).call(this, t);
      return;
    }
    m(this, G, Qg).call(this, t);
  }
  _onStartDragging() {
  }
  _onStopDragging() {
  }
  moveInDOM() {
    i(this, ki) && clearTimeout(i(this, ki)), u(this, ki, setTimeout(() => {
      var t;
      u(this, ki, null), (t = this.parent) == null || t.moveEditorInDOM(this);
    }, 0));
  }
  _setParentAndPosition(t, e, s) {
    t.changeParent(this), this.x = e, this.y = s, this.fixAndSetPosition(), this._onTranslated();
  }
  getRect(t, e, s = this.rotation) {
    const n = this.parentScale, [r, a] = this.pageDimensions, [o, l] = this.pageTranslation, h = t / n, c = e / n, d = this.x * r, f = this.y * a, b = this.width * r, y = this.height * a;
    switch (s) {
      case 0:
        return [d + h + o, a - f - c - y + l, d + h + b + o, a - f - c + l];
      case 90:
        return [d + c + o, a - f + h + l, d + c + y + o, a - f + h + b + l];
      case 180:
        return [d - h - b + o, a - f + c + l, d - h + o, a - f + c + y + l];
      case 270:
        return [d - c - y + o, a - f - h - b + l, d - c + o, a - f - h + l];
      default:
        throw new Error("Invalid rotation");
    }
  }
  getRectInCurrentCoords(t, e) {
    const [s, n, r, a] = t, o = r - s, l = a - n;
    switch (this.rotation) {
      case 0:
        return [s, e - a, o, l];
      case 90:
        return [s, e - n, l, o];
      case 180:
        return [r, e - n, o, l];
      case 270:
        return [r, e - a, l, o];
      default:
        throw new Error("Invalid rotation");
    }
  }
  getPDFRect() {
    return this.getRect(0, 0);
  }
  getNonHCMColor() {
    return this.color && W._colorManager.convert(this._uiManager.getNonHCMColor(this.color));
  }
  onUpdatedColor() {
    var t;
    (t = i(this, ct)) == null || t.onUpdatedColor();
  }
  getData() {
    const {
      comment: {
        text: t,
        color: e,
        date: s,
        opacity: n,
        deleted: r,
        richText: a
      },
      uid: o,
      pageIndex: l,
      creationDate: h,
      modificationDate: c
    } = this;
    return {
      id: o,
      pageIndex: l,
      rect: this.getPDFRect(),
      richText: a,
      contentsObj: {
        str: t
      },
      creationDate: h,
      modificationDate: s || c,
      popupRef: !r,
      color: e,
      opacity: n
    };
  }
  onceAdded(t) {
  }
  isEmpty() {
    return !1;
  }
  enableEditMode() {
    return this.isInEditMode() ? !1 : (this.parent.setEditingState(!1), u(this, Na, !0), !0);
  }
  disableEditMode() {
    return this.isInEditMode() ? (this.parent.setEditingState(!0), u(this, Na, !1), !0) : !1;
  }
  isInEditMode() {
    return i(this, Na);
  }
  shouldGetKeyboardEvents() {
    return i(this, mn);
  }
  needsToBeRebuilt() {
    return this.div && !this.isAttachedToDOM;
  }
  get isOnScreen() {
    const {
      top: t,
      left: e,
      bottom: s,
      right: n
    } = this.getClientDimensions(), {
      innerHeight: r,
      innerWidth: a
    } = window;
    return e < a && n > 0 && t < r && s > 0;
  }
  rebuild() {
    m(this, G, Jg).call(this), m(this, G, Zg).call(this);
  }
  rotate(t) {
  }
  resize() {
  }
  serializeDeleted() {
    var t;
    return {
      id: this.annotationElementId,
      deleted: !0,
      pageIndex: this.pageIndex,
      popupRef: ((t = this._initialData) == null ? void 0 : t.popupRef) || ""
    };
  }
  serialize(t = !1, e = null) {
    var s;
    return {
      annotationType: this.mode,
      pageIndex: this.pageIndex,
      rect: this.getPDFRect(),
      rotation: this.rotation,
      structTreeParentId: this._structTreeParentId,
      popupRef: ((s = this._initialData) == null ? void 0 : s.popupRef) || ""
    };
  }
  static async deserialize(t, e, s) {
    const n = new this.prototype.constructor({
      parent: e,
      id: s.getId(),
      uiManager: s,
      annotationElementId: t.annotationElementId,
      creationDate: t.creationDate,
      modificationDate: t.modificationDate
    });
    n.rotation = t.rotation, u(n, La, t.accessibilityData), n._isCopy = t.isCopy || !1;
    const [r, a] = n.pageDimensions, [o, l, h, c] = n.getRectInCurrentCoords(t.rect, a);
    return n.x = o / r, n.y = l / a, n.width = h / r, n.height = c / a, n;
  }
  get hasBeenModified() {
    return !!this.annotationElementId && (this.deleted || this.serialize() !== null);
  }
  remove() {
    var t, e, s;
    if ((t = i(this, Cr)) == null || t.abort(), u(this, Cr, null), this.isEmpty() || this.commit(), (e = i(this, xr)) == null || e.destroy(), u(this, xr, null), this.parent ? this.parent.remove(this) : this._uiManager.removeEditor(this), this.hideCommentPopup(), i(this, ki) && (clearTimeout(i(this, ki)), u(this, ki, null)), m(this, G, xc).call(this), this.removeEditToolbar(), i(this, Os)) {
      for (const n of i(this, Os).values())
        clearTimeout(n);
      u(this, Os, null);
    }
    this.parent = null, (s = i(this, Ls)) == null || s.remove(), u(this, Ls, null);
  }
  get isResizable() {
    return !1;
  }
  makeResizable() {
    this.isResizable && (m(this, G, hA).call(this), i(this, de).classList.remove("hidden"));
  }
  get toolbarPosition() {
    return null;
  }
  get commentButtonPosition() {
    return this._uiManager.direction === "ltr" ? [1, 0] : [0, 0];
  }
  get commentButtonPositionInPage() {
    const {
      commentButtonPosition: [t, e]
    } = this, [s, n, r, a] = this.getPDFRect();
    return [W._round(s + (r - s) * t), W._round(n + (a - n) * (1 - e))];
  }
  get commentButtonColor() {
    return this._uiManager.makeCommentColor(this.getNonHCMColor(), this.opacity);
  }
  get commentPopupPosition() {
    return i(this, ct).commentPopupPositionInLayer;
  }
  set commentPopupPosition(t) {
    i(this, ct).commentPopupPositionInLayer = t;
  }
  hasDefaultPopupPosition() {
    return i(this, ct).hasDefaultPopupPosition();
  }
  get commentButtonWidth() {
    return i(this, ct).commentButtonWidth;
  }
  get elementBeforePopup() {
    return this.div;
  }
  setCommentButtonStates(t) {
    var e;
    (e = i(this, ct)) == null || e.setCommentButtonStates(t);
  }
  keydown(t) {
    if (!this.isResizable || t.target !== this.div || t.key !== "Enter")
      return;
    this._uiManager.setSelected(this), u(this, gn, {
      savedX: this.x,
      savedY: this.y,
      savedWidth: this.width,
      savedHeight: this.height
    });
    const e = i(this, de).children;
    if (!i(this, Ws)) {
      u(this, Ws, Array.from(e));
      const a = m(this, G, gA).bind(this), o = m(this, G, mA).bind(this), l = this._uiManager._signal;
      for (const h of i(this, Ws)) {
        const c = h.getAttribute("data-resizer-name");
        h.setAttribute("role", "spinbutton"), h.addEventListener("keydown", a, {
          signal: l
        }), h.addEventListener("blur", o, {
          signal: l
        }), h.addEventListener("focus", m(this, G, bA).bind(this, c), {
          signal: l
        }), h.setAttribute("data-l10n-id", W._l10nResizer[c]);
      }
    }
    const s = i(this, Ws)[0];
    let n = 0;
    for (const a of e) {
      if (a === s)
        break;
      n++;
    }
    const r = (360 - this.rotation + this.parentRotation) % 360 / 90 * (i(this, Ws).length / 4);
    if (r !== n) {
      if (r < n)
        for (let o = 0; o < n - r; o++)
          i(this, de).append(i(this, de).firstElementChild);
      else if (r > n)
        for (let o = 0; o < r - n; o++)
          i(this, de).firstElementChild.before(i(this, de).lastElementChild);
      let a = 0;
      for (const o of e) {
        const h = i(this, Ws)[a++].getAttribute("data-resizer-name");
        o.setAttribute("data-l10n-id", W._l10nResizer[h]);
      }
    }
    m(this, G, tm).call(this, 0), u(this, mn, !0), i(this, de).firstElementChild.focus({
      focusVisible: !0
    }), t.preventDefault(), t.stopImmediatePropagation();
  }
  _resizeWithKeyboard(t, e) {
    i(this, mn) && m(this, G, qg).call(this, i(this, Td), {
      deltaX: t,
      deltaY: e,
      fromKeyboard: !0
    });
  }
  _stopResizingWithKeyboard() {
    m(this, G, xc).call(this), this.div.focus();
  }
  select() {
    var t, e;
    if (this.isSelected && this._editToolbar) {
      this._editToolbar.show();
      return;
    }
    if (this.isSelected = !0, this.makeResizable(), (t = this.div) == null || t.classList.add("selectedEditor"), !this._editToolbar) {
      this.addEditToolbar().then(() => {
        var s;
        (s = this.div) != null && s.classList.contains("selectedEditor") && m(this, G, em).call(this);
      });
      return;
    }
    m(this, G, em).call(this), (e = i(this, kt)) == null || e.toggleAltTextBadge(!1);
  }
  focus() {
    this.div && !this.div.contains(document.activeElement) && setTimeout(() => {
      var t;
      return (t = this.div) == null ? void 0 : t.focus({
        preventScroll: !0
      });
    }, 0);
  }
  unselect() {
    var t, e, s, n, r;
    this.isSelected && (this.isSelected = !1, (t = i(this, de)) == null || t.classList.add("hidden"), (e = this.div) == null || e.classList.remove("selectedEditor"), (s = this.div) != null && s.contains(document.activeElement) && this._uiManager.currentLayer.div.focus({
      preventScroll: !0
    }), (n = this._editToolbar) == null || n.hide(), (r = i(this, kt)) == null || r.toggleAltTextBadge(!0), this.hideCommentPopup());
  }
  hideCommentPopup() {
    this.hasComment && this._uiManager.toggleComment(null);
  }
  updateParams(t, e) {
  }
  disableEditing() {
  }
  enableEditing() {
  }
  get canChangeContent() {
    return !1;
  }
  enterInEditMode() {
    this.canChangeContent && (this.enableEditMode(), this.div.focus());
  }
  dblclick(t) {
    t.target.nodeName !== "BUTTON" && (this.enterInEditMode(), this.parent.updateToolbar({
      mode: this.constructor._editorType,
      editId: this.uid
    }));
  }
  getElementForAltText() {
    return this.div;
  }
  get contentDiv() {
    return this.div;
  }
  get isEditing() {
    return i(this, _d);
  }
  set isEditing(t) {
    u(this, _d, t), this.parent && (t ? (this.parent.setSelected(this), this.parent.setActiveEditor(this)) : this.parent.setActiveEditor(null));
  }
  static get MIN_SIZE() {
    return 16;
  }
  static canCreateNewEmptyEditor() {
    return !0;
  }
  get telemetryInitialData() {
    return {
      action: "added"
    };
  }
  get telemetryFinalData() {
    return null;
  }
  _reportTelemetry(t, e = !1) {
    if (e) {
      i(this, Os) || u(this, Os, /* @__PURE__ */ new Map());
      const {
        action: s
      } = t;
      let n = i(this, Os).get(s);
      n && clearTimeout(n), n = setTimeout(() => {
        this._reportTelemetry(t), i(this, Os).delete(s), i(this, Os).size === 0 && u(this, Os, null);
      }, W._telemetryTimeout), i(this, Os).set(s, n);
      return;
    }
    t.type || (t.type = this.editorType), this._uiManager._eventBus.dispatch("reporttelemetry", {
      source: this,
      details: {
        type: "editing",
        data: t
      }
    });
  }
  show(t = this._isVisible) {
    this.div.classList.toggle("hidden", !t), this._isVisible = t;
  }
  enable() {
    this.div && (this.div.tabIndex = 0), u(this, Hl, !1);
  }
  disable() {
    this.div && (this.div.tabIndex = -1), u(this, Hl, !0);
  }
  updateFakeAnnotationElement(t) {
    if (!i(this, Ls) && !this.deleted) {
      u(this, Ls, t.addFakeAnnotation(this));
      return;
    }
    if (this.deleted) {
      i(this, Ls).remove(), u(this, Ls, null);
      return;
    }
    (this.hasEditedComment || this._hasBeenMoved || this._hasBeenResized) && i(this, Ls).updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    });
  }
  renderAnnotationElement(t) {
    if (this.deleted)
      return t.hide(), null;
    let e = t.container.querySelector(".annotationContent");
    if (!e)
      e = document.createElement("div"), e.classList.add("annotationContent", this.editorType), t.container.prepend(e);
    else if (e.nodeName === "CANVAS") {
      const s = e;
      e = document.createElement("div"), e.classList.add("annotationContent", this.editorType), s.before(e);
    }
    return e;
  }
  resetAnnotationElement(t) {
    const {
      firstElementChild: e
    } = t.container;
    (e == null ? void 0 : e.nodeName) === "DIV" && e.classList.contains("annotationContent") && e.remove();
  }
};
La = new WeakMap(), Ws = new WeakMap(), kt = new WeakMap(), ct = new WeakMap(), pn = new WeakMap(), Hl = new WeakMap(), Er = new WeakMap(), xd = new WeakMap(), de = new WeakMap(), Oa = new WeakMap(), gn = new WeakMap(), Ls = new WeakMap(), Cr = new WeakMap(), Td = new WeakMap(), Ra = new WeakMap(), es = new WeakMap(), _d = new WeakMap(), Na = new WeakMap(), mn = new WeakMap(), ki = new WeakMap(), Ul = new WeakMap(), zl = new WeakMap(), Os = new WeakMap(), xr = new WeakMap(), kd = new WeakMap(), wp = new WeakMap(), G = new WeakSet(), Yg = function([t, e], s, n) {
  [s, n] = this.screenToPageTranslation(s, n), this.x += s / t, this.y += n / e, this._onTranslating(this.x, this.y), this.fixAndSetPosition();
}, Gl = new WeakSet(), Ef = function(t, e, s) {
  switch (s) {
    case 90:
      return [e, -t];
    case 180:
      return [-t, -e];
    case 270:
      return [-e, t];
    default:
      return [t, e];
  }
}, Cf = function(t) {
  switch (t) {
    case 90: {
      const [e, s] = this.pageDimensions;
      return [0, -e / s, s / e, 0];
    }
    case 180:
      return [-1, 0, 0, -1];
    case 270: {
      const [e, s] = this.pageDimensions;
      return [0, e / s, -s / e, 0];
    }
    default:
      return [1, 0, 0, 1];
  }
}, hA = function() {
  if (i(this, de))
    return;
  u(this, de, document.createElement("div")), i(this, de).classList.add("resizers");
  const t = this._willKeepAspectRatio ? ["topLeft", "topRight", "bottomRight", "bottomLeft"] : ["topLeft", "topMiddle", "topRight", "middleRight", "bottomRight", "bottomMiddle", "bottomLeft", "middleLeft"], e = this._uiManager._signal;
  for (const s of t) {
    const n = document.createElement("div");
    i(this, de).append(n), n.classList.add("resizer", s), n.setAttribute("data-resizer-name", s), n.addEventListener("pointerdown", m(this, G, cA).bind(this, s), {
      signal: e
    }), n.addEventListener("contextmenu", di, {
      signal: e
    }), n.tabIndex = -1;
  }
  this.div.prepend(i(this, de));
}, cA = function(t, e) {
  var c;
  e.preventDefault();
  const {
    isMac: s
  } = ot.platform;
  if (e.button !== 0 || e.ctrlKey && s)
    return;
  (c = i(this, kt)) == null || c.toggle(!1);
  const n = this._isDraggable;
  this._isDraggable = !1, u(this, Oa, [e.screenX, e.screenY]);
  const r = new AbortController(), a = this._uiManager.combinedSignal(r);
  this.parent.togglePointerEvents(!1), window.addEventListener("pointermove", m(this, G, qg).bind(this, t), {
    passive: !0,
    capture: !0,
    signal: a
  }), window.addEventListener("touchmove", te, {
    passive: !1,
    signal: a
  }), window.addEventListener("contextmenu", di, {
    signal: a
  }), u(this, gn, {
    savedX: this.x,
    savedY: this.y,
    savedWidth: this.width,
    savedHeight: this.height
  });
  const o = this.parent.div.style.cursor, l = this.div.style.cursor;
  this.div.style.cursor = this.parent.div.style.cursor = window.getComputedStyle(e.target).cursor;
  const h = () => {
    var d;
    r.abort(), this.parent.togglePointerEvents(!0), (d = i(this, kt)) == null || d.toggle(!0), this._isDraggable = n, this.parent.div.style.cursor = o, this.div.style.cursor = l, m(this, G, xf).call(this);
  };
  window.addEventListener("pointerup", h, {
    signal: a
  }), window.addEventListener("blur", h, {
    signal: a
  });
}, Kg = function(t, e, s, n) {
  this.width = s, this.height = n, this.x = t, this.y = e, this.setDims(), this.fixAndSetPosition(), this._onResized();
}, xf = function() {
  if (!i(this, gn))
    return;
  const {
    savedX: t,
    savedY: e,
    savedWidth: s,
    savedHeight: n
  } = i(this, gn);
  u(this, gn, null);
  const r = this.x, a = this.y, o = this.width, l = this.height;
  r === t && a === e && o === s && l === n || this.addCommands({
    cmd: m(this, G, Kg).bind(this, r, a, o, l),
    undo: m(this, G, Kg).bind(this, t, e, s, n),
    mustExec: !0
  });
}, qg = function(t, e) {
  const [s, n] = this.parentDimensions, r = this.x, a = this.y, o = this.width, l = this.height, h = W.MIN_SIZE / s, c = W.MIN_SIZE / n, d = m(this, G, Cf).call(this, this.rotation), f = (O, z) => [d[0] * O + d[2] * z, d[1] * O + d[3] * z], b = m(this, G, Cf).call(this, 360 - this.rotation), y = (O, z) => [b[0] * O + b[2] * z, b[1] * O + b[3] * z];
  let A, w, v = !1, S = !1;
  switch (t) {
    case "topLeft":
      v = !0, A = (O, z) => [0, 0], w = (O, z) => [O, z];
      break;
    case "topMiddle":
      A = (O, z) => [O / 2, 0], w = (O, z) => [O / 2, z];
      break;
    case "topRight":
      v = !0, A = (O, z) => [O, 0], w = (O, z) => [0, z];
      break;
    case "middleRight":
      S = !0, A = (O, z) => [O, z / 2], w = (O, z) => [0, z / 2];
      break;
    case "bottomRight":
      v = !0, A = (O, z) => [O, z], w = (O, z) => [0, 0];
      break;
    case "bottomMiddle":
      A = (O, z) => [O / 2, z], w = (O, z) => [O / 2, 0];
      break;
    case "bottomLeft":
      v = !0, A = (O, z) => [0, z], w = (O, z) => [O, 0];
      break;
    case "middleLeft":
      S = !0, A = (O, z) => [0, z / 2], w = (O, z) => [O, z / 2];
      break;
  }
  const E = A(o, l), C = w(o, l);
  let x = f(...C);
  const T = W._round(r + x[0]), k = W._round(a + x[1]);
  let M = 1, P = 1, D, H;
  if (e.fromKeyboard)
    ({
      deltaX: D,
      deltaY: H
    } = e);
  else {
    const {
      screenX: O,
      screenY: z
    } = e, [Nt, St] = i(this, Oa);
    [D, H] = this.screenToPageTranslation(O - Nt, z - St), i(this, Oa)[0] = O, i(this, Oa)[1] = z;
  }
  if ([D, H] = y(D / s, H / n), v) {
    const O = Math.hypot(o, l);
    M = P = Math.max(Math.min(Math.hypot(C[0] - E[0] - D, C[1] - E[1] - H) / O, 1 / o, 1 / l), h / o, c / l);
  } else S ? M = vt(Math.abs(C[0] - E[0] - D), h, 1) / o : P = vt(Math.abs(C[1] - E[1] - H), c, 1) / l;
  const Y = W._round(o * M), Q = W._round(l * P);
  x = f(...w(Y, Q));
  const K = T - x[0], et = k - x[1];
  i(this, es) || u(this, es, [this.x, this.y, this.width, this.height]), this.width = Y, this.height = Q, this.x = K, this.y = et, this.setDims(), this.fixAndSetPosition(), this._onResizing();
}, dA = function() {
  var t;
  u(this, gn, {
    savedX: this.x,
    savedY: this.y,
    savedWidth: this.width,
    savedHeight: this.height
  }), (t = i(this, kt)) == null || t.toggle(!1), this.parent.togglePointerEvents(!1);
}, uA = function(t, e, s) {
  let r = 0.7 * (s / e) + 1 - 0.7;
  if (r === 1)
    return;
  const a = m(this, G, Cf).call(this, this.rotation), o = (T, k) => [a[0] * T + a[2] * k, a[1] * T + a[3] * k], [l, h] = this.parentDimensions, c = this.x, d = this.y, f = this.width, b = this.height, y = W.MIN_SIZE / l, A = W.MIN_SIZE / h;
  r = Math.max(Math.min(r, 1 / f, 1 / b), y / f, A / b);
  const w = W._round(f * r), v = W._round(b * r);
  if (w === f && v === b)
    return;
  i(this, es) || u(this, es, [c, d, f, b]);
  const S = o(f / 2, b / 2), E = W._round(c + S[0]), C = W._round(d + S[1]), x = o(w / 2, v / 2);
  this.x = E - x[0], this.y = C - x[1], this.width = w, this.height = v, this.setDims(), this.fixAndSetPosition(), this._onResizing();
}, fA = function() {
  var t;
  (t = i(this, kt)) == null || t.toggle(!0), this.parent.togglePointerEvents(!0), m(this, G, xf).call(this);
}, Qg = function(t) {
  const {
    isMac: e
  } = ot.platform;
  t.ctrlKey && !e || t.shiftKey || t.metaKey && e ? this.parent.toggleSelected(this) : this.parent.setSelected(this);
}, pA = function(t) {
  const {
    isSelected: e
  } = this;
  this._uiManager.setUpDragSession();
  let s = !1;
  const n = new AbortController(), r = this._uiManager.combinedSignal(n), a = {
    capture: !0,
    passive: !1,
    signal: r
  }, o = (h) => {
    n.abort(), u(this, Er, null), u(this, Ra, !1), this._uiManager.endDragSession() || m(this, G, Qg).call(this, h), s && this._onStopDragging();
  };
  e && (u(this, Ul, t.clientX), u(this, zl, t.clientY), u(this, Er, t.pointerId), u(this, xd, t.pointerType), window.addEventListener("pointermove", (h) => {
    s || (s = !0, this._uiManager.toggleComment(this, !0, !1), this._onStartDragging());
    const {
      clientX: c,
      clientY: d,
      pointerId: f
    } = h;
    if (f !== i(this, Er)) {
      te(h);
      return;
    }
    const [b, y] = this.screenToPageTranslation(c - i(this, Ul), d - i(this, zl));
    u(this, Ul, c), u(this, zl, d), this._uiManager.dragSelectedEditors(b, y), this.div.scrollIntoView({
      block: "nearest"
    });
  }, a), window.addEventListener("touchmove", te, a), window.addEventListener("pointerdown", (h) => {
    h.pointerType === i(this, xd) && (i(this, xr) || h.isPrimary) && o(h), te(h);
  }, a));
  const l = (h) => {
    if (!i(this, Er) || i(this, Er) === h.pointerId) {
      o(h);
      return;
    }
    te(h);
  };
  window.addEventListener("pointerup", l, {
    signal: r
  }), window.addEventListener("blur", l, {
    signal: r
  });
}, Jg = function() {
  if (i(this, Cr) || !this.div)
    return;
  u(this, Cr, new AbortController());
  const t = this._uiManager.combinedSignal(i(this, Cr));
  this.div.addEventListener("focusin", this.focusin.bind(this), {
    signal: t
  }), this.div.addEventListener("focusout", this.focusout.bind(this), {
    signal: t
  });
}, Zg = function() {
  i(this, xr) || !this.div || !this.isResizable || !this._uiManager._supportsPinchToZoom || u(this, xr, new rA({
    container: this.div,
    isPinchingDisabled: () => !this.isSelected,
    onPinchStart: m(this, G, dA).bind(this),
    onPinching: m(this, G, uA).bind(this),
    onPinchEnd: m(this, G, fA).bind(this),
    signal: this._uiManager._signal
  }));
}, gA = function(t) {
  W._resizerKeyboardManager.exec(this, t);
}, mA = function(t) {
  var e;
  i(this, mn) && ((e = t.relatedTarget) == null ? void 0 : e.parentNode) !== i(this, de) && m(this, G, xc).call(this);
}, bA = function(t) {
  u(this, Td, i(this, mn) ? t : "");
}, tm = function(t) {
  if (i(this, Ws))
    for (const e of i(this, Ws))
      e.tabIndex = t;
}, xc = function() {
  u(this, mn, !1), m(this, G, tm).call(this, -1), m(this, G, xf).call(this);
}, em = function() {
  var t;
  (t = this._editToolbar) == null || t.show(), this._uiManager._keepToolbarInPage && (this.fixAndSetPosition(), this._onTranslated());
}, g(W, Gl), _(W, "_l10n", null), _(W, "_l10nAlert", null), _(W, "_l10nResizer", null), _(W, "_borderLineWidth", -1), _(W, "_colorManager", new Bg()), _(W, "_zIndex", 1), _(W, "_telemetryTimeout", 1e3);
let bt = W;
class zw extends bt {
  constructor(t) {
    super(t), this.annotationElementId = t.annotationElementId, this.deleted = !0;
  }
  serialize() {
    return this.serializeDeleted();
  }
}
const oy = 3285377520, xs = 4294901760, pi = 65535;
class sm {
  constructor(t) {
    this.h1 = t ? t & 4294967295 : oy, this.h2 = t ? t & 4294967295 : oy;
  }
  update(t) {
    let e, s;
    if (typeof t == "string") {
      e = new Uint8Array(t.length * 2), s = 0;
      for (let A = 0, w = t.length; A < w; A++) {
        const v = t.charCodeAt(A);
        v <= 255 ? e[s++] = v : (e[s++] = v >>> 8, e[s++] = v & 255);
      }
    } else if (ArrayBuffer.isView(t))
      e = t.slice(), s = e.byteLength;
    else
      throw new Error("Invalid data format, must be a string or TypedArray.");
    const n = s >> 2, r = s - n * 4, a = new Uint32Array(e.buffer, 0, n);
    let o = 0, l = 0, h = this.h1, c = this.h2;
    const d = 3432918353, f = 461845907, b = d & pi, y = f & pi;
    for (let A = 0; A < n; A++)
      A & 1 ? (o = a[A], o = o * d & xs | o * b & pi, o = o << 15 | o >>> 17, o = o * f & xs | o * y & pi, h ^= o, h = h << 13 | h >>> 19, h = h * 5 + 3864292196) : (l = a[A], l = l * d & xs | l * b & pi, l = l << 15 | l >>> 17, l = l * f & xs | l * y & pi, c ^= l, c = c << 13 | c >>> 19, c = c * 5 + 3864292196);
    switch (o = 0, r) {
      case 3:
        o ^= e[n * 4 + 2] << 16;
      case 2:
        o ^= e[n * 4 + 1] << 8;
      case 1:
        o ^= e[n * 4], o = o * d & xs | o * b & pi, o = o << 15 | o >>> 17, o = o * f & xs | o * y & pi, n & 1 ? h ^= o : c ^= o;
    }
    this.h1 = h, this.h2 = c;
  }
  hexdigest() {
    let t = this.h1, e = this.h2;
    return t ^= e >>> 1, t = t * 3981806797 & xs | t * 36045 & pi, e = e * 4283543511 & xs | ((e << 16 | t >>> 16) * 2950163797 & xs) >>> 16, t ^= e >>> 1, t = t * 444984403 & xs | t * 60499 & pi, e = e * 3301882366 & xs | ((e << 16 | t >>> 16) * 3120437893 & xs) >>> 16, t ^= e >>> 1, (t >>> 0).toString(16).padStart(8, "0") + (e >>> 0).toString(16).padStart(8, "0");
  }
}
const Qc = Object.freeze({
  map: null,
  hash: "",
  transfer: void 0
});
var Ba, Ha, bn, ue, vp, yA;
class Bb {
  constructor() {
    g(this, vp);
    g(this, Ba, !1);
    g(this, Ha, null);
    g(this, bn, null);
    g(this, ue, /* @__PURE__ */ new Map());
    _(this, "onSetModified", null);
    _(this, "onResetModified", null);
    _(this, "onAnnotationEditor", null);
  }
  getValue(t, e) {
    const s = i(this, ue).get(t);
    return s === void 0 ? e : Object.assign(e, s);
  }
  getRawValue(t) {
    return i(this, ue).get(t);
  }
  remove(t) {
    var s;
    const e = i(this, ue).get(t);
    e !== void 0 && (e instanceof bt && i(this, bn).delete(e.annotationElementId), i(this, ue).delete(t), i(this, ue).size === 0 && this.resetModified(), !i(this, ue).values().some((n) => n instanceof bt) && ((s = this.onAnnotationEditor) == null || s.call(this, null)));
  }
  setValue(t, e) {
    var r;
    const s = i(this, ue).get(t);
    let n = !1;
    if (s !== void 0)
      for (const [a, o] of Object.entries(e))
        s[a] !== o && (n = !0, s[a] = o);
    else
      n = !0, i(this, ue).set(t, e);
    n && m(this, vp, yA).call(this), e instanceof bt && ((i(this, bn) || u(this, bn, /* @__PURE__ */ new Map())).set(e.annotationElementId, e), (r = this.onAnnotationEditor) == null || r.call(this, e.constructor._type));
  }
  has(t) {
    return i(this, ue).has(t);
  }
  get size() {
    return i(this, ue).size;
  }
  resetModified() {
    var t;
    i(this, Ba) && (u(this, Ba, !1), (t = this.onResetModified) == null || t.call(this));
  }
  get print() {
    return new AA(this);
  }
  get serializable() {
    if (i(this, ue).size === 0)
      return Qc;
    const t = /* @__PURE__ */ new Map(), e = new sm(), s = [], n = /* @__PURE__ */ Object.create(null);
    let r = !1;
    for (const [a, o] of i(this, ue)) {
      const l = o instanceof bt ? o.serialize(!1, n) : o;
      o.page && (o.pageIndex = o.page._pageIndex, delete o.page), l && (t.set(a, l), e.update(`${a}:${JSON.stringify(l)}`), r || (r = !!l.bitmap));
    }
    if (r)
      for (const a of t.values())
        a.bitmap && s.push(a.bitmap);
    return t.size > 0 ? {
      map: t,
      hash: e.hexdigest(),
      transfer: s
    } : Qc;
  }
  get editorStats() {
    let t = null;
    const e = /* @__PURE__ */ new Map();
    let s = 0, n = 0;
    for (const r of i(this, ue).values()) {
      if (!(r instanceof bt)) {
        r.popup && (r.popup.deleted ? n += 1 : s += 1);
        continue;
      }
      r.isCommentDeleted ? n += 1 : r.hasEditedComment && (s += 1);
      const a = r.telemetryFinalData;
      if (!a)
        continue;
      const {
        type: o
      } = a;
      e.getOrInsertComputed(o, () => Object.getPrototypeOf(r).constructor), t || (t = /* @__PURE__ */ Object.create(null));
      const l = t[o] || (t[o] = /* @__PURE__ */ new Map());
      for (const [h, c] of Object.entries(a)) {
        if (h === "type")
          continue;
        const d = l.getOrInsertComputed(h, op);
        d.set(c, (d.get(c) ?? 0) + 1);
      }
    }
    if ((n > 0 || s > 0) && (t || (t = /* @__PURE__ */ Object.create(null)), t.comments = {
      deleted: n,
      edited: s
    }), !t)
      return null;
    for (const [r, a] of e)
      t[r] = a.computeTelemetryFinalData(t[r]);
    return t;
  }
  resetModifiedIds() {
    u(this, Ha, null);
  }
  updateEditor(t, e) {
    var n;
    const s = (n = i(this, bn)) == null ? void 0 : n.get(t);
    return s ? (s.updateFromAnnotationLayer(e), !0) : !1;
  }
  getEditor(t) {
    var e;
    return ((e = i(this, bn)) == null ? void 0 : e.get(t)) || null;
  }
  get modifiedIds() {
    if (i(this, Ha))
      return i(this, Ha);
    const t = [];
    if (i(this, bn))
      for (const s of i(this, bn).values())
        s.serialize() && t.push(s.annotationElementId);
    let e = "";
    if (t.length) {
      const s = new sm();
      s.update(t.join(",")), e = s.hexdigest();
    }
    return u(this, Ha, {
      ids: new Set(t),
      hash: e
    });
  }
  [Symbol.iterator]() {
    return i(this, ue).entries();
  }
}
Ba = new WeakMap(), Ha = new WeakMap(), bn = new WeakMap(), ue = new WeakMap(), vp = new WeakSet(), yA = function() {
  var t;
  i(this, Ba) || (u(this, Ba, !0), (t = this.onSetModified) == null || t.call(this));
};
var Pd;
class AA extends Bb {
  constructor(e) {
    super();
    g(this, Pd, Qc);
    const {
      serializable: s
    } = e;
    if (s === Qc)
      return;
    const {
      map: n,
      hash: r,
      transfer: a
    } = s, o = structuredClone(n, a ? {
      transfer: a
    } : null);
    u(this, Pd, {
      map: o,
      hash: r,
      transfer: []
    });
  }
  get print() {
    it("Should not call PrintAnnotationStorage.print");
  }
  get serializable() {
    return i(this, Pd);
  }
  get modifiedIds() {
    return L(this, "modifiedIds", {
      ids: /* @__PURE__ */ new Set(),
      hash: ""
    });
  }
}
Pd = new WeakMap();
function Gw(p) {
  if (p instanceof URL)
    return p;
  if (typeof p == "string") {
    if (bs) {
      if (/^[a-z][a-z0-9\-+.]+:/i.test(p))
        return new URL(p);
      const e = process.getBuiltinModule("url");
      return new URL(e.pathToFileURL(p));
    }
    const t = URL.parse(p, window.location);
    if (t)
      return t;
  }
  throw new Error("Invalid PDF url data: either string or URL-object is expected in the url property.");
}
function $w(p) {
  if (bs && typeof Buffer < "u" && p instanceof Buffer)
    throw new Error("Please provide binary data as `Uint8Array`, rather than `Buffer`.");
  if (p instanceof Uint8Array && p.byteLength === p.buffer.byteLength)
    return p;
  if (typeof p == "string")
    return ng(p);
  if (p instanceof ArrayBuffer || ArrayBuffer.isView(p) || typeof p == "object" && !isNaN(p == null ? void 0 : p.length))
    return new Uint8Array(p);
  throw new Error("Invalid PDF binary data: either TypedArray, string, or array-like object is expected in the data property.");
}
function hf(p) {
  if (typeof p != "string")
    return null;
  if (p.endsWith("/"))
    return p;
  throw new Error(`Invalid factory url: "${p}" must include trailing slash.`);
}
const im = (p) => typeof p == "object" && Number.isInteger(p == null ? void 0 : p.num) && p.num >= 0 && Number.isInteger(p == null ? void 0 : p.gen) && p.gen >= 0, jw = (p) => typeof p == "object" && typeof (p == null ? void 0 : p.name) == "string", Vw = Tw.bind(null, im, jw);
function Ww(p, t) {
  const e = URL.parse(p);
  if (!(e != null && e.origin) || e.origin === "null")
    return !1;
  const s = new URL(t, e);
  return e.origin === s.origin;
}
function wA(p) {
  if (!Ww(window.location, p)) {
    const t = `await import("${new URL(p, window.location).href}");`;
    return URL.createObjectURL(new Blob([t], {
      type: "text/javascript"
    }));
  }
  return p;
}
var yn, Sp;
class Xw {
  constructor() {
    g(this, yn, /* @__PURE__ */ new Map());
    g(this, Sp, Promise.resolve());
  }
  postMessage(t, e) {
    const s = {
      data: structuredClone(t, e ? {
        transfer: e
      } : null)
    };
    i(this, Sp).then(() => {
      for (const [n] of i(this, yn))
        n.call(this, s);
    });
  }
  addEventListener(t, e, s = null) {
    let n = null;
    if ((s == null ? void 0 : s.signal) instanceof AbortSignal) {
      const {
        signal: r
      } = s;
      if (r.aborted) {
        j("LoopbackPort - cannot use an `aborted` signal.");
        return;
      }
      const a = () => this.removeEventListener(t, e);
      n = () => r.removeEventListener("abort", a), r.addEventListener("abort", a);
    }
    i(this, yn).set(e, n);
  }
  removeEventListener(t, e) {
    const s = i(this, yn).get(e);
    s == null || s(), i(this, yn).delete(e);
  }
  terminate() {
    for (const [, t] of i(this, yn))
      t == null || t();
    i(this, yn).clear();
  }
}
yn = new WeakMap(), Sp = new WeakMap();
var Tr;
class ly {
  constructor() {
    g(this, Tr, /* @__PURE__ */ new Map());
    _(this, "times", []);
  }
  time(t) {
    i(this, Tr).has(t) && j(`Timer is already running for ${t}`), i(this, Tr).set(t, Date.now());
  }
  timeEnd(t) {
    i(this, Tr).has(t) || j(`Timer has not been started for ${t}`), this.times.push({
      name: t,
      start: i(this, Tr).get(t),
      end: Date.now()
    }), i(this, Tr).delete(t);
  }
  toString() {
    const t = Math.max(...this.times.map((e) => e.name.length));
    return this.times.map((e) => `${e.name.padEnd(t)} ${e.end - e.start}ms
`).join("");
  }
}
Tr = new WeakMap();
const Yw = `
struct Uniforms {
  offsetX      : f32,
  offsetY      : f32,
  scaleX       : f32,
  scaleY       : f32,
  paddedWidth  : f32,
  paddedHeight : f32,
  borderSize   : f32,
  _pad         : f32,
};

@group(0) @binding(0) var<uniform> u : Uniforms;

struct VertexInput {
  @location(0) position : vec2<f32>,
  @location(1) color    : vec4<f32>,
};

struct VertexOutput {
  @builtin(position) position : vec4<f32>,
  @location(0)       color    : vec3<f32>,
};

@vertex
fn vs_main(in : VertexInput) -> VertexOutput {
  var out : VertexOutput;
  let cx = (in.position.x + u.offsetX) * u.scaleX;
  let cy = (in.position.y + u.offsetY) * u.scaleY;
  out.position = vec4<f32>(
    ((cx + u.borderSize) / u.paddedWidth) * 2.0 - 1.0,
    1.0 - ((cy + u.borderSize) / u.paddedHeight) * 2.0,
    0.0,
    1.0
  );
  out.color = in.color.rgb;
  return out;
}

@fragment
fn fs_main(in : VertexOutput) -> @location(0) vec4<f32> {
  return vec4<f32>(in.color, 1.0);
}
`;
var Ep, An, Ua, $l, Cp, vA;
class Kw {
  constructor() {
    g(this, Cp);
    g(this, Ep, null);
    g(this, An, null);
    g(this, Ua, null);
    g(this, $l, null);
  }
  init() {
    return i(this, Ep) || u(this, Ep, m(this, Cp, vA).call(this));
  }
  get isReady() {
    return i(this, An) !== null;
  }
  loadMeshShader() {
    if (!i(this, An) || i(this, Ua))
      return;
    const t = i(this, An).createShaderModule({
      code: Yw
    });
    u(this, Ua, i(this, An).createRenderPipeline({
      layout: "auto",
      vertex: {
        module: t,
        entryPoint: "vs_main",
        buffers: [{
          arrayStride: 8,
          attributes: [{
            shaderLocation: 0,
            offset: 0,
            format: "float32x2"
          }]
        }, {
          arrayStride: 4,
          attributes: [{
            shaderLocation: 1,
            offset: 0,
            format: "unorm8x4"
          }]
        }]
      },
      fragment: {
        module: t,
        entryPoint: "fs_main",
        targets: [{
          format: i(this, $l)
        }]
      },
      primitive: {
        topology: "triangle-list"
      }
    }));
  }
  draw(t, e, s, n, r, a, o, l) {
    this.loadMeshShader();
    const h = i(this, An), {
      offsetX: c,
      offsetY: d,
      scaleX: f,
      scaleY: b
    } = n, y = h.createBuffer({
      size: Math.max(t.byteLength, 4),
      usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST
    });
    t.byteLength > 0 && h.queue.writeBuffer(y, 0, t);
    const A = h.createBuffer({
      size: Math.max(e.byteLength, 4),
      usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST
    });
    e.byteLength > 0 && h.queue.writeBuffer(A, 0, e);
    const w = h.createBuffer({
      size: 32,
      usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
    });
    h.queue.writeBuffer(w, 0, new Float32Array([c, d, f, b, a, o, l, 0]));
    const v = h.createBindGroup({
      layout: i(this, Ua).getBindGroupLayout(0),
      entries: [{
        binding: 0,
        resource: {
          buffer: w
        }
      }]
    }), S = new OffscreenCanvas(a, o), E = S.getContext("webgpu");
    E.configure({
      device: h,
      format: i(this, $l),
      alphaMode: r ? "opaque" : "premultiplied"
    });
    const C = r ? {
      r: r[0] / 255,
      g: r[1] / 255,
      b: r[2] / 255,
      a: 1
    } : {
      r: 0,
      g: 0,
      b: 0,
      a: 0
    }, x = h.createCommandEncoder(), T = x.beginRenderPass({
      colorAttachments: [{
        view: E.getCurrentTexture().createView(),
        clearValue: C,
        loadOp: "clear",
        storeOp: "store"
      }]
    });
    return s > 0 && (T.setPipeline(i(this, Ua)), T.setBindGroup(0, v), T.setVertexBuffer(0, y), T.setVertexBuffer(1, A), T.draw(s)), T.end(), h.queue.submit([x.finish()]), y.destroy(), A.destroy(), w.destroy(), S.transferToImageBitmap();
  }
}
Ep = new WeakMap(), An = new WeakMap(), Ua = new WeakMap(), $l = new WeakMap(), Cp = new WeakSet(), vA = async function() {
  var t;
  if (!((t = globalThis.navigator) != null && t.gpu))
    return !1;
  try {
    const e = await navigator.gpu.requestAdapter();
    return e ? (u(this, $l, navigator.gpu.getPreferredCanvasFormat()), u(this, An, await e.requestDevice()), !0) : !1;
  } catch {
    return !1;
  }
};
const ag = new Kw();
function SA() {
  return ag.init();
}
function EA() {
  return ag.isReady;
}
function qw() {
  ag.loadMeshShader();
}
function Qw(p, t, e, s, n, r, a, o) {
  return ag.draw(p, t, e, s, n, r, a, o);
}
const cf = {
  DATA: 1,
  ERROR: 2
}, Wt = {
  CANCEL: 1,
  CANCEL_COMPLETE: 2,
  CLOSE: 3,
  ENQUEUE: 4,
  ERROR: 5,
  PULL: 6,
  PULL_COMPLETE: 7,
  START_COMPLETE: 8
};
function hy() {
}
function Ue(p) {
  if (p instanceof oa || p instanceof kg || p instanceof _g || p instanceof ap || p instanceof of)
    return p;
  if (typeof p != "object" || p === null)
    return new of(String(p), String(p));
  switch (p.name) {
    case "AbortException":
      return new oa(p.message);
    case "InvalidPDFException":
      return new kg(p.message);
    case "PasswordException":
      return new _g(p.message, p.code);
    case "ResponseException":
      return new ap(p.message, p.status, p.missing);
    case "UnknownErrorException":
      return new of(p.message, p.details);
  }
  return new of(p.message, p.toString());
}
var jl, Vl, xp, Pi, za, Xs, wn, Tp, Wl, Ga, zs, CA, xA, TA, Tf;
class aa {
  constructor(t, e, s) {
    g(this, zs);
    g(this, jl, /* @__PURE__ */ new Map());
    g(this, Vl, /* @__PURE__ */ new Map());
    g(this, xp, 1);
    g(this, Pi);
    g(this, za, new AbortController());
    g(this, Xs);
    g(this, wn, /* @__PURE__ */ new Map());
    g(this, Tp, 1);
    g(this, Wl, /* @__PURE__ */ new Map());
    g(this, Ga);
    u(this, Xs, t), u(this, Ga, e), u(this, Pi, s), s.addEventListener("message", m(this, zs, CA).bind(this), {
      signal: i(this, za).signal
    });
  }
  on(t, e) {
    const s = i(this, jl);
    if (s.has(t))
      throw new Error(`There is already a "${t}" handler.`);
    s.set(t, e);
  }
  send(t, e, s) {
    i(this, Pi).postMessage({
      sourceName: i(this, Xs),
      targetName: i(this, Ga),
      action: t,
      data: e
    }, s);
  }
  sendWithPromise(t, e, s) {
    const n = rt(this, xp)._++, r = Promise.withResolvers();
    i(this, Vl).set(n, r);
    try {
      i(this, Pi).postMessage({
        sourceName: i(this, Xs),
        targetName: i(this, Ga),
        action: t,
        callbackId: n,
        data: e
      }, s);
    } catch (a) {
      r.reject(a);
    }
    return r.promise;
  }
  sendWithStream(t, e, s, n) {
    const r = rt(this, Tp)._++, a = i(this, Xs), o = i(this, Ga), l = i(this, Pi);
    return new ReadableStream({
      start: (h) => {
        const c = Promise.withResolvers();
        return i(this, wn).set(r, {
          controller: h,
          startCall: c,
          pullCall: null,
          cancelCall: null,
          isClosed: !1
        }), l.postMessage({
          sourceName: a,
          targetName: o,
          action: t,
          streamId: r,
          data: e,
          desiredSize: h.desiredSize
        }, n), c.promise;
      },
      pull: (h) => {
        const c = Promise.withResolvers();
        return i(this, wn).get(r).pullCall = c, l.postMessage({
          sourceName: a,
          targetName: o,
          stream: Wt.PULL,
          streamId: r,
          desiredSize: h.desiredSize
        }), c.promise;
      },
      cancel: (h) => {
        jt(h instanceof Error, "cancel must have a valid reason");
        const c = Promise.withResolvers();
        return i(this, wn).get(r).cancelCall = c, i(this, wn).get(r).isClosed = !0, l.postMessage({
          sourceName: a,
          targetName: o,
          stream: Wt.CANCEL,
          streamId: r,
          reason: Ue(h)
        }), c.promise;
      }
    }, s);
  }
  destroy() {
    var t;
    (t = i(this, za)) == null || t.abort(), u(this, za, null);
  }
  get destroyed() {
    return !i(this, za);
  }
}
jl = new WeakMap(), Vl = new WeakMap(), xp = new WeakMap(), Pi = new WeakMap(), za = new WeakMap(), Xs = new WeakMap(), wn = new WeakMap(), Tp = new WeakMap(), Wl = new WeakMap(), Ga = new WeakMap(), zs = new WeakSet(), CA = function({
  data: t
}) {
  if (t.targetName !== i(this, Xs))
    return;
  if (t.stream) {
    m(this, zs, TA).call(this, t);
    return;
  }
  if (t.callback) {
    const {
      callbackId: s,
      callback: n
    } = t, r = i(this, Vl).get(s);
    if (!r)
      throw new Error(`Cannot resolve callback ${s}`);
    if (i(this, Vl).delete(s), n === cf.DATA)
      r.resolve(t.data);
    else if (n === cf.ERROR)
      r.reject(Ue(t.reason));
    else
      throw new Error("Unexpected callback case");
    return;
  }
  const e = i(this, jl).get(t.action);
  if (!e)
    throw new Error(`Unknown action from worker: ${t.action}`);
  if (t.callbackId) {
    const s = i(this, Xs), n = t.sourceName, r = i(this, Pi);
    Promise.try(e, t.data).then((a) => {
      r.postMessage({
        sourceName: s,
        targetName: n,
        callback: cf.DATA,
        callbackId: t.callbackId,
        data: a
      });
    }).catch((a) => {
      r.postMessage({
        sourceName: s,
        targetName: n,
        callback: cf.ERROR,
        callbackId: t.callbackId,
        reason: Ue(a)
      });
    });
    return;
  }
  if (t.streamId) {
    m(this, zs, xA).call(this, t);
    return;
  }
  e(t.data);
}, xA = function(t) {
  const e = t.streamId, s = i(this, Xs), n = t.sourceName, r = i(this, Pi), a = i(this, Wl), o = i(this, jl).get(t.action), l = {
    enqueue(h, c = 1, d) {
      if (this.isCancelled)
        return;
      const f = this.desiredSize;
      this.desiredSize -= c, f > 0 && this.desiredSize <= 0 && (this.sinkCapability = Promise.withResolvers(), this.ready = this.sinkCapability.promise), r.postMessage({
        sourceName: s,
        targetName: n,
        stream: Wt.ENQUEUE,
        streamId: e,
        chunk: h
      }, d);
    },
    close() {
      this.isCancelled || (this.isCancelled = !0, r.postMessage({
        sourceName: s,
        targetName: n,
        stream: Wt.CLOSE,
        streamId: e
      }), a.delete(e));
    },
    error(h) {
      this.isCancelled || (this.isCancelled = !0, r.postMessage({
        sourceName: s,
        targetName: n,
        stream: Wt.ERROR,
        streamId: e,
        reason: Ue(h)
      }));
    },
    sinkCapability: Promise.withResolvers(),
    onPull: null,
    onCancel: null,
    isCancelled: !1,
    desiredSize: t.desiredSize,
    ready: null
  };
  l.sinkCapability.resolve(), l.ready = l.sinkCapability.promise, a.set(e, l), Promise.try(o, t.data, l).then(() => {
    r.postMessage({
      sourceName: s,
      targetName: n,
      stream: Wt.START_COMPLETE,
      streamId: e,
      success: !0
    });
  }, (h) => {
    r.postMessage({
      sourceName: s,
      targetName: n,
      stream: Wt.START_COMPLETE,
      streamId: e,
      reason: Ue(h)
    });
  });
}, TA = function(t) {
  const e = t.streamId, s = i(this, Xs), n = t.sourceName, r = i(this, Pi), a = i(this, wn).get(e), o = i(this, Wl).get(e);
  switch (t.stream) {
    case Wt.START_COMPLETE:
      t.success ? a.startCall.resolve() : a.startCall.reject(Ue(t.reason));
      break;
    case Wt.PULL_COMPLETE:
      t.success ? a.pullCall.resolve() : a.pullCall.reject(Ue(t.reason));
      break;
    case Wt.PULL:
      if (!o) {
        r.postMessage({
          sourceName: s,
          targetName: n,
          stream: Wt.PULL_COMPLETE,
          streamId: e,
          success: !0
        });
        break;
      }
      o.desiredSize <= 0 && t.desiredSize > 0 && o.sinkCapability.resolve(), o.desiredSize = t.desiredSize, Promise.try(o.onPull || hy).then(() => {
        r.postMessage({
          sourceName: s,
          targetName: n,
          stream: Wt.PULL_COMPLETE,
          streamId: e,
          success: !0
        });
      }, (h) => {
        r.postMessage({
          sourceName: s,
          targetName: n,
          stream: Wt.PULL_COMPLETE,
          streamId: e,
          reason: Ue(h)
        });
      });
      break;
    case Wt.ENQUEUE:
      if (jt(a, "enqueue should have stream controller"), a.isClosed)
        break;
      a.controller.enqueue(t.chunk);
      break;
    case Wt.CLOSE:
      if (jt(a, "close should have stream controller"), a.isClosed)
        break;
      a.isClosed = !0, a.controller.close(), m(this, zs, Tf).call(this, a, e);
      break;
    case Wt.ERROR:
      jt(a, "error should have stream controller"), a.controller.error(Ue(t.reason)), m(this, zs, Tf).call(this, a, e);
      break;
    case Wt.CANCEL_COMPLETE:
      t.success ? a.cancelCall.resolve() : a.cancelCall.reject(Ue(t.reason)), m(this, zs, Tf).call(this, a, e);
      break;
    case Wt.CANCEL:
      if (!o)
        break;
      const l = Ue(t.reason);
      Promise.try(o.onCancel || hy, l).then(() => {
        r.postMessage({
          sourceName: s,
          targetName: n,
          stream: Wt.CANCEL_COMPLETE,
          streamId: e,
          success: !0
        });
      }, (h) => {
        r.postMessage({
          sourceName: s,
          targetName: n,
          stream: Wt.CANCEL_COMPLETE,
          streamId: e,
          reason: Ue(h)
        });
      }), o.sinkCapability.reject(l), o.isCancelled = !0, i(this, Wl).delete(e);
      break;
    default:
      throw new Error("Unexpected stream case");
  }
}, Tf = async function(t, e) {
  var s, n, r;
  await Promise.allSettled([(s = t.startCall) == null ? void 0 : s.promise, (n = t.pullCall) == null ? void 0 : n.promise, (r = t.cancelCall) == null ? void 0 : r.promise]), i(this, wn).delete(e);
};
var _p;
class _A {
  constructor({
    cMapUrl: t = null,
    standardFontDataUrl: e = null,
    wasmUrl: s = null
  }) {
    g(this, _p, Object.freeze({
      cMapUrl: "CMap",
      standardFontDataUrl: "font",
      wasmUrl: "wasm"
    }));
    this.cMapUrl = t, this.standardFontDataUrl = e, this.wasmUrl = s;
  }
  async fetch({
    kind: t,
    filename: e
  }) {
    switch (t) {
      case "cMapUrl":
      case "standardFontDataUrl":
      case "wasmUrl":
        break;
      default:
        it(`Not implemented: ${t}`);
    }
    const s = this[t];
    if (!s)
      throw new Error(`Ensure that the \`${t}\` API parameter is provided.`);
    const n = `${s}${e}`;
    return this._fetch(n, t).catch((r) => {
      throw new Error(`Unable to load ${i(this, _p)[t]} data at: ${n}`);
    });
  }
  async _fetch(t, e) {
    it("Abstract method `_fetch` called.");
  }
}
_p = new WeakMap();
class cy extends _A {
  async _fetch(t, e) {
    const s = e === "cMapUrl" && !t.endsWith(".bcmap") ? "text" : "bytes", n = await Rb(t, s);
    return n instanceof Uint8Array ? n : ng(n);
  }
}
var Xl;
class kA {
  constructor({
    enableHWA: t = !1
  }) {
    g(this, Xl, !1);
    u(this, Xl, t);
  }
  create(t, e) {
    if (t <= 0 || e <= 0)
      throw new Error("Invalid canvas size");
    const s = this._createCanvas(t, e);
    return {
      canvas: s,
      context: s.getContext("2d", {
        willReadFrequently: !i(this, Xl)
      })
    };
  }
  reset({
    canvas: t
  }, e, s) {
    if (!t)
      throw new Error("Canvas is not specified");
    if (e <= 0 || s <= 0)
      throw new Error("Invalid canvas size");
    t.width = e, t.height = s;
  }
  destroy(t) {
    const {
      canvas: e
    } = t;
    if (!e)
      throw new Error("Canvas is not specified");
    e.width = e.height = 0, t.canvas = null, t.context = null;
  }
  getNoAlphaContext(t) {
    return t.getContext("2d", {
      alpha: !1,
      willReadFrequently: !i(this, Xl)
    });
  }
  _createCanvas(t, e) {
    it("Abstract method `_createCanvas` called.");
  }
}
Xl = new WeakMap();
class PA {
  addFilter(t) {
    return "none";
  }
  addHCMFilter(t, e) {
    return "none";
  }
  addAlphaFilter(t) {
    return "none";
  }
  addLuminosityFilter(t) {
    return "none";
  }
  addKnockoutFilter(t = 0) {
    return "none";
  }
  addHighlightHCMFilter(t, e, s, n, r) {
    return "none";
  }
  addSelectionHCMFilter(t, e) {
    return "none";
  }
  addSelectionFilter() {
    return "none";
  }
  createSelectionStyle(t = null) {
    return null;
  }
  destroy(t = !1) {
  }
}
bs && j("Please use the `legacy` build in Node.js environments.");
async function Jw(p) {
  const e = await process.getBuiltinModule("fs/promises").readFile(p);
  return new Uint8Array(e);
}
class Zw extends PA {
}
class tv extends kA {
  _createCanvas(t, e) {
    return process.getBuiltinModule("module").createRequire(import.meta.url)("@napi-rs/canvas").createCanvas(t, e);
  }
}
class ev extends _A {
  async _fetch(t, e) {
    return Jw(t);
  }
}
const ul = "__forcedDependency", {
  floor: dy,
  ceil: uy
} = Math;
function fy(p, t, e, s, n, r) {
  p[t * 4 + 0] = Math.min(p[t * 4 + 0], e), p[t * 4 + 1] = Math.min(p[t * 4 + 1], s), p[t * 4 + 2] = Math.max(p[t * 4 + 2], n), p[t * 4 + 3] = Math.max(p[t * 4 + 3], r);
}
function sv(p, t, e, s, n) {
  let r;
  p ? (p < 0 && (r = n[0], n[0] = n[2], n[2] = r), n[0] *= p, n[2] *= p, t < 0 && (r = n[1], n[1] = n[3], n[3] = r), n[1] *= t, n[3] *= t) : n.fill(0), n[0] += e, n[1] += s, n[2] += e, n[3] += s;
}
const nm = new Uint32Array(new Uint8Array([255, 255, 0, 0]).buffer)[0];
var $a, _r;
const qb = class qb {
  constructor(t, e) {
    g(this, $a);
    g(this, _r);
    u(this, $a, t), u(this, _r, e);
  }
  static fromBuffer(t) {
    return new qb(new Uint32Array(t), new Uint8ClampedArray(t));
  }
  get buffer() {
    return i(this, $a).buffer;
  }
  get length() {
    return i(this, $a).length;
  }
  isEmpty(t) {
    return i(this, $a)[t] === nm;
  }
  minX(t) {
    return i(this, _r)[t * 4 + 0] / 256;
  }
  minY(t) {
    return i(this, _r)[t * 4 + 1] / 256;
  }
  maxX(t) {
    return (i(this, _r)[t * 4 + 2] + 1) / 256;
  }
  maxY(t) {
    return (i(this, _r)[t * 4 + 3] + 1) / 256;
  }
};
$a = new WeakMap(), _r = new WeakMap();
let cp = qb;
const py = (p, t) => p == null ? void 0 : p.getOrInsertComputed(t, () => ({
  dependencies: /* @__PURE__ */ new Set(),
  isRenderingOperation: !1
}));
var vn, at, xt, ja, Va, Wa, Se, Md, rm;
class iv {
  constructor(t, e) {
    g(this, Md);
    g(this, vn, [[1, 0, 0, 1, 0, 0]]);
    g(this, at, [-1 / 0, -1 / 0, 1 / 0, 1 / 0]);
    g(this, xt, new Float64Array(Yi));
    _(this, "_pendingBBoxIdx", -1);
    g(this, ja);
    g(this, Va);
    g(this, Wa);
    g(this, Se);
    _(this, "_savesStack", []);
    _(this, "_markedContentStack", []);
    u(this, ja, t.width), u(this, Va, t.height), m(this, Md, rm).call(this, e);
  }
  growOperationsCount(t) {
    t >= i(this, Se).length && m(this, Md, rm).call(this, t, i(this, Se));
  }
  get clipBox() {
    return i(this, at);
  }
  save(t) {
    return u(this, at, {
      __proto__: i(this, at)
    }), this._savesStack.push(t), this;
  }
  restore(t, e) {
    const s = Object.getPrototypeOf(i(this, at));
    if (s === null)
      return this;
    u(this, at, s);
    const n = this._savesStack.pop();
    return n !== void 0 && (e == null || e(n, t), i(this, Se)[t] = i(this, Se)[n]), this;
  }
  recordOpenMarker(t) {
    return this._savesStack.push(t), this;
  }
  getOpenMarker() {
    return this._savesStack.length === 0 ? null : this._savesStack.at(-1);
  }
  recordCloseMarker(t, e) {
    const s = this._savesStack.pop();
    return s !== void 0 && (e == null || e(s, t), i(this, Se)[t] = i(this, Se)[s]), this;
  }
  beginMarkedContent(t) {
    return this._markedContentStack.push(t), this;
  }
  endMarkedContent(t, e) {
    const s = this._markedContentStack.pop();
    return s !== void 0 && (e == null || e(s, t), i(this, Se)[t] = i(this, Se)[s]), this;
  }
  pushBaseTransform(t) {
    return i(this, vn).push(I.multiplyByDOMMatrix(i(this, vn).at(-1), t.getTransform())), this;
  }
  popBaseTransform() {
    return i(this, vn).length > 1 && i(this, vn).pop(), this;
  }
  resetBBox(t) {
    return this._pendingBBoxIdx !== t && (this._pendingBBoxIdx = t, i(this, xt).set(Yi, 0)), this;
  }
  recordClipBox(t, e, s, n, r, a) {
    const o = I.multiplyByDOMMatrix(i(this, vn).at(-1), e.getTransform()), l = Yi.slice();
    I.axialAlignedBoundingBox([s, r, n, a], o, l);
    const h = I.intersect(i(this, at), l);
    return h ? (i(this, at)[0] = h[0], i(this, at)[1] = h[1], i(this, at)[2] = h[2], i(this, at)[3] = h[3]) : (i(this, at)[0] = i(this, at)[1] = 1 / 0, i(this, at)[2] = i(this, at)[3] = -1 / 0), this;
  }
  recordBBox(t, e, s, n, r, a) {
    const o = i(this, at);
    if (o[0] === 1 / 0)
      return this;
    const l = I.multiplyByDOMMatrix(i(this, vn).at(-1), e.getTransform());
    if (o[0] === -1 / 0)
      return I.axialAlignedBoundingBox([s, r, n, a], l, i(this, xt)), this;
    const h = Yi.slice();
    return I.axialAlignedBoundingBox([s, r, n, a], l, h), i(this, xt)[0] = vt(h[0], o[0], i(this, xt)[0]), i(this, xt)[1] = vt(h[1], o[1], i(this, xt)[1]), i(this, xt)[2] = vt(h[2], i(this, xt)[2], o[2]), i(this, xt)[3] = vt(h[3], i(this, xt)[3], o[3]), this;
  }
  recordFullPageBBox(t) {
    return i(this, xt)[0] = Math.max(0, i(this, at)[0]), i(this, xt)[1] = Math.max(0, i(this, at)[1]), i(this, xt)[2] = Math.min(i(this, ja), i(this, at)[2]), i(this, xt)[3] = Math.min(i(this, Va), i(this, at)[3]), this;
  }
  recordOperation(t, e = !1, s) {
    if (this._pendingBBoxIdx !== t)
      return this;
    const n = dy(i(this, xt)[0] * 256 / i(this, ja)), r = dy(i(this, xt)[1] * 256 / i(this, Va)), a = uy(i(this, xt)[2] * 256 / i(this, ja)), o = uy(i(this, xt)[3] * 256 / i(this, Va));
    if (fy(i(this, Wa), t, n, r, a, o), s)
      for (const l of s)
        for (const h of l)
          h !== t && fy(i(this, Wa), h, n, r, a, o);
    return e || (this._pendingBBoxIdx = -1), this;
  }
  bboxToClipBoxDropOperation(t) {
    return this._pendingBBoxIdx === t && (this._pendingBBoxIdx = -1, i(this, at)[0] = Math.max(i(this, at)[0], i(this, xt)[0]), i(this, at)[1] = Math.max(i(this, at)[1], i(this, xt)[1]), i(this, at)[2] = Math.min(i(this, at)[2], i(this, xt)[2]), i(this, at)[3] = Math.min(i(this, at)[3], i(this, xt)[3])), this;
  }
  take() {
    return new cp(i(this, Se), i(this, Wa));
  }
  takeDebugMetadata() {
    throw new Error("Unreachable");
  }
  recordSimpleData(t, e) {
    return this;
  }
  recordIncrementalData(t, e) {
    return this;
  }
  resetIncrementalData(t, e) {
    return this;
  }
  recordNamedData(t, e) {
    return this;
  }
  recordSimpleDataFromNamed(t, e, s) {
    return this;
  }
  recordFutureForcedDependency(t, e) {
    return this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    return this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    return this;
  }
  recordCharacterBBox(t, e, s, n = 1, r = 0, a = 0, o) {
    return this;
  }
  getSimpleIndex(t) {
  }
  recordDependencies(t, e) {
    return this;
  }
  recordNamedDependency(t, e) {
    return this;
  }
  recordShowTextOperation(t, e = !1) {
    return this;
  }
}
vn = new WeakMap(), at = new WeakMap(), xt = new WeakMap(), ja = new WeakMap(), Va = new WeakMap(), Wa = new WeakMap(), Se = new WeakMap(), Md = new WeakSet(), rm = function(t, e) {
  const s = new ArrayBuffer(t * 4);
  u(this, Wa, new Uint8ClampedArray(s)), u(this, Se, new Uint32Array(s)), e && e.length > 0 ? (i(this, Se).set(e), i(this, Se).fill(nm, e.length)) : i(this, Se).fill(nm);
};
var Ve, We, Xa, Ys, Yl, kr, Pr, pt;
class nv {
  constructor(t, e = !1) {
    g(this, Ve, {
      __proto__: null
    });
    g(this, We, {
      __proto__: null,
      transform: [],
      moveText: [],
      sameLineText: [],
      [ul]: []
    });
    g(this, Xa, /* @__PURE__ */ new Map());
    g(this, Ys, /* @__PURE__ */ new Set());
    g(this, Yl, /* @__PURE__ */ new Map());
    g(this, kr);
    g(this, Pr);
    g(this, pt);
    u(this, pt, t), e && (u(this, kr, /* @__PURE__ */ new Map()), u(this, Pr, (s, n) => {
      py(i(this, kr), n).dependencies.add(s);
    }));
  }
  get clipBox() {
    return i(this, pt).clipBox;
  }
  growOperationsCount(t) {
    i(this, pt).growOperationsCount(t);
  }
  save(t) {
    return u(this, Ve, {
      __proto__: i(this, Ve)
    }), u(this, We, {
      __proto__: i(this, We),
      transform: {
        __proto__: i(this, We).transform
      },
      moveText: {
        __proto__: i(this, We).moveText
      },
      sameLineText: {
        __proto__: i(this, We).sameLineText
      },
      [ul]: {
        __proto__: i(this, We)[ul]
      }
    }), i(this, pt).save(t), this;
  }
  restore(t) {
    i(this, pt).restore(t, i(this, Pr));
    const e = Object.getPrototypeOf(i(this, Ve));
    return e === null ? this : (u(this, Ve, e), u(this, We, Object.getPrototypeOf(i(this, We))), this);
  }
  recordOpenMarker(t) {
    return i(this, pt).recordOpenMarker(t, i(this, Pr)), this;
  }
  getOpenMarker() {
    return i(this, pt).getOpenMarker();
  }
  recordCloseMarker(t) {
    return i(this, pt).recordCloseMarker(t, i(this, Pr)), this;
  }
  beginMarkedContent(t) {
    return i(this, pt).beginMarkedContent(t), this;
  }
  endMarkedContent(t) {
    return i(this, pt).endMarkedContent(t, i(this, Pr)), this;
  }
  pushBaseTransform(t) {
    return i(this, pt).pushBaseTransform(t), this;
  }
  popBaseTransform() {
    return i(this, pt).popBaseTransform(), this;
  }
  recordSimpleData(t, e) {
    return i(this, Ve)[t] = e, this;
  }
  recordIncrementalData(t, e) {
    return i(this, We)[t].push(e), this;
  }
  resetIncrementalData(t, e) {
    return i(this, We)[t].length = 0, this;
  }
  recordNamedData(t, e) {
    return i(this, Xa).set(t, e), this;
  }
  recordSimpleDataFromNamed(t, e, s) {
    i(this, Ve)[t] = i(this, Xa).get(e) ?? s;
  }
  recordFutureForcedDependency(t, e) {
    return this.recordIncrementalData(ul, e), this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    for (const e of t)
      e in i(this, Ve) && this.recordFutureForcedDependency(e, i(this, Ve)[e]);
    return this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    for (const t of i(this, Ys))
      this.recordFutureForcedDependency(ul, t);
    return this;
  }
  resetBBox(t) {
    return i(this, pt).resetBBox(t), this;
  }
  recordClipBox(t, e, s, n, r, a) {
    return i(this, pt).recordClipBox(t, e, s, n, r, a), this;
  }
  recordBBox(t, e, s, n, r, a) {
    return i(this, pt).recordBBox(t, e, s, n, r, a), this;
  }
  recordCharacterBBox(t, e, s, n = 1, r = 0, a = 0, o) {
    const l = s.bbox;
    let h, c;
    if (l && (h = l[2] !== l[0] && l[3] !== l[1] && i(this, Yl).get(s), h !== !1 && (c = [0, 0, 0, 0], I.axialAlignedBoundingBox(l, s.fontMatrix, c), (n !== 1 || r !== 0 || a !== 0) && sv(n, -n, r, a, c), h)))
      return this.recordBBox(t, e, c[0], c[2], c[1], c[3]);
    if (!o)
      return this.recordFullPageBBox(t);
    const d = o();
    return l && c && h === void 0 && (h = c[0] <= r - d.actualBoundingBoxLeft && c[2] >= r + d.actualBoundingBoxRight && c[1] <= a - d.actualBoundingBoxAscent && c[3] >= a + d.actualBoundingBoxDescent, i(this, Yl).set(s, h), h) ? this.recordBBox(t, e, c[0], c[2], c[1], c[3]) : this.recordBBox(t, e, r - d.actualBoundingBoxLeft, r + d.actualBoundingBoxRight, a - d.actualBoundingBoxAscent, a + d.actualBoundingBoxDescent);
  }
  recordFullPageBBox(t) {
    return i(this, pt).recordFullPageBBox(t), this;
  }
  getSimpleIndex(t) {
    return i(this, Ve)[t];
  }
  recordDependencies(t, e) {
    const s = i(this, Ys), n = i(this, Ve), r = i(this, We);
    for (const a of e)
      a in i(this, Ve) ? s.add(n[a]) : a in r && r[a].forEach(s.add, s);
    return this;
  }
  recordNamedDependency(t, e) {
    return i(this, Xa).has(e) && i(this, Ys).add(i(this, Xa).get(e)), this;
  }
  recordOperation(t, e = !1) {
    if (this.recordDependencies(t, [ul]), i(this, kr)) {
      const n = py(i(this, kr), t), {
        dependencies: r
      } = n;
      i(this, Ys).forEach(r.add, r), i(this, pt)._savesStack.forEach(r.add, r), i(this, pt)._markedContentStack.forEach(r.add, r), r.delete(t), n.isRenderingOperation = !0;
    }
    const s = !e && t === i(this, pt)._pendingBBoxIdx;
    return i(this, pt).recordOperation(t, e, [i(this, Ys), i(this, pt)._savesStack, i(this, pt)._markedContentStack]), s && i(this, Ys).clear(), this;
  }
  recordShowTextOperation(t, e = !1) {
    const s = Array.from(i(this, Ys));
    this.recordOperation(t, e), this.recordIncrementalData("sameLineText", t);
    for (const n of s)
      this.recordIncrementalData("sameLineText", n);
    return this;
  }
  bboxToClipBoxDropOperation(t, e = !1) {
    const s = !e && t === i(this, pt)._pendingBBoxIdx;
    return i(this, pt).bboxToClipBoxDropOperation(t), s && i(this, Ys).clear(), this;
  }
  take() {
    return i(this, Yl).clear(), i(this, pt).take();
  }
  takeDebugMetadata() {
    return i(this, kr);
  }
}
Ve = new WeakMap(), We = new WeakMap(), Xa = new WeakMap(), Ys = new WeakMap(), Yl = new WeakMap(), kr = new WeakMap(), Pr = new WeakMap(), pt = new WeakMap();
var gt, Ht, Ks, Kl, ql;
const Qb = class Qb {
  constructor(t, e, s) {
    g(this, gt);
    g(this, Ht);
    g(this, Ks);
    g(this, Kl, 0);
    g(this, ql, 0);
    if (t instanceof Qb && i(t, Ks) === !!s)
      return t;
    u(this, gt, t), u(this, Ht, e), u(this, Ks, !!s);
  }
  get clipBox() {
    return i(this, gt).clipBox;
  }
  growOperationsCount() {
    throw new Error("Unreachable");
  }
  save(t) {
    return rt(this, ql)._++, i(this, gt).save(i(this, Ht)), this;
  }
  restore(t) {
    return i(this, ql) > 0 && (i(this, gt).restore(i(this, Ht)), rt(this, ql)._--), this;
  }
  recordOpenMarker(t) {
    return rt(this, Kl)._++, this;
  }
  getOpenMarker() {
    return i(this, Kl) > 0 ? i(this, Ht) : i(this, gt).getOpenMarker();
  }
  recordCloseMarker(t) {
    return rt(this, Kl)._--, this;
  }
  beginMarkedContent(t) {
    return this;
  }
  endMarkedContent(t) {
    return this;
  }
  pushBaseTransform(t) {
    return i(this, gt).pushBaseTransform(t), this;
  }
  popBaseTransform() {
    return i(this, gt).popBaseTransform(), this;
  }
  recordSimpleData(t, e) {
    return i(this, gt).recordSimpleData(t, i(this, Ht)), this;
  }
  recordIncrementalData(t, e) {
    return i(this, gt).recordIncrementalData(t, i(this, Ht)), this;
  }
  resetIncrementalData(t, e) {
    return i(this, gt).resetIncrementalData(t, i(this, Ht)), this;
  }
  recordNamedData(t, e) {
    return this;
  }
  recordSimpleDataFromNamed(t, e, s) {
    return i(this, gt).recordSimpleDataFromNamed(t, e, i(this, Ht)), this;
  }
  recordFutureForcedDependency(t, e) {
    return i(this, gt).recordFutureForcedDependency(t, i(this, Ht)), this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    return i(this, gt).inheritSimpleDataAsFutureForcedDependencies(t), this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    return i(this, gt).inheritPendingDependenciesAsFutureForcedDependencies(), this;
  }
  resetBBox(t) {
    return i(this, Ks) || i(this, gt).resetBBox(i(this, Ht)), this;
  }
  recordClipBox(t, e, s, n, r, a) {
    return i(this, Ks) || i(this, gt).recordClipBox(i(this, Ht), e, s, n, r, a), this;
  }
  recordBBox(t, e, s, n, r, a) {
    return i(this, Ks) || i(this, gt).recordBBox(i(this, Ht), e, s, n, r, a), this;
  }
  recordCharacterBBox(t, e, s, n, r, a, o) {
    return i(this, Ks) || i(this, gt).recordCharacterBBox(i(this, Ht), e, s, n, r, a, o), this;
  }
  recordFullPageBBox(t) {
    return i(this, Ks) || i(this, gt).recordFullPageBBox(i(this, Ht)), this;
  }
  getSimpleIndex(t) {
    return i(this, gt).getSimpleIndex(t);
  }
  recordDependencies(t, e) {
    return i(this, gt).recordDependencies(i(this, Ht), e), this;
  }
  recordNamedDependency(t, e) {
    return i(this, gt).recordNamedDependency(i(this, Ht), e), this;
  }
  recordOperation(t) {
    return i(this, gt).recordOperation(i(this, Ht), !0), this;
  }
  recordShowTextOperation(t) {
    return i(this, gt).recordShowTextOperation(i(this, Ht), !0), this;
  }
  bboxToClipBoxDropOperation(t) {
    return i(this, Ks) || i(this, gt).bboxToClipBoxDropOperation(i(this, Ht), !0), this;
  }
  take() {
    throw new Error("Unreachable");
  }
  takeDebugMetadata() {
    throw new Error("Unreachable");
  }
};
gt = new WeakMap(), Ht = new WeakMap(), Ks = new WeakMap(), Kl = new WeakMap(), ql = new WeakMap();
let Jc = Qb;
const Ts = {
  stroke: ["path", "transform", "filter", "strokeColor", "strokeAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "dash"],
  fill: ["path", "transform", "filter", "fillColor", "fillAlpha", "globalCompositeOperation", "SMask"],
  imageXObject: ["transform", "SMask", "filter", "fillAlpha", "strokeAlpha", "globalCompositeOperation"],
  rawFillPath: ["filter", "fillColor", "fillAlpha"],
  showText: ["transform", "leading", "charSpacing", "wordSpacing", "hScale", "textRise", "moveText", "textMatrix", "font", "fontObj", "filter", "fillColor", "textRenderingMode", "SMask", "fillAlpha", "strokeAlpha", "globalCompositeOperation", "sameLineText"],
  transform: ["transform"],
  transformAndFill: ["transform", "filter", "fillColor"]
};
var Ya, Ka, qa, Qa, Ja, Dd;
const Xc = class Xc {
  constructor(t) {
    g(this, Ya);
    g(this, Ka);
    g(this, qa, 4);
    g(this, Qa, 0);
    g(this, Ja, new (i(Xc, Dd))(i(this, qa) * 6));
    u(this, Ya, t.width), u(this, Ka, t.height);
  }
  record(t, e, s, n) {
    if (i(this, Qa) === i(this, qa)) {
      u(this, qa, i(this, qa) * 2);
      const o = new (i(Xc, Dd))(i(this, qa) * 6);
      o.set(i(this, Ja)), u(this, Ja, o);
    }
    const r = wt(t);
    let a;
    if (n[0] !== 1 / 0) {
      const o = Yi.slice();
      I.axialAlignedBoundingBox([0, -s, e, 0], r, o);
      const l = I.intersect(n, o);
      if (!l)
        return;
      const [h, c, d, f] = l;
      if (h !== o[0] || c !== o[1] || d !== o[2] || f !== o[3]) {
        const b = Math.atan2(r[1], r[0]), y = Math.abs(Math.sin(b)), A = Math.abs(Math.cos(b));
        if (y < 1e-6 || A < 1e-6 || Math.abs(y - A) < 1e-6)
          a = [h, c, h, f, d, c];
        else {
          const w = d - h, v = f - c, S = y * y, E = A * A, C = A * y, x = E - S, T = (v * E - w * C) / x, k = (v * C - w * S) / x;
          a = [h + k, c, h, c + T, d, f - T];
        }
      }
    }
    a || (a = [0, -s, 0, 0, e, -s], I.applyTransform(a, r, 0), I.applyTransform(a, r, 2), I.applyTransform(a, r, 4)), a[0] /= i(this, Ya), a[1] /= i(this, Ka), a[2] /= i(this, Ya), a[3] /= i(this, Ka), a[4] /= i(this, Ya), a[5] /= i(this, Ka), i(this, Ja).set(a, i(this, Qa) * 6), rt(this, Qa)._++;
  }
  take() {
    return i(this, Ja).subarray(0, i(this, Qa) * 6);
  }
};
Ya = new WeakMap(), Ka = new WeakMap(), qa = new WeakMap(), Qa = new WeakMap(), Ja = new WeakMap(), Dd = new WeakMap(), g(Xc, Dd, ot.isFloat16ArraySupported ? Float16Array : Float32Array);
let am = Xc;
function rv(p, t, {
  recordOperations: e = !1,
  recordImages: s = !1,
  recordDebugMetadata: n = !1
}) {
  const r = e || s ? new iv(p, t) : null;
  return {
    dependencyTracker: e ? new nv(r, n) : r,
    imagesTracker: s ? new am(p) : null
  };
}
function MA({
  src: p,
  srcPos: t = 0,
  dest: e,
  width: s,
  height: n,
  nonBlackColor: r = 4294967295,
  inverseDecode: a = !1
}) {
  const o = ot.isLittleEndian ? 4278190080 : 255, [l, h] = a ? [r, o] : [o, r], c = s >> 3, d = s & 7, f = l ^ h, b = p.length;
  e = new Uint32Array(e.buffer);
  let y = 0;
  for (let A = 0; A < n; ++A) {
    for (const v = t + c; t < v; ++t, y += 8) {
      const S = p[t];
      e[y] = l ^ -(S >> 7 & 1) & f, e[y + 1] = l ^ -(S >> 6 & 1) & f, e[y + 2] = l ^ -(S >> 5 & 1) & f, e[y + 3] = l ^ -(S >> 4 & 1) & f, e[y + 4] = l ^ -(S >> 3 & 1) & f, e[y + 5] = l ^ -(S >> 2 & 1) & f, e[y + 6] = l ^ -(S >> 1 & 1) & f, e[y + 7] = l ^ -(S & 1) & f;
    }
    if (d === 0)
      continue;
    const w = t < b ? p[t++] : 255;
    for (let v = 0; v < d; ++v, ++y)
      e[y] = l ^ -(w >> 7 - v & 1) & f;
  }
  return {
    srcPos: t,
    destPos: y
  };
}
function av({
  src: p,
  srcPos: t = 0,
  dest: e,
  destPos: s = 0,
  width: n,
  height: r
}) {
  let a = 0;
  const o = n * r * 3, l = p.byteOffset + t, h = l % 4 === 0 ? Math.floor(vt(p.length - t, 0, o) / 4) : 0, c = h > 0 ? new Uint32Array(p.buffer, l, h) : null, d = ot.isLittleEndian ? 4278190080 : 255;
  if (ot.isLittleEndian) {
    for (; a < h - 2; a += 3, s += 4) {
      const f = c[a], b = c[a + 1], y = c[a + 2];
      e[s] = f | d, e[s + 1] = f >>> 24 | b << 8 | d, e[s + 2] = b >>> 16 | y << 16 | d, e[s + 3] = y >>> 8 | d;
    }
    for (let f = t + a * 4, b = t + o; f < b; f += 3)
      e[s++] = p[f] | p[f + 1] << 8 | p[f + 2] << 16 | d;
  } else {
    for (; a < h - 2; a += 3, s += 4) {
      const f = c[a], b = c[a + 1], y = c[a + 2];
      e[s] = f | d, e[s + 1] = f << 24 | b >>> 8 | d, e[s + 2] = b << 16 | y >>> 16 | d, e[s + 3] = y << 8 | d;
    }
    for (let f = t + a * 4, b = t + o; f < b; f += 3)
      e[s++] = p[f] << 24 | p[f + 1] << 16 | p[f + 2] << 8 | d;
  }
  return {
    srcPos: t + o,
    destPos: s
  };
}
const Zt = {
  FILL: "Fill",
  STROKE: "Stroke",
  SHADING: "Shading"
};
function _f(p, t) {
  if (!t)
    return;
  const e = t[2] - t[0], s = t[3] - t[1], n = new Path2D();
  n.rect(t[0], t[1], e, s), p.clip(n);
}
class Hb {
  constructor() {
    _(this, "matrix", null);
  }
  isModifyingCurrentTransform() {
    return !1;
  }
  getPattern() {
    it("Abstract method `getPattern` called.");
  }
}
class ov extends Hb {
  constructor(t) {
    super(), this._type = t[1], this._bbox = t[2], this._colorStops = t[3], this._p0 = t[4], this._p1 = t[5], this._r0 = t[6], this._r1 = t[7];
  }
  isOriginBased() {
    return this._p0[0] === 0 && this._p0[1] === 0 && (!this.isRadial() || this._p1[0] === 0 && this._p1[1] === 0);
  }
  isRadial() {
    return this._type === "radial";
  }
  areConic() {
    if (!this.isRadial())
      return !1;
    const t = Math.hypot(this._p0[0] - this._p1[0], this._p0[1] - this._p1[1]);
    return t + this._r1 > this._r0 && t + this._r0 > this._r1;
  }
  _createGradient(t, e = null) {
    let s, n = this._p0, r = this._p1;
    if (e && (n = n.slice(), r = r.slice(), I.applyTransform(n, e), I.applyTransform(r, e)), this._type === "axial")
      s = t.createLinearGradient(n[0], n[1], r[0], r[1]);
    else if (this._type === "radial") {
      let a = this._r0, o = this._r1;
      if (e) {
        const l = new Float32Array(2);
        I.singularValueDecompose2dScale(e, l), a *= l[0], o *= l[0];
      }
      s = t.createRadialGradient(n[0], n[1], a, r[0], r[1], o);
    }
    for (const a of this._colorStops)
      s.addColorStop(a[0], a[1]);
    return s;
  }
  _createReversedGradient(t, e = null) {
    let s = this._p1, n = this._p0;
    e && (s = s.slice(), n = n.slice(), I.applyTransform(s, e), I.applyTransform(n, e));
    let r = this._r1, a = this._r0;
    if (e) {
      const h = new Float32Array(2);
      I.singularValueDecompose2dScale(e, h), r *= h[0], a *= h[0];
    }
    const o = t.createRadialGradient(s[0], s[1], r, n[0], n[1], a), l = this._colorStops.map(([h, c]) => [1 - h, c]).reverse();
    for (const [h, c] of l)
      o.addColorStop(h, c);
    return o;
  }
  _createRasterPattern(t, e, s, n, r, a) {
    const o = Math.ceil(n[2] - n[0]) || 1, l = Math.ceil(n[3] - n[1]) || 1, h = e.canvasFactory.create(o, l), c = h.context;
    c.clearRect(0, 0, o, l), c.beginPath(), c.rect(0, 0, o, l), c.translate(-n[0], -n[1]), s = I.transform(s, [1, 0, 0, 1, n[0], n[1]]), c.transform(...r), _f(c, this._bbox), this.areConic() && (c.fillStyle = this._createReversedGradient(c), c.fill()), c.fillStyle = this._createGradient(c), c.fill(), a == null || a.applyToCanvas(c);
    const d = t.createPattern(h.canvas, "no-repeat");
    return e.canvasFactory.destroy(h), d.setTransform(new DOMMatrix(s)), d;
  }
  getPattern(t, e, s, n) {
    const r = e.current.transferMapsFallback;
    if (n === Zt.STROKE || n === Zt.FILL) {
      if (this.isOriginBased() && !r) {
        let l = I.transform(s, e.baseTransform);
        this.matrix && (l = I.transform(l, this.matrix));
        const h = 1e-3, c = Math.hypot(l[0], l[1]), d = Math.hypot(l[2], l[3]), f = (l[0] * l[2] + l[1] * l[3]) / (c * d);
        if (Math.abs(f) < h)
          if (this.isRadial()) {
            if (Math.abs(c - d) < h)
              return this._createGradient(t, l);
          } else
            return this._createGradient(t, l);
      }
      const a = e.current.getClippedPathBoundingBox(n, wt(t)) || [0, 0, 0, 0], o = this.matrix ? I.transform(e.baseTransform, this.matrix) : e.baseTransform;
      return this._createRasterPattern(t, e, s, a, o, r);
    }
    return r && s ? this._createRasterPattern(t, e, s, e.current.clipBox, wt(t), r) : (this.areConic() && (t.save(), _f(t, this._bbox), t.fillStyle = this._createReversedGradient(t), t.fillRect(-1e10, -1e10, 2e10, 2e10), t.restore()), _f(t, this._bbox), this._createGradient(t));
  }
}
function lv(p, t, e, s, n, r, a, o) {
  const l = t.coords, h = t.colors, c = p.data, d = p.width * 4;
  let f;
  l[e * 2 + 1] > l[s * 2 + 1] && (f = e, e = s, s = f, f = r, r = a, a = f), l[s * 2 + 1] > l[n * 2 + 1] && (f = s, s = n, n = f, f = a, a = o, o = f), l[e * 2 + 1] > l[s * 2 + 1] && (f = e, e = s, s = f, f = r, r = a, a = f);
  const b = (l[e * 2] + t.offsetX) * t.scaleX, y = (l[e * 2 + 1] + t.offsetY) * t.scaleY, A = (l[s * 2] + t.offsetX) * t.scaleX, w = (l[s * 2 + 1] + t.offsetY) * t.scaleY, v = (l[n * 2] + t.offsetX) * t.scaleX, S = (l[n * 2 + 1] + t.offsetY) * t.scaleY;
  if (y >= S)
    return;
  const E = h[r * 4], C = h[r * 4 + 1], x = h[r * 4 + 2], T = h[a * 4], k = h[a * 4 + 1], M = h[a * 4 + 2], P = h[o * 4], D = h[o * 4 + 1], H = h[o * 4 + 2], Y = Math.round(y), Q = Math.round(S);
  let K, et, O, z, Nt, St, Ss, ke;
  for (let Bt = Y; Bt <= Q; Bt++) {
    if (Bt < w) {
      const Vt = Bt < y ? 0 : (y - Bt) / (y - w);
      K = b - (b - A) * Vt, et = E - (E - T) * Vt, O = C - (C - k) * Vt, z = x - (x - M) * Vt;
    } else {
      let Vt;
      Bt > S ? Vt = 1 : w === S ? Vt = 0 : Vt = (w - Bt) / (w - S), K = A - (A - v) * Vt, et = T - (T - P) * Vt, O = k - (k - D) * Vt, z = M - (M - H) * Vt;
    }
    let Et;
    Bt < y ? Et = 0 : Bt > S ? Et = 1 : Et = (y - Bt) / (y - S), Nt = b - (b - v) * Et, St = E - (E - P) * Et, Ss = C - (C - D) * Et, ke = x - (x - H) * Et;
    const ui = Math.round(Math.min(K, Nt)), Ji = Math.round(Math.max(K, Nt));
    let Es = d * Bt + ui * 4;
    for (let Vt = ui; Vt <= Ji; Vt++)
      Et = (K - Vt) / (K - Nt), Et < 0 ? Et = 0 : Et > 1 && (Et = 1), c[Es++] = et - (et - St) * Et | 0, c[Es++] = O - (O - Ss) * Et | 0, c[Es++] = z - (z - ke) * Et | 0, c[Es++] = 255;
  }
}
class hv extends Hb {
  constructor(t) {
    super(), this._posData = t[2], this._colData = t[3], this._vertexCount = t[4], this._bounds = t[5], this._bbox = t[6], this._background = t[7], qw();
  }
  _createMeshCanvas(t, e, s, n = null) {
    const l = Math.floor(this._bounds[0]), h = Math.floor(this._bounds[1]), c = Math.ceil(this._bounds[2]) - l, d = Math.ceil(this._bounds[3]) - h, f = Math.min(Math.ceil(Math.abs(c * t[0] * 1.1)), 3e3) || 1, b = Math.min(Math.ceil(Math.abs(d * t[1] * 1.1)), 3e3) || 1, y = c ? c / f : 1, A = d ? d / b : 1, w = {
      coords: this._posData,
      colors: this._colData,
      offsetX: -l,
      offsetY: -h,
      scaleX: 1 / y,
      scaleY: 1 / A
    }, v = f + 4, S = b + 4, E = s.create(v, S);
    if (EA() && this._vertexCount > 48)
      E.context.drawImage(Qw(this._posData, this._colData, this._vertexCount, w, e, v, S, 2), 0, 0);
    else {
      const C = E.context.createImageData(f, b);
      if (e) {
        const x = C.data;
        for (let T = 0, k = x.length; T < k; T += 4)
          x[T] = e[0], x[T + 1] = e[1], x[T + 2] = e[2], x[T + 3] = 255;
      }
      for (let x = 0, T = this._vertexCount; x < T; x += 3)
        lv(C, w, x, x + 1, x + 2, x, x + 1, x + 2);
      E.context.putImageData(C, 2, 2);
    }
    return n == null || n.applyToCanvas(E.context), {
      canvas: E.canvas,
      offsetX: l - 2 * y,
      offsetY: h - 2 * A,
      scaleX: y,
      scaleY: A
    };
  }
  isModifyingCurrentTransform() {
    return !0;
  }
  getPattern(t, e, s, n) {
    _f(t, this._bbox);
    const r = new Float32Array(2);
    if (n === Zt.SHADING)
      I.singularValueDecompose2dScale(wt(t), r);
    else if (this.matrix) {
      I.singularValueDecompose2dScale(this.matrix, r);
      const [l, h] = r;
      I.singularValueDecompose2dScale(e.baseTransform, r), r[0] *= l, r[1] *= h;
    } else
      I.singularValueDecompose2dScale(e.baseTransform, r);
    const a = this._createMeshCanvas(r, n === Zt.SHADING ? null : this._background, e.canvasFactory, e.current.transferMapsFallback);
    n !== Zt.SHADING && (t.setTransform(...e.baseTransform), this.matrix && t.transform(...this.matrix)), t.translate(a.offsetX, a.offsetY), t.scale(a.scaleX, a.scaleY);
    const o = t.createPattern(a.canvas, "no-repeat");
    return e.canvasFactory.destroy(a), o;
  }
}
class cv extends Hb {
  getPattern() {
    return "hotpink";
  }
}
function dv(p) {
  switch (p[0]) {
    case "RadialAxial":
      return new ov(p);
    case "Mesh":
      return new hv(p);
    case "Dummy":
      return new cv();
  }
  throw new Error(`Unknown IR type: ${p[0]}`);
}
const gy = {
  COLORED: 1,
  UNCOLORED: 2
}, kp = class kp {
  constructor(t, e, s, n) {
    this.color = t[1], this.operatorList = t[2], this.matrix = t[3], this.bbox = t[4], this.xstep = t[5], this.ystep = t[6], this.paintType = t[7], this.tilingType = t[8], this.needsIsolation = t[9] ?? !0, this.ctx = e, this.canvasGraphicsFactory = s, this.baseTransform = n, this.patternBaseMatrix = this.matrix ? I.transform(n, this.matrix) : n;
  }
  canSkipPatternCanvas([t, e, s, n]) {
    const [r, a, o, l] = this.bbox, h = Math.abs(this.xstep), c = Math.abs(this.ystep);
    if (t > h + 1e-6 || e > c + 1e-6)
      return null;
    const d = Math.floor((s - o) / h) + 1, f = Math.ceil((s + t - r) / h) - 1, b = Math.floor((n - l) / c) + 1, y = Math.ceil((n + e - a) / c) - 1;
    return f <= d && y <= b ? [d, b] : null;
  }
  updatePatternDims(t, e) {
    const s = Yi.slice();
    I.axialAlignedBoundingBox(t, I.inverseTransform(this.patternBaseMatrix), s), e[0] = s[2] - s[0], e[1] = s[3] - s[1], e[2] = s[0], e[3] = s[1];
  }
  _renderTileCanvas(t, e, s, n) {
    var f, b;
    const [r, a, o, l] = this.bbox, h = t.canvasFactory.create(s.size, n.size), c = h.context, d = this.canvasGraphicsFactory.createCanvasGraphics(c, e);
    return d.groupLevel = t.groupLevel, d.current.transferMapsFallback = t.current.transferMapsFallback, this.setFillAndStrokeStyleToContext(d, this.paintType, this.color), c.translate(-s.scale * r, -n.scale * a), d.transform(0, s.scale, 0, 0, n.scale, 0, 0), c.save(), (f = d.dependencyTracker) == null || f.save(), this.clipBbox(d, r, a, o, l), d.baseTransform = wt(d.ctx), d.executeOperatorList(this.operatorList), d.endDrawing(), (b = d.dependencyTracker) == null || b.restore(), c.restore(), h;
  }
  _getCombinedScales() {
    const t = new Float32Array(2);
    I.singularValueDecompose2dScale(this.matrix, t);
    const [e, s] = t;
    return I.singularValueDecompose2dScale(this.baseTransform, t), [e * t[0], s * t[1]];
  }
  drawPattern(t, e, s = !1, [n, r], a) {
    const [o, l, h, c] = this.bbox, d = t.dependencyTracker;
    d && (t.dependencyTracker = new Jc(d, a));
    try {
      if (t.save(), s ? t.ctx.clip(e, "evenodd") : t.ctx.clip(e), t.ctx.setTransform(...this.patternBaseMatrix), t.ctx.translate(n * this.xstep, r * this.ystep), this.needsIsolation || t.ctx.globalAlpha !== 1 || t.ctx.globalCompositeOperation !== "source-over" || t.inSMaskMode) {
        const f = h - o, b = c - l, [y, A] = this._getCombinedScales(), w = this.getSizeAndScale(f, this.ctx.canvas.width, y), v = this.getSizeAndScale(b, this.ctx.canvas.height, A), S = this._renderTileCanvas(t, a, w, v);
        t.ctx.drawImage(S.canvas, o, l, f, b), t.canvasFactory.destroy(S);
      } else
        t.resetGraphicsState(), this.setFillAndStrokeStyleToContext(t, this.paintType, this.color), this.clipBbox(t, o, l, h, c), t.baseTransformStack.push(t.baseTransform), t.baseTransform = wt(t.ctx), t.executeOperatorList(this.operatorList), t.baseTransform = t.baseTransformStack.pop();
      t.restore();
    } finally {
      d && (t.dependencyTracker = d);
    }
  }
  createPatternCanvas(t, e) {
    const [s, n, r, a] = this.bbox, o = r - s, l = a - n;
    let {
      xstep: h,
      ystep: c
    } = this;
    h = Math.abs(h), c = Math.abs(c), ig("TilingType: " + this.tilingType);
    const [d, f] = this._getCombinedScales();
    let b = o, y = l, A = !1, w = !1;
    Math.ceil(h * d) >= Math.ceil(o * d) ? b = h : A = !0, Math.ceil(c * f) >= Math.ceil(l * f) ? y = c : w = !0;
    const v = this.getSizeAndScale(b, this.ctx.canvas.width, d), S = this.getSizeAndScale(y, this.ctx.canvas.height, f), E = this._renderTileCanvas(t, e, v, S);
    if (A || w) {
      const C = E.canvas;
      A && (b = h), w && (y = c);
      const x = this.getSizeAndScale(b, this.ctx.canvas.width, d), T = this.getSizeAndScale(y, this.ctx.canvas.height, f), k = x.size, M = T.size, P = t.canvasFactory.create(k, M), D = P.context, H = A ? Math.min(Math.floor(o / h), Math.ceil(C.width / k)) : 0, Y = w ? Math.min(Math.floor(l / c), Math.ceil(C.height / M)) : 0;
      let Q = C, K = null;
      if (w) {
        K = t.canvasFactory.create(C.width, M);
        const et = K.context;
        for (let O = Y; O >= 0; O--)
          et.drawImage(C, 0, M * O, C.width, M, 0, 0, C.width, M);
        Q = K.canvas;
      }
      for (let et = H; et >= 0; et--)
        D.drawImage(Q, k * et, 0, k, M, 0, 0, k, M);
      return K && t.canvasFactory.destroy(K), t.canvasFactory.destroy(E), {
        canvas: P.canvas,
        canvasEntry: P,
        scaleX: x.scale,
        scaleY: T.scale,
        offsetX: s,
        offsetY: n
      };
    }
    return {
      canvas: E.canvas,
      canvasEntry: E,
      scaleX: v.scale,
      scaleY: S.scale,
      offsetX: s,
      offsetY: n
    };
  }
  getSizeAndScale(t, e, s) {
    const n = Math.max(kp.MAX_PATTERN_SIZE, e);
    let r = Math.ceil(t * s);
    return r >= n ? r = n : s = r / t, {
      scale: s,
      size: r
    };
  }
  clipBbox(t, e, s, n, r) {
    const a = n - e, o = r - s, l = new Path2D();
    l.rect(e, s, a, o), I.axialAlignedBoundingBox([e, s, n, r], wt(t.ctx), t.current.minMax), t.ctx.clip(l), t.current.updateClipFromPath();
  }
  setFillAndStrokeStyleToContext(t, e, s) {
    var a;
    switch (e) {
      case gy.COLORED:
        s = "#000000";
        break;
      case gy.UNCOLORED:
        break;
      default:
        throw new Sw(`Unsupported paint type: ${e}`);
    }
    const {
      ctx: n,
      current: r
    } = t;
    r.patternFill = r.patternStroke = !1, n.fillStyle = n.strokeStyle = ((a = r.transferMapsFallback) == null ? void 0 : a.applyToColor(s)) ?? s, r.fillColor = r.strokeColor = s;
  }
  isModifyingCurrentTransform() {
    return !1;
  }
  getPattern(t, e, s, n, r) {
    const a = n !== Zt.SHADING ? I.transform(s, this.patternBaseMatrix) : s, o = this.createPatternCanvas(e, r);
    let l = new DOMMatrix(a);
    l = l.translate(o.offsetX, o.offsetY), l = l.scale(1 / o.scaleX, 1 / o.scaleY);
    const h = t.createPattern(o.canvas, "repeat");
    return e.canvasFactory.destroy(o.canvasEntry), h.setTransform(l), h;
  }
};
_(kp, "MAX_PATTERN_SIZE", 3e3);
let Vc = kp;
const uv = 16, fv = 100, pv = 15, my = 10, Ke = 16, ys = new Float32Array(2);
function by(p, t) {
  if (p._removeMirroring)
    throw new Error("Context is already forwarding operations.");
  const e = /* @__PURE__ */ new Map();
  for (const s of ["save", "restore", "rotate", "scale", "translate", "transform", "setTransform", "resetTransform", "clip", "moveTo", "lineTo", "bezierCurveTo", "quadraticCurveTo", "arc", "arcTo", "ellipse", "rect", "roundRect", "closePath", "beginPath"]) {
    const n = p[s];
    typeof n != "function" || typeof t[s] != "function" || (e.set(s, n), p[s] = function(...r) {
      return t[s](...r), n.apply(this, r);
    });
  }
  p._removeMirroring = () => {
    for (const [s, n] of e)
      p[s] = n;
    delete p._removeMirroring;
  };
}
function df(p, t, e, s, n, r, a, o, l, h) {
  const [c, d, f, b, y, A] = wt(p);
  if (d === 0 && f === 0) {
    const S = a * c + y, E = Math.round(S), C = o * b + A, x = Math.round(C), T = (a + l) * c + y, k = Math.abs(Math.round(T) - E) || 1, M = (o + h) * b + A, P = Math.abs(Math.round(M) - x) || 1;
    return p.setTransform(Math.sign(c), 0, 0, Math.sign(b), E, x), p.drawImage(t, e, s, n, r, 0, 0, k, P), p.setTransform(c, d, f, b, y, A), [k, P];
  }
  if (c === 0 && b === 0) {
    const S = o * f + y, E = Math.round(S), C = a * d + A, x = Math.round(C), T = (o + h) * f + y, k = Math.abs(Math.round(T) - E) || 1, M = (a + l) * d + A, P = Math.abs(Math.round(M) - x) || 1;
    return p.setTransform(0, Math.sign(d), Math.sign(f), 0, E, x), p.drawImage(t, e, s, n, r, 0, 0, P, k), p.setTransform(c, d, f, b, y, A), [P, k];
  }
  p.drawImage(t, e, s, n, r, a, o, l, h);
  const w = Math.hypot(c, d), v = Math.hypot(f, b);
  return [w * l, v * h];
}
class wg {
  constructor(t, e) {
    _(this, "alphaIsShape", !1);
    _(this, "fontSize", 0);
    _(this, "fontSizeScale", 1);
    _(this, "textMatrix", null);
    _(this, "textMatrixScale", 1);
    _(this, "fontMatrix", xg);
    _(this, "leading", 0);
    _(this, "x", 0);
    _(this, "y", 0);
    _(this, "lineX", 0);
    _(this, "lineY", 0);
    _(this, "charSpacing", 0);
    _(this, "wordSpacing", 0);
    _(this, "textHScale", 1);
    _(this, "textRenderingMode", qt.FILL);
    _(this, "textRise", 0);
    _(this, "fillColor", "#000000");
    _(this, "strokeColor", "#000000");
    _(this, "tilingPatternDims", null);
    _(this, "patternFill", !1);
    _(this, "patternStroke", !1);
    _(this, "fillAlpha", 1);
    _(this, "strokeAlpha", 1);
    _(this, "lineWidth", 1);
    _(this, "activeSMask", null);
    _(this, "transferMaps", "none");
    _(this, "transferMapsFallback", null);
    _(this, "minMax", va.slice());
    this.clipBox = new Float32Array([0, 0, t, e]);
  }
  clone() {
    var e;
    const t = Object.create(this);
    return t.clipBox = this.clipBox.slice(), t.minMax = this.minMax.slice(), t.tilingPatternDims = (e = this.tilingPatternDims) == null ? void 0 : e.slice(), t;
  }
  getPathBoundingBox(t = Zt.FILL, e = null) {
    const s = this.minMax.slice();
    if (t === Zt.STROKE) {
      e || it("Stroke bounding box must include transform."), I.singularValueDecompose2dScale(e, ys);
      const n = ys[0] * this.lineWidth / 2, r = ys[1] * this.lineWidth / 2;
      s[0] -= n, s[1] -= r, s[2] += n, s[3] += r;
    }
    return s;
  }
  updateClipFromPath() {
    const t = I.intersect(this.clipBox, this.getPathBoundingBox());
    this.startNewPathAndClipBox(t || [0, 0, 0, 0]);
  }
  isEmptyClip() {
    return this.minMax[0] === 1 / 0;
  }
  startNewPathAndClipBox(t) {
    this.clipBox.set(t, 0), this.minMax.set(va, 0);
  }
  getClippedPathBoundingBox(t = Zt.FILL, e = null) {
    return I.intersect(this.clipBox, this.getPathBoundingBox(t, e));
  }
}
function yy(p, t) {
  const {
    width: e,
    height: s,
    kind: n
  } = t, r = s % Ke, a = (s - r) / Ke, o = r === 0 ? a : a + 1, l = p.createImageData(e, Ke);
  let h = 0;
  const c = t.data, d = l.data;
  let f;
  if (n === bf.GRAYSCALE_1BPP)
    for (f = 0; f < o; f++)
      ({
        srcPos: h
      } = MA({
        src: c,
        srcPos: h,
        dest: d,
        width: e,
        height: f < a ? Ke : r
      })), p.putImageData(l, 0, f * Ke);
  else if (n === bf.RGBA_32BPP) {
    let b = 0, y = e * Ke * 4;
    for (f = 0; f < a; f++)
      d.set(c.subarray(h, h + y)), h += y, p.putImageData(l, 0, b), b += Ke;
    f < o && (y = e * r * 4, d.set(c.subarray(h, h + y)), p.putImageData(l, 0, b));
  } else if (n === bf.RGB_24BPP)
    for (f = 0; f < o; f++)
      ({
        srcPos: h
      } = av({
        src: c,
        srcPos: h,
        dest: new Uint32Array(d.buffer),
        width: e,
        height: f < a ? Ke : r
      })), p.putImageData(l, 0, f * Ke);
  else
    throw new Error(`bad image kind: ${n}`);
}
function Ay(p, t) {
  if (t.bitmap) {
    p.drawImage(t.bitmap, 0, 0);
    return;
  }
  const {
    width: e,
    height: s
  } = t, n = s % Ke, r = (s - n) / Ke, a = n === 0 ? r : r + 1, o = p.createImageData(e, Ke);
  let l = 0;
  const h = t.data, c = o.data;
  for (let d = 0; d < a; d++)
    ({
      srcPos: l
    } = MA({
      src: h,
      srcPos: l,
      dest: c,
      width: e,
      height: d < r ? Ke : n,
      nonBlackColor: 0
    })), p.putImageData(o, 0, d * Ke);
}
function da(p, t) {
  const e = ["strokeStyle", "fillStyle", "fillRule", "globalAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "globalCompositeOperation", "font", "filter"];
  for (const s of e)
    p[s] !== void 0 && (t[s] = p[s]);
  p.setLineDash !== void 0 && (t.setLineDash(p.getLineDash()), t.lineDashOffset = p.lineDashOffset);
}
function DA(p, t) {
  var e;
  (e = p.setAttribute) == null || e.call(p, "data-canvas-name", t), p._pdfjsCanvasName = t;
}
function gv(p) {
  return p._pdfjsCanvasName ?? null;
}
function uf(p) {
  p.strokeStyle = p.fillStyle = "#000000", p.fillRule = "nonzero", p.globalAlpha = 1, p.lineWidth = 1, p.lineCap = "butt", p.lineJoin = "miter", p.miterLimit = 10, p.globalCompositeOperation = "source-over", p.font = "10px sans-serif", p.setLineDash !== void 0 && (p.setLineDash([]), p.lineDashOffset = 0);
  const {
    filter: t
  } = p;
  t !== "none" && t !== "" && (p.filter = "none");
}
var Ql;
class mv {
  constructor(t) {
    g(this, Ql);
    const [e, s = e, n = e] = t, r = I.identity0to256Map.slice();
    u(this, Ql, [e || r, s || r, n || r]);
  }
  applyToColor(t) {
    if (typeof t != "string" || !t.startsWith("#"))
      return t;
    const [e, s, n] = mc(t), [r, a, o] = i(this, Ql);
    return I.makeHexColor(r[e], a[s], o[n]);
  }
  applyToImageData({
    data: t
  }) {
    const [e, s, n] = i(this, Ql);
    for (let r = 0, a = t.length; r < a; r += 4)
      t[r] = e[t[r]], t[r + 1] = s[t[r + 1]], t[r + 2] = n[t[r + 2]];
  }
  applyToCanvas(t) {
    const {
      width: e,
      height: s
    } = t.canvas, n = t.getImageData(0, 0, e, s);
    this.applyToImageData(n), t.putImageData(n, 0, 0);
  }
}
Ql = new WeakMap();
function wy(p, t, e) {
  if (t)
    return !0;
  I.singularValueDecompose2dScale(p, ys);
  const s = Math.fround(e * la.PDF_TO_CSS_UNITS);
  return ys[0] <= s && ys[1] <= s;
}
const bv = ["butt", "round", "square"], yv = ["miter", "round", "bevel"], Av = {}, vy = {};
var Pp, Mp, ss, Mr, Za, to, eo, so, io, no, ro, Mi, N, om, lm, hm, cm, dm, He, ye, um, Tc, _c, IA, kf;
const nn = class nn {
  constructor(t, e, s, n, r, {
    optionalContentConfig: a,
    markedContentStack: o = null,
    pixelRatio: l = ws.pixelRatio
  }, h, c, d, f) {
    g(this, N);
    g(this, ss, 0);
    g(this, Mr, 0);
    g(this, Za, null);
    g(this, to, null);
    g(this, eo, null);
    g(this, so, null);
    g(this, io, 1);
    g(this, no);
    g(this, ro, null);
    g(this, Mi, []);
    this.ctx = t, this.current = new wg(this.ctx.canvas.width, this.ctx.canvas.height), this.stateStack = [], this.pendingClip = null, this.pendingEOFill = !1, this.commonObjs = e, this.objs = s, this.canvasFactory = n, this.filterFactory = r, this.groupStack = [], this.baseTransform = null, this.baseTransformStack = [], this.groupLevel = 0, this.smaskStack = [], this.tempSMask = null, this.smaskGroupCanvases = [], this.smaskPreparedEntry = null, this.smaskPreparedFor = null, this.smaskPreparedOffsetX = 0, this.smaskPreparedOffsetY = 0, this.smaskPreparedOOBAlpha = null, this.suspendedCtx = null, this.contentVisible = !0, this.markedContentStack = o || [], this.optionalContentConfig = a, this.pixelRatio = l, this.cachedPatterns = /* @__PURE__ */ new Map(), this.annotationCanvasMap = h, this.viewportScale = 1, this.outputScaleX = 1, this.outputScaleY = 1, this.pageColors = c, this._cachedScaleForStroking = [-1, 0], this._cachedBitmapsMap = /* @__PURE__ */ new Map(), this.dependencyTracker = d ?? null, this.imagesTracker = f ?? null;
  }
  getObject(t, e, s = null) {
    var n;
    return typeof e == "string" ? ((n = this.dependencyTracker) == null || n.recordNamedDependency(t, e), e.startsWith("g_") ? this.commonObjs.get(e) : this.objs.get(e)) : s;
  }
  beginDrawing({
    transform: t,
    viewport: e,
    transparency: s = !1,
    background: n = null
  }) {
    const r = this.ctx.canvas.width, a = this.ctx.canvas.height, o = this.ctx.fillStyle;
    if (this.ctx.fillStyle = n || "#ffffff", this.ctx.fillRect(0, 0, r, a), this.ctx.fillStyle = o, s) {
      const l = this.transparentCanvasEntry = this.canvasFactory.create(r, a);
      this.compositeCtx = this.ctx, {
        canvas: this.transparentCanvas,
        context: this.ctx
      } = l, this.ctx.save(), this.ctx.transform(...wt(this.compositeCtx));
    }
    this.ctx.save(), uf(this.ctx), t && (this.ctx.transform(...t), this.outputScaleX = t[0], this.outputScaleY = t[3]), this.ctx.transform(...e.transform), this.viewportScale = e.scale, this.baseTransform = wt(this.ctx);
  }
  executeOperatorList(t, e, s, n, r, a) {
    var c;
    const o = t.argsArray, l = t.fnArray, h = this._pathCache;
    this._pathCache = t.pathCache ?? i(nn, Mp).getOrInsertComputed(t, op);
    try {
      let d = e || 0;
      const f = o.length;
      if (f === d)
        return d;
      const b = f - d > my && typeof s == "function", y = b ? Date.now() + pv : 0;
      let A = 0;
      const w = this.commonObjs, v = this.objs;
      let S, E;
      for (; ; ) {
        if (r !== void 0) {
          if (d === r.nextBreakPoint)
            return r.breakIt(d, s), d;
          if (r.shouldSkip(d)) {
            if (++d === f)
              return d;
            continue;
          }
        }
        if (!a || a(d, t))
          if (S = l[d], E = o[d] ?? null, S !== an.dependency)
            E === null ? this[S](d) : this[S](d, ...E);
          else
            for (const C of E) {
              (c = this.dependencyTracker) == null || c.recordNamedData(C, d);
              const x = C.startsWith("g_") ? w : v;
              if (!x.has(C))
                return x.get(C, s, n), d;
            }
        if (d++, d === f)
          return d;
        if (b && ++A > my) {
          if (Date.now() > y)
            return s(), d;
          A = 0;
        }
      }
    } finally {
      this._pathCache = h;
    }
  }
  endDrawing() {
    m(this, N, om).call(this);
    for (const t of this.smaskGroupCanvases)
      this.canvasFactory.destroy(t);
    this.smaskGroupCanvases.length = 0, this._clearPreparedSMask(), this.tempSMask = null, this.smaskStack.length = 0;
    for (const t of i(this, Mi))
      m(this, N, kf).call(this, t);
    i(this, Mi).length = 0, u(this, Za, null), u(this, to, null), u(this, eo, null), u(this, so, null), u(this, io, 1), u(this, ro, null), u(this, Mr, 0), u(this, ss, 0), this.cachedPatterns.clear();
    for (const t of this._cachedBitmapsMap.values()) {
      for (const e of t.values())
        typeof HTMLCanvasElement < "u" && e instanceof HTMLCanvasElement && (e.width = e.height = 0);
      t.clear();
    }
    this._cachedBitmapsMap.clear(), m(this, N, lm).call(this);
  }
  _scaleImage(t, e) {
    const s = t.width ?? t.displayWidth, n = t.height ?? t.displayHeight, r = Math.max(Math.hypot(e[0], e[1]), 1), a = Math.max(Math.hypot(e[2], e[3]), 1), o = [];
    let l = r, h = a, c = s, d = n;
    for (; l > 2 && c > 1 || h > 2 && d > 1; ) {
      let v = c, S = d;
      l > 2 && c > 1 && (v = Math.ceil(c / 2), l /= c / v), h > 2 && d > 1 && (S = Math.ceil(d / 2), h /= d / S), o.push({
        newWidth: v,
        newHeight: S
      }), c = v, d = S;
    }
    if (o.length === 0)
      return {
        img: t,
        paintWidth: s,
        paintHeight: n,
        tmpCanvas: null
      };
    if (o.length === 1) {
      const {
        newWidth: v,
        newHeight: S
      } = o[0], E = this.canvasFactory.create(v, S);
      return E.context.drawImage(t, 0, 0, s, n, 0, 0, v, S), {
        img: E.canvas,
        paintWidth: v,
        paintHeight: S,
        tmpCanvas: E
      };
    }
    let f = this.canvasFactory.create(1, 1), b = this.canvasFactory.create(1, 1), y = s, A = n, w = t;
    for (const {
      newWidth: v,
      newHeight: S
    } of o)
      this.canvasFactory.reset(b, v, S), b.context.drawImage(w, 0, 0, y, A, 0, 0, v, S), [f, b] = [b, f], w = f.canvas, y = v, A = S;
    return this.canvasFactory.destroy(b), {
      img: f.canvas,
      paintWidth: y,
      paintHeight: A,
      tmpCanvas: f
    };
  }
  _createMaskCanvas(t, e) {
    var H, Y;
    const s = this.ctx, {
      width: n,
      height: r
    } = e, a = this.current.patternFill, o = a ? this.current.fillColor : s.fillStyle, l = wt(s);
    let h, c, d, f;
    if ((e.bitmap || e.data) && e.count > 1) {
      const Q = e.bitmap || e.data.buffer;
      c = JSON.stringify(a ? l : [l.slice(0, 4), o]), h = this._cachedBitmapsMap.getOrInsertComputed(Q, op);
      const K = h.get(c);
      if (K && !a) {
        const et = Math.round(Math.min(l[0], l[2]) + l[4]), O = Math.round(Math.min(l[1], l[3]) + l[5]);
        return (H = this.dependencyTracker) == null || H.recordDependencies(t, Ts.transformAndFill), {
          canvas: K,
          offsetX: et,
          offsetY: O
        };
      }
      d = K;
    }
    d || (f = this.canvasFactory.create(n, r), Ay(f.context, e));
    let b = I.transform(l, [1 / n, 0, 0, -1 / r, 0, 0]);
    b = I.transform(b, [1, 0, 0, 1, 0, -r]);
    const y = va.slice();
    I.axialAlignedBoundingBox([0, 0, n, r], b, y);
    const [A, w, v, S] = y, E = Math.round(v - A) || 1, C = Math.round(S - w) || 1, x = this.canvasFactory.create(E, C), T = x.context, k = A, M = w;
    T.translate(-k, -M), T.transform(...b);
    let P = null;
    if (!d) {
      const Q = this._scaleImage(f.canvas, Zi(T));
      d = Q.img, P = Q.tmpCanvas, d !== f.canvas && (this.canvasFactory.destroy(f), f = null), h && a && (h.set(c, d), P = null, f = null);
    }
    T.imageSmoothingEnabled = wy(wt(T), e.interpolate, this.pixelRatio), df(T, d, 0, 0, d.width, d.height, 0, 0, n, r), P && this.canvasFactory.destroy(P), f && this.canvasFactory.destroy(f), T.globalCompositeOperation = "source-in";
    const D = I.transform(Zi(T), [1, 0, 0, 1, -k, -M]);
    return T.fillStyle = a ? o.getPattern(s, this, D, Zt.FILL, t) : o, T.fillRect(0, 0, n, r), h && !a && h.set(c, x.canvas), (Y = this.dependencyTracker) == null || Y.recordDependencies(t, Ts.transformAndFill), {
      canvas: x.canvas,
      canvasEntry: h && !a ? null : x,
      offsetX: Math.round(k),
      offsetY: Math.round(M)
    };
  }
  setLineWidth(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("lineWidth", t), e !== this.current.lineWidth && (this._cachedScaleForStroking[0] = -1), this.current.lineWidth = e, this.ctx.lineWidth = e;
  }
  setLineCap(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("lineCap", t), this.ctx.lineCap = bv[e];
  }
  setLineJoin(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("lineJoin", t), this.ctx.lineJoin = yv[e];
  }
  setMiterLimit(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("miterLimit", t), this.ctx.miterLimit = e;
  }
  setDash(t, e, s) {
    var r;
    (r = this.dependencyTracker) == null || r.recordSimpleData("dash", t);
    const n = this.ctx;
    n.setLineDash !== void 0 && (n.setLineDash(e), n.lineDashOffset = s);
  }
  setRenderingIntent(t, e) {
  }
  setFlatness(t, e) {
  }
  setGState(t, e) {
    var s, n, r, a, o;
    for (const [l, h] of e)
      switch (l) {
        case "LW":
          this.setLineWidth(t, h);
          break;
        case "LC":
          this.setLineCap(t, h);
          break;
        case "LJ":
          this.setLineJoin(t, h);
          break;
        case "ML":
          this.setMiterLimit(t, h);
          break;
        case "D":
          this.setDash(t, h[0], h[1]);
          break;
        case "RI":
          this.setRenderingIntent(t, h);
          break;
        case "FL":
          this.setFlatness(t, h);
          break;
        case "Font":
          this.setFont(t, h[0], h[1]);
          break;
        case "CA":
          (s = this.dependencyTracker) == null || s.recordSimpleData("strokeAlpha", t), this.current.strokeAlpha = h;
          break;
        case "ca":
          (n = this.dependencyTracker) == null || n.recordSimpleData("fillAlpha", t), this.ctx.globalAlpha = this.current.fillAlpha = h;
          break;
        case "BM":
          (r = this.dependencyTracker) == null || r.recordSimpleData("globalCompositeOperation", t), this.ctx.globalCompositeOperation = h;
          break;
        case "SMask":
          (a = this.dependencyTracker) == null || a.recordSimpleData("SMask", t), this.current.activeSMask = h ? this.tempSMask : null, this.current.activeSMask && (this.current.activeSMask.blendMode = this.ctx.globalCompositeOperation), this.tempSMask = null, this.checkSMaskState(t);
          break;
        case "TR": {
          (o = this.dependencyTracker) == null || o.recordSimpleData("filter", t);
          let c = this.filterFactory.addFilter(h);
          this.ctx.filter = c;
          let d = null;
          h && (c === "none" || !ot.isCanvasFilterSupported || this.ctx.filter === "none" || this.ctx.filter === "") && (this.ctx.filter = c = "none", d = new mv(h)), this.current.transferMaps = c, (d || this.current.transferMapsFallback) && (this.current.transferMapsFallback = d, this.current.patternFill || (this.ctx.fillStyle = m(this, N, _c).call(this, this.current.fillColor)), this.current.patternStroke || (this.ctx.strokeStyle = m(this, N, _c).call(this, this.current.strokeColor)));
          break;
        }
      }
  }
  get inSMaskMode() {
    return !!this.suspendedCtx;
  }
  _clearPreparedSMask() {
    this.smaskPreparedEntry && (this.canvasFactory.destroy(this.smaskPreparedEntry), this.smaskPreparedEntry = null), this.smaskPreparedFor = null, this.smaskPreparedOffsetX = 0, this.smaskPreparedOffsetY = 0, this.smaskPreparedOOBAlpha = null;
  }
  _ensurePreparedSMask(t) {
    t !== this.smaskPreparedFor && (this._clearPreparedSMask(), this._prepareSMaskCanvas(t));
  }
  checkSMaskState(t) {
    const e = this.inSMaskMode;
    this.current.activeSMask && !e ? this.beginSMaskMode(t) : !this.current.activeSMask && e ? this.endSMaskMode() : this.current.activeSMask && e && this._ensurePreparedSMask(this.current.activeSMask);
  }
  _prepareSMaskCanvas(t) {
    const {
      canvas: e,
      subtype: s,
      backdrop: n,
      transferMap: r
    } = t, a = s === "Luminosity" || s === "Alpha" && r;
    if (!a && !(s === "Luminosity" && n)) {
      this.smaskPreparedFor = t;
      return;
    }
    let o;
    if (s === "Luminosity" && n) {
      const [S, E, C] = mc(n), x = Math.round(0.3 * S + 0.59 * E + 0.11 * C);
      o = (r == null ? void 0 : r[x]) ?? x;
    } else
      o = (r == null ? void 0 : r[0]) ?? 0;
    const l = 4, {
      width: h,
      height: c
    } = this.ctx.canvas, d = e.width * e.height, f = h * c < l * d, b = a ? {
      url: s === "Alpha" ? this.filterFactory.addAlphaFilter(r) : this.filterFactory.addLuminosityFilter(r),
      subtype: s,
      transferMap: r
    } : null, y = s === "Luminosity" ? n : null;
    let A, w, v;
    f ? (A = this._bakeSMaskCanvas(e, t.offsetX, t.offsetY, h, c, y, b), w = 0, v = 0) : (A = this._bakeSMaskCanvas(e, 0, 0, e.width, e.height, y, b), w = t.offsetX, v = t.offsetY), this.smaskPreparedEntry = A, this.smaskPreparedFor = t, this.smaskPreparedOffsetX = w, this.smaskPreparedOffsetY = v, this.smaskPreparedOOBAlpha = !f && o !== 0 ? o : null;
  }
  _bakeSMaskCanvas(t, e, s, n, r, a, o) {
    !a && !o && it("_bakeSMaskCanvas with neither backdrop nor filter");
    const l = this.canvasFactory.create(n, r), h = l.context;
    if (h.drawImage(t, e, s), a && (h.globalCompositeOperation = "destination-atop", h.fillStyle = a, h.fillRect(0, 0, n, r)), !o)
      return l;
    const c = this.canvasFactory.create(n, r), d = c.context;
    d.filter = o.url;
    const f = ot.isCanvasFilterSupported && d.filter !== "none" && d.filter !== "";
    if (d.drawImage(l.canvas, 0, 0), ot.isCanvasFilterSupported && (d.filter = "none"), !f) {
      const b = d.getImageData(0, 0, n, r), {
        data: y
      } = b, {
        transferMap: A
      } = o;
      if (o.subtype === "Luminosity")
        for (let w = 0, v = y.length; w < v; w += 4) {
          const S = 0.3 * y[w] + 0.59 * y[w + 1] + 0.11 * y[w + 2] + 0.5 | 0;
          y[w] = y[w + 1] = y[w + 2] = 0, y[w + 3] = (A == null ? void 0 : A[S]) ?? S;
        }
      else
        for (let w = 3, v = y.length; w < v; w += 4)
          y[w] = A[y[w]];
      d.putImageData(b, 0, 0);
    }
    return this.canvasFactory.destroy(l), c;
  }
  beginSMaskMode(t) {
    if (this.inSMaskMode)
      throw new Error("beginSMaskMode called while already in smask mode");
    const {
      width: e,
      height: s
    } = this.ctx.canvas, n = this.canvasFactory.create(e, s);
    this.smaskScratchCanvas = n, this.suspendedCtx = this.ctx;
    const r = this.ctx = n.context;
    r.setTransform(this.suspendedCtx.getTransform()), da(this.suspendedCtx, r), by(r, this.suspendedCtx), this._ensurePreparedSMask(this.current.activeSMask), this.setGState(t, [["BM", "source-over"]]);
  }
  endSMaskMode() {
    if (!this.inSMaskMode)
      throw new Error("endSMaskMode called while not in smask mode");
    this.ctx._removeMirroring(), da(this.ctx, this.suspendedCtx), this.ctx = this.suspendedCtx, this.suspendedCtx = null, this.canvasFactory.destroy(this.smaskScratchCanvas), this.smaskScratchCanvas = null, this._clearPreparedSMask();
  }
  compose(t) {
    if (!this.current.activeSMask)
      return;
    t = t ? [Math.floor(t[0]), Math.floor(t[1]), Math.ceil(t[2]), Math.ceil(t[3])] : [0, 0, this.ctx.canvas.width, this.ctx.canvas.height];
    const e = this.current.activeSMask, s = this.suspendedCtx, n = i(this, Mr) > 0 && s === this.ctx;
    this.composeSMask(n ? null : s, e, this.ctx, t), !n && (this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height), this.ctx.restore());
  }
  composeSMask(t, e, s, n) {
    const r = n[0], a = n[1], o = n[2] - r, l = n[3] - a;
    if (o === 0 || l === 0)
      return;
    const h = this.smaskPreparedEntry;
    if (h) {
      let c = r, d = a, f = o, b = l;
      const y = this.smaskPreparedOOBAlpha, A = y !== null;
      if (A) {
        c = Math.max(r, e.offsetX), d = Math.max(a, e.offsetY);
        const w = Math.min(r + o, e.offsetX + e.canvas.width), v = Math.min(a + l, e.offsetY + e.canvas.height);
        f = w - c, b = v - d;
      }
      if (f > 0 && b > 0) {
        const w = c - this.smaskPreparedOffsetX, v = d - this.smaskPreparedOffsetY;
        s.save(), s.globalAlpha = 1, s.setTransform(1, 0, 0, 1, 0, 0);
        const S = new Path2D();
        S.rect(c, d, f, b), s.clip(S), s.globalCompositeOperation = "destination-in", s.drawImage(h.canvas, w, v, f, b, c, d, f, b), s.restore();
      }
      A && y < 255 && this._applySMaskOOBAlpha(s, r, a, o, l, c, d, c + f, d + b, y);
    } else
      this.genericComposeSMask(e, s, o, l, r, a);
    t && (t.save(), t.globalAlpha = 1, t.globalCompositeOperation = e.blendMode || "source-over", t.setTransform(1, 0, 0, 1, 0, 0), t.drawImage(s.canvas, r, a, o, l, r, a, o, l), t.restore());
  }
  _applySMaskOOBAlpha(t, e, s, n, r, a, o, l, h, c) {
    const d = a < l && o < h;
    if (d && a === e && o === s && l === e + n && h === s + r)
      return;
    const f = new Path2D();
    f.rect(e, s, n, r), d && f.rect(a, o, l - a, h - o), t.save(), t.globalAlpha = c / 255, t.setTransform(1, 0, 0, 1, 0, 0), t.clip(f, "evenodd"), t.globalCompositeOperation = "destination-in", t.fillStyle = "#000000", t.fillRect(e, s, n, r), t.restore();
  }
  genericComposeSMask(t, e, s, n, r, a) {
    const {
      context: o,
      offsetX: l,
      offsetY: h
    } = t;
    e.save(), e.globalAlpha = 1, e.setTransform(1, 0, 0, 1, 0, 0);
    const c = new Path2D();
    c.rect(r, a, s, n), e.clip(c), e.globalCompositeOperation = "destination-in", e.drawImage(o.canvas, r - l, a - h, s, n, r, a, s, n), e.restore();
  }
  save(t) {
    var s;
    this.inSMaskMode && da(this.ctx, this.suspendedCtx), this.ctx.save();
    const e = this.current;
    this.stateStack.push(e), this.current = e.clone(), (s = this.dependencyTracker) == null || s.save(t);
  }
  restore(t) {
    var e;
    if ((e = this.dependencyTracker) == null || e.restore(t), this.stateStack.length === 0) {
      this.inSMaskMode && this.endSMaskMode();
      return;
    }
    this.current = this.stateStack.pop(), this.ctx.restore(), this.inSMaskMode && (da(this.suspendedCtx, this.ctx), this.ctx.setTransform(this.suspendedCtx.getTransform())), this.checkSMaskState(t), this.pendingClip = null, this._cachedScaleForStroking[0] = -1;
  }
  resetGraphicsState() {
    const {
      clipBox: t,
      transferMaps: e,
      transferMapsFallback: s
    } = this.current, n = this.current = new wg(0, 0);
    n.clipBox = t, n.transferMaps = e, n.transferMapsFallback = s;
    const r = this.ctx;
    r.lineWidth = 1, r.lineCap = "butt", r.lineJoin = "miter", r.miterLimit = 10, r.setLineDash !== void 0 && (r.setLineDash([]), r.lineDashOffset = 0), this._cachedScaleForStroking[0] = -1;
  }
  transform(t, e, s, n, r, a, o) {
    var l;
    (l = this.dependencyTracker) == null || l.recordIncrementalData("transform", t), this.ctx.transform(e, s, n, r, a, o), this._cachedScaleForStroking[0] = -1;
  }
  constructPath(t, e, s, n) {
    let r = this._pathCache.get(t);
    if (!n) {
      r || (r = new Path2D(), this._pathCache.set(t, r)), e !== an.stroke && e !== an.closeStroke && (this.current.tilingPatternDims = null), this[e](t, r);
      return;
    }
    if (this.dependencyTracker !== null) {
      const o = e === an.stroke ? this.current.lineWidth / 2 : 0;
      this.dependencyTracker.resetBBox(t).recordBBox(t, this.ctx, n[0] - o, n[2] + o, n[1] - o, n[3] + o).recordDependencies(t, ["transform"]);
    }
    r || (r = Ny(s[0]), this._pathCache.set(t, r)), I.axialAlignedBoundingBox(n, wt(this.ctx), this.current.minMax);
    const a = this.current.tilingPatternDims;
    if (a && e !== an.stroke && e !== an.closeStroke && this.current.fillColor instanceof Vc) {
      const o = I.intersect(this.current.clipBox, this.current.minMax);
      o ? this.current.fillColor.updatePatternDims(o, a) : this.current.tilingPatternDims = null;
    }
    this[e](t, r), this._pathStartIdx = t;
  }
  closePath(t) {
    this.ctx.closePath();
  }
  stroke(t, e, s = !0) {
    var o;
    const n = s && m(this, N, He).call(this, this.current.strokeAlpha), r = this.ctx, a = this.current.strokeColor;
    if (r.globalAlpha = this.current.strokeAlpha, this.contentVisible)
      if (typeof a == "object" && (a != null && a.getPattern)) {
        const l = a.isModifyingCurrentTransform() ? r.getTransform() : null;
        if (r.save(), r.strokeStyle = a.getPattern(r, this, Zi(r), Zt.STROKE, t), l) {
          const h = new Path2D();
          h.addPath(e, r.getTransform().invertSelf().multiplySelf(l)), e = h;
        }
        this.rescaleAndStroke(e, !1), r.restore();
      } else
        this.rescaleAndStroke(e, !0);
    (o = this.dependencyTracker) == null || o.recordDependencies(t, Ts.stroke), s && this.consumePath(t, e, this.current.getClippedPathBoundingBox(Zt.STROKE, wt(this.ctx))), r.globalAlpha = this.current.fillAlpha, m(this, N, ye).call(this, n);
  }
  closeStroke(t, e) {
    this.stroke(t, e);
  }
  fill(t, e, s = !0) {
    var c, d, f;
    const n = s && m(this, N, He).call(this, this.current.fillAlpha), r = this.ctx, a = this.current.fillColor, o = this.current.patternFill;
    let l = !1;
    const h = this.current.getClippedPathBoundingBox();
    if ((c = this.dependencyTracker) == null || c.recordDependencies(t, Ts.fill), o) {
      const b = this.current.tilingPatternDims, y = b && a.canSkipPatternCanvas(b);
      if (y) {
        const {
          pendingClip: w,
          pendingEOFill: v
        } = this;
        this.pendingClip = null, this.pendingEOFill = !1, a.drawPattern(this, e, v, y, t), this.pendingClip = w, s && this.consumePath(t, e, h), this.current.tilingPatternDims = null, m(this, N, ye).call(this, n);
        return;
      }
      const A = a.isModifyingCurrentTransform() ? r.getTransform() : null;
      if ((d = this.dependencyTracker) == null || d.save(t), r.save(), r.fillStyle = a.getPattern(r, this, Zi(r), Zt.FILL, t), A) {
        const w = new Path2D();
        w.addPath(e, r.getTransform().invertSelf().multiplySelf(A)), e = w;
      }
      l = !0;
    }
    this.contentVisible && h !== null && (this.pendingEOFill ? (r.fill(e, "evenodd"), this.pendingEOFill = !1) : r.fill(e)), l && (r.restore(), (f = this.dependencyTracker) == null || f.restore(t)), s && this.consumePath(t, e, h), m(this, N, ye).call(this, n);
  }
  eoFill(t, e) {
    this.pendingEOFill = !0, this.fill(t, e);
  }
  fillStroke(t, e) {
    const s = m(this, N, He).call(this, Math.min(this.current.fillAlpha, this.current.strokeAlpha));
    this.fill(t, e, !1), this.stroke(t, e, !1), this.consumePath(t, e), m(this, N, ye).call(this, s);
  }
  eoFillStroke(t, e) {
    this.pendingEOFill = !0, this.fillStroke(t, e);
  }
  closeFillStroke(t, e) {
    this.fillStroke(t, e);
  }
  closeEOFillStroke(t, e) {
    this.pendingEOFill = !0, this.fillStroke(t, e);
  }
  endPath(t, e) {
    this.consumePath(t, e);
  }
  rawFillPath(t, e) {
    var n;
    const s = m(this, N, He).call(this, this.current.fillAlpha);
    this.ctx.fill(e), (n = this.dependencyTracker) == null || n.recordDependencies(t, Ts.rawFillPath).recordOperation(t), m(this, N, ye).call(this, s);
  }
  clip(t) {
    var e;
    (e = this.dependencyTracker) == null || e.recordFutureForcedDependency("clipMode", t), this.pendingClip = Av;
  }
  eoClip(t) {
    var e;
    (e = this.dependencyTracker) == null || e.recordFutureForcedDependency("clipMode", t), this.pendingClip = vy;
  }
  beginText(t) {
    var e;
    this.current.textMatrix = null, this.current.textMatrixScale = 1, this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0, (e = this.dependencyTracker) == null || e.recordOpenMarker(t).resetIncrementalData("sameLineText").resetIncrementalData("moveText", t);
  }
  endText(t) {
    const e = this.pendingTextPaths, s = this.ctx;
    if (this.dependencyTracker) {
      const {
        dependencyTracker: n
      } = this;
      e !== void 0 && n.recordFutureForcedDependency("textClip", n.getOpenMarker()).recordFutureForcedDependency("textClip", t), n.recordCloseMarker(t);
    }
    if (e !== void 0) {
      const n = new Path2D(), r = s.getTransform().invertSelf();
      for (const {
        transform: a,
        x: o,
        y: l,
        fontSize: h,
        path: c
      } of e)
        c && n.addPath(c, new DOMMatrix(a).preMultiplySelf(r).translate(o, l).scale(h, -h));
      s.clip(n);
    }
    delete this.pendingTextPaths;
  }
  setCharSpacing(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("charSpacing", t), this.current.charSpacing = e;
  }
  setWordSpacing(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("wordSpacing", t), this.current.wordSpacing = e;
  }
  setHScale(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("hScale", t), this.current.textHScale = e / 100;
  }
  setLeading(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("leading", t), this.current.leading = -e;
  }
  setFont(t, e, s) {
    var d, f;
    (d = this.dependencyTracker) == null || d.recordSimpleData("font", t).recordSimpleDataFromNamed("fontObj", e, t);
    const n = this.commonObjs.get(e), r = this.current;
    if (!n)
      throw new Error(`Can't find font for ${e}`);
    if (r.fontMatrix = n.fontMatrix || xg, (r.fontMatrix[0] === 0 || r.fontMatrix[3] === 0) && j("Invalid font matrix for font " + e), s < 0 ? (s = -s, r.fontDirection = -1) : r.fontDirection = 1, this.current.font = n, this.current.fontSize = s, n.isType3Font)
      return;
    const a = n.loadedName || "sans-serif", o = ((f = n.systemFontInfo) == null ? void 0 : f.css) || `"${a}", ${n.fallbackName}`;
    let l = "normal";
    n.black ? l = "900" : n.bold && (l = "bold");
    const h = n.italic ? "italic" : "normal", c = vt(s, uv, fv);
    this.current.fontSizeScale = s / c, this.ctx.font = `${h} ${l} ${c}px ${o}`;
  }
  setTextRenderingMode(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("textRenderingMode", t), this.current.textRenderingMode = e;
  }
  setTextRise(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("textRise", t), this.current.textRise = e;
  }
  moveText(t, e, s) {
    var n;
    (n = this.dependencyTracker) == null || n.resetIncrementalData("sameLineText").recordIncrementalData("moveText", t), this.current.x = this.current.lineX += e, this.current.y = this.current.lineY += s;
  }
  setLeadingMoveText(t, e, s) {
    this.setLeading(t, -s), this.moveText(t, e, s);
  }
  setTextMatrix(t, e) {
    var n;
    (n = this.dependencyTracker) == null || n.resetIncrementalData("sameLineText").recordSimpleData("textMatrix", t);
    const {
      current: s
    } = this;
    s.textMatrix = e, s.textMatrixScale = Math.hypot(e[0], e[1]), s.x = s.lineX = 0, s.y = s.lineY = 0;
  }
  nextLine(t) {
    var e;
    this.moveText(t, 0, this.current.leading), (e = this.dependencyTracker) == null || e.recordIncrementalData("moveText", this.dependencyTracker.getSimpleIndex("leading") ?? t);
  }
  paintChar(t, e, s, n, r, a) {
    var v, S, E, C;
    const o = this.ctx, l = this.current, h = l.font, c = l.textRenderingMode, d = l.fontSize / l.fontSizeScale, f = c & qt.FILL_STROKE_MASK, b = !!(c & qt.ADD_TO_PATH_FLAG), y = l.patternFill && !h.missingFile, A = l.patternStroke && !h.missingFile;
    let w;
    if ((h.disableFontFace || b || y || A) && !h.missingFile && (w = h.getPathGenerator(this.commonObjs, e)), w && (h.disableFontFace || y || A)) {
      o.save(), o.translate(s, n), o.scale(d, -d), (v = this.dependencyTracker) == null || v.recordCharacterBBox(t, o, h);
      let x;
      if (f === qt.FILL || f === qt.FILL_STROKE)
        if (r) {
          x = o.getTransform(), o.setTransform(...r);
          const T = m(this, N, um).call(this, w, x, r);
          o.fill(T);
        } else
          o.fill(w);
      if (f === qt.STROKE || f === qt.FILL_STROKE)
        if (a) {
          x || (x = o.getTransform()), o.setTransform(...a);
          const {
            a: T,
            b: k,
            c: M,
            d: P
          } = x, D = I.inverseTransform(a), H = I.transform([T, k, M, P, 0, 0], D);
          I.singularValueDecompose2dScale(H, ys), o.lineWidth *= Math.max(ys[0], ys[1]) / d, o.stroke(m(this, N, um).call(this, w, x, a));
        } else
          o.lineWidth /= d, o.stroke(w);
      o.restore();
    } else
      (f === qt.FILL || f === qt.FILL_STROKE) && (o.fillText(e, s, n), (S = this.dependencyTracker) == null || S.recordCharacterBBox(t, o, h, d, s, n, () => o.measureText(e))), (f === qt.STROKE || f === qt.FILL_STROKE) && (this.dependencyTracker && ((E = this.dependencyTracker) == null || E.recordCharacterBBox(t, o, h, d, s, n, () => o.measureText(e)).recordDependencies(t, Ts.stroke)), o.strokeText(e, s, n));
    b && ((this.pendingTextPaths || (this.pendingTextPaths = [])).push({
      transform: wt(o),
      x: s,
      y: n,
      fontSize: d,
      path: w
    }), (C = this.dependencyTracker) == null || C.recordCharacterBBox(t, o, h, d, s, n));
  }
  get isFontSubpixelAAEnabled() {
    const t = this.canvasFactory.create(10, 10), e = t.context;
    e.scale(1.5, 1), e.fillText("I", 0, 10);
    const s = e.getImageData(0, 0, 10, 10).data;
    this.canvasFactory.destroy(t);
    let n = !1;
    for (let r = 3; r < s.length; r += 4)
      if (s[r] > 0 && s[r] < 255) {
        n = !0;
        break;
      }
    return L(this, "isFontSubpixelAAEnabled", n);
  }
  showText(t, e) {
    var Y, Q, K, et;
    this.dependencyTracker && (this.dependencyTracker.recordDependencies(t, Ts.showText).resetBBox(t), this.current.textRenderingMode & qt.ADD_TO_PATH_FLAG && this.dependencyTracker.recordFutureForcedDependency("textClip", t).inheritPendingDependenciesAsFutureForcedDependencies());
    const s = this.current, n = s.font;
    if (n.isType3Font) {
      const O = m(this, N, He).call(this, s.fillAlpha);
      this.showType3Text(t, e), (Y = this.dependencyTracker) == null || Y.recordShowTextOperation(t), m(this, N, ye).call(this, O);
      return;
    }
    const r = s.fontSize;
    if (r === 0) {
      (Q = this.dependencyTracker) == null || Q.recordOperation(t);
      return;
    }
    const a = m(this, N, He).call(this, s.fillAlpha), o = this.ctx, l = s.fontSizeScale, h = s.charSpacing, c = s.wordSpacing, d = s.fontDirection, f = s.textHScale * d, b = e.length, y = n.vertical, A = y ? 1 : -1, w = r * s.fontMatrix[0], v = s.textRenderingMode === qt.FILL && !n.disableFontFace && !s.patternFill;
    o.save(), s.textMatrix && o.transform(...s.textMatrix), o.translate(s.x, s.y + s.textRise), d > 0 ? o.scale(f, -1) : o.scale(f, 1);
    let S, E;
    const C = s.textRenderingMode & qt.FILL_STROKE_MASK, x = C === qt.FILL || C === qt.FILL_STROKE, T = C === qt.STROKE || C === qt.FILL_STROKE;
    let k = s.lineWidth;
    const M = s.textMatrixScale;
    if (M === 0 || k === 0 ? T && (k = this.getSinglePixelWidth()) : k /= M, l !== 1 && (o.scale(l, l), k /= l), o.lineWidth = k, x && s.patternFill && ([o.fillStyle, S] = m(this, N, Tc).call(this, s.fillColor, Zt.FILL, t)), T && s.patternStroke && ([o.strokeStyle, E] = m(this, N, Tc).call(this, s.strokeColor, Zt.STROKE, t)), n.isInvalidPDFjsFont) {
      const O = [];
      let z = 0;
      for (const St of e)
        O.push(St.unicode), z += St.width;
      const Nt = O.join("");
      if (o.fillText(Nt, 0, 0), this.dependencyTracker !== null) {
        const St = o.measureText(Nt);
        this.dependencyTracker.recordBBox(t, this.ctx, -St.actualBoundingBoxLeft, St.actualBoundingBoxRight, -St.actualBoundingBoxAscent, St.actualBoundingBoxDescent).recordShowTextOperation(t);
      }
      s.x += z * w * f, o.restore(), this.compose(), m(this, N, ye).call(this, a);
      return;
    }
    let P = 0, D, H = null;
    for (D = 0; D < b; ++D) {
      const O = e[D];
      if (typeof O == "number") {
        P += A * O * r / 1e3;
        continue;
      }
      let z = !1;
      const Nt = (O.isSpace ? c : 0) + h, St = O.fontChar, Ss = O.accent;
      let ke, Bt, Et, ui = O.width;
      if (y) {
        const Cs = O.vmetric, fi = -Cs[1] * w, ca = Cs[2] * w;
        if (ui = -Cs[0], ke = fi / l, Bt = (P + ca) / l, O.isRotated) {
          Et = o.measureText(St);
          const dl = w / l, bc = O.width / 2 * dl, gg = ke + bc;
          ke = Bt - /* inlined export .DEFAULT_VERTICAL_ORIGIN_Y */
          (880 - /* inlined export .DEFAULT_VERTICAL_ADVANCE */
          1e3 / 2) * dl - bc, Bt = (Et.actualBoundingBoxAscent - Et.actualBoundingBoxDescent) / 2 - gg, z = !0, o.save(), o.rotate(Math.PI / 2);
        }
      } else
        ke = P / l, Bt = 0;
      const Ji = O.isRotated ? O.width : ui;
      let Es = 1;
      if ((n.remeasure || O.isRotated) && Ji > 0) {
        Et ?? (Et = o.measureText(St));
        const Cs = Et.width * 1e3 / r * l;
        Ji < Cs && this.isFontSubpixelAAEnabled ? (Es = Ji / Cs, z || (z = !0, o.save()), o.scale(Es, 1), ke /= Es) : Ji !== Cs && (ke += (Ji - Cs) / 2e3 * r / l);
      }
      if (z && n.missingFile && (S || E) && (H || (H = /* @__PURE__ */ new Map()), [o.fillStyle, o.strokeStyle] = H.getOrInsertComputed(O.isRotated ? -Es : Es, () => [S ? m(this, N, Tc).call(this, s.fillColor, Zt.FILL, t)[0] : o.fillStyle, E ? m(this, N, Tc).call(this, s.strokeColor, Zt.STROKE, t)[0] : o.strokeStyle])), this.contentVisible && (O.isInFont || n.missingFile)) {
        if (v && !Ss)
          o.fillText(St, ke, Bt), (K = this.dependencyTracker) == null || K.recordCharacterBBox(t, o, Et ? {
            bbox: null
          } : n, r / l, ke, Bt, () => Et ?? o.measureText(St));
        else if (this.paintChar(t, St, ke, Bt, S, E), Ss) {
          const Cs = ke + r * Ss.offset.x / l, fi = Bt - r * Ss.offset.y / l;
          this.paintChar(t, Ss.fontChar, Cs, fi, S, E);
        }
      }
      const Vt = y ? ui * w - Nt * d : ui * w + Nt * d;
      P += Vt, z && o.restore();
    }
    y ? s.y -= P : s.x += P * f, o.restore(), this.compose(), (et = this.dependencyTracker) == null || et.recordShowTextOperation(t), m(this, N, ye).call(this, a);
  }
  showType3Text(t, e) {
    const s = this.ctx, n = this.current, r = n.font, a = n.fontSize, o = n.fontDirection, l = r.vertical ? 1 : -1, h = n.charSpacing, c = n.wordSpacing, d = n.textHScale * o, f = n.fontMatrix || xg, b = e.length, y = n.textRenderingMode !== qt.INVISIBLE;
    let A, w, v, S;
    if (a === 0)
      return;
    this._cachedScaleForStroking[0] = -1, s.save(), n.textMatrix && s.transform(...n.textMatrix), s.translate(n.x, n.y + n.textRise), s.scale(d, o);
    const E = this.dependencyTracker;
    this.dependencyTracker = E ? new Jc(E, t) : null;
    try {
      for (A = 0; A < b; ++A) {
        if (w = e[A], typeof w == "number") {
          S = l * w * a / 1e3, this.ctx.translate(S, 0), n.x += S * d;
          continue;
        }
        const C = (w.isSpace ? c : 0) + h, x = r.charProcOperatorList.get(w.operatorListId);
        x ? this.contentVisible && y && (this.save(), s.scale(a, a), s.transform(...f), this.executeOperatorList(x), this.restore()) : j(`Type3 character "${w.operatorListId}" is not available.`), v = w.width * f[0] * a + C * o, s.translate(v, 0), n.x += v * d;
      }
    } finally {
      E && (this.dependencyTracker = E);
    }
    s.restore();
  }
  setCharWidth(t, e, s) {
  }
  setCharWidthAndBounds(t, e, s, n, r, a, o) {
    var h;
    const l = new Path2D();
    l.rect(n, r, a - n, o - r), this.ctx.clip(l), (h = this.dependencyTracker) == null || h.recordBBox(t, this.ctx, n, a, r, o).recordClipBox(t, this.ctx, n, a, r, o), this.endPath(t);
  }
  getColorN_Pattern(t, e) {
    let s;
    if (e[0] === "TilingPattern") {
      const n = this.baseTransform || wt(this.ctx), r = {
        createCanvasGraphics: (a, o) => new nn(a, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
          optionalContentConfig: this.optionalContentConfig,
          markedContentStack: this.markedContentStack,
          pixelRatio: this.pixelRatio
        }, void 0, void 0, this.dependencyTracker ? new Jc(this.dependencyTracker, o, !0) : null)
      };
      s = new Vc(e, this.ctx, r, n);
    } else
      s = this._getPattern(t, e[1], e[2]);
    return s;
  }
  setStrokeColorN(t, ...e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("strokeColor", t), this.current.strokeColor = this.getColorN_Pattern(t, e), this.current.patternStroke = !0;
  }
  setFillColorN(t, ...e) {
    var n;
    (n = this.dependencyTracker) == null || n.recordSimpleData("fillColor", t);
    const s = this.current.fillColor = this.getColorN_Pattern(t, e);
    this.current.patternFill = !0, this.current.tilingPatternDims = s instanceof Vc ? [0, 0, 0, 0] : null;
  }
  setStrokeRGBColor(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("strokeColor", t), this.current.strokeColor = e, this.ctx.strokeStyle = m(this, N, _c).call(this, e), this.current.patternStroke = !1;
  }
  setStrokeTransparent(t) {
    var e;
    (e = this.dependencyTracker) == null || e.recordSimpleData("strokeColor", t), this.ctx.strokeStyle = this.current.strokeColor = "transparent", this.current.patternStroke = !1;
  }
  setFillRGBColor(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.recordSimpleData("fillColor", t), this.current.fillColor = e, this.ctx.fillStyle = m(this, N, _c).call(this, e), this.current.patternFill = !1, this.current.tilingPatternDims = null;
  }
  setFillTransparent(t) {
    var e;
    (e = this.dependencyTracker) == null || e.recordSimpleData("fillColor", t), this.ctx.fillStyle = this.current.fillColor = "transparent", this.current.patternFill = !1, this.current.tilingPatternDims = null;
  }
  _getPattern(t, e, s = null) {
    const n = this.cachedPatterns.getOrInsertComputed(e, () => dv(this.getObject(t, e)));
    return s && (n.matrix = s), n;
  }
  shadingFill(t, e) {
    var o;
    if (!this.contentVisible)
      return;
    const s = m(this, N, He).call(this, this.current.fillAlpha), n = this.ctx;
    this.save(t);
    const r = this._getPattern(t, e);
    n.fillStyle = r.getPattern(n, this, Zi(n), Zt.SHADING, t);
    const a = Zi(n);
    if (a) {
      const {
        width: l,
        height: h
      } = n.canvas, c = va.slice();
      I.axialAlignedBoundingBox([0, 0, l, h], a, c);
      const [d, f, b, y] = c;
      this.ctx.fillRect(d, f, b - d, y - f);
    } else
      this.ctx.fillRect(-1e10, -1e10, 2e10, 2e10);
    (o = this.dependencyTracker) == null || o.resetBBox(t).recordFullPageBBox(t).recordDependencies(t, Ts.transform).recordDependencies(t, Ts.fill).recordOperation(t), this.compose(this.current.getClippedPathBoundingBox()), this.restore(t), m(this, N, ye).call(this, s);
  }
  beginInlineImage() {
    it("Should not call beginInlineImage");
  }
  beginImageData() {
    it("Should not call beginImageData");
  }
  paintFormXObjectBegin(t, e, s) {
    var n;
    if (this.contentVisible && (this.save(t), this.baseTransformStack.push(this.baseTransform), e && this.transform(t, ...e), this.baseTransform = wt(this.ctx), s)) {
      I.axialAlignedBoundingBox(s, this.baseTransform, this.current.minMax);
      const [r, a, o, l] = s, h = new Path2D();
      h.rect(r, a, o - r, l - a), this.ctx.clip(h), (n = this.dependencyTracker) == null || n.recordClipBox(t, this.ctx, r, o, a, l), this.endPath(t);
    }
  }
  paintFormXObjectEnd(t) {
    this.contentVisible && (this.restore(t), this.baseTransform = this.baseTransformStack.pop());
  }
  beginGroup(t, e) {
    var C;
    if (!this.contentVisible)
      return;
    this.save(t);
    const {
      inSMaskMode: s
    } = this;
    s && (this.endSMaskMode(), this.current.activeSMask = null);
    const n = this.ctx;
    if ((!e.needsIsolation || !e.isolated && !e.hasSoftMask) && !e.knockout && !e.isGray && i(this, ss) === 0 && n.globalAlpha === 1 && n.globalCompositeOperation === "source-over" && !s) {
      if (e.bbox) {
        let x = new Path2D();
        const [T, k, M, P] = e.bbox;
        if (x.rect(T, k, M - T, P - k), e.matrix) {
          const D = new Path2D();
          D.addPath(x, new DOMMatrix(e.matrix)), x = D;
        }
        n.clip(x);
      }
      this.groupStack.push(null), i(this, Mi).push(null), this.groupLevel++;
      return;
    }
    !e.isolated && !e.knockout && i(this, ss) === 0 && ig("TODO: Fully support non-isolated non-knockout groups.");
    const r = wt(n);
    e.matrix && n.transform(...e.matrix);
    const a = [0, 0, n.canvas.width, n.canvas.height];
    let o;
    e.bbox ? (o = va.slice(), I.axialAlignedBoundingBox(e.bbox, wt(n), o), o = I.intersect(o, a) || [0, 0, 0, 0]) : o = a;
    const l = Math.floor(o[0]), h = Math.floor(o[1]), c = Math.max(Math.ceil(o[2]) - l, 1), d = Math.max(Math.ceil(o[3]) - h, 1);
    this.current.startNewPathAndClipBox([0, 0, c, d]);
    const f = this.canvasFactory.create(c, d);
    e.smask && this.smaskGroupCanvases.push(f);
    const b = f.context, y = e.knockout && !e.isolated ? n : null, A = !e.isolated && !e.knockout && !e.smask && e.needsIsolation && i(this, ss) > 0, w = e.knockout ? this.canvasFactory.create(c, d) : null, v = i(this, ss);
    e.knockout ? rt(this, ss)._++ : u(this, ss, 0), b.translate(-l, -h), b.transform(...r);
    const S = !e.isolated && !e.smask && e.needsIsolation, E = S && !s && v === 0 && !e.knockout && !e.isGray && e.hasSoftMask && n.globalAlpha === 1 && n.globalCompositeOperation === "source-over" && this.current.transferMaps === "none" && !this.current.transferMapsFallback;
    if (S && (s || E) && (b.save(), b.setTransform(1, 0, 0, 1, 0, 0), b.drawImage(n.canvas, -l, -h), b.restore()), e.bbox) {
      let x = new Path2D();
      const [T, k, M, P] = e.bbox;
      if (x.rect(T, k, M - T, P - k), e.matrix) {
        const D = new Path2D();
        D.addPath(x, new DOMMatrix(e.matrix)), x = D;
      }
      b.clip(x);
    }
    e.smask && this.smaskStack.push({
      canvas: f.canvas,
      context: b,
      offsetX: l,
      offsetY: h,
      subtype: e.smask.subtype,
      backdrop: e.smask.backdrop,
      transferMap: e.smask.transferMap || null
    }), (!e.smask || this.dependencyTracker) && (n.setTransform(1, 0, 0, 1, 0, 0), n.translate(l, h), n.save()), da(n, b), this.ctx = b, (C = this.dependencyTracker) == null || C.inheritSimpleDataAsFutureForcedDependencies(["fillAlpha", "strokeAlpha", "globalCompositeOperation"]).pushBaseTransform(n), this.setGState(t, [["BM", "source-over"], ["ca", 1], ["CA", 1], ["TR", null]]), this.groupStack.push(n), i(this, Mi).push({
      backdropCtx: y,
      savedKnockoutLevel: v,
      offsetX: l,
      offsetY: h,
      hasInnerBackdrop: A,
      replaceBackdrop: E,
      knockoutMaskEntry: w,
      knockoutTempEntry: null,
      knockoutBackdropEntry: null
    }), this.groupLevel++;
  }
  endGroup(t, e) {
    var a, o;
    if (!this.contentVisible)
      return;
    this.groupLevel--;
    const s = this.ctx, n = this.groupStack.pop(), r = i(this, Mi).pop();
    if (r && u(this, ss, r.savedKnockoutLevel), n === null) {
      this.restore(t);
      return;
    }
    if (e.isGray && m(this, N, IA).call(this, s), this.ctx = n, this.ctx.imageSmoothingEnabled = !1, (a = this.dependencyTracker) == null || a.popBaseTransform(), e.smask)
      this.tempSMask = this.smaskStack.pop(), this.restore(t), this.dependencyTracker && (this.ctx.restore(), this.inSMaskMode && this.ctx.setTransform(this.suspendedCtx.getTransform())), m(this, N, kf).call(this, r);
    else {
      this.ctx.restore();
      const l = wt(this.ctx);
      this.restore(t), (o = this.current.transferMapsFallback) == null || o.applyToCanvas(s), this.ctx.save(), this.ctx.setTransform(...l);
      const h = va.slice();
      I.axialAlignedBoundingBox([0, 0, s.canvas.width, s.canvas.height], l, h);
      const c = i(this, Mi).at(-1);
      if (i(this, ss) > 0)
        if (r.hasInnerBackdrop) {
          const {
            width: d,
            height: f
          } = s.canvas, b = this.canvasFactory.create(d, f), y = b.context;
          y.drawImage(n.canvas, r.offsetX, r.offsetY, d, f, 0, 0, d, f), y.globalCompositeOperation = "source-over", y.drawImage(s.canvas, 0, 0);
          const A = m(this, N, hm).call(this, s.canvas);
          y.globalCompositeOperation = "destination-in", y.drawImage(A.canvas, 0, 0);
          const w = this.ctx.globalCompositeOperation, v = this.ctx.globalAlpha, S = this.ctx.filter;
          this.ctx.save(), this.ctx.setTransform(...l), this.ctx.globalAlpha = 1, ot.isCanvasFilterSupported && (this.ctx.filter = "none"), this.ctx.globalCompositeOperation = "destination-out", this.ctx.drawImage(A.canvas, 0, 0), this.ctx.globalCompositeOperation = w, this.ctx.globalAlpha = v, ot.isCanvasFilterSupported && (this.ctx.filter = S ?? "none"), this.ctx.drawImage(b.canvas, 0, 0), this.ctx.restore(), this.canvasFactory.destroy(A), this.canvasFactory.destroy(b);
        } else {
          const d = (c == null ? void 0 : c.backdropCtx) ?? null;
          m(this, N, dm).call(this, this.ctx, s.canvas, {
            backdropCanvas: (d == null ? void 0 : d.canvas) ?? null,
            destTransform: l,
            backdropOffset: d ? [c.offsetX + r.offsetX, c.offsetY + r.offsetY] : [0, 0],
            sourceAlpha: this.ctx.globalAlpha,
            sourceFilter: this.ctx.filter
          });
        }
      else {
        if (r.replaceBackdrop) {
          const d = new Path2D();
          d.rect(0, 0, s.canvas.width, s.canvas.height), this.ctx.clip(d), this.ctx.globalCompositeOperation = "copy";
        }
        this.ctx.drawImage(s.canvas, 0, 0);
      }
      this.ctx.restore(), this.canvasFactory.destroy({
        canvas: s.canvas,
        context: s
      }), m(this, N, kf).call(this, r), this.compose(h);
    }
  }
  beginAnnotation(t, e, s, n, r, a, o) {
    if (m(this, N, om).call(this), uf(this.ctx), this.ctx.save(), this.save(t), this.baseTransform && this.ctx.setTransform(...this.baseTransform), s) {
      const l = s[2] - s[0], h = s[3] - s[1];
      if (a && this.annotationCanvasMap) {
        n = n.slice(), n[4] -= s[0], n[5] -= s[1], I.singularValueDecompose2dScale(wt(this.ctx), ys);
        const {
          viewportScale: c
        } = this, d = Math.ceil(l * this.outputScaleX * c), f = Math.ceil(h * this.outputScaleY * c);
        this.annotationCanvas = this.canvasFactory.create(d, f);
        const {
          canvas: b,
          context: y
        } = this.annotationCanvas;
        if (o) {
          const A = this.annotationCanvasMap.getOrInsertComputed(e, gc);
          DA(b, o);
          const w = A.findIndex((v) => gv(v) === o);
          w === -1 ? A.push(b) : A[w] = b;
        } else
          this.annotationCanvasMap.set(e, b);
        this.annotationCanvas.savedCtx = this.ctx, this.ctx = y, this.ctx.save(), this.ctx.setTransform(ys[0], 0, 0, -ys[1], 0, h * ys[1]), uf(this.ctx);
      } else {
        uf(this.ctx), this.endPath(t);
        const c = new Path2D();
        c.rect(s[0], s[1], l, h), this.ctx.clip(c);
      }
    }
    this.current = new wg(this.ctx.canvas.width, this.ctx.canvas.height), this.baseTransformStack.push(this.baseTransform), this.transform(t, ...n), this.transform(t, ...r), this.baseTransform = wt(this.ctx);
  }
  endAnnotation(t) {
    this.annotationCanvas && (this.ctx.restore(), m(this, N, lm).call(this), this.ctx = this.annotationCanvas.savedCtx, delete this.annotationCanvas.savedCtx, delete this.annotationCanvas), this.baseTransform = this.baseTransformStack.pop();
  }
  paintImageMaskXObject(t, e) {
    var l;
    if (!this.contentVisible)
      return;
    const s = e.count;
    e = this.getObject(t, e.data, e), e.count = s;
    const n = m(this, N, He).call(this, this.current.fillAlpha), r = this.ctx, a = this._createMaskCanvas(t, e), o = a.canvas;
    r.save(), r.setTransform(1, 0, 0, 1, 0, 0), r.drawImage(o, a.offsetX, a.offsetY), (l = this.dependencyTracker) == null || l.resetBBox(t).recordBBox(t, this.ctx, a.offsetX, a.offsetX + o.width, a.offsetY, a.offsetY + o.height).recordOperation(t), r.restore(), a.canvasEntry && this.canvasFactory.destroy(a.canvasEntry), this.compose(), m(this, N, ye).call(this, n);
  }
  paintImageMaskXObjectRepeat(t, e, s, n = 0, r = 0, a, o) {
    var f, b, y;
    if (!this.contentVisible)
      return;
    e = this.getObject(t, e.data, e);
    const l = m(this, N, He).call(this, this.current.fillAlpha), h = this.ctx;
    h.save();
    const c = wt(h);
    h.transform(s, n, r, a, 0, 0);
    const d = this._createMaskCanvas(t, e);
    h.setTransform(1, 0, 0, 1, d.offsetX - c[4], d.offsetY - c[5]), (f = this.dependencyTracker) == null || f.resetBBox(t);
    for (let A = 0, w = o.length; A < w; A += 2) {
      const v = I.transform(c, [s, n, r, a, o[A], o[A + 1]]);
      h.drawImage(d.canvas, v[4], v[5]), (b = this.dependencyTracker) == null || b.recordBBox(t, this.ctx, v[4], v[4] + d.canvas.width, v[5], v[5] + d.canvas.height);
    }
    h.restore(), d.canvasEntry && this.canvasFactory.destroy(d.canvasEntry), this.compose(), (y = this.dependencyTracker) == null || y.recordOperation(t), m(this, N, ye).call(this, l);
  }
  paintImageMaskXObjectGroup(t, e) {
    var o, l, h;
    if (!this.contentVisible)
      return;
    const s = m(this, N, He).call(this, this.current.fillAlpha), n = this.ctx, r = this.current.patternFill, a = r ? this.current.fillColor : n.fillStyle;
    (o = this.dependencyTracker) == null || o.resetBBox(t).recordDependencies(t, Ts.transformAndFill);
    for (const c of e) {
      const {
        data: d,
        width: f,
        height: b,
        transform: y
      } = c, A = this.canvasFactory.create(f, b), w = A.context;
      w.save();
      const v = this.getObject(t, d, c);
      Ay(w, v), w.globalCompositeOperation = "source-in", w.fillStyle = r ? a.getPattern(w, this, Zi(n), Zt.FILL, t) : a, w.fillRect(0, 0, f, b), w.restore(), n.save(), n.transform(...y), n.scale(1, -1), df(n, A.canvas, 0, 0, f, b, 0, -1, 1, 1), this.canvasFactory.destroy(A), (l = this.dependencyTracker) == null || l.recordBBox(t, n, 0, f, 0, b), n.restore();
    }
    this.compose(), (h = this.dependencyTracker) == null || h.recordOperation(t), m(this, N, ye).call(this, s);
  }
  paintImageXObject(t, e) {
    if (!this.contentVisible)
      return;
    const s = this.getObject(t, e);
    if (!s) {
      j("Dependent image isn't ready yet");
      return;
    }
    this.paintInlineImageXObject(t, s);
  }
  paintImageXObjectRepeat(t, e, s, n, r) {
    if (!this.contentVisible)
      return;
    const a = this.getObject(t, e);
    if (!a) {
      j("Dependent image isn't ready yet");
      return;
    }
    const o = a.width, l = a.height, h = [];
    for (let c = 0, d = r.length; c < d; c += 2)
      h.push({
        transform: [s, 0, 0, n, r[c], r[c + 1]],
        x: 0,
        y: 0,
        w: o,
        h: l
      });
    this.paintInlineImageXObjectGroup(t, a, h);
  }
  applyTransferMapsToCanvas(t) {
    var e;
    return this.current.transferMaps !== "none" ? (t.filter = this.current.transferMaps, t.drawImage(t.canvas, 0, 0), t.filter = "none") : (e = this.current.transferMapsFallback) == null || e.applyToCanvas(t), t.canvas;
  }
  applyTransferMapsToBitmap(t) {
    const {
      transferMaps: e,
      transferMapsFallback: s
    } = this.current;
    if (e === "none" && !s)
      return {
        img: t.bitmap,
        canvasEntry: null
      };
    const {
      bitmap: n,
      width: r,
      height: a
    } = t, o = this.canvasFactory.create(r, a), l = o.context;
    return l.filter = e, l.drawImage(n, 0, 0), l.filter = "none", s == null || s.applyToCanvas(l), {
      img: o.canvas,
      canvasEntry: o
    };
  }
  paintInlineImageXObject(t, e) {
    var d;
    if (!this.contentVisible)
      return;
    const s = e.width, n = e.height, r = m(this, N, He).call(this, this.current.fillAlpha), a = this.ctx;
    this.save(t);
    const {
      filter: o
    } = a;
    o !== "none" && o !== "" && (a.filter = "none"), a.scale(1 / s, -1 / n);
    let l, h = null;
    if (e.bitmap) {
      const f = this.applyTransferMapsToBitmap(e);
      l = f.img, h = f.canvasEntry;
    } else {
      const f = this.canvasFactory.create(s, n);
      yy(f.context, e), l = this.applyTransferMapsToCanvas(f.context), h = f;
    }
    const c = this._scaleImage(l, Zi(a));
    a.imageSmoothingEnabled = wy(wt(a), e.interpolate, this.pixelRatio), this.dependencyTracker && (this.dependencyTracker.resetBBox(t).recordBBox(t, a, 0, s, -n, 0).recordDependencies(t, Ts.imageXObject).recordOperation(t), (d = this.imagesTracker) == null || d.record(a, s, n, this.dependencyTracker.clipBox)), df(a, c.img, 0, 0, c.paintWidth, c.paintHeight, 0, -n, s, n), c.tmpCanvas && this.canvasFactory.destroy(c.tmpCanvas), h && this.canvasFactory.destroy(h), this.compose(), this.restore(t), m(this, N, ye).call(this, r);
  }
  paintInlineImageXObjectGroup(t, e, s) {
    var l, h, c;
    if (!this.contentVisible)
      return;
    const n = m(this, N, He).call(this, this.current.fillAlpha), r = this.ctx;
    let a, o = null;
    if (e.bitmap && !this.current.transferMapsFallback)
      a = e.bitmap;
    else if (e.bitmap)
      ({
        img: a,
        canvasEntry: o
      } = this.applyTransferMapsToBitmap(e));
    else {
      const d = e.width, f = e.height, b = this.canvasFactory.create(d, f);
      yy(b.context, e), a = this.applyTransferMapsToCanvas(b.context), o = b;
    }
    (l = this.dependencyTracker) == null || l.resetBBox(t);
    for (const d of s)
      r.save(), r.transform(...d.transform), r.scale(1, -1), df(r, a, d.x, d.y, d.w, d.h, 0, -1, 1, 1), (h = this.dependencyTracker) == null || h.recordBBox(t, r, 0, 1, -1, 0), r.restore();
    o && this.canvasFactory.destroy(o), (c = this.dependencyTracker) == null || c.recordOperation(t), this.compose(), m(this, N, ye).call(this, n);
  }
  paintSolidColorImageMask(t) {
    var s;
    if (!this.contentVisible)
      return;
    const e = m(this, N, He).call(this, this.current.fillAlpha);
    (s = this.dependencyTracker) == null || s.resetBBox(t).recordBBox(t, this.ctx, 0, 1, 0, 1).recordDependencies(t, Ts.fill).recordOperation(t), this.ctx.fillRect(0, 0, 1, 1), this.compose(), m(this, N, ye).call(this, e);
  }
  markPoint(t, e) {
  }
  markPointProps(t, e, s) {
  }
  beginMarkedContent(t, e) {
    var s;
    (s = this.dependencyTracker) == null || s.beginMarkedContent(t), this.markedContentStack.push({
      visible: !0
    });
  }
  beginMarkedContentProps(t, e, s) {
    var n;
    (n = this.dependencyTracker) == null || n.beginMarkedContent(t), e === "OC" ? this.markedContentStack.push({
      visible: this.optionalContentConfig.isVisible(s)
    }) : this.markedContentStack.push({
      visible: !0
    }), this.contentVisible = this.isContentVisible();
  }
  endMarkedContent(t) {
    var e;
    (e = this.dependencyTracker) == null || e.endMarkedContent(t), this.markedContentStack.pop(), this.contentVisible = this.isContentVisible();
  }
  beginCompat(t) {
  }
  endCompat(t) {
  }
  consumePath(t, e, s) {
    var a, o;
    const n = this.current.isEmptyClip();
    this.pendingClip && this.current.updateClipFromPath(), this.pendingClip || this.compose(s);
    const r = this.ctx;
    this.pendingClip ? (n || (this.pendingClip === vy ? r.clip(e, "evenodd") : r.clip(e)), this.pendingClip = null, (a = this.dependencyTracker) == null || a.bboxToClipBoxDropOperation(t).recordFutureForcedDependency("clipPath", t)) : (o = this.dependencyTracker) == null || o.recordOperation(t), this.current.startNewPathAndClipBox(this.current.clipBox);
  }
  getSinglePixelWidth() {
    const t = wt(this.ctx);
    if (t[1] === 0 && t[2] === 0)
      return 1 / Math.min(Math.abs(t[0]), Math.abs(t[3]));
    const e = Math.abs(t[0] * t[3] - t[2] * t[1]), s = Math.hypot(t[0], t[2]), n = Math.hypot(t[1], t[3]);
    return Math.max(s, n) / e;
  }
  getScaleForStroking() {
    if (this._cachedScaleForStroking[0] === -1) {
      const {
        lineWidth: t
      } = this.current, {
        a: e,
        b: s,
        c: n,
        d: r
      } = this.ctx.getTransform();
      let a, o;
      if (s === 0 && n === 0) {
        const l = Math.abs(e), h = Math.abs(r);
        if (l === h)
          if (t === 0)
            a = o = 1 / l;
          else {
            const c = l * t;
            a = o = c < 1 ? 1 / c : 1;
          }
        else if (t === 0)
          a = 1 / l, o = 1 / h;
        else {
          const c = l * t, d = h * t;
          a = c < 1 ? 1 / c : 1, o = d < 1 ? 1 / d : 1;
        }
      } else {
        const l = Math.abs(e * r - s * n), h = Math.hypot(e, s), c = Math.hypot(n, r);
        if (t === 0)
          a = c / l, o = h / l;
        else {
          const d = t * l;
          a = c > d ? c / d : 1, o = h > d ? h / d : 1;
        }
      }
      this._cachedScaleForStroking[0] = a, this._cachedScaleForStroking[1] = o;
    }
    return this._cachedScaleForStroking;
  }
  rescaleAndStroke(t, e) {
    const {
      ctx: s,
      current: {
        lineWidth: n
      }
    } = this, [r, a] = this.getScaleForStroking();
    if (r === a) {
      s.lineWidth = (n || 1) * r, s.stroke(t);
      return;
    }
    const o = i(nn, Pp) ?? u(nn, Pp, new DOMMatrix()), l = s.getLineDash();
    e && s.save(), s.scale(r, a), o.a = 1 / r, o.d = 1 / a;
    const h = new Path2D();
    if (h.addPath(t, o), l.length > 0) {
      const c = Math.max(r, a);
      s.setLineDash(l.map((d) => d / c)), s.lineDashOffset /= c;
    }
    s.lineWidth = n || 1, s.stroke(h), e && s.restore();
  }
  isContentVisible() {
    for (let t = this.markedContentStack.length - 1; t >= 0; t--)
      if (!this.markedContentStack[t].visible)
        return !1;
    return !0;
  }
};
Pp = new WeakMap(), Mp = new WeakMap(), ss = new WeakMap(), Mr = new WeakMap(), Za = new WeakMap(), to = new WeakMap(), eo = new WeakMap(), so = new WeakMap(), io = new WeakMap(), no = new WeakMap(), ro = new WeakMap(), Mi = new WeakMap(), N = new WeakSet(), om = function() {
  for (; this.stateStack.length || this.inSMaskMode; )
    this.restore();
  this.current.activeSMask = null, this.ctx.restore(), this.transparentCanvas && (this.ctx = this.compositeCtx, this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.drawImage(this.transparentCanvas, 0, 0), this.ctx.restore(), this.canvasFactory.destroy(this.transparentCanvasEntry), this.transparentCanvas = null, this.transparentCanvasEntry = null);
}, lm = function() {
  if (this.pageColors) {
    const t = this.filterFactory.addHCMFilter(this.pageColors.foreground, this.pageColors.background);
    if (t !== "none") {
      const e = this.ctx.filter;
      this.ctx.filter = t, this.ctx.drawImage(this.ctx.canvas, 0, 0), this.ctx.filter = e;
    }
  }
}, hm = function(t, e = null, s = 1) {
  const {
    width: n,
    height: r
  } = t, a = e ?? this.canvasFactory.create(n, r), o = a.context;
  s = Math.round(s * 255) / 255;
  const l = s < 1;
  l && i(this, no) === void 0 && u(this, no, ot.isCanvasFilterSupported ? /* @__PURE__ */ new Map() : "none");
  let h = "none";
  if (l && i(this, no) instanceof Map && (h = i(this, no).getOrInsertComputed(s, () => this.filterFactory.addKnockoutFilter(s))), !l || h !== "none")
    return e && (o.save(), o.setTransform(1, 0, 0, 1, 0, 0), o.clearRect(0, 0, n, r), o.restore()), o.filter = h, o.drawImage(t, 0, 0), o.filter = "none", a;
  const c = t.getContext("2d", {
    willReadFrequently: !0
  }).getImageData(0, 0, n, r), d = o.createImageData(n, r), f = c.data, b = d.data, y = s > 0 ? 1 / s : 1e6;
  for (let A = 3, w = f.length; A < w; A += 4)
    b[A] = Math.min(Math.round(f[A] * y), 255);
  return o.putImageData(d, 0, 0), a;
}, cm = function(t, e, s, n) {
  let r = (t == null ? void 0 : t[e]) ?? null;
  if (r && (r.canvas.width !== s || r.canvas.height !== n) && (this.canvasFactory.destroy(r), r = null), !r)
    return r = this.canvasFactory.create(s, n), t && (t[e] = r), r;
  const a = r.context;
  return a.save(), a.setTransform(1, 0, 0, 1, 0, 0), a.clearRect(0, 0, s, n), a.restore(), r;
}, dm = function(t, e, s = {}) {
  const {
    backdropCanvas: n = null,
    destTransform: r = [1, 0, 0, 1, 0, 0],
    backdropOffset: a = [0, 0],
    reuseMaskEntry: o = null,
    poolMeta: l = null,
    sourceAlpha: h = 1,
    sourceFilter: c = "none",
    knockoutAlpha: d = 1
  } = s, {
    width: f,
    height: b
  } = e, y = m(this, N, hm).call(this, e, o, d), A = t.globalCompositeOperation;
  if (t.save(), t.setTransform(...r), t.globalAlpha = 1, ot.isCanvasFilterSupported && (t.filter = "none"), t.globalCompositeOperation = "destination-out", t.drawImage(y.canvas, 0, 0), n) {
    const [w, v] = a, S = m(this, N, cm).call(this, l, "knockoutBackdropEntry", f, b), E = S.context;
    E.drawImage(n, w, v, f, b, 0, 0, f, b), E.globalCompositeOperation = "destination-in", E.drawImage(y.canvas, 0, 0), E.globalCompositeOperation = "source-over", t.globalCompositeOperation = "destination-over", t.drawImage(S.canvas, 0, 0), l || this.canvasFactory.destroy(S);
  }
  t.globalCompositeOperation = A, t.globalAlpha = h, ot.isCanvasFilterSupported && (t.filter = c ?? "none"), t.drawImage(e, 0, 0), t.restore(), o || this.canvasFactory.destroy(y);
}, He = function(t = 1) {
  if (i(this, ss) === 0 || i(this, Mr) > 0 || !this.contentVisible)
    return !1;
  rt(this, Mr)._++, u(this, io, t);
  const e = i(this, Mi).at(-1), {
    canvas: s
  } = this.ctx, n = m(this, N, cm).call(this, e, "knockoutTempEntry", s.width, s.height);
  u(this, Za, n);
  const r = n.context;
  return r.save(), r.setTransform(this.ctx.getTransform()), da(this.ctx, r), u(this, so, r.globalCompositeOperation), r.globalCompositeOperation = "source-over", by(r, this.ctx), u(this, ro, e), u(this, to, this.ctx), u(this, eo, this.suspendedCtx), this.ctx = r, this.inSMaskMode && (this.suspendedCtx = r), !0;
}, ye = function(t) {
  var l;
  if (!t)
    return;
  const e = i(this, Za), s = i(this, to), n = i(this, eo), r = e.context;
  u(this, Za, null), u(this, to, null), u(this, eo, null), this.inSMaskMode && this.suspendedCtx === r && this.ctx !== r && this.endSMaskMode(), this.inSMaskMode && (this.suspendedCtx = n), this.ctx._removeMirroring(), this.ctx.globalCompositeOperation = i(this, so), u(this, so, null), da(this.ctx, s), this.ctx = s;
  const a = i(this, ro);
  u(this, ro, null);
  const o = i(this, io);
  u(this, io, 1);
  try {
    m(this, N, dm).call(this, n ?? s, e.canvas, {
      backdropCanvas: ((l = a == null ? void 0 : a.backdropCtx) == null ? void 0 : l.canvas) ?? null,
      backdropOffset: a != null && a.backdropCtx ? [a.offsetX, a.offsetY] : [0, 0],
      reuseMaskEntry: (a == null ? void 0 : a.knockoutMaskEntry) ?? null,
      poolMeta: a,
      knockoutAlpha: o
    });
  } finally {
    r.restore(), rt(this, Mr)._--, a || this.canvasFactory.destroy(e);
  }
}, um = function(t, e, s) {
  const n = new Path2D();
  return n.addPath(t, new DOMMatrix(s).invertSelf().multiplySelf(e)), n;
}, Tc = function(t, e, s) {
  const n = this.ctx;
  n.save();
  const r = t.getPattern(n, this, Zi(n), e, s), a = wt(n);
  return n.restore(), [r, a];
}, _c = function(t) {
  var e;
  return ((e = this.current.transferMapsFallback) == null ? void 0 : e.applyToColor(t)) ?? t;
}, IA = function(t) {
  const {
    canvas: e
  } = t, {
    width: s,
    height: n
  } = e;
  if (ot.isCanvasFilterSupported) {
    t.save(), t.setTransform(1, 0, 0, 1, 0, 0), t.filter = "grayscale(1)", t.globalAlpha = 1, t.globalCompositeOperation = "copy", t.drawImage(e, 0, 0), t.restore();
    return;
  }
  const r = t.getImageData(0, 0, s, n), {
    data: a
  } = r;
  for (let o = 0, l = a.length; o < l; o += 4) {
    const h = a[o] * 0.2126 + a[o + 1] * 0.7152 + a[o + 2] * 0.0722 + 0.5 | 0;
    a[o] = a[o + 1] = a[o + 2] = h;
  }
  t.putImageData(r, 0, 0);
}, kf = function(t) {
  t && (t.knockoutMaskEntry && (this.canvasFactory.destroy(t.knockoutMaskEntry), t.knockoutMaskEntry = null), t.knockoutTempEntry && (this.canvasFactory.destroy(t.knockoutTempEntry), t.knockoutTempEntry = null), t.knockoutBackdropEntry && (this.canvasFactory.destroy(t.knockoutBackdropEntry), t.knockoutBackdropEntry = null));
}, g(nn, Pp, null), g(nn, Mp, /* @__PURE__ */ new WeakMap());
let Al = nn;
for (const p in an)
  Al.prototype[p] !== void 0 && (Al.prototype[an[p]] = Al.prototype[p]);
class wv extends kA {
  constructor({
    ownerDocument: t = globalThis.document,
    enableHWA: e = !1
  }) {
    super({
      enableHWA: e
    }), this._document = t;
  }
  _createCanvas(t, e) {
    const s = this._document.createElement("canvas");
    return s.width = t, s.height = e, s;
  }
}
var ao, Jl, Sn, Di, ae, oo, Dr, F, se, kc, gi, Pf, ua, FA, fm, fa, Pc, Mc, pm, Dc, LA, gm, OA;
class vv extends PA {
  constructor({
    docId: e,
    ownerDocument: s = globalThis.document
  }) {
    super();
    g(this, F);
    g(this, ao);
    g(this, Jl);
    g(this, Sn);
    g(this, Di);
    g(this, ae);
    g(this, oo);
    g(this, Dr, 0);
    u(this, Di, e), u(this, ae, s);
  }
  addFilter(e) {
    if (!e)
      return "none";
    let s = i(this, F, se).get(e);
    if (s)
      return s;
    const [n, r, a] = m(this, F, Pf).call(this, e), o = e.length === 1 ? n : `${n}${r}${a}`;
    if (s = i(this, F, se).get(o), s)
      return i(this, F, se).set(e, s), s;
    const l = `g_${i(this, Di)}_transfer_map_${rt(this, Dr)._++}`, h = m(this, F, ua).call(this, l);
    i(this, F, se).set(e, h), i(this, F, se).set(o, h);
    const c = m(this, F, fa).call(this, l);
    return m(this, F, Mc).call(this, n, r, a, c), h;
  }
  addHCMFilter(e, s) {
    var y;
    const n = `${e}-${s}`, r = "base";
    let a = i(this, F, kc).get(r);
    if ((a == null ? void 0 : a.key) === n || (a ? ((y = a.filter) == null || y.remove(), a.key = n, a.url = "none", a.filter = null) : (a = {
      key: n,
      url: "none",
      filter: null
    }, i(this, F, kc).set(r, a)), !e || !s))
      return a.url;
    const o = m(this, F, Dc).call(this, e);
    e = I.makeHexColor(...o);
    const l = m(this, F, Dc).call(this, s);
    if (s = I.makeHexColor(...l), m(this, F, gm).call(this), e === "#000000" && s === "#ffffff" || e === s)
      return a.url;
    const c = Array.from({
      length: 256
    }, (A, w) => Ig(w / 255)).join(","), d = `g_${i(this, Di)}_hcm_filter`, f = a.filter = m(this, F, fa).call(this, d);
    m(this, F, Mc).call(this, c, c, c, f), m(this, F, fm).call(this, f);
    const b = (A, w) => {
      const v = o[A] / 255, S = l[A] / 255, E = new Array(w + 1);
      for (let C = 0; C <= w; C++)
        E[C] = v + C / w * (S - v);
      return E.join(",");
    };
    return m(this, F, Mc).call(this, b(0, 5), b(1, 5), b(2, 5), f), a.url = m(this, F, ua).call(this, d), a.url;
  }
  addSelectionHCMFilter(e, s) {
    return this.addHighlightHCMFilter("selection", e, s, "HighlightText", "Highlight");
  }
  addSelectionFilter() {
    return this.addHighlightHCMFilter("selection_default", "black", "white", "HighlightText", "Highlight");
  }
  createSelectionStyle(e = null) {
    const s = e ? this.addSelectionHCMFilter(e.foreground, e.background) : this.addSelectionFilter();
    return s === "none" || !ot.platform.isFirefox ? null : {
      "backdrop-filter": s,
      "background-color": "transparent"
    };
  }
  addAlphaFilter(e) {
    let s = i(this, F, se).get(e);
    if (s)
      return s;
    const [n] = m(this, F, Pf).call(this, [e]), r = `alpha_${n}`;
    if (s = i(this, F, se).get(r), s)
      return i(this, F, se).set(e, s), s;
    const a = `g_${i(this, Di)}_alpha_map_${rt(this, Dr)._++}`, o = m(this, F, ua).call(this, a);
    i(this, F, se).set(e, o), i(this, F, se).set(r, o);
    const l = m(this, F, fa).call(this, a);
    return m(this, F, pm).call(this, n, l), o;
  }
  addLuminosityFilter(e) {
    let s = i(this, F, se).get(e || "luminosity");
    if (s)
      return s;
    let n, r;
    if (e ? ([n] = m(this, F, Pf).call(this, [e]), r = `luminosity_${n}`) : r = "luminosity", s = i(this, F, se).get(r), s)
      return i(this, F, se).set(e, s), s;
    const a = `g_${i(this, Di)}_luminosity_map_${rt(this, Dr)._++}`, o = m(this, F, ua).call(this, a);
    i(this, F, se).set(e, o), i(this, F, se).set(r, o);
    const l = m(this, F, fa).call(this, a);
    return m(this, F, FA).call(this, l), e && m(this, F, pm).call(this, n, l), o;
  }
  addKnockoutFilter(e = 0) {
    const s = e > 0 ? Math.min(1 / e, 1e6) : 1e6, n = `knockout_${s}`, r = i(this, F, se).get(n);
    if (r)
      return r;
    const a = `g_${i(this, Di)}_knockout_filter_${rt(this, Dr)._++}`, o = m(this, F, ua).call(this, a);
    i(this, F, se).set(n, o);
    const l = m(this, F, fa).call(this, a), h = i(this, ae).createElementNS(Re, "feComponentTransfer");
    l.append(h);
    const c = i(this, ae).createElementNS(Re, "feFuncA");
    return c.setAttribute("type", "linear"), c.setAttribute("slope", `${s}`), c.setAttribute("intercept", "0"), h.append(c), o;
  }
  addHighlightHCMFilter(e, s, n, r, a) {
    var S;
    const o = `${s}-${n}-${r}-${a}`;
    let l = i(this, F, kc).get(e);
    if ((l == null ? void 0 : l.key) === o || (l ? ((S = l.filter) == null || S.remove(), l.key = o, l.url = "none", l.filter = null) : (l = {
      key: o,
      url: "none",
      filter: null
    }, i(this, F, kc).set(e, l)), !s || !n))
      return l.url;
    const [h, c] = [s, n].map(m(this, F, Dc).bind(this));
    let d = Math.round(0.2126 * h[0] + 0.7152 * h[1] + 0.0722 * h[2]), f = Math.round(0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]), [b, y] = [r, a].map(m(this, F, OA).bind(this));
    f < d && ([d, f, b, y] = [f, d, y, b]), m(this, F, gm).call(this);
    const A = (E, C, x) => {
      const T = new Array(256), k = (f - d) / x, M = E / 255, P = (C - E) / (255 * x);
      let D = 0;
      for (let H = 0; H <= x; H++) {
        const Y = Math.round(d + H * k), Q = M + H * P;
        for (let K = D; K <= Y; K++)
          T[K] = Q;
        D = Y + 1;
      }
      for (let H = D; H < 256; H++)
        T[H] = T[D - 1];
      return T.join(",");
    }, w = `g_${i(this, Di)}_hcm_${e}_filter`, v = l.filter = m(this, F, fa).call(this, w);
    return m(this, F, fm).call(this, v), m(this, F, Mc).call(this, A(b[0], y[0], 5), A(b[1], y[1], 5), A(b[2], y[2], 5), v), l.url = m(this, F, ua).call(this, w), l.url;
  }
  destroy(e = !1) {
    var s, n, r, a;
    e && ((s = i(this, oo)) != null && s.size) || ((n = i(this, Sn)) == null || n.parentNode.parentNode.remove(), u(this, Sn, null), (r = i(this, Jl)) == null || r.clear(), u(this, Jl, null), (a = i(this, oo)) == null || a.clear(), u(this, oo, null), u(this, Dr, 0));
  }
}
ao = new WeakMap(), Jl = new WeakMap(), Sn = new WeakMap(), Di = new WeakMap(), ae = new WeakMap(), oo = new WeakMap(), Dr = new WeakMap(), F = new WeakSet(), se = function() {
  return i(this, Jl) || u(this, Jl, /* @__PURE__ */ new Map());
}, kc = function() {
  return i(this, oo) || u(this, oo, /* @__PURE__ */ new Map());
}, gi = function() {
  if (!i(this, Sn)) {
    const e = i(this, ae).createElement("div"), {
      style: s
    } = e;
    s.colorScheme = "only light", s.visibility = "hidden", s.contain = "strict", s.width = s.height = 0, s.position = "absolute", s.top = s.left = 0, s.zIndex = -1;
    const n = i(this, ae).createElementNS(Re, "svg");
    n.setAttribute("width", 0), n.setAttribute("height", 0), u(this, Sn, i(this, ae).createElementNS(Re, "defs")), e.append(n), n.append(i(this, Sn)), i(this, ae).body.append(e);
  }
  return i(this, Sn);
}, Pf = function(e) {
  const s = (o) => o && Array.from(o, (l) => l / 255).join(",");
  if (e.length === 1) {
    const o = s(e[0]);
    return [o, o, o];
  }
  const [n, r, a] = e;
  return [s(n), s(r), s(a)];
}, ua = function(e) {
  if (i(this, ao) === void 0) {
    u(this, ao, "");
    const s = i(this, ae).URL;
    s !== i(this, ae).baseURI && (rg(s) ? j('#createUrl: ignore "data:"-URL for performance reasons.') : u(this, ao, Oy(s, "")));
  }
  return `url(${i(this, ao)}#${e})`;
}, FA = function(e) {
  const s = i(this, ae).createElementNS(Re, "feColorMatrix");
  s.setAttribute("type", "matrix"), s.setAttribute("values", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.3 0.59 0.11 0 0"), e.append(s);
}, fm = function(e) {
  const s = i(this, ae).createElementNS(Re, "feColorMatrix");
  s.setAttribute("type", "matrix"), s.setAttribute("values", "0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0 0 0 1 0"), e.append(s);
}, fa = function(e) {
  const s = i(this, ae).createElementNS(Re, "filter");
  return s.setAttribute("color-interpolation-filters", "sRGB"), s.setAttribute("id", e), i(this, F, gi).append(s), s;
}, Pc = function(e, s, n) {
  if (!n)
    return;
  const r = i(this, ae).createElementNS(Re, s);
  r.setAttribute("type", "discrete"), r.setAttribute("tableValues", n), e.append(r);
}, Mc = function(e, s, n, r) {
  const a = i(this, ae).createElementNS(Re, "feComponentTransfer");
  r.append(a), m(this, F, Pc).call(this, a, "feFuncR", e), m(this, F, Pc).call(this, a, "feFuncG", s), m(this, F, Pc).call(this, a, "feFuncB", n);
}, pm = function(e, s) {
  const n = i(this, ae).createElementNS(Re, "feComponentTransfer");
  s.append(n), m(this, F, Pc).call(this, n, "feFuncA", e);
}, Dc = function(e) {
  return i(this, F, gi).style.color = "CanvasText", i(this, F, gi).style.backgroundColor = e, nf(getComputedStyle(i(this, F, gi)).getPropertyValue("background-color"));
}, LA = function(e) {
  return i(this, F, gi).style.color = "CanvasText", i(this, F, gi).style.backgroundColor = e, mc(getComputedStyle(i(this, F, gi)).getPropertyValue("background-color"));
}, gm = function() {
  i(this, F, gi).style.color = "", i(this, F, gi).style.backgroundColor = "";
}, OA = function(e) {
  const [s, n, r, a] = m(this, F, LA).call(this, e);
  if (a === 1)
    return [s, n, r];
  const [o, l, h] = m(this, F, Dc).call(this, "Canvas");
  return [vg(s, o, a), vg(n, l, a), vg(r, h, a)];
};
function vg(p, t, e) {
  return Math.round(e * p + (1 - e) * t);
}
const Sy = new RegExp("\\p{Cc}", "u");
function Sv(p) {
  const t = p[0];
  if (p.length < 2 || t !== '"' && t !== "'" || p.at(-1) !== t)
    return !1;
  const e = p.length - 1;
  for (let s = 1; s < e; s++) {
    const n = p[s];
    if (n === t || Sy.test(n) || n === "\\" && (++s >= e || Sy.test(p[s])))
      return !1;
  }
  return !0;
}
function Ey(p) {
  return Sv(p) ? p : `"${p.replaceAll(/["\\\p{Cc}]/gu, (e) => e === '"' || e === "\\" ? `\\${e}` : `\\${e.codePointAt(0).toString(16)} `)}"`;
}
var lo, Zl, qs, fc, RA, NA;
class Ev {
  constructor({
    ownerDocument: t = globalThis.document,
    styleElement: e = null
  }) {
    g(this, fc);
    g(this, lo, /* @__PURE__ */ new Set());
    g(this, Zl, /* @__PURE__ */ new Set());
    g(this, qs, null);
    this._document = t, this.styleElement = null, this.loadingRequests = [], this.loadTestFontId = 0;
  }
  addNativeFontFace(t) {
    i(this, lo).add(t), this._document.fonts.add(t);
  }
  removeNativeFontFace(t) {
    i(this, lo).delete(t), this._document.fonts.delete(t);
  }
  insertRule(t) {
    const e = m(this, fc, RA).call(this);
    e.insertRule(t, e.cssRules.length);
  }
  clear() {
    var t;
    for (const e of i(this, lo))
      this._document.fonts.delete(e);
    if (i(this, lo).clear(), i(this, Zl).clear(), i(this, qs)) {
      const {
        adoptedStyleSheets: e
      } = this._document;
      e != null && e.includes(i(this, qs)) && (this._document.adoptedStyleSheets = e.filter((s) => s !== i(this, qs))), u(this, qs, null);
    }
    (t = this.styleElement) == null || t.remove(), this.styleElement = null;
  }
  async loadSystemFont({
    systemFontInfo: t,
    disableFontFace: e,
    _inspectFont: s
  }) {
    if (!(!t || i(this, Zl).has(t.loadedName))) {
      if (jt(!e, "loadSystemFont shouldn't be called when `disableFontFace` is set."), this.isFontLoadingAPISupported) {
        const {
          loadedName: n,
          src: r,
          style: a
        } = t, o = new FontFace(n, r, a);
        this.addNativeFontFace(o);
        try {
          await o.load(), i(this, Zl).add(n), s == null || s(t);
        } catch {
          j(`Cannot load system font: ${t.baseFontName}, installing it could help to improve PDF rendering.`), this.removeNativeFontFace(o);
        }
        return;
      }
      it("Not implemented: loadSystemFont without the Font Loading API.");
    }
  }
  async bind(t) {
    if (t.attached || t.missingFile && !t.systemFontInfo)
      return;
    if (t.attached = !0, t.systemFontInfo) {
      await this.loadSystemFont(t);
      return;
    }
    if (this.isFontLoadingAPISupported) {
      const s = t.createNativeFontFace();
      if (s) {
        this.addNativeFontFace(s);
        try {
          await s.loaded;
        } catch (n) {
          throw j(`Failed to load font '${s.family}': '${n}'.`), t.disableFontFace = !0, n;
        }
      }
      return;
    }
    const e = t.createFontFaceRule();
    if (e) {
      if (this.insertRule(e), this.isSyncFontLoadingSupported)
        return;
      await m(this, fc, NA).call(this, t);
    }
  }
  get isFontLoadingAPISupported() {
    var t;
    return L(this, "isFontLoadingAPISupported", !!((t = this._document) != null && t.fonts));
  }
  get isSyncFontLoadingSupported() {
    return L(this, "isSyncFontLoadingSupported", bs || ot.platform.isFirefox);
  }
}
lo = new WeakMap(), Zl = new WeakMap(), qs = new WeakMap(), fc = new WeakSet(), RA = function() {
  var e;
  if (i(this, qs))
    return i(this, qs);
  const t = ((e = this._document.defaultView) == null ? void 0 : e.CSSStyleSheet) || globalThis.CSSStyleSheet;
  if (!this.styleElement && t) {
    const {
      adoptedStyleSheets: s
    } = this._document;
    if (s) {
      const n = new t();
      return s.push(n), u(this, qs, n);
    }
  }
  return this.styleElement || (this.styleElement = this._document.createElement("style"), this._document.documentElement.getElementsByTagName("head")[0].append(this.styleElement)), u(this, qs, this.styleElement.sheet);
}, NA = function(t) {
  function e() {
    for (jt(!a.done, "completeRequest() cannot be called twice."), a.done = !0; s.length > 0 && s[0].done; ) {
      const P = s.shift();
      setTimeout(P.resolve, 0);
    }
  }
  const {
    loadingRequests: s
  } = this, {
    promise: n,
    resolve: r
  } = Promise.withResolvers(), a = {
    done: !1,
    resolve: r
  };
  s.push(a), this._loadTestFont ?? (this._loadTestFont = atob("T1RUTwALAIAAAwAwQ0ZGIDHtZg4AAAOYAAAAgUZGVE1lkzZwAAAEHAAAABxHREVGABQAFQAABDgAAAAeT1MvMlYNYwkAAAEgAAAAYGNtYXABDQLUAAACNAAAAUJoZWFk/xVFDQAAALwAAAA2aGhlYQdkA+oAAAD0AAAAJGhtdHgD6AAAAAAEWAAAAAZtYXhwAAJQAAAAARgAAAAGbmFtZVjmdH4AAAGAAAAAsXBvc3T/hgAzAAADeAAAACAAAQAAAAEAALZRFsRfDzz1AAsD6AAAAADOBOTLAAAAAM4KHDwAAAAAA+gDIQAAAAgAAgAAAAAAAAABAAADIQAAAFoD6AAAAAAD6AABAAAAAAAAAAAAAAAAAAAAAQAAUAAAAgAAAAQD6AH0AAUAAAKKArwAAACMAooCvAAAAeAAMQECAAACAAYJAAAAAAAAAAAAAQAAAAAAAAAAAAAAAFBmRWQAwAAuAC4DIP84AFoDIQAAAAAAAQAAAAAAAAAAACAAIAABAAAADgCuAAEAAAAAAAAAAQAAAAEAAAAAAAEAAQAAAAEAAAAAAAIAAQAAAAEAAAAAAAMAAQAAAAEAAAAAAAQAAQAAAAEAAAAAAAUAAQAAAAEAAAAAAAYAAQAAAAMAAQQJAAAAAgABAAMAAQQJAAEAAgABAAMAAQQJAAIAAgABAAMAAQQJAAMAAgABAAMAAQQJAAQAAgABAAMAAQQJAAUAAgABAAMAAQQJAAYAAgABWABYAAAAAAAAAwAAAAMAAAAcAAEAAAAAADwAAwABAAAAHAAEACAAAAAEAAQAAQAAAC7//wAAAC7////TAAEAAAAAAAABBgAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAAAAD/gwAyAAAAAQAAAAAAAAAAAAAAAAAAAAABAAQEAAEBAQJYAAEBASH4DwD4GwHEAvgcA/gXBIwMAYuL+nz5tQXkD5j3CBLnEQACAQEBIVhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYAAABAQAADwACAQEEE/t3Dov6fAH6fAT+fPp8+nwHDosMCvm1Cvm1DAz6fBQAAAAAAAABAAAAAMmJbzEAAAAAzgTjFQAAAADOBOQpAAEAAAAAAAAADAAUAAQAAAABAAAAAgABAAAAAAAAAAAD6AAAAAAAAA=="));
  function o(P, D) {
    return P.charCodeAt(D) << 24 | P.charCodeAt(D + 1) << 16 | P.charCodeAt(D + 2) << 8 | P.charCodeAt(D + 3) & 255;
  }
  function l(P) {
    return String.fromCharCode(P >> 24 & 255, P >> 16 & 255, P >> 8 & 255, P & 255);
  }
  function h(P, D, H, Y) {
    const Q = P.substring(0, D), K = P.substring(D + H);
    return Q + Y + K;
  }
  let c, d;
  const f = this._document.createElement("canvas");
  f.width = 1, f.height = 1;
  const b = f.getContext("2d");
  let y = 0;
  function A(P, D) {
    if (++y > 30) {
      j("Load test font never loaded."), D();
      return;
    }
    if (b.font = "30px " + P, b.fillText(".", 0, 20), b.getImageData(0, 0, 1, 1).data[3] > 0) {
      D();
      return;
    }
    setTimeout(A.bind(null, P, D));
  }
  const w = `lt${Date.now()}${this.loadTestFontId++}`;
  let v = this._loadTestFont;
  v = h(v, 976, w.length, w);
  const E = 16, C = 1482184792;
  let x = o(v, E);
  for (c = 0, d = w.length - 3; c < d; c += 4)
    x = x - C + o(w, c) | 0;
  c < w.length && (x = x - C + o(w + "XXX", c) | 0), v = h(v, E, 4, l(x));
  const T = `url(data:font/opentype;base64,${btoa(v)});`, k = `@font-face {font-family:"${w}";src:${T}}`;
  this.insertRule(k);
  const M = this._document.createElement("div");
  M.style.visibility = "hidden", M.style.width = M.style.height = "10px", M.style.position = "absolute", M.style.top = M.style.left = "0px";
  for (const P of [t.loadedName, w]) {
    const D = this._document.createElement("span");
    D.textContent = "Hi", D.style.fontFamily = P, M.append(D);
  }
  return this._document.body.append(M), A(w, () => {
    M.remove(), e();
  }), n;
};
var Id, Ut;
class Cv {
  constructor(t, e = null, s, n) {
    g(this, Id, /* @__PURE__ */ new Map());
    g(this, Ut);
    u(this, Ut, t), this._inspectFont = e, s && (this.charProcOperatorList = s), n && Object.assign(this, n);
  }
  createNativeFontFace() {
    var s;
    const {
      data: t
    } = this;
    if (!t || this.disableFontFace)
      return null;
    let e;
    if (!this.cssFontInfo)
      e = new FontFace(this.loadedName, t, {});
    else {
      const n = {
        weight: this.cssFontInfo.fontWeight
      };
      this.cssFontInfo.italicAngle && (n.style = `oblique ${this.cssFontInfo.italicAngle}deg`), e = new FontFace(Ey(this.cssFontInfo.fontFamily), t, n);
    }
    return (s = this._inspectFont) == null || s.call(this, this), e;
  }
  createFontFaceRule() {
    var n;
    const {
      data: t
    } = this;
    if (!t || this.disableFontFace)
      return null;
    const e = `url(data:${this.mimetype};base64,${t.toBase64()});`;
    let s;
    if (!this.cssFontInfo)
      s = `@font-face {font-family:"${this.loadedName}";src:${e}}`;
    else {
      let r = `font-weight: ${this.cssFontInfo.fontWeight};`;
      this.cssFontInfo.italicAngle && (r += `font-style: oblique ${this.cssFontInfo.italicAngle}deg;`), s = `@font-face {font-family:${Ey(this.cssFontInfo.fontFamily)};${r}src:${e}}`;
    }
    return (n = this._inspectFont) == null || n.call(this, this, e), s;
  }
  getPathGenerator(t, e) {
    let s = i(this, Id).get(e);
    if (s)
      return s;
    const n = `${this.loadedName}_path_${e}`;
    let r;
    try {
      r = t.get(n);
    } catch (a) {
      j(`getPathGenerator - ignoring character: "${a}".`);
    }
    return s = Ny(r == null ? void 0 : r.path), this.fontExtraProperties || t.delete(n), i(this, Id).set(e, s), s;
  }
  get black() {
    return i(this, Ut).black;
  }
  get bold() {
    return i(this, Ut).bold;
  }
  get disableFontFace() {
    return i(this, Ut).disableFontFace;
  }
  set disableFontFace(t) {
    L(this, "disableFontFace", !!t);
  }
  get fontExtraProperties() {
    return i(this, Ut).fontExtraProperties;
  }
  get isInvalidPDFjsFont() {
    return i(this, Ut).isInvalidPDFjsFont;
  }
  get isType3Font() {
    return i(this, Ut).isType3Font;
  }
  get italic() {
    return i(this, Ut).italic;
  }
  get missingFile() {
    return i(this, Ut).missingFile;
  }
  get remeasure() {
    return i(this, Ut).remeasure;
  }
  get vertical() {
    return i(this, Ut).vertical;
  }
  get bbox() {
    return i(this, Ut).bbox;
  }
  get fontMatrix() {
    return i(this, Ut).fontMatrix;
  }
  get fallbackName() {
    return i(this, Ut).fallbackName;
  }
  get loadedName() {
    return i(this, Ut).loadedName;
  }
  get mimetype() {
    return this.missingFile ? null : "font/opentype";
  }
  get data() {
    return i(this, Ut).data;
  }
  clearData() {
    i(this, Ut).clearData();
  }
  get cssFontInfo() {
    return i(this, Ut).cssFontInfo;
  }
  get systemFontInfo() {
    return i(this, Ut).systemFontInfo;
  }
}
Id = new WeakMap(), Ut = new WeakMap();
var Fd, Ld;
class og {
  constructor(t, e, s) {
    g(this, Fd, null);
    g(this, Ld, null);
    _(this, "_fullReader", null);
    _(this, "_rangeReaders", /* @__PURE__ */ new Set());
    _(this, "_source", null);
    this._source = t, u(this, Fd, e), u(this, Ld, s);
  }
  get _progressiveDataLength() {
    var t;
    return ((t = this._fullReader) == null ? void 0 : t._loaded) ?? 0;
  }
  getFullReader() {
    return jt(!this._fullReader, "BasePDFStream.getFullReader can only be called once."), this._fullReader = new (i(this, Fd))(this);
  }
  getRangeReader(t, e) {
    if (e <= this._progressiveDataLength)
      return null;
    const s = new (i(this, Ld))(this, t, e);
    return this._rangeReaders.add(s), s;
  }
  cancelAllRequests(t) {
    var e;
    (e = this._fullReader) == null || e.cancel(t);
    for (const s of new Set(this._rangeReaders))
      s.cancel(t);
  }
}
Fd = new WeakMap(), Ld = new WeakMap();
class lg {
  constructor(t) {
    _(this, "onProgress", null);
    _(this, "_contentLength", 0);
    _(this, "_filename", null);
    _(this, "_headersCapability", Promise.withResolvers());
    _(this, "_isRangeSupported", !1);
    _(this, "_isStreamingSupported", !1);
    _(this, "_loaded", 0);
    _(this, "_stream", null);
    this._stream = t;
  }
  _callOnProgress() {
    var t;
    (t = this.onProgress) == null || t.call(this, {
      loaded: this._loaded,
      total: this._contentLength
    });
  }
  get headersReady() {
    return this._headersCapability.promise;
  }
  get filename() {
    return this._filename;
  }
  get contentLength() {
    return this._contentLength;
  }
  get isRangeSupported() {
    return this._isRangeSupported;
  }
  get isStreamingSupported() {
    return this._isStreamingSupported;
  }
  async read() {
    it("Abstract method `read` called");
  }
  cancel(t) {
    it("Abstract method `cancel` called");
  }
}
class hg {
  constructor(t, e, s) {
    _(this, "_stream", null);
    this._stream = t;
  }
  async read() {
    it("Abstract method `read` called");
  }
  cancel(t) {
    it("Abstract method `cancel` called");
  }
}
function xv(p) {
  let t = !0, e = s("filename\\*", "i").exec(p);
  if (e) {
    e = e[1];
    let c = o(e);
    return c = unescape(c), c = l(c), c = h(c), r(c);
  }
  if (e = a(p), e) {
    const c = h(e);
    return r(c);
  }
  if (e = s("filename", "i").exec(p), e) {
    e = e[1];
    let c = o(e);
    return c = h(c), r(c);
  }
  function s(c, d) {
    return new RegExp("(?:^|;)\\s*" + c + '\\s*=\\s*([^";\\s][^;\\s]*|"(?:[^"\\\\]|\\\\"?)+"?)', d);
  }
  function n(c, d) {
    if (c) {
      if (!/^[\x00-\xFF]+$/.test(d))
        return d;
      try {
        const f = new TextDecoder(c, {
          fatal: !0
        }), b = ng(d);
        d = f.decode(b), t = !1;
      } catch {
      }
    }
    return d;
  }
  function r(c) {
    return t && /[\x80-\xff]/.test(c) && (c = n("utf-8", c), t && (c = n("iso-8859-1", c))), c;
  }
  function a(c) {
    const d = [];
    let f;
    const b = s("filename\\*((?!0\\d)\\d+)(\\*?)", "ig");
    for (; (f = b.exec(c)) !== null; ) {
      let [, A, w, v] = f;
      if (A = parseInt(A, 10), A in d) {
        if (A === 0)
          break;
        continue;
      }
      d[A] = [w, v];
    }
    const y = [];
    for (let A = 0; A < d.length && A in d; ++A) {
      let [w, v] = d[A];
      v = o(v), w && (v = unescape(v), A === 0 && (v = l(v))), y.push(v);
    }
    return y.join("");
  }
  function o(c) {
    if (c.startsWith('"')) {
      const d = c.slice(1).split('\\"');
      for (let f = 0; f < d.length; ++f) {
        const b = d[f].indexOf('"');
        b !== -1 && (d[f] = d[f].slice(0, b), d.length = f + 1), d[f] = d[f].replaceAll(/\\(.)/g, "$1");
      }
      c = d.join('"');
    }
    return c;
  }
  function l(c) {
    const d = c.indexOf("'");
    if (d === -1)
      return c;
    const f = c.slice(0, d), y = c.slice(d + 1).replace(/^[^']*'/, "");
    return n(f, y);
  }
  function h(c) {
    return !c.startsWith("=?") || /[\x00-\x19\x80-\xff]/.test(c) ? c : c.replaceAll(/=\?([\w-]*)\?([QB])\?((?:[^?]|\?(?!=))*)\?=/gi, function(d, f, b, y) {
      if (b === "q" || b === "Q")
        return y = y.replaceAll("_", " ").replaceAll(/=([0-9a-f]{2})/gi, (A, w) => String.fromCharCode(parseInt(w, 16))), n(f, y);
      try {
        y = atob(y);
      } catch {
      }
      return n(f, y);
    });
  }
  return "";
}
function BA(p, t) {
  const e = new Headers();
  if (!p || !t || typeof t != "object")
    return e;
  for (const s in t) {
    const n = t[s];
    n !== void 0 && e.append(s, n);
  }
  return e;
}
function Tv(p) {
  let t = p.length;
  for (; t > 0 && p[t - 1] !== " " && /\s/.test(p[t - 1]); )
    t--;
  return p.slice(0, t);
}
function cg(p) {
  var t;
  return ((t = URL.parse(p)) == null ? void 0 : t.origin) ?? null;
}
function HA({
  responseHeaders: p,
  isHttp: t,
  rangeChunkSize: e,
  disableRange: s
}) {
  const n = {
    contentLength: 0,
    isRangeSupported: !1
  }, r = parseInt(p.get("Content-Length"), 10);
  return !Number.isInteger(r) || (n.contentLength = r, r <= 2 * e) || s || !t || p.get("Accept-Ranges") !== "bytes" || (p.get("Content-Encoding") || "identity") === "identity" && (n.isRangeSupported = !0), n;
}
function UA(p) {
  const t = p.get("Content-Disposition");
  if (t) {
    let e = xv(t);
    if (e.includes("%"))
      try {
        e = decodeURIComponent(e);
      } catch {
      }
    if (Nb(e))
      return e;
  }
  return null;
}
function dg(p, t) {
  return new ap(`Unexpected server response (${p}) while retrieving PDF "${t.href}".`, p, p === 404 || p === 0 && t.protocol === "file:");
}
function zA(p, t) {
  if (p !== t)
    throw new Error(`Expected range response-origin "${p}" to match "${t}".`);
}
function GA(p, t, e, s) {
  return fetch(p, {
    method: "GET",
    headers: t,
    signal: s.signal,
    mode: "cors",
    credentials: e ? "include" : "same-origin",
    redirect: "follow"
  });
}
function $A(p, t) {
  if (p !== 200 && p !== 206)
    throw dg(p, t);
}
function ug(p) {
  if (p instanceof Uint8Array)
    return p.buffer;
  if (p instanceof ArrayBuffer)
    return p;
  throw new Error(`getArrayBuffer - unexpected data: ${p}`);
}
class _v extends og {
  constructor(e) {
    super(e, kv, Pv);
    _(this, "_responseOrigin", null);
    const {
      httpHeaders: s,
      url: n
    } = e;
    jt(/https?:/.test(n.protocol), "PDFFetchStream only supports http(s):// URLs."), this.headers = BA(!0, s);
  }
}
class kv extends lg {
  constructor(e) {
    super(e);
    _(this, "_abortController", new AbortController());
    _(this, "_reader", null);
    const {
      disableRange: s,
      disableStream: n,
      rangeChunkSize: r,
      url: a,
      withCredentials: o
    } = e._source;
    this._isStreamingSupported = !n;
    const l = new Headers(e.headers);
    GA(a, l, o, this._abortController).then((h) => {
      e._responseOrigin = cg(h.url), $A(h.status, a), this._reader = h.body.getReader();
      const c = h.headers, {
        contentLength: d,
        isRangeSupported: f
      } = HA({
        responseHeaders: c,
        isHttp: !0,
        rangeChunkSize: r,
        disableRange: s
      });
      this._contentLength = d, this._isRangeSupported = f, this._filename = UA(c), !this._isStreamingSupported && this._isRangeSupported && this.cancel(new oa("Streaming is disabled.")), this._headersCapability.resolve();
    }).catch(this._headersCapability.reject);
  }
  async read() {
    await this._headersCapability.promise;
    const {
      value: e,
      done: s
    } = await this._reader.read();
    return s ? {
      value: e,
      done: s
    } : (this._loaded += e.byteLength, this._callOnProgress(), {
      value: ug(e),
      done: !1
    });
  }
  cancel(e) {
    var s;
    (s = this._reader) == null || s.cancel(e).catch(() => {
    }), this._abortController.abort();
  }
}
class Pv extends hg {
  constructor(e, s, n) {
    super(e, s, n);
    _(this, "_abortController", new AbortController());
    _(this, "_readCapability", Promise.withResolvers());
    _(this, "_reader", null);
    const {
      url: r,
      withCredentials: a
    } = e._source, o = new Headers(e.headers);
    o.append("Range", `bytes=${s}-${n - 1}`), GA(r, o, a, this._abortController).then((l) => {
      const h = cg(l.url);
      zA(h, e._responseOrigin), $A(l.status, r), this._reader = l.body.getReader(), this._readCapability.resolve();
    }).catch(this._readCapability.reject), this._readCapability.promise.catch(() => {
    });
  }
  async read() {
    await this._readCapability.promise;
    const {
      value: e,
      done: s
    } = await this._reader.read();
    return s ? {
      value: e,
      done: s
    } : {
      value: ug(e),
      done: !1
    };
  }
  cancel(e) {
    var s;
    (s = this._reader) == null || s.cancel(e).catch(() => {
    }), this._abortController.abort();
  }
}
function Cy(p) {
  return p instanceof Uint8Array && p.byteLength === p.buffer.byteLength ? p.buffer : new Uint8Array(p).buffer;
}
function fg() {
  for (const p of this._requests)
    p.resolve({
      value: void 0,
      done: !0
    });
  this._requests.length = 0;
}
var Dp, jA;
class Mv extends og {
  constructor(e) {
    super(e, Dv, Iv);
    g(this, Dp);
    _(this, "_progressiveDone", !1);
    _(this, "_queuedChunks", []);
    const {
      pdfDataRangeTransport: s
    } = e, {
      initialData: n,
      progressiveDone: r
    } = s;
    if ((n == null ? void 0 : n.length) > 0) {
      const o = Cy(n);
      this._queuedChunks.push(o);
    }
    this._progressiveDone = r;
    const a = (o) => {
      var l;
      switch (o.type) {
        case "range":
        case "progressiveRead":
          m(this, Dp, jA).call(this, o.begin, o.chunk);
          break;
        case "progressiveDone":
          (l = this._fullReader) == null || l.progressiveDone(), this._progressiveDone = !0;
          break;
      }
    };
    s.transportReady(a);
  }
  getFullReader() {
    const e = super.getFullReader();
    return this._queuedChunks = null, e;
  }
  getRangeReader(e, s) {
    const n = super.getRangeReader(e, s);
    return n && (n.onDone = () => this._rangeReaders.delete(n), this._source.pdfDataRangeTransport.requestDataRange(e, s)), n;
  }
  cancelAllRequests(e) {
    super.cancelAllRequests(e), this._source.pdfDataRangeTransport.abort();
  }
}
Dp = new WeakSet(), jA = function(e, s) {
  const n = Cy(s);
  if (e === void 0)
    this._fullReader ? this._fullReader._enqueue(n) : this._queuedChunks.push(n);
  else {
    const r = this._rangeReaders.keys().find((a) => a._begin === e);
    jt(r, "#onReceiveData - no `PDFDataTransportStreamRangeReader` instance found."), r._enqueue(n);
  }
};
var Od;
class Dv extends lg {
  constructor(e) {
    super(e);
    g(this, Od, fg.bind(this));
    _(this, "_done", !1);
    _(this, "_queuedChunks", null);
    _(this, "_requests", []);
    const {
      pdfDataRangeTransport: s,
      disableRange: n,
      disableStream: r
    } = e._source, {
      length: a,
      contentDispositionFilename: o
    } = s;
    this._queuedChunks = e._queuedChunks || [];
    for (const h of this._queuedChunks)
      this._loaded += h.byteLength;
    this._done = e._progressiveDone, this._contentLength = a, this._isStreamingSupported = !r, this._isRangeSupported = !n, Nb(o) && (this._filename = o), this._headersCapability.resolve();
    const l = this._loaded;
    Promise.resolve().then(() => {
      l > 0 && this._loaded === l && this._callOnProgress();
    });
  }
  _enqueue(e) {
    this._done || (this._requests.length > 0 ? this._requests.shift().resolve({
      value: e,
      done: !1
    }) : this._queuedChunks.push(e), this._loaded += e.byteLength, this._callOnProgress());
  }
  async read() {
    if (this._queuedChunks.length > 0)
      return {
        value: this._queuedChunks.shift(),
        done: !1
      };
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const e = Promise.withResolvers();
    return this._requests.push(e), e.promise;
  }
  cancel(e) {
    this._done = !0, i(this, Od).call(this);
  }
  progressiveDone() {
    this._done || (this._done = !0), this._queuedChunks.length === 0 && i(this, Od).call(this);
  }
}
Od = new WeakMap();
var Rd;
class Iv extends hg {
  constructor(e, s, n) {
    super(e, s, n);
    g(this, Rd, fg.bind(this));
    _(this, "onDone", null);
    _(this, "_begin", -1);
    _(this, "_done", !1);
    _(this, "_queuedChunk", null);
    _(this, "_requests", []);
    this._begin = s;
  }
  _enqueue(e) {
    var s;
    this._done || (this._requests.length === 0 ? this._queuedChunk = e : (this._requests.shift().resolve({
      value: e,
      done: !1
    }), i(this, Rd).call(this)), this._done = !0, (s = this.onDone) == null || s.call(this));
  }
  async read() {
    if (this._queuedChunk) {
      const s = this._queuedChunk;
      return this._queuedChunk = null, {
        value: s,
        done: !1
      };
    }
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const e = Promise.withResolvers();
    return this._requests.push(e), e.promise;
  }
  cancel(e) {
    var s;
    this._done = !0, i(this, Rd).call(this), (s = this.onDone) == null || s.call(this);
  }
}
Rd = new WeakMap();
const Sg = 200, xy = 206;
function Fv(p) {
  return typeof p != "string" ? p : ng(p).buffer;
}
var Ii, pc, VA, WA;
class Lv extends og {
  constructor(e) {
    super(e, Ov, Rv);
    g(this, pc);
    g(this, Ii, /* @__PURE__ */ new WeakMap());
    _(this, "_responseOrigin", null);
    const {
      httpHeaders: s,
      url: n
    } = e;
    this.url = n, this.isHttp = /https?:/.test(n.protocol), this.headers = BA(this.isHttp, s);
  }
  _request(e) {
    const s = new XMLHttpRequest(), n = {
      validateStatus: null,
      onHeadersReceived: e.onHeadersReceived,
      onDone: e.onDone,
      onError: e.onError,
      onProgress: e.onProgress
    };
    i(this, Ii).set(s, n), s.open("GET", this.url), s.withCredentials = this._source.withCredentials;
    for (const [r, a] of this.headers)
      s.setRequestHeader(r, a);
    return this.isHttp && "begin" in e && "end" in e ? (s.setRequestHeader("Range", `bytes=${e.begin}-${e.end - 1}`), n.validateStatus = (r) => r === xy || r === Sg) : n.validateStatus = (r) => r === Sg, s.responseType = "arraybuffer", jt(e.onError, "Expected `onError` callback to be provided."), s.onerror = () => e.onError(s.status), s.onreadystatechange = m(this, pc, WA).bind(this, s), s.onprogress = m(this, pc, VA).bind(this, s), s.send(null), s;
  }
  _abortRequest(e) {
    i(this, Ii).has(e) && (i(this, Ii).delete(e), e.abort());
  }
  getRangeReader(e, s) {
    const n = super.getRangeReader(e, s);
    return n && (n.onClosed = () => this._rangeReaders.delete(n)), n;
  }
}
Ii = new WeakMap(), pc = new WeakSet(), VA = function(e, s) {
  var r;
  const n = i(this, Ii).get(e);
  (r = n == null ? void 0 : n.onProgress) == null || r.call(n, s);
}, WA = function(e, s) {
  const n = i(this, Ii).get(e);
  if (!n || (e.readyState >= 2 && n.onHeadersReceived && (n.onHeadersReceived(), delete n.onHeadersReceived), e.readyState !== 4) || !i(this, Ii).has(e))
    return;
  if (i(this, Ii).delete(e), e.status === 0 && this.isHttp) {
    n.onError(e.status);
    return;
  }
  const r = e.status || Sg;
  if (!n.validateStatus(r)) {
    n.onError(e.status);
    return;
  }
  const a = Fv(e.response);
  if (r === xy) {
    const o = e.getResponseHeader("Content-Range");
    /bytes \d+-\d+\/\d+/.test(o) ? n.onDone(a) : (j('Missing or invalid "Content-Range" header.'), n.onError(0));
  } else a ? n.onDone(a) : n.onError(e.status);
};
var Nd, qi, XA, YA, KA, qA;
class Ov extends lg {
  constructor(e) {
    super(e);
    g(this, qi);
    g(this, Nd, fg.bind(this));
    _(this, "_cachedChunks", []);
    _(this, "_done", !1);
    _(this, "_requests", []);
    _(this, "_storedError", null);
    this._fullRequestXhr = e._request({
      onHeadersReceived: m(this, qi, XA).bind(this),
      onDone: m(this, qi, YA).bind(this),
      onError: m(this, qi, KA).bind(this),
      onProgress: m(this, qi, qA).bind(this)
    });
  }
  async read() {
    if (await this._headersCapability.promise, this._storedError)
      throw this._storedError;
    if (this._cachedChunks.length > 0)
      return {
        value: this._cachedChunks.shift(),
        done: !1
      };
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const e = Promise.withResolvers();
    return this._requests.push(e), e.promise;
  }
  cancel(e) {
    this._done = !0, this._headersCapability.reject(e), i(this, Nd).call(this), this._stream._abortRequest(this._fullRequestXhr), this._fullRequestXhr = null;
  }
}
Nd = new WeakMap(), qi = new WeakSet(), XA = function() {
  const e = this._stream, {
    disableRange: s,
    rangeChunkSize: n
  } = e._source, r = this._fullRequestXhr;
  e._responseOrigin = cg(r.responseURL);
  const a = r.getAllResponseHeaders(), o = new Headers(a ? Tv(a.trimStart()).split(/[\r\n]+/).map((c) => {
    const [d, ...f] = c.split(": ");
    return [d, f.join(": ")];
  }) : []), {
    contentLength: l,
    isRangeSupported: h
  } = HA({
    responseHeaders: o,
    isHttp: e.isHttp,
    rangeChunkSize: n,
    disableRange: s
  });
  this._contentLength = l, this._isRangeSupported = h, this._filename = UA(o), this._isRangeSupported && e._abortRequest(r), this._headersCapability.resolve();
}, YA = function(e) {
  this._requests.length > 0 ? this._requests.shift().resolve({
    value: e,
    done: !1
  }) : this._cachedChunks.push(e), this._done = !0, this._cachedChunks.length === 0 && i(this, Nd).call(this);
}, KA = function(e) {
  this._storedError = dg(e, this._stream.url), this._headersCapability.reject(this._storedError);
  for (const s of this._requests)
    s.reject(this._storedError);
  this._requests.length = 0, this._cachedChunks.length = 0;
}, qA = function(e) {
  var s;
  (s = this.onProgress) == null || s.call(this, {
    loaded: e.loaded,
    total: e.lengthComputable ? e.total : this._contentLength
  });
};
var Bd, qn, QA, JA, mm;
class Rv extends hg {
  constructor(e, s, n) {
    super(e, s, n);
    g(this, qn);
    g(this, Bd, fg.bind(this));
    _(this, "onClosed", null);
    _(this, "_done", !1);
    _(this, "_queuedChunk", null);
    _(this, "_requests", []);
    _(this, "_storedError", null);
    this._requestXhr = e._request({
      begin: s,
      end: n,
      onHeadersReceived: m(this, qn, QA).bind(this),
      onDone: m(this, qn, JA).bind(this),
      onError: m(this, qn, mm).bind(this),
      onProgress: null
    });
  }
  async read() {
    if (this._storedError)
      throw this._storedError;
    if (this._queuedChunk !== null) {
      const s = this._queuedChunk;
      return this._queuedChunk = null, {
        value: s,
        done: !1
      };
    }
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const e = Promise.withResolvers();
    return this._requests.push(e), e.promise;
  }
  cancel(e) {
    var s;
    this._done = !0, i(this, Bd).call(this), this._stream._abortRequest(this._requestXhr), (s = this.onClosed) == null || s.call(this);
  }
}
Bd = new WeakMap(), qn = new WeakSet(), QA = function() {
  var s;
  const e = cg((s = this._requestXhr) == null ? void 0 : s.responseURL);
  try {
    zA(e, this._stream._responseOrigin);
  } catch (n) {
    this._storedError = n, m(this, qn, mm).call(this, 0);
  }
}, JA = function(e) {
  var s;
  this._requests.length > 0 ? this._requests.shift().resolve({
    value: e,
    done: !1
  }) : this._queuedChunk = e, this._done = !0, i(this, Bd).call(this), (s = this.onClosed) == null || s.call(this);
}, mm = function(e) {
  this._storedError ?? (this._storedError = dg(e, this._stream.url));
  for (const s of this._requests)
    s.reject(this._storedError);
  this._requests.length = 0, this._queuedChunk = null;
};
function ZA(p, t = null) {
  const e = process.getBuiltinModule("fs"), {
    Readable: s
  } = process.getBuiltinModule("stream"), n = e.createReadStream(p, t);
  return s.toWeb(n);
}
class Nv extends og {
  constructor(t) {
    super(t, Bv, Hv);
    const {
      url: e
    } = t;
    jt(e.protocol === "file:", "PDFNodeStream only supports file:// URLs.");
  }
}
class Bv extends lg {
  constructor(e) {
    super(e);
    _(this, "_reader", null);
    const {
      disableRange: s,
      disableStream: n,
      rangeChunkSize: r,
      url: a
    } = e._source;
    this._isStreamingSupported = !n, process.getBuiltinModule("fs/promises").lstat(a).then((l) => {
      const h = ZA(a);
      this._reader = h.getReader();
      const {
        size: c
      } = l;
      this._contentLength = c, this._isRangeSupported = !s && c > 2 * r, !this._isStreamingSupported && this._isRangeSupported && this.cancel(new oa("Streaming is disabled.")), this._headersCapability.resolve();
    }).catch((l) => {
      l.code === "ENOENT" && (l = dg(0, a)), this._headersCapability.reject(l);
    });
  }
  async read() {
    await this._headersCapability.promise;
    const {
      value: e,
      done: s
    } = await this._reader.read();
    return s ? {
      value: e,
      done: s
    } : (this._loaded += e.byteLength, this._callOnProgress(), {
      value: ug(e),
      done: !1
    });
  }
  cancel(e) {
    var s;
    (s = this._reader) == null || s.cancel(e).catch(() => {
    });
  }
}
class Hv extends hg {
  constructor(e, s, n) {
    super(e, s, n);
    _(this, "_readCapability", Promise.withResolvers());
    _(this, "_reader", null);
    const {
      url: r
    } = e._source;
    try {
      const a = ZA(r, {
        start: s,
        end: n - 1
      });
      this._reader = a.getReader(), this._readCapability.resolve();
    } catch (a) {
      this._readCapability.reject(a);
    }
    this._readCapability.promise.catch(() => {
    });
  }
  async read() {
    await this._readCapability.promise;
    const {
      value: e,
      done: s
    } = await this._reader.read();
    return s ? {
      value: e,
      done: s
    } : {
      value: ug(e),
      done: !1
    };
  }
  cancel(e) {
    var s;
    (s = this._reader) == null || s.cancel(e).catch(() => {
    });
  }
}
function Uv(p) {
  return jc(p) ? _v : bs ? Nv : Lv;
}
var Hd, Ud, zd, Gd;
class Te {
  static get rendererPorts() {
    return i(this, Ud);
  }
  static set rendererPorts(t) {
    if (!Array.isArray(t) || !t.every((e) => typeof Worker < "u" && e instanceof Worker))
      throw new Error("Invalid `rendererPorts` type.");
    u(this, Ud, t);
  }
  static get rendererSrc() {
    return i(this, zd);
  }
  static set rendererSrc(t) {
    if (typeof t != "string")
      throw new Error("Invalid `rendererSrc` type.");
    u(this, zd, t);
  }
  static get workerPort() {
    return i(this, Hd);
  }
  static set workerPort(t) {
    if (!(typeof Worker < "u" && t instanceof Worker) && t !== null)
      throw new Error("Invalid `workerPort` type.");
    u(this, Hd, t);
  }
  static get workerSrc() {
    return i(this, Gd);
  }
  static set workerSrc(t) {
    if (typeof t != "string")
      throw new Error("Invalid `workerSrc` type.");
    u(this, Gd, t);
  }
}
Hd = new WeakMap(), Ud = new WeakMap(), zd = new WeakMap(), Gd = new WeakMap(), g(Te, Hd, null), g(Te, Ud, []), g(Te, zd, ""), g(Te, Gd, "");
var th, $d;
class zv {
  constructor({
    parsedData: t,
    rawData: e
  }) {
    g(this, th);
    g(this, $d);
    u(this, th, t), u(this, $d, e);
  }
  getRaw() {
    return i(this, $d);
  }
  get(t) {
    return i(this, th).get(t) ?? null;
  }
  [Symbol.iterator]() {
    return i(this, th).entries();
  }
}
th = new WeakMap(), $d = new WeakMap();
class t0 {
}
_(t0, "strings", ["fontFamily", "fontWeight", "italicAngle"]);
class e0 {
}
_(e0, "strings", ["css", "loadedName", "baseFontName", "src"]);
const bi = class bi {
};
_(bi, "bools", ["black", "bold", "disableFontFace", "fontExtraProperties", "isInvalidPDFjsFont", "isType3Font", "italic", "missingFile", "remeasure", "vertical"]), _(bi, "strings", ["fallbackName", "loadedName"]), _(bi, "OFFSET_BBOX", Math.ceil(bi.bools.length * 2 / 8)), _(bi, "OFFSET_FONT_MATRIX", bi.OFFSET_BBOX + 1 + 8), _(bi, "OFFSET_STRINGS", bi.OFFSET_FONT_MATRIX + 1 + 48);
let Jn = bi;
class Ne {
}
_(Ne, "KIND", 0), _(Ne, "HAS_BBOX", 1), _(Ne, "HAS_BACKGROUND", 2), _(Ne, "SHADING_TYPE", 3), _(Ne, "N_COORD", 4), _(Ne, "N_COLOR", 8), _(Ne, "N_STOP", 12), _(Ne, "N_FIGURES", 16);
class Gv {
  static get decoder() {
    return L(this, "decoder", new TextDecoder());
  }
  static get encoder() {
    return L(this, "encoder", new TextEncoder());
  }
}
function Wc(p, t, e, s = 0) {
  const {
    decoder: n
  } = Gv;
  for (let a = 0; a < e; a++)
    s += t.getUint32(s) + 4;
  const r = t.getUint32(s);
  return n.decode(new Uint8Array(p, s + 4, r));
}
var jd, Vd, eh, Mf;
class $v {
  constructor(t) {
    g(this, eh);
    g(this, jd);
    g(this, Vd);
    u(this, jd, t), u(this, Vd, new DataView(t));
  }
  get fontFamily() {
    return L(this, "fontFamily", m(this, eh, Mf).call(this, 0));
  }
  get fontWeight() {
    return L(this, "fontWeight", m(this, eh, Mf).call(this, 1));
  }
  get italicAngle() {
    return L(this, "italicAngle", m(this, eh, Mf).call(this, 2));
  }
}
jd = new WeakMap(), Vd = new WeakMap(), eh = new WeakSet(), Mf = function(t) {
  return jt(t < t0.strings.length, "Invalid string index"), Wc(i(this, jd), i(this, Vd), t);
};
var ho, Ir, co, Ic;
class jv {
  constructor(t) {
    g(this, co);
    g(this, ho);
    g(this, Ir);
    u(this, ho, t), u(this, Ir, new DataView(t));
  }
  get css() {
    return L(this, "css", m(this, co, Ic).call(this, 0));
  }
  get loadedName() {
    return L(this, "loadedName", m(this, co, Ic).call(this, 1));
  }
  get baseFontName() {
    return L(this, "baseFontName", m(this, co, Ic).call(this, 2));
  }
  get src() {
    return L(this, "src", m(this, co, Ic).call(this, 3));
  }
  get style() {
    let t = 0;
    t += 4 + i(this, Ir).getUint32(t);
    const e = Wc(i(this, ho), i(this, Ir), 0, t), s = Wc(i(this, ho), i(this, Ir), 1, t);
    return L(this, "style", {
      style: e,
      weight: s
    });
  }
}
ho = new WeakMap(), Ir = new WeakMap(), co = new WeakSet(), Ic = function(t) {
  return jt(t < e0.strings.length, "Invalid string index"), Wc(i(this, ho), i(this, Ir), t, 4);
};
var Qs, Rs, Mt, $s, bm, ym, Fc;
class Vv {
  constructor(t) {
    g(this, Mt);
    g(this, Qs);
    g(this, Rs);
    u(this, Qs, t), u(this, Rs, new DataView(t));
  }
  get black() {
    return L(this, "black", m(this, Mt, $s).call(this, 0));
  }
  get bold() {
    return L(this, "bold", m(this, Mt, $s).call(this, 1));
  }
  get disableFontFace() {
    return L(this, "disableFontFace", m(this, Mt, $s).call(this, 2));
  }
  get fontExtraProperties() {
    return L(this, "fontExtraProperties", m(this, Mt, $s).call(this, 3));
  }
  get isInvalidPDFjsFont() {
    return L(this, "isInvalidPDFjsFont", m(this, Mt, $s).call(this, 4));
  }
  get isType3Font() {
    return L(this, "isType3Font", m(this, Mt, $s).call(this, 5));
  }
  get italic() {
    return L(this, "italic", m(this, Mt, $s).call(this, 6));
  }
  get missingFile() {
    return L(this, "missingFile", m(this, Mt, $s).call(this, 7));
  }
  get remeasure() {
    return L(this, "remeasure", m(this, Mt, $s).call(this, 8));
  }
  get vertical() {
    return L(this, "vertical", m(this, Mt, $s).call(this, 9));
  }
  get bbox() {
    return L(this, "bbox", m(this, Mt, bm).call(this, Jn.OFFSET_BBOX, 4, "getInt16", 2));
  }
  get fontMatrix() {
    return L(this, "fontMatrix", m(this, Mt, bm).call(this, Jn.OFFSET_FONT_MATRIX, 6, "getFloat64", 8));
  }
  get fallbackName() {
    return L(this, "fallbackName", m(this, Mt, ym).call(this, 0));
  }
  get loadedName() {
    return L(this, "loadedName", m(this, Mt, ym).call(this, 1));
  }
  get data() {
    const {
      offset: t,
      length: e
    } = m(this, Mt, Fc).call(this, 2);
    return e ? new Uint8Array(i(this, Qs), t + 4, e) : void 0;
  }
  clearData() {
    const {
      offset: t,
      length: e
    } = m(this, Mt, Fc).call(this, 2);
    e && (i(this, Rs).setUint32(t, 0), u(this, Qs, new Uint8Array(i(this, Qs), 0, t + 4).slice().buffer), u(this, Rs, new DataView(i(this, Qs))));
  }
  get cssFontInfo() {
    const {
      offset: t,
      length: e
    } = m(this, Mt, Fc).call(this, 1);
    let s = null;
    if (e) {
      const n = new Uint8Array(i(this, Qs), t + 4, e).slice();
      s = new $v(n.buffer);
    }
    return L(this, "cssFontInfo", s);
  }
  get systemFontInfo() {
    const {
      offset: t,
      length: e
    } = m(this, Mt, Fc).call(this, 0);
    let s = null;
    if (e) {
      const n = new Uint8Array(i(this, Qs), t + 4, e).slice();
      s = new jv(n.buffer);
    }
    return L(this, "systemFontInfo", s);
  }
}
Qs = new WeakMap(), Rs = new WeakMap(), Mt = new WeakSet(), $s = function(t) {
  jt(t < Jn.bools.length, "Invalid boolean index");
  const e = Math.floor(t / 4), s = t * 2 % 8, n = i(this, Rs).getUint8(e) >> s & 3;
  return n === 0 ? void 0 : n === 2;
}, bm = function(t, e, s, n) {
  const r = i(this, Rs).getUint8(t++);
  if (r === 0)
    return;
  jt(r === e, "Invalid array length.");
  const a = new Array(r);
  for (let o = 0; o < r; o++)
    a[o] = i(this, Rs)[s](t, !0), t += n;
  return a;
}, ym = function(t) {
  return jt(t < Jn.strings.length, "Invalid string index"), Wc(i(this, Qs), i(this, Rs), t, Jn.OFFSET_STRINGS + 4);
}, Fc = function(t) {
  let e = Jn.OFFSET_STRINGS;
  for (let n = 0; n <= t; n++)
    e += 4 + i(this, Rs).getUint32(e);
  const s = i(this, Rs).getUint32(e);
  return {
    offset: e,
    length: s
  };
};
class Wv {
  constructor(t) {
    this.buffer = t, this.view = new DataView(t), this.data = new Uint8Array(t);
  }
  getIR() {
    const t = this.view, e = this.data[Ne.KIND], s = !!this.data[Ne.HAS_BBOX], n = !!this.data[Ne.HAS_BACKGROUND], r = t.getUint32(Ne.N_COORD, !0), a = t.getUint32(Ne.N_COLOR, !0), o = t.getUint32(Ne.N_STOP, !0);
    let l = 20;
    const h = new Float32Array(this.buffer, l, r * 2);
    l += r * 8;
    const c = new Uint8Array(this.buffer, l, a * 4);
    l += a * 4;
    const d = [];
    for (let y = 0; y < o; ++y) {
      const A = t.getFloat32(l, !0);
      l += 4;
      const w = t.getUint32(l, !0);
      l += 4, d.push([A, `#${w.toString(16).padStart(6, "0")}`]);
    }
    let f = null;
    if (s) {
      f = [];
      for (let y = 0; y < 4; ++y)
        f.push(t.getFloat32(l, !0)), l += 4;
    }
    let b = null;
    if (n && (b = new Uint8Array(this.buffer, l, 3), l += 3), e === 1)
      return ["RadialAxial", "axial", f, d, [h[0], h[1]], [h[2], h[3]], null, null];
    if (e === 2)
      return ["RadialAxial", "radial", f, d, [h[0], h[1]], [h[3], h[4]], h[2], h[5]];
    if (e === 3) {
      const y = this.data[Ne.SHADING_TYPE];
      let A = null;
      if (h.length > 0) {
        A = Yi.slice();
        for (let w = 0, v = h.length; w < v; w += 2)
          I.pointBoundingBox(h[w], h[w + 1], A);
      }
      return ["Mesh", y, h, c, r, A, f, b];
    }
    throw new Error(`Unsupported pattern kind: ${e}`);
  }
}
var sh;
class Xv {
  constructor(t) {
    g(this, sh);
    u(this, sh, t);
  }
  get path() {
    return ot.isFloat16ArraySupported ? new Float16Array(i(this, sh)) : new Float32Array(i(this, sh));
  }
}
sh = new WeakMap();
const pa = Symbol("INITIAL_DATA"), Eg = () => ({
  ...Promise.withResolvers(),
  data: pa
});
var is;
class Ub {
  constructor() {
    g(this, is, /* @__PURE__ */ new Map());
  }
  get(t, e = null, s = null) {
    if (e) {
      const r = i(this, is).getOrInsertComputed(t, Eg);
      return r.promise.then(() => e(r.data), s), null;
    }
    const n = i(this, is).get(t);
    if (!n || n.data === pa)
      throw new Error(`Requesting object that isn't resolved yet ${t}.`);
    return n.data;
  }
  has(t) {
    const e = i(this, is).get(t);
    return !!e && e.data !== pa;
  }
  delete(t) {
    const e = i(this, is).get(t);
    return !e || e.data === pa ? !1 : (i(this, is).delete(t), !0);
  }
  resolve(t, e = null) {
    const s = i(this, is).getOrInsertComputed(t, Eg);
    if (s.data !== pa)
      throw new Error(`Object already resolved ${t}.`);
    s.data = e, s.resolve();
  }
  reject(t, e) {
    const s = i(this, is).getOrInsertComputed(t, Eg);
    s.data === pa && (s.promise.catch(() => {
    }), s.reject(e));
  }
  clear() {
    var t;
    for (const {
      data: e
    } of i(this, is).values())
      (t = e == null ? void 0 : e.bitmap) == null || t.close();
    i(this, is).clear();
  }
  *[Symbol.iterator]() {
    for (const [t, {
      data: e
    }] of i(this, is))
      e !== pa && (yield [t, e]);
  }
}
is = new WeakMap();
class Yv {
  constructor({
    messageHandler: t,
    commonObjs: e,
    fontLoader: s,
    pageCache: n,
    pdfBug: r = !1,
    shouldCreatePageObjs: a = !1
  }) {
    this.messageHandler = t, this.commonObjs = e, this.fontLoader = s, this.pageCache = n, this.pdfBug = r, this.shouldCreatePageObjs = a;
  }
  resolveCommonObject(t, e, s) {
    var n;
    if (e === "CopyLocalImage") {
      const {
        imageRef: r
      } = s;
      jt(r, "The imageRef must be defined.");
      for (const a of this.pageCache.values()) {
        const o = a.objs || a;
        for (const [, l] of o) {
          if ((l == null ? void 0 : l.ref) !== r)
            continue;
          if (!l.dataLen)
            return null;
          const h = structuredClone(l);
          return this.commonObjs.resolve(t, h), l.dataLen;
        }
      }
      return null;
    }
    switch (e) {
      case "Font":
        if ("error" in s) {
          const h = s.error;
          j(`Error during font loading: ${h}`), this.commonObjs.resolve(t, h);
          break;
        }
        const r = new Vv(s.buffer), a = this.pdfBug && ((n = globalThis.FontInspector) != null && n.enabled) ? (h, c) => globalThis.FontInspector.fontAdded(h, c) : null, o = new Cv(r, a, s.charProcOperatorList, s.extra);
        this.fontLoader.bind(o).catch(() => this.messageHandler.sendWithPromise("FontFallback", {
          id: t
        }).catch((h) => {
          j(`FontFallback failed for "${t}": ${h}`);
        })).finally(() => {
          o.fontExtraProperties || o.clearData(), this.commonObjs.resolve(t, o);
        });
        break;
      case "FontPath":
        this.commonObjs.resolve(t, new Xv(s));
        break;
      case "Image":
        this.commonObjs.resolve(t, s);
        break;
      case "Pattern":
        const l = new Wv(s);
        this.commonObjs.resolve(t, l.getIR());
        break;
      default:
        throw new Error(`Got unknown common object type ${e}`);
    }
    return null;
  }
  resolveObject(t, e, s, n) {
    var o, l;
    let r = this.pageCache.get(e);
    if (!r) {
      if (!this.shouldCreatePageObjs)
        return !1;
      r = new Ub(), this.pageCache.set(e, r);
    }
    const a = r.objs || r;
    if (a.has(t))
      return !1;
    if (((o = r._intentStates) == null ? void 0 : o.size) === 0)
      return (l = n == null ? void 0 : n.bitmap) == null || l.close(), !1;
    switch (s) {
      case "Image":
      case "Pattern":
        return a.resolve(t, n), !0;
      default:
        throw new Error(`Got unknown object type ${s}`);
    }
  }
}
const ga = Symbol("INTERNAL");
var Wd, Xd, ih, uo;
class Kv {
  constructor(t, {
    name: e,
    intent: s,
    usage: n,
    rbGroups: r
  }) {
    g(this, Wd, !1);
    g(this, Xd, !1);
    g(this, ih, !1);
    g(this, uo, !0);
    u(this, Wd, !!(t & ms.DISPLAY)), u(this, Xd, !!(t & ms.PRINT)), this.name = e, this.intent = s, this.usage = n, this.rbGroups = r;
  }
  get visible() {
    if (i(this, ih))
      return i(this, uo);
    if (!i(this, uo))
      return !1;
    const {
      print: t,
      view: e
    } = this.usage;
    return i(this, Wd) ? (e == null ? void 0 : e.viewState) !== "OFF" : i(this, Xd) ? (t == null ? void 0 : t.printState) !== "OFF" : !0;
  }
  _setVisible(t, e, s = !1) {
    t !== ga && it("Internal method `_setVisible` called."), u(this, ih, s), u(this, uo, e);
  }
  get serializable() {
    return {
      userSet: i(this, ih),
      visible: i(this, uo)
    };
  }
}
Wd = new WeakMap(), Xd = new WeakMap(), ih = new WeakMap(), uo = new WeakMap();
var Fr, nt, nh, rh, Yd, Kd, wm;
const Jb = class Jb {
  constructor(t, e = ms.DISPLAY, s = null) {
    g(this, Kd);
    g(this, Fr, null);
    g(this, nt, /* @__PURE__ */ new Map());
    g(this, nh, null);
    g(this, rh, null);
    g(this, Yd);
    _(this, "creator", null);
    _(this, "name", null);
    if (u(this, Yd, t), this.renderingIntent = e, t !== null) {
      this.name = t.name, this.creator = t.creator, u(this, rh, t.order);
      for (const n of t.groups)
        i(this, nt).set(n.id, new Kv(e, n));
      if (s) {
        s.size !== i(this, nt).size && it("Incorrect serialized groupState.");
        for (const [n, r] of s)
          i(this, nt).get(n)._setVisible(ga, r.visible, r.userSet);
      } else {
        if (t.baseState === "OFF")
          for (const n of i(this, nt).values())
            n._setVisible(ga, !1);
        for (const n of t.on)
          i(this, nt).get(n)._setVisible(ga, !0);
        for (const n of t.off)
          i(this, nt).get(n)._setVisible(ga, !1);
      }
      u(this, nh, this.getHash());
    }
  }
  isVisible(t) {
    if (i(this, nt).size === 0)
      return !0;
    if (!t)
      return ig("Optional content group not defined."), !0;
    if (t.type === "OCG")
      return i(this, nt).has(t.id) ? i(this, nt).get(t.id).visible : (j(`Optional content group not found: ${t.id}`), !0);
    if (t.type === "OCMD") {
      if (t.expression)
        return m(this, Kd, wm).call(this, t.expression);
      if (!t.policy || t.policy === "AnyOn") {
        for (const e of t.ids) {
          if (!i(this, nt).has(e))
            return j(`Optional content group not found: ${e}`), !0;
          if (i(this, nt).get(e).visible)
            return !0;
        }
        return !1;
      } else if (t.policy === "AllOn") {
        for (const e of t.ids) {
          if (!i(this, nt).has(e))
            return j(`Optional content group not found: ${e}`), !0;
          if (!i(this, nt).get(e).visible)
            return !1;
        }
        return !0;
      } else if (t.policy === "AnyOff") {
        for (const e of t.ids) {
          if (!i(this, nt).has(e))
            return j(`Optional content group not found: ${e}`), !0;
          if (!i(this, nt).get(e).visible)
            return !0;
        }
        return !1;
      } else if (t.policy === "AllOff") {
        for (const e of t.ids) {
          if (!i(this, nt).has(e))
            return j(`Optional content group not found: ${e}`), !0;
          if (i(this, nt).get(e).visible)
            return !1;
        }
        return !0;
      }
      return j(`Unknown optional content policy ${t.policy}.`), !0;
    }
    return j(`Unknown group type ${t.type}.`), !0;
  }
  setVisibility(t, e = !0, s = !0) {
    var r;
    const n = i(this, nt).get(t);
    if (!n) {
      j(`Optional content group not found: ${t}`);
      return;
    }
    if (s && e && n.rbGroups.length)
      for (const a of n.rbGroups)
        for (const o of a)
          o !== t && ((r = i(this, nt).get(o)) == null || r._setVisible(ga, !1, !0));
    n._setVisible(ga, !!e, !0), u(this, Fr, null);
  }
  setOCGState({
    state: t,
    preserveRB: e
  }) {
    let s;
    for (const n of t) {
      switch (n) {
        case "ON":
        case "OFF":
        case "Toggle":
          s = n;
          continue;
      }
      const r = i(this, nt).get(n);
      if (r)
        switch (s) {
          case "ON":
            this.setVisibility(n, !0, e);
            break;
          case "OFF":
            this.setVisibility(n, !1, e);
            break;
          case "Toggle":
            this.setVisibility(n, !r.visible, e);
            break;
        }
    }
    u(this, Fr, null);
  }
  get hasInitialVisibility() {
    return i(this, nh) === null || this.getHash() === i(this, nh);
  }
  getOrder() {
    return i(this, nt).size ? i(this, rh) ? i(this, rh).slice() : [...i(this, nt).keys()] : null;
  }
  getGroup(t) {
    return i(this, nt).get(t) || null;
  }
  getHash() {
    if (i(this, Fr) !== null)
      return i(this, Fr);
    const t = new sm();
    for (const [e, s] of i(this, nt))
      t.update(`${e}:${s.visible}`);
    return u(this, Fr, t.hexdigest());
  }
  [Symbol.iterator]() {
    return i(this, nt).entries();
  }
  get serializable() {
    const t = /* @__PURE__ */ new Map();
    for (const [e, s] of i(this, nt))
      t.set(e, s.serializable);
    return {
      data: i(this, Yd),
      renderingIntent: this.renderingIntent,
      groupState: t
    };
  }
  static fromSerializable({
    data: t,
    renderingIntent: e,
    groupState: s
  }) {
    return new Jb(t, e, s);
  }
};
Fr = new WeakMap(), nt = new WeakMap(), nh = new WeakMap(), rh = new WeakMap(), Yd = new WeakMap(), Kd = new WeakSet(), wm = function(t) {
  const e = t.length;
  if (e < 2)
    return !0;
  const s = t[0];
  for (let n = 1; n < e; n++) {
    const r = t[n];
    let a;
    if (Array.isArray(r))
      a = m(this, Kd, wm).call(this, r);
    else if (i(this, nt).has(r))
      a = i(this, nt).get(r).visible;
    else
      return j(`Optional content group not found: ${r}`), !0;
    switch (s) {
      case "And":
        if (!a)
          return !1;
        break;
      case "Or":
        if (a)
          return !0;
        break;
      case "Not":
        return !a;
      default:
        return !0;
    }
  }
  return s === "And";
};
let Am = Jb;
var Ot, Ns, Qt, qd, fo, Fi, be, Lc, Df, vm, Sm;
class qv {
  constructor() {
    g(this, be);
    g(this, Ot, null);
    g(this, Ns, null);
    g(this, Qt, 0);
    g(this, qd, 0);
    g(this, fo, null);
    g(this, Fi, null);
  }
  get pagesNumber() {
    return i(this, Qt);
  }
  set pagesNumber(t) {
    i(this, Qt) !== t && (u(this, Qt, u(this, qd, t)), u(this, Ot, null), u(this, Ns, null));
  }
  movePages(t, e, s) {
    m(this, be, Lc).call(this);
    const n = i(this, Ot), r = e.length, a = new Uint32Array(r);
    let o = 0;
    for (let f = 0; f < r; f++) {
      const b = e[f] - 1;
      a[f] = n[b], b < s && o++;
    }
    const l = i(this, Qt), h = l - r, c = new Int32Array(l), d = vt(s - o, 0, h);
    for (let f = 0, b = 0; f < l; f++)
      t.has(f + 1) || (n[b] = n[f], c[b++] = f + 1);
    n.copyWithin(d + r, d, h), n.set(a, d), c.copyWithin(d + r, d, h), c.set(e, d), u(this, Ns, c), l === i(this, qd) && n.every((f, b) => f === b + 1) && u(this, Ot, null);
  }
  deletePages(t) {
    m(this, be, Lc).call(this);
    const e = i(this, Ot), s = m(this, be, Df).call(this);
    u(this, Fi, {
      pageNumberToId: e.slice(),
      pagesNumber: i(this, Qt),
      prevPageNumbers: i(this, Ns).slice()
    });
    const n = i(this, Qt) - t.length;
    u(this, Qt, n);
    const r = u(this, Ot, new Uint32Array(n));
    u(this, Ns, new Int32Array(n));
    let a = 0, o = 0;
    for (const l of t) {
      const h = l - 1;
      h !== a && (r.set(e.subarray(a, h), o), o += h - a), a = h + 1;
    }
    a < e.length && r.set(e.subarray(a), o), m(this, be, vm).call(this, s, new Set(t));
  }
  cancelDelete() {
    i(this, Fi) && (u(this, Ot, i(this, Fi).pageNumberToId), u(this, Qt, i(this, Fi).pagesNumber), u(this, Ns, i(this, Fi).prevPageNumbers), u(this, Fi, null));
  }
  cleanSavedData() {
    u(this, Fi, null);
  }
  copyPages(t) {
    m(this, be, Lc).call(this), u(this, fo, {
      pageNumbers: t,
      pageIds: t.map((e) => i(this, Ot)[e - 1])
    });
  }
  cancelCopy() {
    u(this, fo, null);
  }
  pastePages(t) {
    m(this, be, Lc).call(this);
    const e = i(this, Ot), s = m(this, be, Df).call(this), {
      pageNumbers: n,
      pageIds: r
    } = i(this, fo), a = i(this, Qt) + n.length;
    u(this, Qt, a);
    const o = u(this, Ot, new Uint32Array(a));
    u(this, Ns, new Int32Array(a)), o.set(e.subarray(0, t), 0), o.set(r, t), o.set(e.subarray(t), t + n.length), m(this, be, vm).call(this, s, null, t, n), u(this, fo, null);
  }
  hasBeenAltered() {
    return i(this, Ot) !== null;
  }
  getPageMappingForSaving(t = null, e = m(this, be, Sm).call(this)) {
    t ?? (t = m(this, be, Df).call(this));
    let s = 0;
    for (const r of t.values())
      s = Math.max(s, r.length);
    const n = new Array(s);
    for (let r = 0; r < s; r++)
      n[r] = {
        document: null,
        pageIndices: [],
        includePages: []
      };
    for (const [r, a] of t)
      for (let o = 0, l = a.length; o < l; o++)
        n[o].includePages.push([r - 1, a[o] - 1]);
    for (const {
      includePages: r,
      pageIndices: a
    } of n) {
      r.sort((o, l) => o[0] - l[0]);
      for (let o = 0, l = r.length; o < l; o++)
        a.push(r[o][1]), r[o] = r[o][0];
    }
    return {
      pageInfos: n,
      copyLevels: e
    };
  }
  extractPages(t) {
    t = Array.from(t).sort((s, n) => s - n);
    const e = /* @__PURE__ */ new Map();
    for (let s = 0, n = t.length; s < n; s++) {
      const r = this.getPageId(t[s]);
      e.getOrInsertComputed(r, gc).push(s + 1);
    }
    return this.getPageMappingForSaving(e, m(this, be, Sm).call(this, t));
  }
  getPrevPageNumber(t) {
    var e;
    return ((e = i(this, Ns)) == null ? void 0 : e[t - 1]) ?? 0;
  }
  getPageNumber(t) {
    if (!i(this, Ot))
      return t;
    const e = i(this, Ot);
    for (let s = 0, n = i(this, Qt); s < n; s++)
      if (e[s] === t)
        return s + 1;
    return 0;
  }
  getPageId(t) {
    var e;
    return ((e = i(this, Ot)) == null ? void 0 : e[t - 1]) ?? t;
  }
  getMapping() {
    var t;
    return (t = i(this, Ot)) == null ? void 0 : t.subarray(0, this.pagesNumber);
  }
}
Ot = new WeakMap(), Ns = new WeakMap(), Qt = new WeakMap(), qd = new WeakMap(), fo = new WeakMap(), Fi = new WeakMap(), be = new WeakSet(), Lc = function() {
  if (i(this, Ot))
    return;
  const t = i(this, Qt), e = u(this, Ot, new Uint32Array(t));
  for (let s = 0; s < t; s++)
    e[s] = s + 1;
  u(this, Ns, new Int32Array(e));
}, Df = function() {
  const t = /* @__PURE__ */ new Map(), e = i(this, Ot);
  for (let s = 0, n = i(this, Qt); s < n; s++) {
    const r = e[s], a = t.get(r);
    a ? a.push(s + 1) : t.set(r, [s + 1]);
  }
  return t;
}, vm = function(t, e = null, s = -1, n = null) {
  const r = i(this, Ns), a = i(this, Ot), o = s + ((n == null ? void 0 : n.length) ?? 0), l = /* @__PURE__ */ new Map();
  for (let h = 0, c = i(this, Qt); h < c; h++) {
    if (h >= s && h < o) {
      r[h] = -n[h - s];
      continue;
    }
    const d = a[h], f = t.get(d);
    let b = l.get(d) || 0;
    if (e && f)
      for (; b < f.length && e.has(f[b]); )
        b++;
    r[h] = f == null ? void 0 : f[b], l.set(d, b + 1);
  }
}, Sm = function(t = null) {
  if (!i(this, Ot))
    return null;
  const e = new Int32Array(i(this, Qt)).fill(-1), s = /* @__PURE__ */ new Map();
  if (t)
    for (const n of t) {
      const r = this.getPageId(n), a = s.get(r) ?? 0;
      s.set(r, a + 1), e[n - 1] = a;
    }
  else
    for (let n = 0, r = i(this, Qt); n < r; n++) {
      const a = i(this, Ot)[n], o = s.get(a) ?? 0;
      s.set(a, o + 1), e[n] = o;
    }
  return e;
};
const Ty = 5e3;
function Em({
  bitmap: p,
  annotationBitmaps: t
}) {
  if (p == null || p.close(), t)
    for (const [, , e] of t)
      e.close();
}
var Qd, En, po, ah, oh, Cn, lh, Jd, Zd, tu, Li, go, Ip, s0;
class Qv {
  constructor({
    rendererWorker: t,
    renderTasks: e,
    canvas: s,
    canvasFactory: n,
    annotationCanvasMap: r,
    operatorListState: a,
    initParams: o,
    onFrame: l,
    onError: h
  }) {
    g(this, Ip);
    g(this, Qd);
    g(this, En, !1);
    g(this, po);
    g(this, ah);
    g(this, oh, 0);
    g(this, Cn);
    g(this, lh);
    g(this, Jd);
    g(this, Zd);
    g(this, tu);
    g(this, Li);
    g(this, go);
    _(this, "imageCoordinates", null);
    _(this, "recordedBBoxes", null);
    u(this, Li, t), u(this, go, e), u(this, po, s), u(this, ah, n), u(this, Qd, r), u(this, tu, a), u(this, lh, o), u(this, Cn, o.renderTaskId), u(this, Zd, l), u(this, Jd, h);
  }
  async initialize(t, e) {
    try {
      await i(this, Li).promise;
    } catch {
      return !1;
    }
    if (!i(this, Li).messageHandler || i(this, En))
      return !1;
    try {
      await i(this, Li).sendWithPromise("InitializeGraphics", {
        ...i(this, lh),
        width: i(this, po).width,
        height: i(this, po).height,
        transparency: t,
        optionalContentConfig: e.serializable
      });
    } catch (s) {
      return i(this, En) || j(`Failed to initialize graphics in renderer worker: ${s.message}. Falling back to main-thread rendering.`), !1;
    }
    return i(this, En) || i(this, go).set(i(this, Cn), this), !0;
  }
  async executeOperatorList(t, e, s) {
    const n = i(this, Li).messageHandler;
    if (!n)
      throw new Error("Renderer worker was destroyed during rendering.");
    const {
      lastChunk: r
    } = t, a = t.argsArray.length, o = i(this, tu);
    if (o.sentLength < a) {
      const c = o.sentLength;
      n.send("AppendOperatorList", {
        pageProxyId: i(this, lh).pageProxyId,
        operatorListId: o.id,
        fnArray: t.fnArray.slice(c, a),
        argsArray: t.argsArray.slice(c, a)
      }), o.sentLength = a;
    }
    let l = null;
    if (s && i(this, oh) < a) {
      const c = i(this, oh);
      l = new Uint8Array(a - c);
      for (let d = c; d < a; d++)
        l[d - c] = s(d, t) ? 1 : 0;
      u(this, oh, a);
    }
    const h = await i(this, Li).sendWithPromise("ExecuteOperatorList", {
      renderTaskId: i(this, Cn),
      operatorListIdx: e,
      operatorListLength: a,
      operationsFilterMask: l,
      lastChunk: r
    }).catch((c) => {
      if (!i(this, En))
        throw c;
      return {
        operatorListIdx: e,
        aborted: !0
      };
    });
    if (h.aborted && !i(this, En))
      throw new Error("Render task was aborted in the renderer worker.");
    if (r && h.operatorListIdx === a) {
      i(this, go).delete(i(this, Cn));
      const {
        recordedBBoxesBuffer: c,
        imageCoordinates: d
      } = h;
      c && (this.recordedBBoxes = cp.fromBuffer(c)), this.imageCoordinates = d ?? null;
    }
    return h.operatorListIdx;
  }
  cancel() {
    var t;
    u(this, En, !0), i(this, go).delete(i(this, Cn)), (t = i(this, Li).messageHandler) == null || t.send("CleanupRenderTask", {
      renderTaskId: i(this, Cn)
    });
  }
  drawFrame(t) {
    try {
      t.bitmap && i(this, ah).getNoAlphaContext(i(this, po)).drawImage(t.bitmap, 0, 0), t.annotationBitmaps && m(this, Ip, s0).call(this, t.annotationBitmaps);
    } catch (e) {
      i(this, Jd).call(this, e);
      return;
    } finally {
      Em(t);
    }
    i(this, Zd).call(this);
  }
}
Qd = new WeakMap(), En = new WeakMap(), po = new WeakMap(), ah = new WeakMap(), oh = new WeakMap(), Cn = new WeakMap(), lh = new WeakMap(), Jd = new WeakMap(), Zd = new WeakMap(), tu = new WeakMap(), Li = new WeakMap(), go = new WeakMap(), Ip = new WeakSet(), s0 = function(t) {
  const e = i(this, Qd), s = /* @__PURE__ */ new Set();
  for (const [n, r, a] of t) {
    const {
      canvas: o,
      context: l
    } = i(this, ah).create(a.width, a.height);
    if (l.drawImage(a, 0, 0), !r) {
      e.set(n, o);
      continue;
    }
    DA(o, r), s.has(n) ? e.get(n).push(o) : (s.add(n), e.set(n, [o]));
  }
};
var hh, eu, su, Ee, Fp, Lp, Js, mo, Oi, iu, Op, nu, bo, ch, dh, Rp, uh, Tt, i0, Cm, n0, r0, xm, a0, Oc, If;
const Zn = class Zn {
  constructor({
    port: t = null,
    verbosity: e = Fy(),
    enableHWA: s = !1,
    enableWebGPU: n = !1
  } = {}) {
    g(this, Tt);
    g(this, hh, Promise.withResolvers());
    g(this, eu);
    g(this, su);
    g(this, Ee, null);
    g(this, Fp, 0);
    g(this, Lp, /* @__PURE__ */ new WeakMap());
    g(this, Js, []);
    g(this, mo, /* @__PURE__ */ new Set());
    g(this, Oi, null);
    g(this, iu, null);
    g(this, Op, 0);
    g(this, nu, /* @__PURE__ */ new Map());
    g(this, bo, null);
    g(this, ch, null);
    g(this, dh, null);
    _(this, "destroyed", !1);
    this.verbosity = e, u(this, eu, s), u(this, su, n), t ? m(this, Tt, n0).call(this, t) : m(this, Tt, r0).call(this);
  }
  static get isAvailable() {
    var t;
    return (!!Te.rendererSrc || Te.rendererPorts.length > 0) && typeof Worker < "u" && ot.isOffscreenCanvasSupported && !!((t = globalThis.document) != null && t.fonts);
  }
  get promise() {
    return i(this, hh).promise;
  }
  get messageHandler() {
    return i(this, Ee);
  }
  get port() {
    return i(this, Oi);
  }
  destroy() {
    var t, e, s, n;
    this.destroyed = !0, i(this, Oi) && (i(this, Ee) && (m(this, Tt, a0).call(this, i(this, Oi)), i(this, Ee).send("Disconnect", null)), i(Zn, uh).delete(i(this, Oi)), u(this, Oi, null)), (t = i(this, bo)) == null || t.call(this, "Worker was destroyed."), (e = i(this, dh)) == null || e.abort(), u(this, dh, null), (s = i(this, ch)) == null || s.terminate(), u(this, ch, null), (n = i(this, Ee)) == null || n.destroy(), u(this, Ee, null);
    for (const r of i(this, mo))
      r(new Error("Renderer worker was destroyed."));
    i(this, mo).clear();
  }
  static create({
    ports: t = [],
    ...e
  } = {}) {
    const s = t.find((n) => !i(this, uh).has(n)) ?? null;
    return !s && t.length > 0 && j("RendererWorker.create - no unused `rendererPorts` available, falling back to `rendererSrc`."), new Zn({
      ...e,
      port: s
    });
  }
  sendWithPromise(t, e) {
    const s = i(this, Ee);
    if (!s)
      return Promise.reject(new Error("Renderer worker was destroyed."));
    const {
      promise: n,
      resolve: r,
      reject: a
    } = Promise.withResolvers();
    return i(this, mo).add(a), s.sendWithPromise(t, e).then(r, a), n.finally(() => {
      i(this, mo).delete(a);
    });
  }
  sendCommonObj(t, e, s) {
    m(this, Tt, If).call(this, "commonobj", [t, e, s], t, null, e === "Font");
  }
  sendObj(t, e, s, n) {
    m(this, Tt, If).call(this, "obj", [t, e, s, n], t, e);
  }
  cleanup(t) {
    m(this, Tt, Oc).call(this, "Cleanup", {
      keepLoadedFonts: t
    });
  }
  cleanupPage(t) {
    m(this, Tt, Oc).call(this, "cleanupPage", {
      pageProxyId: t
    });
  }
  createRenderTask({
    pageProxyId: t,
    operatorList: e,
    params: s,
    pageColors: n,
    canvasFactory: r,
    annotationCanvasMap: a,
    onFrame: o,
    onError: l
  }) {
    const {
      canvas: h,
      canvasContext: c,
      background: d
    } = s;
    if (!i(this, Ee) && !i(this, Js) || c || d && typeof d != "string" || n || s.recordForDebugger)
      return null;
    const f = i(this, Lp).getOrInsertComputed(e, () => ({
      id: rt(this, Fp)._++,
      sentLength: 0
    }));
    return new Qv({
      rendererWorker: this,
      renderTasks: i(this, nu),
      canvas: h,
      canvasFactory: r,
      annotationCanvasMap: a,
      operatorListState: f,
      initParams: {
        pageProxyId: t,
        operatorListId: f.id,
        renderTaskId: rt(this, Op)._++,
        hasAnnotationCanvasMap: !!a,
        recordOperations: s.recordOperations,
        recordImages: s.recordImages,
        partialFrames: s.partialFrames,
        transform: s.transform,
        viewport: s.viewport,
        background: d,
        pixelRatio: ws.pixelRatio
      },
      onFrame: o,
      onError: l
    });
  }
};
hh = new WeakMap(), eu = new WeakMap(), su = new WeakMap(), Ee = new WeakMap(), Fp = new WeakMap(), Lp = new WeakMap(), Js = new WeakMap(), mo = new WeakMap(), Oi = new WeakMap(), iu = new WeakMap(), Op = new WeakMap(), nu = new WeakMap(), bo = new WeakMap(), ch = new WeakMap(), dh = new WeakMap(), Rp = new WeakMap(), uh = new WeakMap(), Tt = new WeakSet(), i0 = function() {
  i(this, Ee).on("RenderFrame", (e) => {
    const s = i(this, nu).get(e.renderTaskId);
    s ? s.drawFrame(e) : Em(e);
  }), i(this, hh).resolve(), i(this, Ee).send("configure", {
    verbosity: this.verbosity,
    enableHWA: i(this, eu),
    enableWebGPU: i(this, su)
  });
  const t = i(this, Js);
  u(this, Js, null);
  for (const e of t)
    e();
}, Cm = function(t) {
  u(this, Js, null), i(this, hh).reject(t);
}, n0 = function(t) {
  i(Zn, uh).add(t), u(this, Oi, t);
  const e = rt(Zn, Rp)._++, s = `main${e}`, n = `renderer${e}`;
  u(this, iu, {
    sourceName: s,
    targetName: n
  });
  const r = new aa("main", "renderer", t);
  r.send("Connect", {
    sourceName: n,
    targetName: s
  }), r.destroy(), m(this, Tt, xm).call(this, t, new aa(s, n, t), !0);
}, r0 = function() {
  try {
    const {
      rendererSrc: t
    } = Te;
    if (!t)
      throw new Error('No "GlobalWorkerOptions.rendererSrc" specified.');
    const e = new Worker(wA(t), {
      type: "module"
    });
    m(this, Tt, xm).call(this, e, new aa("main", "renderer", e), !1);
  } catch (t) {
    m(this, Tt, Cm).call(this, t);
  }
}, xm = function(t, e, s) {
  let n = null;
  const r = (l) => {
    u(this, bo, null), clearTimeout(n), a.abort(), e.destroy(), s ? u(this, Oi, null) : t.terminate(), m(this, Tt, Cm).call(this, new Error(`Renderer worker failed to initialize: "${(l == null ? void 0 : l.message) ?? l}".`));
  };
  u(this, bo, r);
  const a = new AbortController(), o = (l, h) => {
    if (!i(this, Ee)) {
      r(h);
      return;
    }
    l.preventDefault(), j(`Renderer worker failed: "${h}". Falling back to main-thread rendering.`), this.destroy();
  };
  t.addEventListener("error", (l) => {
    var h;
    return o(l, ((h = l.error) == null ? void 0 : h.message) ?? l.message);
  }, {
    signal: a.signal
  }), t.addEventListener("messageerror", (l) => o(l, "Cannot deserialize a message."), {
    signal: a.signal
  }), s && (n = setTimeout(() => r("Connection timed out."), Ty)), e.on("ready", (l) => {
    if (!((l == null ? void 0 : l.testObj) instanceof Uint8Array)) {
      r("TypedArray transfer test failed.");
      return;
    }
    const h = "6.5.438";
    if (h !== l.workerVersion) {
      r(`The API version "${h}" does not match the Worker version "${l.workerVersion}".`);
      return;
    }
    u(this, bo, null), clearTimeout(n), u(this, Ee, e), s || u(this, ch, t), u(this, dh, a), m(this, Tt, i0).call(this);
  });
}, a0 = function(t) {
  const {
    sourceName: e,
    targetName: s
  } = i(this, iu), n = new AbortController(), r = setTimeout(() => n.abort(), Ty);
  t.addEventListener("message", ({
    data: a
  }) => {
    (a == null ? void 0 : a.targetName) !== e || a.sourceName !== s || (a.action === "RenderFrame" ? Em(a.data) : a.action === "Disconnected" && (clearTimeout(r), n.abort()));
  }, {
    signal: n.signal
  });
}, Oc = function(t, e) {
  var s;
  if (i(this, Js)) {
    i(this, Js).push(() => m(this, Tt, Oc).call(this, t, e));
    return;
  }
  (s = i(this, Ee)) == null || s.send(t, e);
}, If = function(t, e, s, n, r = !1) {
  var a;
  try {
    if (i(this, Js)) {
      const o = r ? structuredClone(e) : e;
      i(this, Js).push(() => m(this, Tt, If).call(this, t, o, s, n));
      return;
    }
    (a = i(this, Ee)) == null || a.send(t, e);
  } catch (o) {
    j(`RendererWorker - failed to send "${t}": ${o}`), m(this, Tt, Oc).call(this, "objFailed", {
      id: s,
      pageProxyId: n,
      reason: o.message
    });
  }
}, g(Zn, Rp, 0), g(Zn, uh, /* @__PURE__ */ new WeakSet());
let dp = Zn;
const Jv = 1e5, Zv = 30;
var Dy, Lr, Ie, ru, au, fh, ph, xn, ou, lu, gh, yo, hu, mh, Ao, bh, cu, yh, Ah, du, wh, wo, uu, vh, Sh, ha, o0, l0, h0, Qe, Tm, c0, _m, d0, u0;
const he = class he {
  constructor({
    textContentSource: t,
    images: e,
    container: s,
    viewport: n
  }) {
    g(this, ha);
    g(this, Lr, Promise.withResolvers());
    g(this, Ie, null);
    g(this, ru, !1);
    g(this, au, !!((Dy = globalThis.FontInspector) != null && Dy.enabled));
    g(this, fh, null);
    g(this, ph, null);
    g(this, xn, null);
    g(this, ou, 0);
    g(this, lu, 0);
    g(this, gh, ws.pixelRatio);
    g(this, yo, null);
    g(this, hu, null);
    g(this, mh, 0);
    g(this, Ao, 0);
    g(this, bh, /* @__PURE__ */ Object.create(null));
    g(this, cu, []);
    g(this, yh, null);
    g(this, Ah, []);
    g(this, du, null);
    var h;
    if (t instanceof ReadableStream)
      u(this, yh, t);
    else if (typeof t == "object")
      u(this, yh, new ReadableStream({
        start(c) {
          c.enqueue(t), c.close();
        }
      }));
    else
      throw new Error('No "textContentSource" parameter specified.');
    u(this, Ie, u(this, hu, s)), u(this, fh, e), u(this, Ao, n.scale * i(this, gh)), u(this, mh, n.rotation), u(this, xn, {
      div: null,
      properties: null,
      ctx: null
    });
    const {
      pageWidth: r,
      pageHeight: a,
      pageX: o,
      pageY: l
    } = n.rawDims;
    u(this, du, [1, 0, 0, -1, -o, l + a]), u(this, lu, r), u(this, ou, a), m(h = he, Qe, d0).call(h), s.style.setProperty("--min-font-size", i(he, vh)), nl(s, n), i(this, Lr).promise.finally(() => {
      i(he, Sh).delete(this), u(this, xn, null), u(this, bh, null);
    }).catch(() => {
    });
  }
  static get fontFamilyMap() {
    const {
      isWindows: t,
      isFirefox: e
    } = ot.platform;
    return L(this, "fontFamilyMap", /* @__PURE__ */ new Map([["sans-serif", `${t && e ? "Calibri, " : ""}sans-serif`], ["monospace", `${t && e ? "Lucida Console, " : ""}monospace`]]));
  }
  render() {
    i(this, fh) && i(this, Ie).append(i(this, fh).render());
    const t = () => {
      i(this, yo).read().then(({
        value: e,
        done: s
      }) => {
        if (s) {
          i(this, Lr).resolve();
          return;
        }
        i(this, ph) ?? u(this, ph, e.lang), Object.assign(i(this, bh), e.styles), m(this, ha, o0).call(this, e.items), t();
      }, i(this, Lr).reject);
    };
    return u(this, yo, i(this, yh).getReader()), i(he, Sh).add(this), t(), i(this, Lr).promise;
  }
  update({
    viewport: t
  }) {
    const e = t.scale * ws.pixelRatio, s = t.rotation;
    s !== i(this, mh) && (u(this, mh, s), nl(i(this, hu), {
      rotation: s
    })), e !== i(this, Ao) && (u(this, Ao, e), u(this, gh, ws.pixelRatio));
  }
  cancel() {
    var e;
    const t = new oa("TextLayer task cancelled.");
    (e = i(this, yo)) == null || e.cancel(t).catch(() => {
    }), u(this, yo, null), i(this, Lr).reject(t);
  }
  get textDivs() {
    return i(this, Ah);
  }
  get textContentItemsStr() {
    return i(this, cu);
  }
  static cleanup() {
    if (!(i(this, Sh).size > 0)) {
      i(this, wh).clear();
      for (const {
        canvas: t
      } of i(this, wo).values())
        t.remove();
      i(this, wo).clear();
    }
  }
};
Lr = new WeakMap(), Ie = new WeakMap(), ru = new WeakMap(), au = new WeakMap(), fh = new WeakMap(), ph = new WeakMap(), xn = new WeakMap(), ou = new WeakMap(), lu = new WeakMap(), gh = new WeakMap(), yo = new WeakMap(), hu = new WeakMap(), mh = new WeakMap(), Ao = new WeakMap(), bh = new WeakMap(), cu = new WeakMap(), yh = new WeakMap(), Ah = new WeakMap(), du = new WeakMap(), wh = new WeakMap(), wo = new WeakMap(), uu = new WeakMap(), vh = new WeakMap(), Sh = new WeakMap(), ha = new WeakSet(), o0 = function(t) {
  var n, r;
  if (i(this, ru))
    return;
  (r = i(this, xn)).ctx ?? (r.ctx = m(n = he, Qe, Tm).call(n, i(this, ph)));
  const e = i(this, Ah), s = i(this, cu);
  for (const a of t) {
    if (e.length > Jv) {
      j("Ignoring additional textDivs for performance reasons."), u(this, ru, !0);
      return;
    }
    if (a.str === void 0) {
      if (a.type === "beginMarkedContentProps" || a.type === "beginMarkedContent") {
        const o = i(this, Ie);
        u(this, Ie, document.createElement("span")), i(this, Ie).classList.add("markedContent"), a.id && i(this, Ie).setAttribute("id", a.id), a.tag === "Artifact" && (i(this, Ie).ariaHidden = !0), o.append(i(this, Ie));
      } else a.type === "endMarkedContent" && u(this, Ie, i(this, Ie).parentNode);
      continue;
    }
    s.push(a.str), m(this, ha, l0).call(this, a);
  }
}, l0 = function(t) {
  var A;
  const e = document.createElement("span"), s = {
    angle: 0,
    canvasWidth: 0,
    hasText: t.str !== "",
    hasEOL: t.hasEOL,
    fontSize: 0
  };
  i(this, Ah).push(e);
  const n = I.transform(i(this, du), t.transform);
  let r = Math.atan2(n[1], n[0]);
  const a = i(this, bh)[t.fontName];
  a.vertical && (r += Math.PI / 2);
  let o = i(this, au) && a.fontSubstitution || a.fontFamily;
  o = he.fontFamilyMap.get(o) || o;
  const l = Math.hypot(n[2], n[3]), h = l * m(A = he, Qe, u0).call(A, o, a, i(this, ph));
  let c, d;
  r === 0 ? (c = n[4], d = n[5] - h) : (c = n[4] + h * Math.sin(r), d = n[5] - h * Math.cos(r));
  const f = e.style;
  f.left = `${(100 * c / i(this, lu)).toFixed(2)}%`, f.top = `${(100 * d / i(this, ou)).toFixed(2)}%`;
  const b = Math.round(l * 100) / 100;
  f.setProperty("--font-height", `${b}px`), f.fontFamily = o, s.fontSize = b, e.setAttribute("role", "presentation"), e.textContent = t.str, e.dir = t.dir, i(this, au) && (e.dataset.fontName = a.fontSubstitutionLoadedName || t.fontName), r !== 0 && (s.angle = r * (180 / Math.PI));
  let y = !1;
  if (t.str.length > 1)
    y = !0;
  else if (t.str !== " " && t.transform[0] !== t.transform[3]) {
    const w = Math.abs(t.transform[0]), v = Math.abs(t.transform[3]);
    w !== v && Math.max(w, v) / Math.min(w, v) > 1.5 && (y = !0);
  }
  if (y && (s.canvasWidth = a.vertical ? t.height : t.width), i(this, xn).div = e, i(this, xn).properties = s, m(this, ha, h0).call(this, i(this, xn)), s.hasText && i(this, Ie).append(e), s.hasEOL) {
    const w = document.createElement("br");
    w.setAttribute("role", "presentation"), i(this, Ie).append(w);
  }
}, h0 = function(t) {
  var l, h;
  const {
    div: e,
    properties: s,
    ctx: n
  } = t, {
    style: r
  } = e, {
    canvasWidth: a,
    fontSize: o
  } = s;
  if (a !== 0 && o !== 0 && s.hasText) {
    const {
      fontFamily: c
    } = r, d = i(this, gh), f = m(l = he, Qe, c0).call(l, o * i(this, Ao) / d) * d;
    m(h = he, Qe, _m).call(h, n, f, c);
    const {
      width: b
    } = n.measureText(e.textContent);
    b > 0 && r.setProperty("--scale-x", a * f / (b * o));
  }
  s.angle !== 0 && r.setProperty("--rotate", `${s.angle}deg`);
}, Qe = new WeakSet(), Tm = function(t = null) {
  let e = i(this, wo).get(t || (t = ""));
  if (!e) {
    const s = document.createElement("canvas");
    s.style.cssText = "position:absolute;top:0;left:0;width:0;height:0;display:none;letter-spacing:normal;word-spacing:normal", s.lang = t, document.body.append(s), e = s.getContext("2d", {
      alpha: !1,
      willReadFrequently: !0
    }), i(this, wo).set(t, e), i(this, uu).set(e, {
      size: 0,
      family: ""
    });
  }
  return e;
}, c0 = function(t) {
  t = Math.fround(t);
  const e = Math.fround(t * ((1 << 17) + 1));
  return Math.fround(e - Math.fround(e - t));
}, _m = function(t, e, s) {
  const n = i(this, uu).get(t);
  e === n.size && s === n.family || (t.font = `${e}px ${s}`, n.size = e, n.family = s);
}, d0 = function() {
  if (i(this, vh) !== null)
    return;
  const t = document.createElement("div");
  t.style.opacity = 0, t.style.lineHeight = 1, t.style.fontSize = "1px", t.style.position = "absolute", t.textContent = "X", document.body.append(t), u(this, vh, t.getBoundingClientRect().height), t.remove();
}, u0 = function(t, e, s) {
  const n = i(this, wh).get(t);
  if (n)
    return n;
  const r = m(this, Qe, Tm).call(this, s);
  m(this, Qe, _m).call(this, r, Zv, t);
  const a = r.measureText(""), o = a.fontBoundingBoxAscent, l = Math.abs(a.fontBoundingBoxDescent);
  let h = 0.8;
  return o ? h = o / (o + l) : (ot.platform.isFirefox && j("Enable the `dom.textMetrics.fontBoundingBox.enabled` preference in `about:config` to improve TextLayer rendering."), e.ascent ? h = e.ascent : e.descent && (h = 1 + e.descent)), i(this, wh).set(t, h), h;
}, g(he, Qe), g(he, wh, /* @__PURE__ */ new Map()), g(he, wo, /* @__PURE__ */ new Map()), g(he, uu, /* @__PURE__ */ new WeakMap()), g(he, vh, null), g(he, Sh, /* @__PURE__ */ new Set());
let Zc = he;
const tS = 100;
function f0(p = {}) {
  const t = new km(), {
    docId: e
  } = t, s = p.url ? Gw(p.url) : null, n = p.data ? $w(p.data) : null, r = p.httpHeaders || null, a = p.withCredentials === !0, o = p.password ?? null, l = p.range instanceof p0 ? p.range : null, h = Number.isInteger(p.rangeChunkSize) && p.rangeChunkSize > 0 ? p.rangeChunkSize : 2 ** 16;
  let c = p.worker instanceof td ? p.worker : null;
  const d = p.verbosity, f = typeof p.docBaseUrl == "string" && !rg(p.docBaseUrl) ? p.docBaseUrl : null, b = hf(p.cMapUrl), y = p.cMapPacked !== !1, A = hf(p.iccUrl), w = hf(p.standardFontDataUrl), v = hf(p.wasmUrl), S = p.stopAtErrors !== !0, E = Number.isInteger(p.maxImageSize) && p.maxImageSize > -1 ? p.maxImageSize : -1, C = typeof p.isOffscreenCanvasSupported == "boolean" ? p.isOffscreenCanvasSupported : !bs, x = typeof p.isImageDecoderSupported == "boolean" ? p.isImageDecoderSupported : !bs, T = Number.isInteger(p.canvasMaxAreaInBytes) ? p.canvasMaxAreaInBytes : -1, k = typeof p.disableFontFace == "boolean" ? p.disableFontFace : bs, M = p.fontExtraProperties === !0, P = p.enableXfa === !0, D = p.ownerDocument || globalThis.document, H = p.disableRange === !0, Y = p.disableStream === !0, Q = p.disableAutoFetch === !0, K = p.pdfBug === !0, et = p.CanvasFactory || (bs ? tv : wv), O = p.FilterFactory || (bs ? Zw : vv), z = p.BinaryDataFactory || (bs ? ev : cy), Nt = p.enableHWA === !0, St = p.enableWebGPU === !0;
  St && SA();
  const Ss = p.useWasm !== !1, ke = p.pagesMapper || new qv(), Bt = null, Et = typeof p.useSystemFonts == "boolean" ? p.useSystemFonts : !bs && !k, ui = typeof p.useWorkerFetch == "boolean" ? p.useWorkerFetch : !!(z === cy && b && y && w && v && jc(b, document.baseURI) && jc(w, document.baseURI) && jc(v, document.baseURI)), Ji = p.disableWorkerRendering === !0 || !C || D !== globalThis.document || !1 || !dp.isAvailable;
  ww(d);
  const Es = {
    canvasFactory: new et({
      ownerDocument: D,
      enableHWA: Nt
    }),
    filterFactory: new O({
      docId: e,
      ownerDocument: D
    }),
    binaryDataFactory: ui ? null : new z({
      cMapUrl: b,
      standardFontDataUrl: w,
      wasmUrl: v
    })
  };
  if (c || (c = td.create({
    verbosity: d,
    port: Te.workerPort
  }), t._worker = c), !Ji) {
    const fi = dp.create({
      verbosity: d,
      enableHWA: Nt,
      enableWebGPU: St,
      ports: Te.rendererPorts
    });
    fi.promise.catch((ca) => {
      fi.destroyed || (j(`Renderer worker disabled: ${ca.message}`), fi.destroy());
    }), t._rendererWorker = fi;
  }
  const Vt = {
    docId: e,
    apiVersion: "6.5.438",
    data: n,
    password: o,
    disableAutoFetch: Q,
    rangeChunkSize: h,
    docBaseUrl: f,
    enableXfa: P,
    evaluatorOptions: {
      maxImageSize: E,
      disableFontFace: k,
      ignoreErrors: S,
      isOffscreenCanvasSupported: C,
      isImageDecoderSupported: x,
      canvasMaxAreaInBytes: T,
      fontExtraProperties: M,
      useSystemFonts: Et,
      useWasm: Ss,
      useWorkerFetch: ui,
      cMapUrl: b,
      cMapPacked: y,
      iccUrl: A,
      standardFontDataUrl: w,
      wasmUrl: v
    }
  }, Cs = {
    ownerDocument: D,
    pdfBug: K,
    styleElement: Bt,
    rendererWorker: t._rendererWorker,
    enableWebGPU: St,
    loadingParams: {
      disableAutoFetch: Q,
      enableXfa: P
    }
  };
  return c.promise.then(function() {
    if (c.destroyed)
      throw new Error("Worker was destroyed");
    const fi = c.messageHandler.sendWithPromise("GetDocRequest", Vt, n ? [n.buffer] : null);
    let ca;
    if (!n) if (l)
      ca = new Mv({
        pdfDataRangeTransport: l,
        disableRange: H,
        disableStream: Y
      });
    else if (s) {
      const dl = Uv(s);
      ca = new dl({
        url: s,
        httpHeaders: r,
        withCredentials: a,
        rangeChunkSize: h,
        disableRange: H,
        disableStream: Y
      });
    } else
      throw new Error("getDocument - expected either `data`, `range`, or `url` parameter.");
    return fi.then((dl) => {
      if (c.destroyed)
        throw new Error("Worker was destroyed");
      const bc = new aa(e, dl, c.port), gg = new sS(bc, t, ca, Cs, Es, ke);
      if (t._transport = gg, t.destroyed)
        throw new Error("Loading aborted");
      bc.send("Ready", null);
    });
  }).catch(t._capability.reject).finally(t._setupCapability.resolve), t;
}
var Np;
const Bp = class Bp {
  constructor() {
    _(this, "_capability", Promise.withResolvers());
    _(this, "_setupCapability", Promise.withResolvers());
    _(this, "_transport", null);
    _(this, "_worker", null);
    _(this, "_rendererWorker", null);
    _(this, "docId", `d${rt(Bp, Np)._++}`);
    _(this, "destroyed", !1);
    _(this, "onPassword", null);
    _(this, "onProgress", null);
  }
  get promise() {
    return this._capability.promise;
  }
  async destroy() {
    var t, e, s, n, r;
    this.destroyed = !0, this._capability.promise.catch(() => {
    });
    try {
      (t = this._worker) != null && t.port && (this._worker._pendingDestroy = !0), await this._setupCapability.promise, await ((e = this._transport) == null ? void 0 : e.destroy());
    } catch (a) {
      throw (s = this._worker) != null && s.port && delete this._worker._pendingDestroy, a;
    } finally {
      (n = this._rendererWorker) == null || n.destroy(), this._rendererWorker = null;
    }
    this._transport = null, (r = this._worker) == null || r.destroy(), this._worker = null;
  }
  async getData() {
    return this._transport.getData();
  }
};
Np = new WeakMap(), g(Bp, Np, 0);
let km = Bp;
var Eh, vo;
class p0 {
  constructor(t, e, s = !1, n = null) {
    g(this, Eh, Promise.withResolvers());
    g(this, vo, null);
    this.length = t, this.initialData = e, this.progressiveDone = s, this.contentDispositionFilename = n;
  }
  onDataRange(t, e) {
    i(this, vo).call(this, {
      type: "range",
      begin: t,
      chunk: e
    });
  }
  onDataProgressiveRead(t) {
    i(this, Eh).promise.then(() => {
      i(this, vo).call(this, {
        type: "progressiveRead",
        chunk: t
      });
    });
  }
  onDataProgressiveDone() {
    i(this, Eh).promise.then(() => {
      i(this, vo).call(this, {
        type: "progressiveDone"
      });
    });
  }
  transportReady(t) {
    u(this, vo, t), i(this, Eh).resolve();
  }
  requestDataRange(t, e) {
    it("Abstract method PDFDataRangeTransport.requestDataRange");
  }
  abort() {
  }
}
Eh = new WeakMap(), vo = new WeakMap();
class eS {
  constructor(t, e) {
    this._pdfInfo = t, this._transport = e;
  }
  get pagesMapper() {
    return this._transport.pagesMapper;
  }
  get annotationStorage() {
    return this._transport.annotationStorage;
  }
  get canvasFactory() {
    return this._transport.canvasFactory;
  }
  get filterFactory() {
    return this._transport.filterFactory;
  }
  get numPages() {
    return this._pdfInfo.numPages;
  }
  get fingerprints() {
    return this._pdfInfo.fingerprints;
  }
  get isPureXfa() {
    return L(this, "isPureXfa", !!this._transport._htmlForXfa);
  }
  get allXfaHtml() {
    return this._transport._htmlForXfa;
  }
  getPage(t) {
    return this._transport.getPage(t);
  }
  getPageIndex(t) {
    return this._transport.getPageIndex(t);
  }
  getDestinations() {
    return this._transport.getDestinations();
  }
  getDestination(t) {
    return this._transport.getDestination(t);
  }
  getPageLabels() {
    return this._transport.getPageLabels();
  }
  getPageLayout() {
    return this._transport.getPageLayout();
  }
  getPageMode() {
    return this._transport.getPageMode();
  }
  getViewerPreferences() {
    return this._transport.getViewerPreferences();
  }
  getOpenAction() {
    return this._transport.getOpenAction();
  }
  getAttachments() {
    return this._transport.getAttachments();
  }
  getAttachmentContent(t) {
    return this._transport.getAttachmentContent(t);
  }
  getAnnotationsByType(t, e) {
    return this._transport.getAnnotationsByType(t, e);
  }
  getJSActions() {
    return this._transport.getDocJSActions();
  }
  getOutline() {
    return this._transport.getOutline();
  }
  getOptionalContentConfig({
    intent: t = "display"
  } = {}) {
    const {
      renderingIntent: e
    } = this._transport.getRenderingIntent(t);
    return this._transport.getOptionalContentConfig(e);
  }
  getPermissions() {
    return this._transport.getPermissions();
  }
  getMetadata() {
    return this._transport.getMetadata();
  }
  getMarkInfo() {
    return this._transport.getMarkInfo();
  }
  getData() {
    return this._transport.getData();
  }
  saveDocument(t) {
    return this._transport.saveDocument(t);
  }
  extractPages(t, e = null) {
    return this._transport.extractPages(t, e);
  }
  getDownloadInfo() {
    return this._transport.downloadInfoCapability.promise;
  }
  cleanup(t = !1) {
    return this._transport.startCleanup(t || this.isPureXfa);
  }
  cachedPageNumber(t) {
    return this._transport.cachedPageNumber(t);
  }
  get loadingParams() {
    return this._transport.loadingParams;
  }
  get loadingTask() {
    return this._transport.loadingTask;
  }
  getFieldObjects() {
    return this._transport.getFieldObjects();
  }
  getSignatures() {
    return this._transport.getSignatures();
  }
  getSignatureData(t) {
    return this._transport.getSignatureData(t);
  }
  hasJSActions() {
    return this._transport.hasJSActions();
  }
  getCalculationOrderIds() {
    return this._transport.getCalculationOrderIds();
  }
}
var Tn, So, Hp, Eo, Rc;
const Yc = class Yc {
  constructor(t, e, s, n, r = !1) {
    g(this, Eo);
    g(this, Tn, !1);
    g(this, So, null);
    this._pageIndex = t, this._id = rt(Yc, Hp)._++, this._pageInfo = e, this._transport = s, this._stats = r ? new ly() : null, this._pdfBug = r, this.commonObjs = s.commonObjs, this.objs = new Ub(), this._intentStates = /* @__PURE__ */ new Map(), this.destroyed = !1, this.recordedBBoxes = null, u(this, So, n), this.imageCoordinates = null;
  }
  clone(t) {
    const e = new Yc(t, this._pageInfo, this._transport, i(this, So), this._pdfBug);
    return e.clonedFromIndex = this.clonedFromIndex ?? this._pageIndex, this._transport.updatePage(e), e;
  }
  get pageNumber() {
    return this._pageIndex + 1;
  }
  set pageNumber(t) {
    this._pageIndex = t - 1, this._transport.updatePage(this);
  }
  get rotate() {
    return this._pageInfo.rotate;
  }
  get ref() {
    return this._pageInfo.ref;
  }
  get userUnit() {
    return this._pageInfo.userUnit;
  }
  get view() {
    return this._pageInfo.view;
  }
  getViewport({
    scale: t,
    rotation: e = this.rotate,
    offsetX: s = 0,
    offsetY: n = 0,
    dontFlip: r = !1
  } = {}) {
    return new rf({
      viewBox: this.view,
      userUnit: this.userUnit,
      scale: t,
      rotation: e,
      offsetX: s,
      offsetY: n,
      dontFlip: r
    });
  }
  getAnnotations({
    intent: t = "display"
  } = {}) {
    const {
      renderingIntent: e
    } = this._transport.getRenderingIntent(t);
    return this._transport.getAnnotations(this._pageIndex, e);
  }
  getJSActions() {
    return this._transport.getPageJSActions(this._pageIndex);
  }
  get filterFactory() {
    return this._transport.filterFactory;
  }
  get isPureXfa() {
    return L(this, "isPureXfa", !!this._transport._htmlForXfa);
  }
  async getXfa() {
    var t;
    return ((t = this._transport._htmlForXfa) == null ? void 0 : t.children[this._pageIndex]) || null;
  }
  render({
    canvasContext: t,
    canvas: e = t.canvas,
    viewport: s,
    intent: n = "display",
    annotationMode: r = tr.ENABLE,
    transform: a = null,
    background: o = null,
    optionalContentConfigPromise: l = null,
    annotationCanvasMap: h = null,
    pageColors: c = null,
    printAnnotationStorage: d = null,
    isEditing: f = !1,
    recordImages: b = !1,
    recordOperations: y = !1,
    partialFrames: A = !1,
    operationsFilter: w = null
  }) {
    var Y, Q, K;
    (Y = this._stats) == null || Y.time("Overall");
    const v = this._transport.getRenderingIntent(n, r, d, f), {
      renderingIntent: S,
      cacheKey: E
    } = v;
    u(this, Tn, !1), l || (l = this._transport.getOptionalContentConfig(S));
    const C = this._intentStates.getOrInsertComputed(E, Mg);
    C.streamReaderCancelTimeout && (clearTimeout(C.streamReaderCancelTimeout), C.streamReaderCancelTimeout = null);
    const x = !!(S & ms.PRINT);
    C.displayReadyCapability || (C.displayReadyCapability = Promise.withResolvers(), C.operatorList = {
      fnArray: [],
      argsArray: [],
      lastChunk: !1,
      separateAnnots: null
    }, (Q = this._stats) == null || Q.time("Page Request"), this._pumpOperatorList(v));
    const T = !!(this._pdfBug && ((K = globalThis.StepperManager) != null && K.enabled)), k = !!e && !this.recordedBBoxes && (y || T), M = !!e && !this.imageCoordinates && b, P = (et) => {
      var O, z;
      if (C.renderTasks.delete(D), k) {
        const {
          recordedBBoxes: Nt
        } = D;
        Nt && ((O = D.stepper) == null || O.setOperatorBBoxes(Nt, D.debugMetadata), y && (this.recordedBBoxes = Nt));
      }
      M && !et && (this.imageCoordinates = D.imageCoordinates), x && u(this, Tn, !0), m(this, Eo, Rc).call(this), et ? (D.capability.reject(et), this._abortOperatorList({
        intentState: C,
        reason: et instanceof Error ? et : new Error(et)
      })) : D.capability.resolve(), this._stats && (this._stats.timeEnd("Rendering"), this._stats.timeEnd("Overall"), (z = globalThis.Stats) != null && z.enabled && globalThis.Stats.add(this.pageNumber, this._stats));
    }, D = new Mm({
      callback: P,
      params: {
        canvas: e,
        canvasContext: t,
        viewport: s,
        transform: a,
        background: o,
        recordOperations: k,
        recordImages: M,
        partialFrames: A,
        recordForDebugger: T
      },
      objs: this.objs,
      commonObjs: this.commonObjs,
      annotationCanvasMap: h,
      operatorList: C.operatorList,
      pageIndex: this._pageIndex,
      pageProxyId: this._id,
      canvasFactory: this._transport.canvasFactory,
      filterFactory: this._transport.filterFactory,
      useRequestAnimationFrame: !x,
      pdfBug: this._pdfBug,
      pageColors: c,
      operationsFilter: w,
      rendererWorker: this._transport.rendererWorker,
      waitForGPU: () => this._transport.waitForGPU()
    });
    (C.renderTasks || (C.renderTasks = /* @__PURE__ */ new Set())).add(D);
    const H = D.task;
    return Promise.all([C.displayReadyCapability.promise, l]).then(async ([et, O]) => {
      var z;
      if (this.destroyed) {
        P();
        return;
      }
      if ((z = this._stats) == null || z.time("Rendering"), !(O.renderingIntent & S))
        throw new Error("Must use the same `intent`-argument when calling the `PDFPageProxy.render` and `PDFDocumentProxy.getOptionalContentConfig` methods.");
      await D.initializeGraphics({
        transparency: et,
        optionalContentConfig: O
      }), D.operatorListChanged();
    }).catch(P), H;
  }
  getOperatorList({
    intent: t = "display",
    annotationMode: e = tr.ENABLE,
    printAnnotationStorage: s = null,
    isEditing: n = !1
  } = {}) {
    var h;
    function r() {
      o.operatorList.lastChunk && (o.opListReadCapability.resolve(o.operatorList), o.renderTasks.delete(l));
    }
    const a = this._transport.getRenderingIntent(t, e, s, n, !0), o = this._intentStates.getOrInsertComputed(a.cacheKey, Mg);
    let l;
    return o.opListReadCapability || (l = /* @__PURE__ */ Object.create(null), l.operatorListChanged = r, o.opListReadCapability = Promise.withResolvers(), (o.renderTasks || (o.renderTasks = /* @__PURE__ */ new Set())).add(l), o.operatorList = {
      fnArray: [],
      argsArray: [],
      lastChunk: !1,
      separateAnnots: null
    }, (h = this._stats) == null || h.time("Page Request"), this._pumpOperatorList(a)), o.opListReadCapability.promise;
  }
  streamTextContent({
    includeMarkedContent: t = !1,
    disableNormalization: e = !1
  } = {}) {
    return this._transport.messageHandler.sendWithStream("GetTextContent", {
      pageId: i(this, So).getPageId(this._pageIndex + 1) - 1,
      pageIndex: this._pageIndex,
      includeMarkedContent: t === !0,
      disableNormalization: e === !0
    }, {
      highWaterMark: 100,
      size: (n) => n.items.length
    });
  }
  async getTextContent(t = {}) {
    if (this._transport._htmlForXfa)
      return this.getXfa().then((r) => qc.textContent(r));
    const s = this.streamTextContent(t).getReader(), n = {
      items: [],
      styles: /* @__PURE__ */ Object.create(null),
      lang: null
    };
    for (; ; ) {
      const {
        value: r,
        done: a
      } = await s.read();
      if (a)
        break;
      n.lang ?? (n.lang = r.lang), Object.assign(n.styles, r.styles), n.items.push(...r.items);
    }
    return n;
  }
  getStructTree() {
    return this._transport.getStructTree(this._pageIndex);
  }
  _destroy() {
    this.destroyed = !0;
    const t = [];
    for (const e of this._intentStates.values())
      if (this._abortOperatorList({
        intentState: e,
        reason: new Error("Page was destroyed."),
        force: !0
      }), !e.opListReadCapability)
        for (const s of e.renderTasks)
          t.push(s.completed), s.cancel();
    return this.objs.clear(), this._transport.cleanupPage(this._id), u(this, Tn, !1), Promise.all(t);
  }
  cleanup(t = !1) {
    u(this, Tn, !0);
    const e = m(this, Eo, Rc).call(this);
    return t && e && this._stats && (this._stats = new ly()), e;
  }
  _startRenderPage(t, e) {
    var n, r;
    const s = this._intentStates.get(e);
    s && ((n = this._stats) == null || n.timeEnd("Page Request"), (r = s.displayReadyCapability) == null || r.resolve(t));
  }
  _renderPageChunk(t, e) {
    for (let s = 0, n = t.length; s < n; s++)
      e.operatorList.fnArray.push(t.fnArray[s]), e.operatorList.argsArray.push(t.argsArray[s]);
    e.operatorList.lastChunk = t.lastChunk, e.operatorList.separateAnnots = t.separateAnnots;
    for (const s of e.renderTasks)
      s.operatorListChanged();
    t.lastChunk && m(this, Eo, Rc).call(this);
  }
  _pumpOperatorList({
    renderingIntent: t,
    cacheKey: e,
    annotationStorageSerializable: s,
    modifiedIds: n
  }) {
    const {
      map: r,
      transfer: a
    } = s, l = this._transport.messageHandler.sendWithStream("GetOperatorList", {
      pageId: i(this, So).getPageId(this._pageIndex + 1) - 1,
      pageIndex: this._pageIndex,
      pageProxyId: this._id,
      intent: t,
      cacheKey: e,
      annotationStorage: r,
      modifiedIds: n
    }, void 0, a).getReader(), h = this._intentStates.get(e);
    h.streamReader = l;
    const c = () => {
      l.read().then(({
        value: d,
        done: f
      }) => {
        if (f) {
          h.streamReader = null;
          return;
        }
        this._transport.destroyed || (this._renderPageChunk(d, h), c());
      }, (d) => {
        if (h.streamReader = null, !this._transport.destroyed) {
          if (h.operatorList) {
            h.operatorList.lastChunk = !0;
            for (const f of h.renderTasks)
              f.operatorListChanged();
            m(this, Eo, Rc).call(this);
          }
          if (h.displayReadyCapability)
            h.displayReadyCapability.reject(d);
          else if (h.opListReadCapability)
            h.opListReadCapability.reject(d);
          else
            throw d;
        }
      });
    };
    c();
  }
  _abortOperatorList({
    intentState: t,
    reason: e,
    force: s = !1
  }) {
    if (t.streamReader) {
      if (t.streamReaderCancelTimeout && (clearTimeout(t.streamReaderCancelTimeout), t.streamReaderCancelTimeout = null), !s) {
        if (t.renderTasks.size > 0)
          return;
        if (e instanceof Lb) {
          let n = tS;
          e.extraDelay > 0 && e.extraDelay < 1e3 && (n += e.extraDelay), t.streamReaderCancelTimeout = setTimeout(() => {
            t.streamReaderCancelTimeout = null, this._abortOperatorList({
              intentState: t,
              reason: e,
              force: !0
            });
          }, n);
          return;
        }
      }
      if (t.streamReader.cancel(new oa(e.message)).catch(() => {
      }), t.streamReader = null, !this._transport.destroyed) {
        for (const [n, r] of this._intentStates)
          if (r === t) {
            this._intentStates.delete(n);
            break;
          }
        this.cleanup();
      }
    }
  }
  get stats() {
    return this._stats;
  }
};
Tn = new WeakMap(), So = new WeakMap(), Hp = new WeakMap(), Eo = new WeakSet(), Rc = function() {
  if (!i(this, Tn) || this.destroyed)
    return !1;
  for (const {
    renderTasks: t,
    operatorList: e
  } of this._intentStates.values())
    if (t.size > 0 || !e.lastChunk)
      return !1;
  return this._intentStates.clear(), this.objs.clear(), this._transport.cleanupPage(this._id), u(this, Tn, !1), !0;
}, g(Yc, Hp, 0);
let Pm = Yc;
var Or, Zs, _n, Co, Up, xo, To, qe, Ff, g0, m0, Lf, Ch, Of;
const ie = class ie {
  constructor({
    name: t = null,
    port: e = null,
    verbosity: s = Fy()
  } = {}) {
    g(this, qe);
    g(this, Or, Promise.withResolvers());
    g(this, Zs, null);
    g(this, _n, null);
    g(this, Co, null);
    if (this.name = t, this.destroyed = !1, this.verbosity = s, e) {
      if (i(ie, To).has(e))
        throw new Error("Cannot use more than one PDFWorker per port.");
      i(ie, To).set(e, this), m(this, qe, g0).call(this, e);
    } else
      m(this, qe, m0).call(this);
  }
  get promise() {
    return i(this, Or).promise;
  }
  get port() {
    return i(this, _n);
  }
  get messageHandler() {
    return i(this, Zs);
  }
  destroy() {
    var t, e;
    this.destroyed = !0, (t = i(this, Co)) == null || t.terminate(), u(this, Co, null), i(ie, To).delete(i(this, _n)), u(this, _n, null), (e = i(this, Zs)) == null || e.destroy(), u(this, Zs, null);
  }
  static create(t) {
    const e = i(this, To).get(t == null ? void 0 : t.port);
    if (e) {
      if (e._pendingDestroy)
        throw new Error("PDFWorker.create - the worker is being destroyed.\nPlease remember to await `PDFDocumentLoadingTask.destroy()`-calls.");
      return e;
    }
    return new ie(t);
  }
  static get workerSrc() {
    if (Te.workerSrc)
      return Te.workerSrc;
    throw new Error('No "GlobalWorkerOptions.workerSrc" specified.');
  }
  static get _setupFakeWorkerGlobal() {
    return L(this, "_setupFakeWorkerGlobal", (async () => i(this, Ch, Of) ? i(this, Ch, Of) : (await import(
      /*webpackIgnore: true*/
      /*@vite-ignore*/
      this.workerSrc
    )).WorkerMessageHandler)());
  }
};
Or = new WeakMap(), Zs = new WeakMap(), _n = new WeakMap(), Co = new WeakMap(), Up = new WeakMap(), xo = new WeakMap(), To = new WeakMap(), qe = new WeakSet(), Ff = function() {
  i(this, Or).resolve(), i(this, Zs).send("configure", {
    verbosity: this.verbosity
  });
}, g0 = function(t) {
  u(this, _n, t), u(this, Zs, new aa("main", "worker", t)), i(this, Zs).on("ready", () => {
  }), m(this, qe, Ff).call(this);
}, m0 = function() {
  if (i(ie, xo) || i(ie, Ch, Of)) {
    m(this, qe, Lf).call(this);
    return;
  }
  const {
    workerSrc: t
  } = ie;
  try {
    const e = new Worker(wA(t), {
      type: "module"
    }), s = new aa("main", "worker", e), n = () => {
      r.abort(), s.destroy(), e.terminate(), this.destroyed ? i(this, Or).reject(new Error("Worker was destroyed")) : m(this, qe, Lf).call(this);
    }, r = new AbortController();
    e.addEventListener("error", () => {
      i(this, Co) || n();
    }, {
      signal: r.signal
    }), s.on("ready", (a) => {
      if (r.abort(), this.destroyed || !(a instanceof Uint8Array)) {
        n();
        return;
      }
      u(this, Zs, s), u(this, _n, e), u(this, Co, e), m(this, qe, Ff).call(this);
    });
  } catch {
    ig("The worker has been disabled."), m(this, qe, Lf).call(this);
  }
}, Lf = function() {
  i(ie, xo) || (j("Setting up fake worker."), u(ie, xo, !0)), ie._setupFakeWorkerGlobal.then((t) => {
    if (this.destroyed) {
      i(this, Or).reject(new Error("Worker was destroyed"));
      return;
    }
    const e = new Xw();
    u(this, _n, e);
    const s = `fake${rt(ie, Up)._++}`, n = new aa(s + "_worker", s, e);
    t.setup(n, e), u(this, Zs, new aa(s, s + "_worker", e)), m(this, qe, Ff).call(this);
  }).catch((t) => {
    i(this, Or).reject(new Error(`Setting up fake worker failed: "${t.message}".`));
  });
}, Ch = new WeakSet(), Of = function() {
  var t;
  try {
    return ((t = globalThis.pdfjsWorker) == null ? void 0 : t.WorkerMessageHandler) || null;
  } catch {
    return null;
  }
}, g(ie, Ch), g(ie, Up, 0), g(ie, xo, !1), g(ie, To, /* @__PURE__ */ new WeakMap()), bs && (u(ie, xo, !0), Te.workerSrc || (Te.workerSrc = "./pdf.worker.mjs"));
let td = ie;
var ns, xh, Rr, kn, Ri, _o, Th, Pn, fu, ci, Nc, Rf;
class sS {
  constructor(t, e, s, n, r, a) {
    g(this, ci);
    _(this, "downloadInfoCapability", Promise.withResolvers());
    g(this, ns, null);
    g(this, xh, !1);
    g(this, Rr, /* @__PURE__ */ new Map());
    g(this, kn, null);
    g(this, Ri, /* @__PURE__ */ new Map());
    g(this, _o, /* @__PURE__ */ new Map());
    g(this, Th, /* @__PURE__ */ new Map());
    g(this, Pn, null);
    g(this, fu, null);
    this.messageHandler = t, this.loadingTask = e, u(this, kn, s), this.commonObjs = new Ub(), this.fontLoader = new Ev({
      ownerDocument: n.ownerDocument,
      styleElement: n.styleElement
    }), this.rendererWorker = n.rendererWorker, this.loadingParams = n.loadingParams, this._params = n, this.canvasFactory = r.canvasFactory, this.filterFactory = r.filterFactory, this.binaryDataFactory = r.binaryDataFactory, this.pagesMapper = a, this.destroyed = !1, this.destroyCapability = null, this.setupMessageHandler();
  }
  updatePage(t) {
    i(this, Ri).set(t._id, t), i(this, _o).set(t._pageIndex, Promise.resolve(t));
  }
  get annotationStorage() {
    return L(this, "annotationStorage", new Bb());
  }
  getRenderingIntent(t, e = tr.ENABLE, s = null, n = !1, r = !1) {
    let a = ms.DISPLAY, o = Qc;
    switch (t) {
      case "any":
        a = ms.ANY;
        break;
      case "display":
        break;
      case "print":
        a = ms.PRINT;
        break;
      default:
        j(`getRenderingIntent - invalid intent: ${t}`);
    }
    const l = a & ms.PRINT && s instanceof AA ? s : this.annotationStorage;
    switch (e) {
      case tr.DISABLE:
        a += ms.ANNOTATIONS_DISABLE;
        break;
      case tr.ENABLE:
        break;
      case tr.ENABLE_FORMS:
        a += ms.ANNOTATIONS_FORMS;
        break;
      case tr.ENABLE_STORAGE:
        a += ms.ANNOTATIONS_STORAGE, o = l.serializable;
        break;
      default:
        j(`getRenderingIntent - invalid annotationMode: ${e}`);
    }
    n && (a += ms.IS_EDITING), r && (a += ms.OPLIST);
    const {
      ids: h,
      hash: c
    } = l.modifiedIds, d = [a, o.hash, c];
    return {
      renderingIntent: a,
      cacheKey: d.join("_"),
      annotationStorageSerializable: o,
      modifiedIds: h
    };
  }
  destroy() {
    var s;
    if (this.destroyCapability)
      return this.destroyCapability.promise;
    this.destroyed = !0, this.destroyCapability = Promise.withResolvers(), (s = i(this, Pn)) == null || s.reject(new Error("Worker was destroyed during onPassword callback"));
    const t = [];
    for (const n of i(this, Ri).values())
      t.push(n._destroy());
    i(this, Ri).clear(), i(this, _o).clear(), i(this, Th).clear(), Object.hasOwn(this, "annotationStorage") && this.annotationStorage.resetModified();
    const e = this.messageHandler.sendWithPromise("Terminate", null);
    return t.push(e), Promise.all(t).then(() => {
      var n, r;
      this.commonObjs.clear(), this.fontLoader.clear(), i(this, Rr).clear(), this.filterFactory.destroy(), Zc.cleanup(), (n = i(this, kn)) == null || n.cancelAllRequests(new oa("Worker was terminated.")), (r = this.messageHandler) == null || r.destroy(), this.messageHandler = null, this.rendererWorker = null, this.destroyCapability.resolve();
    }, this.destroyCapability.reject), this.destroyCapability.promise;
  }
  setupMessageHandler() {
    var n;
    const {
      messageHandler: t,
      loadingTask: e
    } = this;
    t.on("GetReader", (r, a) => {
      jt(i(this, kn), "GetReader - no `BasePDFStream` instance available."), u(this, ns, i(this, kn).getFullReader()), i(this, ns).onProgress = (o) => m(this, ci, Rf).call(this, o), a.onPull = () => {
        i(this, ns).read().then(function({
          value: o,
          done: l
        }) {
          if (l) {
            a.close();
            return;
          }
          jt(o instanceof ArrayBuffer, "GetReader - expected an ArrayBuffer."), a.enqueue(new Uint8Array(o), 1, [o]);
        }).catch((o) => {
          a.error(o);
        });
      }, a.onCancel = (o) => {
        i(this, ns).cancel(o), a.ready.catch((l) => {
          if (!this.destroyed)
            throw l;
        });
      };
    }), t.on("ReaderHeadersReady", async (r) => {
      await i(this, ns).headersReady;
      const {
        isStreamingSupported: a,
        isRangeSupported: o,
        contentLength: l
      } = i(this, ns);
      return a && o && (i(this, ns).onProgress = null), {
        isStreamingSupported: a,
        isRangeSupported: o,
        contentLength: l
      };
    }), t.on("GetRangeReader", (r, a) => {
      jt(i(this, kn), "GetRangeReader - no `BasePDFStream` instance available.");
      const o = i(this, kn).getRangeReader(r.begin, r.end);
      if (!o) {
        a.close();
        return;
      }
      a.onPull = () => {
        o.read().then(function({
          value: l,
          done: h
        }) {
          if (h) {
            a.close();
            return;
          }
          jt(l instanceof ArrayBuffer, "GetRangeReader - expected an ArrayBuffer."), a.enqueue(new Uint8Array(l), 1, [l]);
        }).catch((l) => {
          a.error(l);
        });
      }, a.onCancel = (l) => {
        o.cancel(l), a.ready.catch((h) => {
          if (!this.destroyed)
            throw h;
        });
      };
    }), t.on("GetDoc", ({
      pdfInfo: r
    }) => {
      this.pagesMapper.pagesNumber = r.numPages, this._numPages = r.numPages, this._htmlForXfa = r.htmlForXfa, delete r.htmlForXfa, e._capability.resolve(new eS(r, this));
    }), t.on("DocException", (r) => {
      e._capability.reject(Ue(r));
    }), t.on("PasswordRequest", (r) => {
      u(this, Pn, Promise.withResolvers());
      try {
        if (!e.onPassword)
          throw Ue(r);
        const a = (o) => {
          o instanceof Error ? i(this, Pn).reject(o) : i(this, Pn).resolve({
            password: o
          });
        };
        e.onPassword(a, r.code);
      } catch (a) {
        i(this, Pn).reject(a);
      }
      return i(this, Pn).promise;
    }), t.on("DataLoaded", (r) => {
      m(this, ci, Rf).call(this, {
        loaded: r.length,
        total: r.length
      }), this.downloadInfoCapability.resolve(r);
    }), t.on("StartRenderPage", (r) => {
      if (this.destroyed)
        return;
      i(this, Ri).get(r.pageProxyId)._startRenderPage(r.transparency, r.cacheKey);
    });
    const s = new Yv({
      messageHandler: t,
      commonObjs: this.commonObjs,
      fontLoader: this.fontLoader,
      pageCache: i(this, Ri),
      pdfBug: this._params.pdfBug
    });
    (n = this.rendererWorker) == null || n.promise.then(() => {
      var r, a;
      (a = (r = this.rendererWorker) == null ? void 0 : r.messageHandler) == null || a.on("FontFallback", (o) => this.destroyed ? null : t.sendWithPromise("FontFallback", o));
    }, () => {
    }), t.on("commonobj", ([r, a, o]) => {
      if (this.destroyed)
        return null;
      const {
        rendererWorker: l
      } = this;
      if (a === "CopyLocalImage") {
        if (this.commonObjs.has(r))
          return null;
        const h = s.resolveCommonObject(r, a, o);
        return h && (l == null || l.sendCommonObj(r, "Image", this.commonObjs.get(r))), h;
      }
      return l == null || l.sendCommonObj(r, a, o), this.commonObjs.has(r) || (s.resolveCommonObject(r, a, o), a === "Pattern" && this.commonObjs.get(r)[0] === "Mesh" && u(this, xh, !0)), null;
    }), t.on("obj", ([r, a, o, l]) => {
      var h;
      this.destroyed || (o === "Pattern" && l[0] === "Mesh" && u(this, xh, !0), s.resolveObject(r, a, o, l) && ((h = this.rendererWorker) == null || h.sendObj(r, a, o, l)));
    }), t.on("DocProgress", (r) => {
      this.destroyed || m(this, ci, Rf).call(this, r);
    }), t.on("FetchBinaryData", async (r) => {
      if (this.destroyed)
        throw new Error("Worker was destroyed.");
      if (!this.binaryDataFactory)
        throw new Error("`BinaryDataFactory` not initialized, see the `useWorkerFetch` parameter.");
      return this.binaryDataFactory.fetch(r);
    });
  }
  getData() {
    return this.messageHandler.sendWithPromise("GetData", null);
  }
  saveDocument(t = null) {
    var n;
    this.annotationStorage.size <= 0 && j("saveDocument called while `annotationStorage` is empty, please use the getData-method instead.");
    const {
      map: e,
      transfer: s
    } = this.annotationStorage.serializable;
    return this.messageHandler.sendWithPromise("SaveDocument", {
      isPureXfa: !!this._htmlForXfa,
      numPages: this._numPages,
      annotationStorage: e,
      supportsPrintToPDF: i(this, fu) !== null,
      filename: ((n = i(this, ns)) == null ? void 0 : n.filename) ?? null
    }, s).finally(() => {
      u(this, fu, null), this.annotationStorage.resetModified();
    });
  }
  extractPages(t, e = null) {
    var a;
    const s = {
      pageInfos: t
    };
    let n;
    const r = globalThis.ImageBitmap;
    if (typeof r == "function") {
      const o = Array.isArray(t) ? t : [t];
      for (const l of o)
        (l == null ? void 0 : l.image) instanceof r && (n || (n = [])).push(l.image);
    }
    if (this.annotationStorage.size > 0) {
      const o = this.annotationStorage.serializable;
      let {
        map: l
      } = o;
      (a = o.transfer) != null && a.length && (n ? n.push(...o.transfer) : n = o.transfer);
      const h = this.pagesMapper.getMapping();
      if (h) {
        const c = /* @__PURE__ */ new Map();
        for (const [d, f] of l) {
          if ((f == null ? void 0 : f.pageIndex) !== void 0 && f.pageIndex >= 0 && f.pageIndex < h.length) {
            const b = (e == null ? void 0 : e[f.pageIndex]) ?? 0, y = h[f.pageIndex] - 1;
            if (y !== f.pageIndex || b !== 0) {
              c.set(d, {
                ...f,
                pageIndex: y,
                copyLevel: b
              });
              continue;
            }
          }
          c.set(d, f);
        }
        l = c;
      }
      s.annotationStorage = l;
    }
    return this.messageHandler.sendWithPromise("ExtractPages", s, n).finally(() => {
      this.annotationStorage.resetModified();
    });
  }
  waitForGPU() {
    return this._params.enableWebGPU && i(this, xh) && !EA() ? SA() : null;
  }
  getPage(t) {
    if (!Number.isInteger(t) || t <= 0 || t > this.pagesMapper.pagesNumber)
      return Promise.reject(new Error("Invalid page request."));
    const e = t - 1, s = this.pagesMapper.getPageId(t) - 1, n = i(this, _o).get(e);
    if (n)
      return n;
    const r = this.messageHandler.sendWithPromise("GetPage", {
      pageIndex: s
    }).then((a) => {
      if (this.destroyed)
        throw new Error("Transport destroyed");
      a.refStr && i(this, Th).set(a.refStr, s);
      const o = new Pm(e, a, this, this.pagesMapper, this._params.pdfBug);
      return i(this, Ri).set(o._id, o), o;
    });
    return i(this, _o).set(e, r), r;
  }
  async getPageIndex(t) {
    if (!im(t))
      throw new Error("Invalid pageIndex request.");
    const e = await this.messageHandler.sendWithPromise("GetPageIndex", {
      num: t.num,
      gen: t.gen
    }), s = this.pagesMapper.getPageNumber(e + 1);
    if (s === 0)
      throw new Error("GetPageIndex: page has been removed.");
    return s - 1;
  }
  getAnnotations(t, e) {
    return this.messageHandler.sendWithPromise("GetAnnotations", {
      pageIndex: this.pagesMapper.getPageId(t + 1) - 1,
      intent: e
    });
  }
  getFieldObjects() {
    return m(this, ci, Nc).call(this, "GetFieldObjects");
  }
  getSignatures() {
    return m(this, ci, Nc).call(this, "GetSignatures");
  }
  getSignatureData(t) {
    return this.messageHandler.sendWithPromise("GetSignatureData", t);
  }
  hasJSActions() {
    return m(this, ci, Nc).call(this, "HasJSActions");
  }
  getCalculationOrderIds() {
    return this.messageHandler.sendWithPromise("GetCalculationOrderIds", null);
  }
  getDestinations() {
    return this.messageHandler.sendWithPromise("GetDestinations", null);
  }
  getDestination(t) {
    return typeof t != "string" ? Promise.reject(new Error("Invalid destination request.")) : this.messageHandler.sendWithPromise("GetDestination", {
      id: t
    });
  }
  getPageLabels() {
    return this.messageHandler.sendWithPromise("GetPageLabels", null);
  }
  getPageLayout() {
    return this.messageHandler.sendWithPromise("GetPageLayout", null);
  }
  getPageMode() {
    return this.messageHandler.sendWithPromise("GetPageMode", null);
  }
  getViewerPreferences() {
    return this.messageHandler.sendWithPromise("GetViewerPreferences", null);
  }
  getOpenAction() {
    return this.messageHandler.sendWithPromise("GetOpenAction", null);
  }
  getAttachments() {
    return this.messageHandler.sendWithPromise("GetAttachments", null);
  }
  getAttachmentContent(t) {
    return this.messageHandler.sendWithPromise("GetAttachmentContent", t);
  }
  getAnnotationsByType(t, e) {
    return this.messageHandler.sendWithPromise("GetAnnotationsByType", {
      types: t,
      pageIndexesToSkip: e
    });
  }
  getDocJSActions() {
    return m(this, ci, Nc).call(this, "GetDocJSActions");
  }
  getPageJSActions(t) {
    return this.messageHandler.sendWithPromise("GetPageJSActions", {
      pageIndex: this.pagesMapper.getPageId(t + 1) - 1
    });
  }
  getStructTree(t) {
    return this.messageHandler.sendWithPromise("GetStructTree", {
      pageIndex: this.pagesMapper.getPageId(t + 1) - 1
    });
  }
  getOutline() {
    return this.messageHandler.sendWithPromise("GetOutline", null);
  }
  getOptionalContentConfig(t) {
    const e = "GetOptionalContentConfig";
    return i(this, Rr).getOrInsertComputed(e, () => this.messageHandler.sendWithPromise(e, null).catch((s) => (j(`${e}: "${s}".`), null))).then((s) => new Am(s, t));
  }
  getPermissions() {
    return this.messageHandler.sendWithPromise("GetPermissions", null);
  }
  getMetadata() {
    const t = "GetMetadata";
    return i(this, Rr).getOrInsertComputed(t, () => this.messageHandler.sendWithPromise(t, null).then((e) => {
      var s, n;
      return {
        info: e[0],
        metadata: e[1] ? new zv(e[1]) : null,
        contentDispositionFilename: ((s = i(this, ns)) == null ? void 0 : s.filename) ?? null,
        contentLength: ((n = i(this, ns)) == null ? void 0 : n.contentLength) ?? null,
        hasStructTree: e[2]
      };
    }));
  }
  getMarkInfo() {
    return this.messageHandler.sendWithPromise("GetMarkInfo", null);
  }
  async startCleanup(t = !1) {
    var e;
    if (!this.destroyed) {
      await this.messageHandler.sendWithPromise("Cleanup", null);
      for (const s of i(this, Ri).values())
        if (!s.cleanup())
          throw new Error(`startCleanup: Page ${s.pageNumber} is currently rendering.`);
      this.commonObjs.clear(), t || this.fontLoader.clear(), (e = this.rendererWorker) == null || e.cleanup(t), i(this, Rr).clear(), this.filterFactory.destroy(!0), Zc.cleanup();
    }
  }
  cleanupPage(t) {
    var e;
    this.destroyed || this.messageHandler.send("CleanupPage", {
      pageProxyId: t
    }), (e = this.rendererWorker) == null || e.cleanupPage(t);
  }
  cachedPageNumber(t) {
    if (!im(t))
      return null;
    const e = t.gen === 0 ? `${t.num}R` : `${t.num}R${t.gen}`, s = i(this, Th).get(e);
    if (s >= 0) {
      const n = this.pagesMapper.getPageNumber(s + 1);
      if (n !== 0)
        return n;
    }
    return null;
  }
}
ns = new WeakMap(), xh = new WeakMap(), Rr = new WeakMap(), kn = new WeakMap(), Ri = new WeakMap(), _o = new WeakMap(), Th = new WeakMap(), Pn = new WeakMap(), fu = new WeakMap(), ci = new WeakSet(), Nc = function(t, e = null) {
  return i(this, Rr).getOrInsertComputed(t, () => this.messageHandler.sendWithPromise(t, e));
}, Rf = function({
  loaded: t,
  total: e
}) {
  var s, n;
  (n = (s = this.loadingTask).onProgress) == null || n.call(s, {
    loaded: t,
    total: e,
    percent: e ? vt(Math.round(t / e * 100), 0, 100) : NaN
  });
};
class iS {
  constructor(t) {
    _(this, "_internalRenderTask", null);
    _(this, "onContinue", null);
    _(this, "onError", null);
    _(this, "onFrame", null);
    this._internalRenderTask = t;
  }
  get promise() {
    return this._internalRenderTask.capability.promise;
  }
  cancel(t = 0) {
    this._internalRenderTask.cancel(null, t);
  }
  get separateAnnots() {
    const {
      separateAnnots: t
    } = this._internalRenderTask.operatorList;
    if (!t)
      return !1;
    const {
      annotationCanvasMap: e
    } = this._internalRenderTask;
    return t.form || t.canvas && (e == null ? void 0 : e.size) > 0;
  }
  get imageCoordinates() {
    return this._internalRenderTask.imageCoordinates || null;
  }
  get isWorkerRendering() {
    return this._internalRenderTask.isWorkerRendering;
  }
}
var ko, pu, Nr, fe, gu, Po;
const Aa = class Aa {
  constructor({
    callback: t,
    params: e,
    objs: s,
    commonObjs: n,
    annotationCanvasMap: r,
    operatorList: a,
    pageIndex: o,
    pageProxyId: l,
    canvasFactory: h,
    filterFactory: c,
    useRequestAnimationFrame: d = !1,
    pdfBug: f = !1,
    pageColors: b = null,
    operationsFilter: y = null,
    rendererWorker: A = null,
    waitForGPU: w = null
  }) {
    g(this, ko, null);
    g(this, pu, null);
    g(this, Nr, null);
    g(this, fe, null);
    g(this, gu, null);
    this.callback = t, this.params = e, this.objs = s, this.commonObjs = n, this.annotationCanvasMap = r, this.operatorListIdx = null, this.operatorList = a, this._pageIndex = o, this.canvasFactory = h, this.filterFactory = c, this._pdfBug = f, this.pageColors = b, this.running = !1, this.graphicsReadyCallback = null, this.graphicsReady = !1, this._useRequestAnimationFrame = d === !0 && typeof window < "u", this.cancelled = !1, this.capability = Promise.withResolvers(), this.task = new iS(this), this._cancelBound = this.cancel.bind(this), this._continueBound = this._continue.bind(this), this._scheduleNextBound = this._scheduleNext.bind(this), this._nextBound = this._next.bind(this), this._canvas = e.canvas, this._canvasContext = e.canvas ? null : e.canvasContext, this._operationsFilter = y, u(this, gu, w), u(this, fe, (A == null ? void 0 : A.createRenderTask({
      pageProxyId: l,
      operatorList: a,
      params: e,
      pageColors: b,
      canvasFactory: h,
      annotationCanvasMap: r,
      onFrame: () => {
        var v, S;
        return (S = (v = this.task).onFrame) == null ? void 0 : S.call(v);
      },
      onError: (v) => this.cancel(v)
    })) ?? null);
  }
  get completed() {
    return this.capability.promise.catch(() => {
    });
  }
  get isWorkerRendering() {
    return !!i(this, fe);
  }
  get imageCoordinates() {
    var t;
    return i(this, fe) ? i(this, fe).imageCoordinates : (t = i(this, pu)) == null ? void 0 : t.take();
  }
  get recordedBBoxes() {
    var t;
    return i(this, fe) ? i(this, fe).recordedBBoxes : (t = i(this, ko)) == null ? void 0 : t.take();
  }
  get debugMetadata() {
    var t;
    return ((t = i(this, ko)) == null ? void 0 : t.takeDebugMetadata()) ?? null;
  }
  async initializeGraphics({
    transparency: t = !1,
    optionalContentConfig: e
  }) {
    var s, n;
    if (!this.cancelled) {
      if (this._canvas) {
        if (i(Aa, Po).has(this._canvas))
          throw new Error("Cannot use the same canvas during multiple render() operations. Use different canvas or ensure previous operations were cancelled or completed.");
        i(Aa, Po).add(this._canvas);
      }
      if (this._pdfBug && ((s = globalThis.StepperManager) != null && s.enabled) && (this.stepper = globalThis.StepperManager.create(this._pageIndex), this.stepper.init(this.operatorList), this.stepper.nextBreakPoint = this.stepper.getNextBreakPoint()), i(this, fe)) {
        const r = await i(this, fe).initialize(t, e);
        if (this.cancelled)
          return;
        r || u(this, fe, null);
      }
      if (!i(this, fe)) {
        const {
          viewport: r,
          transform: a,
          background: o,
          recordOperations: l,
          recordImages: h,
          recordForDebugger: c
        } = this.params, d = this._canvasContext || this.canvasFactory.getNoAlphaContext(this._canvas), {
          dependencyTracker: f,
          imagesTracker: b
        } = rv(this._canvas, this.operatorList.fnArray.length, {
          recordOperations: l,
          recordImages: h,
          recordDebugMetadata: c
        });
        u(this, ko, f), u(this, pu, b), this.gfx = new Al(d, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
          optionalContentConfig: e
        }, this.annotationCanvasMap, this.pageColors, f, b), this.gfx.beginDrawing({
          transform: a,
          viewport: r,
          transparency: t,
          background: o
        });
      }
      this.operatorListIdx = 0, this.graphicsReady = !0, (n = this.graphicsReadyCallback) == null || n.call(this);
    }
  }
  cancel(t = null, e = 0) {
    var s, n, r, a;
    this.running = !1, this.cancelled = !0, (s = i(this, fe)) == null || s.cancel(), (n = this.gfx) == null || n.endDrawing(), i(this, Nr) && (window.cancelAnimationFrame(i(this, Nr)), u(this, Nr, null)), i(Aa, Po).delete(this._canvas), t || (t = new Lb(`Rendering cancelled, page ${this._pageIndex + 1}`, e)), this.callback(t), (a = (r = this.task).onError) == null || a.call(r, t);
  }
  operatorListChanged() {
    var t, e;
    if (!this.graphicsReady) {
      this.graphicsReadyCallback || (this.graphicsReadyCallback = this._continueBound);
      return;
    }
    (t = i(this, ko)) == null || t.growOperationsCount(this.operatorList.fnArray.length), (e = this.stepper) == null || e.updateOperatorList(this.operatorList), !this.running && this._continue();
  }
  _continue() {
    this.running = !0, !this.cancelled && (this.task.onContinue ? this.task.onContinue(this._scheduleNextBound) : this._scheduleNext());
  }
  _scheduleNext() {
    this._useRequestAnimationFrame ? u(this, Nr, window.requestAnimationFrame(() => {
      u(this, Nr, null), this._nextBound().catch(this._cancelBound);
    })) : Promise.resolve().then(this._nextBound).catch(this._cancelBound);
  }
  async _next() {
    var s, n;
    if (this.cancelled)
      return;
    if (!i(this, fe)) {
      const r = (s = i(this, gu)) == null ? void 0 : s.call(this);
      if (r && (await r, this.cancelled))
        return;
    }
    const {
      operatorList: t
    } = this, {
      lastChunk: e
    } = t;
    if (i(this, fe)) {
      if (this.operatorListIdx = await i(this, fe).executeOperatorList(t, this.operatorListIdx, this._operationsFilter), this.cancelled)
        return;
      if (this.operatorListIdx !== t.argsArray.length || e !== t.lastChunk) {
        this._continue();
        return;
      }
    } else
      this.operatorListIdx = this.gfx.executeOperatorList(t, this.operatorListIdx, this._continueBound, null, this.stepper, this._operationsFilter);
    this.operatorListIdx === t.argsArray.length && (this.running = !1, e && ((n = this.gfx) == null || n.endDrawing(), i(Aa, Po).delete(this._canvas), this.callback()));
  }
};
ko = new WeakMap(), pu = new WeakMap(), Nr = new WeakMap(), fe = new WeakMap(), gu = new WeakMap(), Po = new WeakMap(), g(Aa, Po, /* @__PURE__ */ new WeakSet());
let Mm = Aa;
const nS = "6.5.438", rS = "0a4153349";
var rs, Mo, _h, Jt, mu, kh, Mn, bu, Br, ti, yu, mt, Dm, Im, Fm, ma, b0, Qn;
const Ge = class Ge {
  constructor({
    editor: t = null,
    uiManager: e = null
  }) {
    g(this, mt);
    g(this, rs, null);
    g(this, Mo, null);
    g(this, _h);
    g(this, Jt, null);
    g(this, mu, !1);
    g(this, kh, !1);
    g(this, Mn, null);
    g(this, bu);
    g(this, Br, null);
    g(this, ti, null);
    var s, n;
    t ? (u(this, kh, !1), u(this, Mn, t)) : u(this, kh, !0), u(this, ti, (t == null ? void 0 : t._uiManager) || e), u(this, bu, i(this, ti)._eventBus), u(this, _h, ((s = t == null ? void 0 : t.color) == null ? void 0 : s.toUpperCase()) || ((n = i(this, ti)) == null ? void 0 : n.highlightColors.values().next().value) || "#FFFF98"), i(Ge, yu) || u(Ge, yu, Object.freeze({
      blue: "pdfjs-editor-colorpicker-blue",
      green: "pdfjs-editor-colorpicker-green",
      pink: "pdfjs-editor-colorpicker-pink",
      red: "pdfjs-editor-colorpicker-red",
      yellow: "pdfjs-editor-colorpicker-yellow"
    }));
  }
  static get _keyboardManager() {
    return L(this, "_keyboardManager", new rl([[["Escape"], Ge.prototype._hideDropdownFromKeyboard], [["Space"], Ge.prototype._colorSelectFromKeyboard], [["ArrowDown", "ArrowRight"], Ge.prototype._moveToNext], [["ArrowUp", "ArrowLeft"], Ge.prototype._moveToPrevious], [["Home"], Ge.prototype._moveToBeginning], [["End"], Ge.prototype._moveToEnd]]));
  }
  renderButton() {
    const t = u(this, rs, document.createElement("button"));
    t.className = "colorPicker", t.tabIndex = "0", t.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-button"), t.ariaHasPopup = "true", i(this, Mn) && (t.ariaControls = `${i(this, Mn).id}_colorpicker_dropdown`);
    const e = i(this, ti)._signal;
    t.addEventListener("click", m(this, mt, ma).bind(this), {
      signal: e
    }), t.addEventListener("keydown", m(this, mt, Fm).bind(this), {
      signal: e
    });
    const s = u(this, Mo, document.createElement("span"));
    return s.className = "swatch", s.ariaHidden = "true", s.style.backgroundColor = i(this, _h), t.append(s), t;
  }
  renderMainDropdown() {
    const t = u(this, Jt, m(this, mt, Dm).call(this));
    return t.ariaOrientation = "horizontal", t.ariaLabelledBy = "highlightColorPickerLabel", t;
  }
  _colorSelectFromKeyboard(t) {
    if (t.target === i(this, rs)) {
      m(this, mt, ma).call(this, t);
      return;
    }
    const e = t.target.getAttribute("data-color");
    e && m(this, mt, Im).call(this, e, t);
  }
  _moveToNext(t) {
    var e, s;
    if (!i(this, mt, Qn)) {
      m(this, mt, ma).call(this, t);
      return;
    }
    if (t.target === i(this, rs)) {
      (e = i(this, Jt).firstElementChild) == null || e.focus();
      return;
    }
    (s = t.target.nextSibling) == null || s.focus();
  }
  _moveToPrevious(t) {
    var e, s;
    if (t.target === ((e = i(this, Jt)) == null ? void 0 : e.firstElementChild) || t.target === i(this, rs)) {
      i(this, mt, Qn) && this._hideDropdownFromKeyboard();
      return;
    }
    i(this, mt, Qn) || m(this, mt, ma).call(this, t), (s = t.target.previousSibling) == null || s.focus();
  }
  _moveToBeginning(t) {
    var e;
    if (!i(this, mt, Qn)) {
      m(this, mt, ma).call(this, t);
      return;
    }
    (e = i(this, Jt).firstElementChild) == null || e.focus();
  }
  _moveToEnd(t) {
    var e;
    if (!i(this, mt, Qn)) {
      m(this, mt, ma).call(this, t);
      return;
    }
    (e = i(this, Jt).lastElementChild) == null || e.focus();
  }
  hideDropdown() {
    var t, e;
    (t = i(this, Jt)) == null || t.classList.add("hidden"), i(this, rs).ariaExpanded = "false", (e = i(this, Br)) == null || e.abort(), u(this, Br, null);
  }
  _hideDropdownFromKeyboard() {
    var t;
    if (!i(this, kh)) {
      if (!i(this, mt, Qn)) {
        (t = i(this, Mn)) == null || t.unselect();
        return;
      }
      this.hideDropdown(), i(this, rs).focus({
        preventScroll: !0,
        focusVisible: i(this, mu)
      });
    }
  }
  update(t) {
    if (i(this, Mo) && (i(this, Mo).style.backgroundColor = t), !i(this, Jt))
      return;
    const e = i(this, ti).highlightColors.values();
    for (const s of i(this, Jt).children)
      s.ariaSelected = e.next().value === t.toUpperCase();
  }
  destroy() {
    var t, e;
    (t = i(this, rs)) == null || t.remove(), u(this, rs, null), u(this, Mo, null), (e = i(this, Jt)) == null || e.remove(), u(this, Jt, null);
  }
};
rs = new WeakMap(), Mo = new WeakMap(), _h = new WeakMap(), Jt = new WeakMap(), mu = new WeakMap(), kh = new WeakMap(), Mn = new WeakMap(), bu = new WeakMap(), Br = new WeakMap(), ti = new WeakMap(), yu = new WeakMap(), mt = new WeakSet(), Dm = function() {
  const t = document.createElement("div"), e = i(this, ti)._signal;
  t.addEventListener("contextmenu", di, {
    signal: e
  }), t.className = "dropdown", t.role = "listbox", t.ariaMultiSelectable = "false", t.ariaOrientation = "vertical", t.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-dropdown"), i(this, Mn) && (t.id = `${i(this, Mn).id}_colorpicker_dropdown`);
  for (const [s, n] of i(this, ti).highlightColors) {
    const r = document.createElement("button");
    r.tabIndex = "0", r.role = "option", r.setAttribute("data-color", n), r.title = s, r.setAttribute("data-l10n-id", i(Ge, yu)[s]);
    const a = document.createElement("span");
    r.append(a), a.className = "swatch", a.style.backgroundColor = n, r.ariaSelected = n === i(this, _h), r.addEventListener("click", m(this, mt, Im).bind(this, n), {
      signal: e
    }), t.append(r);
  }
  return t.addEventListener("keydown", m(this, mt, Fm).bind(this), {
    signal: e
  }), t;
}, Im = function(t, e) {
  e.stopPropagation(), i(this, bu).dispatch("switchannotationeditorparams", {
    source: this,
    type: tt.HIGHLIGHT_COLOR,
    value: t
  }), this.update(t);
}, Fm = function(t) {
  Ge._keyboardManager.exec(this, t);
}, ma = function(t) {
  if (i(this, mt, Qn)) {
    this.hideDropdown();
    return;
  }
  if (u(this, mu, t.detail === 0), i(this, Br) || (u(this, Br, new AbortController()), window.addEventListener("pointerdown", m(this, mt, b0).bind(this), {
    signal: i(this, ti).combinedSignal(i(this, Br))
  })), i(this, rs).ariaExpanded = "true", i(this, Jt)) {
    i(this, Jt).classList.remove("hidden");
    return;
  }
  const e = u(this, Jt, m(this, mt, Dm).call(this));
  i(this, rs).append(e);
}, b0 = function(t) {
  var e;
  (e = i(this, Jt)) != null && e.contains(t.target) || this.hideDropdown();
}, Qn = function() {
  return i(this, Jt) && !i(this, Jt).classList.contains("hidden");
}, g(Ge, yu, null);
let up = Ge;
var as, Ph, Do, Dn, Au;
const wa = class wa {
  constructor(t) {
    g(this, as, null);
    g(this, Ph, !1);
    g(this, Do, null);
    g(this, Dn, null);
    u(this, Do, t), u(this, Dn, t._uiManager), i(wa, Au) || u(wa, Au, Object.freeze({
      freetext: "pdfjs-editor-color-picker-free-text-input",
      ink: "pdfjs-editor-color-picker-ink-input"
    }));
  }
  renderButton() {
    if (i(this, as))
      return i(this, as);
    const {
      editorType: t,
      colorType: e,
      colorAndOpacityType: s,
      opacityType: n,
      color: r,
      opacity: a
    } = i(this, Do), o = u(this, Ph, ot.isAlphaColorInputSupported && n !== void 0), l = u(this, as, document.createElement("input"));
    if (l.type = "color", o) {
      l.setAttribute("alpha", "");
      const h = I.hexNums[Math.round((a ?? 1) * 255)];
      l.value = (r || "#000000") + h;
    } else
      l.value = r || "#000000";
    return l.className = "basicColorPicker", l.tabIndex = 0, l.setAttribute("data-l10n-id", i(wa, Au)[t]), l.addEventListener("input", () => {
      if (o) {
        const h = mc(l.value);
        if (!h)
          return;
        const [c, d, f, b] = h, y = I.makeHexColor(c, d, f);
        s !== void 0 ? i(this, Dn).updateParams(s, {
          color: y,
          opacity: b
        }) : (i(this, Dn).updateParams(e, y), i(this, Dn).updateParams(n, b));
      } else
        i(this, Dn).updateParams(e, l.value);
    }, {
      signal: i(this, Dn)._signal
    }), l;
  }
  update(t) {
    if (i(this, as))
      if (i(this, Ph)) {
        const e = I.hexNums[Math.round(i(this, Do).opacity * 255)];
        i(this, as).value = t + e;
      } else
        i(this, as).value = t;
  }
  updateOpacity(t) {
    if (!i(this, as) || !i(this, Ph))
      return;
    const e = I.hexNums[Math.round(t * 255)];
    i(this, as).value = i(this, Do).color + e;
  }
  destroy() {
    var t;
    (t = i(this, as)) == null || t.remove(), u(this, as, null);
  }
  hideDropdown() {
  }
};
as = new WeakMap(), Ph = new WeakMap(), Do = new WeakMap(), Dn = new WeakMap(), Au = new WeakMap(), g(wa, Au, null);
let fp = wa;
function _y(p) {
  return Math.floor(vt(p, 0, 1) * 255).toString(16).padStart(2, "0");
}
function Ac(p) {
  return vt(p, 0, 1) * 255;
}
class ky {
  static CMYK_G([t, e, s, n]) {
    return ["G", 1 - Math.min(1, 0.3 * t + 0.59 * s + 0.11 * e + n)];
  }
  static G_CMYK([t]) {
    return ["CMYK", 0, 0, 0, 1 - t];
  }
  static G_RGB([t]) {
    return ["RGB", t, t, t];
  }
  static G_rgb([t]) {
    return t = Ac(t), [t, t, t];
  }
  static G_HTML([t]) {
    const e = _y(t);
    return `#${e}${e}${e}`;
  }
  static RGB_G([t, e, s]) {
    return ["G", 0.3 * t + 0.59 * e + 0.11 * s];
  }
  static RGB_rgb(t) {
    return t.map(Ac);
  }
  static RGB_HTML(t) {
    return `#${t.map(_y).join("")}`;
  }
  static T_HTML() {
    return "#00000000";
  }
  static T_rgb() {
    return [null];
  }
  static CMYK_RGB([t, e, s, n]) {
    return ["RGB", 1 - Math.min(1, t + n), 1 - Math.min(1, s + n), 1 - Math.min(1, e + n)];
  }
  static CMYK_rgb([t, e, s, n]) {
    return [Ac(1 - Math.min(1, t + n)), Ac(1 - Math.min(1, s + n)), Ac(1 - Math.min(1, e + n))];
  }
  static CMYK_HTML(t) {
    const e = this.CMYK_RGB(t).slice(1);
    return this.RGB_HTML(e);
  }
  static RGB_CMYK([t, e, s]) {
    const n = 1 - t, r = 1 - e, a = 1 - s, o = Math.min(n, r, a);
    return ["CMYK", n, r, a, o];
  }
}
class aS {
  create(t, e, s = !1) {
    if (t <= 0 || e <= 0)
      throw new Error("Invalid SVG dimensions");
    const n = this._createSVG("svg:svg");
    return n.setAttribute("version", "1.1"), s || (n.setAttribute("width", `${t}px`), n.setAttribute("height", `${e}px`)), n.setAttribute("preserveAspectRatio", "none"), n.setAttribute("viewBox", `0 0 ${t} ${e}`), n;
  }
  createElement(t) {
    if (typeof t != "string")
      throw new Error("Invalid SVG element type");
    return this._createSVG(t);
  }
  _createSVG(t) {
    it("Abstract method `_createSVG` called.");
  }
}
class zb extends aS {
  _createSVG(t) {
    return document.createElementNS(Re, t);
  }
}
const oS = 9, ol = /* @__PURE__ */ new WeakSet(), lS = (/* @__PURE__ */ new Date()).getTimezoneOffset() * 60 * 1e3;
class Cg {
  static create(t) {
    switch (t.data.annotationType) {
      case It.LINK:
        return new Gb(t);
      case It.TEXT:
        return new cS(t);
      case It.WIDGET:
        switch (t.data.fieldType) {
          case "Tx":
            return new dS(t);
          case "Btn":
            return t.data.radioButton ? new pS(t) : t.data.checkBox ? new fS(t) : new gS(t);
          case "Ch":
            return new mS(t);
          case "Sig":
            return new uS(t);
        }
        return new cl(t);
      case It.POPUP:
        return new Om(t);
      case It.FREETEXT:
        return new C0(t);
      case It.LINE:
        return new yS(t);
      case It.SQUARE:
        return new AS(t);
      case It.CIRCLE:
        return new wS(t);
      case It.POLYLINE:
        return new x0(t);
      case It.CARET:
        return new SS(t);
      case It.INK:
        return new $b(t);
      case It.POLYGON:
        return new vS(t);
      case It.HIGHLIGHT:
        return new T0(t);
      case It.UNDERLINE:
        return new ES(t);
      case It.SQUIGGLY:
        return new CS(t);
      case It.STRIKEOUT:
        return new xS(t);
      case It.STAMP:
        return new _0(t);
      case It.FILEATTACHMENT:
        return new TS(t);
      case It.RICHMEDIA:
      case It.SCREEN:
      case It.SOUND:
        return new k0(t);
      default:
        return new dt(t);
    }
  }
}
var Io, Mh, Bs, wu, Lm;
const zp = class zp {
  constructor(t, {
    isRenderable: e = !1,
    ignoreBorder: s = !1,
    createQuadrilaterals: n = !1
  } = {}) {
    g(this, wu);
    g(this, Io, null);
    g(this, Mh, !1);
    g(this, Bs, null);
    this.isRenderable = e, this.data = t.data, this.layer = t.layer, this.linkService = t.linkService, this.downloadManager = t.downloadManager, this.imageResourcesPath = t.imageResourcesPath, this.renderForms = t.renderForms, this.annotationStorage = t.annotationStorage, this.enableComment = t.enableComment, this.enableAnnotationEditing = t.enableAnnotationEditing !== !1, this.enableScripting = t.enableScripting, this.hasJSActions = t.hasJSActions, this._fieldObjects = t.fieldObjects, this.parent = t.parent, this.hasOwnCommentButton = !1, e && (this.contentElement = this.container = this._createContainer(s)), n && this._createQuadrilaterals();
  }
  static _hasPopupData({
    contentsObj: t,
    richText: e
  }) {
    return !!(t != null && t.str || e != null && e.str);
  }
  static get _svgFactory() {
    return L(this, "_svgFactory", new zb());
  }
  get _isEditable() {
    return this.enableAnnotationEditing && this.data.isEditable;
  }
  get hasPopupData() {
    return zp._hasPopupData(this.data) || this.enableComment && !!this.commentText;
  }
  get commentData() {
    var s;
    const {
      data: t
    } = this, e = (s = this.annotationStorage) == null ? void 0 : s.getEditor(t.id);
    return e ? e.getData() : t;
  }
  get hasCommentButton() {
    return this.enableComment && this.hasPopupElement;
  }
  get commentButtonPosition() {
    var o;
    const t = (o = this.annotationStorage) == null ? void 0 : o.getEditor(this.data.id);
    if (t)
      return t.commentButtonPositionInPage;
    const {
      quadPoints: e,
      inkLists: s,
      rect: n
    } = this.data;
    let r = -1 / 0, a = -1 / 0;
    if ((e == null ? void 0 : e.length) >= 8) {
      for (let l = 0; l < e.length; l += 8)
        e[l + 1] > a ? (a = e[l + 1], r = e[l + 2]) : e[l + 1] === a && (r = Math.max(r, e[l + 2]));
      return [r, a];
    }
    if ((s == null ? void 0 : s.length) >= 1) {
      for (const l of s)
        for (let h = 0, c = l.length; h < c; h += 2)
          l[h + 1] > a ? (a = l[h + 1], r = l[h]) : l[h + 1] === a && (r = Math.max(r, l[h]));
      if (r !== 1 / 0)
        return [r, a];
    }
    return n ? [n[2], n[3]] : null;
  }
  _normalizePoint(t) {
    const {
      page: {
        view: e
      },
      viewport: {
        rawDims: {
          pageWidth: s,
          pageHeight: n,
          pageX: r,
          pageY: a
        }
      }
    } = this.parent;
    return t[1] = e[3] - t[1] + e[1], t[0] = 100 * (t[0] - r) / s, t[1] = 100 * (t[1] - a) / n, t;
  }
  get commentText() {
    var e, s, n;
    const {
      data: t
    } = this;
    return ((s = (e = this.annotationStorage.getRawValue(`${dc}${t.id}`)) == null ? void 0 : e.popup) == null ? void 0 : s.contents) || ((n = t.contentsObj) == null ? void 0 : n.str) || "";
  }
  set commentText(t) {
    const {
      data: e
    } = this, s = {
      deleted: !t,
      contents: t || ""
    };
    this.annotationStorage.updateEditor(e.id, {
      popup: s
    }) || this.annotationStorage.setValue(`${dc}${e.id}`, {
      id: e.id,
      annotationType: e.annotationType,
      page: this.parent.page,
      popup: s,
      popupRef: e.popupRef,
      modificationDate: /* @__PURE__ */ new Date()
    }), t || this.removePopup();
  }
  removePopup() {
    var t, e;
    (e = ((t = i(this, Bs)) == null ? void 0 : t.popup) || this.popup) == null || e.remove(), u(this, Bs, this.popup = null);
  }
  updateEdited(t) {
    var r;
    if (!this.container)
      return;
    t.rect && (i(this, Io) || u(this, Io, {
      rect: this.data.rect.slice(0)
    }));
    const {
      rect: e,
      popup: s
    } = t;
    e && m(this, wu, Lm).call(this, e);
    let n = ((r = i(this, Bs)) == null ? void 0 : r.popup) || this.popup;
    !n && (s != null && s.text) && (this._createPopup(s), n = i(this, Bs).popup), n && (n.updateEdited(t), s != null && s.deleted && (n.remove(), u(this, Bs, null), this.popup = null));
  }
  resetEdited() {
    var t;
    i(this, Io) && (m(this, wu, Lm).call(this, i(this, Io).rect), (t = i(this, Bs)) == null || t.popup.resetEdited(), u(this, Io, null));
  }
  _createContainer(t) {
    const {
      data: e,
      parent: {
        page: s,
        viewport: n
      }
    } = this, r = document.createElement("section");
    r.setAttribute("data-annotation-id", e.id), !(this instanceof cl) && !(this instanceof Gb) && !(this instanceof k0) && (r.tabIndex = 0);
    const {
      style: a
    } = r;
    if (a.zIndex = this.parent.zIndex, this.parent.zIndex += 2, e.alternativeText && (r.title = e.alternativeText), e.noRotate && r.classList.add("norotate"), !e.rect || this instanceof Om) {
      const {
        rotation: A
      } = e;
      return !e.hasOwnCanvas && A !== 0 && this.setRotation(A, r), r;
    }
    const {
      width: o,
      height: l
    } = this;
    if (!t && e.borderStyle.width > 0) {
      a.borderWidth = `${e.borderStyle.width}px`;
      const A = e.borderStyle.horizontalCornerRadius, w = e.borderStyle.verticalCornerRadius;
      if (A > 0 || w > 0) {
        const S = `calc(${A}px * var(--total-scale-factor)) / calc(${w}px * var(--total-scale-factor))`;
        a.borderRadius = S;
      }
      switch (e.borderStyle.style) {
        case fl.SOLID:
          a.borderStyle = "solid";
          break;
        case fl.DASHED:
          a.borderStyle = "dashed";
          break;
        case fl.BEVELED:
          j("Unimplemented border style: beveled");
          break;
        case fl.INSET:
          j("Unimplemented border style: inset");
          break;
        case fl.UNDERLINE:
          a.borderBottomStyle = "solid";
          break;
      }
      const v = e.borderColor || null;
      v ? (u(this, Mh, !0), a.borderColor = I.makeHexColor(...v)) : a.borderWidth = 0;
    }
    const h = I.normalizeRect([e.rect[0], s.view[3] - e.rect[1] + s.view[1], e.rect[2], s.view[3] - e.rect[3] + s.view[1]]), {
      pageWidth: c,
      pageHeight: d,
      pageX: f,
      pageY: b
    } = n.rawDims;
    a.left = `${100 * (h[0] - f) / c}%`, a.top = `${100 * (h[1] - b) / d}%`;
    const {
      rotation: y
    } = e;
    return e.hasOwnCanvas || y === 0 ? (a.width = `${100 * o / c}%`, a.height = `${100 * l / d}%`) : this.setRotation(y, r), r;
  }
  setRotation(t, e = this.container) {
    if (!this.data.rect)
      return;
    const {
      pageWidth: s,
      pageHeight: n
    } = this.parent.viewport.rawDims;
    let {
      width: r,
      height: a
    } = this;
    t % 180 !== 0 && ([r, a] = [a, r]), e.style.width = `${100 * r / s}%`, e.style.height = `${100 * a / n}%`, e.setAttribute("data-main-rotation", (360 - t) % 360);
  }
  get _commonActions() {
    const t = (e, s, n) => {
      const r = n.detail[e], a = r[0], o = r.slice(1);
      n.target.style[s] = ky[`${a}_HTML`](o), this.annotationStorage.setValue(this.data.id, {
        [s]: ky[`${a}_rgb`](o)
      });
    };
    return L(this, "_commonActions", {
      display: (e) => {
        const {
          display: s
        } = e.detail, n = s % 2 === 1;
        this.container.style.visibility = n ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
          noView: n,
          noPrint: s === 1 || s === 2
        });
      },
      print: (e) => {
        this.annotationStorage.setValue(this.data.id, {
          noPrint: !e.detail.print
        });
      },
      hidden: (e) => {
        const {
          hidden: s
        } = e.detail;
        this.container.style.visibility = s ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
          noPrint: s,
          noView: s
        });
      },
      focus: (e) => {
        setTimeout(() => e.target.focus({
          preventScroll: !1
        }), 0);
      },
      userName: (e) => {
        e.target.title = e.detail.userName;
      },
      readonly: (e) => {
        e.target.disabled = e.detail.readonly;
      },
      required: (e) => {
        this._setRequired(e.target, e.detail.required);
      },
      bgColor: (e) => {
        t("bgColor", "backgroundColor", e);
      },
      fillColor: (e) => {
        t("fillColor", "backgroundColor", e);
      },
      fgColor: (e) => {
        t("fgColor", "color", e);
      },
      textColor: (e) => {
        t("textColor", "color", e);
      },
      borderColor: (e) => {
        t("borderColor", "borderColor", e);
      },
      strokeColor: (e) => {
        t("strokeColor", "borderColor", e);
      },
      rotation: (e) => {
        const s = e.detail.rotation;
        this.setRotation(s), this.annotationStorage.setValue(this.data.id, {
          rotation: s
        });
      }
    });
  }
  _dispatchEventFromSandbox(t, e) {
    const s = this._commonActions;
    for (const n of Object.keys(e.detail)) {
      const r = t[n] || s[n];
      r == null || r(e);
    }
  }
  _setDefaultPropertiesFromJS(t) {
    if (!this.enableScripting)
      return;
    const e = this.annotationStorage.getRawValue(this.data.id);
    if (!e)
      return;
    const s = this._commonActions;
    for (const [n, r] of Object.entries(e)) {
      const a = s[n];
      if (a) {
        const o = {
          detail: {
            [n]: r
          },
          target: t
        };
        a(o), delete e[n];
      }
    }
  }
  _createQuadrilaterals() {
    if (!this.container)
      return;
    const {
      quadPoints: t
    } = this.data;
    if (!t)
      return;
    const [e, s, n, r] = this.data.rect.map(Math.fround);
    if (t.length === 8) {
      const [A, w, v, S] = t.subarray(2, 6);
      if (n === A && r === w && e === v && s === S)
        return;
    }
    const {
      style: a
    } = this.container;
    let o;
    if (i(this, Mh)) {
      const {
        borderColor: A,
        borderWidth: w
      } = a;
      a.borderWidth = 0, o = ["url('data:image/svg+xml;utf8,", `<svg xmlns="${Re}" preserveAspectRatio="none" viewBox="0 0 1 1">`, `<g fill="transparent" stroke="${A}" stroke-width="${w}">`], this.container.classList.add("hasBorder");
    }
    const l = n - e, h = r - s, c = zp._svgFactory, d = c.createElement("svg");
    d.classList.add("quadrilateralsContainer"), d.setAttribute("width", 0), d.setAttribute("height", 0), d.role = "none";
    const f = c.createElement("defs");
    d.append(f);
    const b = c.createElement("clipPath"), y = `clippath_${this.data.id}`;
    b.setAttribute("id", y), b.setAttribute("clipPathUnits", "objectBoundingBox"), f.append(b);
    for (let A = 2, w = t.length; A < w; A += 8) {
      const v = t[A], S = t[A + 1], E = t[A + 2], C = t[A + 3], x = c.createElement("rect"), T = (E - e) / l, k = (r - S) / h, M = (v - E) / l, P = (S - C) / h;
      x.setAttribute("x", T), x.setAttribute("y", k), x.setAttribute("width", M), x.setAttribute("height", P), b.append(x), o == null || o.push(`<rect vector-effect="non-scaling-stroke" x="${T}" y="${k}" width="${M}" height="${P}"/>`);
    }
    i(this, Mh) && (o.push("</g></svg>')"), a.backgroundImage = o.join("")), this.container.append(d), this.container.style.clipPath = `url(#${y})`;
  }
  _createPopup(t = null) {
    const {
      data: e
    } = this;
    let s, n;
    t ? (s = {
      str: t.text
    }, n = t.date) : (s = e.contentsObj, n = e.modificationDate), u(this, Bs, new Om({
      data: {
        color: e.color,
        titleObj: e.titleObj,
        modificationDate: n,
        contentsObj: s,
        richText: e.richText,
        parentRect: e.rect,
        borderStyle: 0,
        id: `popup_${e.id}`,
        rotation: e.rotation,
        noRotate: !0
      },
      linkService: this.linkService,
      parent: this.parent,
      elements: [this]
    }));
  }
  get hasPopupElement() {
    return !!(i(this, Bs) || this.popup || this.data.popupRef);
  }
  get extraPopupElement() {
    return i(this, Bs);
  }
  render() {
    it("Abstract method `AnnotationElement.render` called");
  }
  _getElementsByName(t, e = null) {
    const s = [];
    if (this._fieldObjects) {
      const n = this._fieldObjects.get(t) || [];
      for (const {
        page: r,
        id: a,
        exportValues: o
      } of n) {
        if (r === -1 || a === e)
          continue;
        const l = typeof o == "string" ? o : null, h = document.querySelector(`[data-element-id="${a}"]`);
        if (h && !ol.has(h)) {
          j(`_getElementsByName - element not allowed: ${a}`);
          continue;
        }
        s.push({
          id: a,
          exportValue: l,
          domElement: h
        });
      }
      return s;
    }
    for (const n of document.getElementsByName(t)) {
      const {
        exportValue: r
      } = n, a = n.getAttribute("data-element-id");
      a === e || !ol.has(n) || s.push({
        id: a,
        exportValue: r,
        domElement: n
      });
    }
    return s;
  }
  show() {
    var t;
    this.container && (this.container.hidden = !1), (t = this.popup) == null || t.maybeShow();
  }
  hide() {
    var t;
    this.container && (this.container.hidden = !0), (t = this.popup) == null || t.forceHide();
  }
  getElementsToTriggerPopup() {
    return this.container;
  }
  addHighlightArea() {
    const t = this.getElementsToTriggerPopup();
    if (Array.isArray(t))
      for (const e of t)
        e.classList.add("highlightArea");
    else
      t.classList.add("highlightArea");
  }
  _editOnDoubleClick() {
    if (!this._isEditable)
      return;
    const {
      annotationEditorType: t,
      data: {
        id: e
      }
    } = this;
    this.container.addEventListener("dblclick", () => {
      var s;
      (s = this.linkService.eventBus) == null || s.dispatch("switchannotationeditormode", {
        source: this,
        mode: t,
        editId: e,
        mustEnterInEditMode: !0
      });
    });
  }
  updateOC(t) {
    if (!this.data.oc || !t)
      return;
    t.isVisible(this.data.oc) ? this.show() : this.hide();
  }
  get width() {
    return this.data.rect[2] - this.data.rect[0];
  }
  get height() {
    return this.data.rect[3] - this.data.rect[1];
  }
  _setBackgroundColor(t) {
    const e = this.data.backgroundColor || null;
    t.style.backgroundColor = e === null ? "transparent" : I.makeHexColor(...e);
  }
};
Io = new WeakMap(), Mh = new WeakMap(), Bs = new WeakMap(), wu = new WeakSet(), Lm = function(t) {
  const {
    container: {
      style: e
    },
    data: {
      rect: s,
      rotation: n
    },
    parent: {
      viewport: {
        rawDims: {
          pageWidth: r,
          pageHeight: a,
          pageX: o,
          pageY: l
        }
      }
    }
  } = this;
  s == null || s.splice(0, 4, ...t), e.left = `${100 * (t[0] - o) / r}%`, e.top = `${100 * (a - t[3] + l) / a}%`, n === 0 ? (e.width = `${100 * (t[2] - t[0]) / r}%`, e.height = `${100 * (t[3] - t[1]) / a}%`) : this.setRotation(n);
};
let dt = zp;
class hS extends dt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.editor = t.editor;
  }
  render() {
    return this.container.className = "editorAnnotation", this.container;
  }
  createOrUpdatePopup() {
    const {
      editor: t
    } = this;
    t.hasComment && this._createPopup(t.comment);
  }
  get hasCommentButton() {
    return this.enableComment && this.editor.hasComment;
  }
  get commentButtonPosition() {
    return this.editor.commentButtonPositionInPage;
  }
  get commentText() {
    return this.editor.comment.text;
  }
  set commentText(t) {
    this.editor.comment = t, t || this.removePopup();
  }
  get commentData() {
    return this.editor.getData();
  }
  remove() {
    this.parent.removeAnnotation(this.data.id), this.container.remove(), this.container = null, this.removePopup();
  }
}
var As, ba, y0, A0;
class Gb extends dt {
  constructor(e, s = null) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !!(s != null && s.ignoreBorder),
      createQuadrilaterals: !0
    });
    g(this, As);
    this.isTooltipOnly = e.data.isTooltipOnly;
  }
  render() {
    const {
      data: e,
      linkService: s
    } = this, n = document.createElement("a");
    n.setAttribute("data-element-id", e.id);
    let r = !1;
    return e.url ? (s.addLinkAttributes(n, e.url, e.newWindow), r = !0) : e.action ? (this._bindNamedAction(n, e.action, e.overlaidText), r = !0) : e.attachment ? (m(this, As, y0).call(this, n, e.attachmentId, e.attachment, e.overlaidText, e.attachmentDest), r = !0) : e.setOCGState ? (m(this, As, A0).call(this, n, e.setOCGState, e.overlaidText), r = !0) : e.dest ? (this._bindLink(n, e.dest, e.overlaidText), r = !0) : (e.actions && (e.actions.has("Action") || e.actions.has("Mouse Up") || e.actions.has("Mouse Down")) && this.enableScripting && this.hasJSActions && (this._bindJSAction(n, e), r = !0), e.resetForm ? (this._bindResetFormAction(n, e.resetForm), r = !0) : this.isTooltipOnly && !r && (this._bindLink(n, ""), r = !0)), this.container.classList.add("linkAnnotation"), r && (this.contentElement = n, this.container.append(n)), this.container;
  }
  _bindLink(e, s, n = "") {
    e.href = this.linkService.getDestinationHash(s), e.onclick = () => (s && this.linkService.goToDestination(s), !1), (s || s === "") && m(this, As, ba).call(this), n && (e.title = n);
  }
  _bindNamedAction(e, s, n = "") {
    e.href = this.linkService.getAnchorUrl(""), e.onclick = () => (this.linkService.executeNamedAction(s), !1), n && (e.title = n), m(this, As, ba).call(this);
  }
  _bindJSAction(e, {
    actions: s,
    id: n,
    overlaidText: r
  }) {
    e.href = this.linkService.getAnchorUrl("");
    const a = /* @__PURE__ */ new Map([["Action", "onclick"], ["Mouse Up", "onmouseup"], ["Mouse Down", "onmousedown"]]);
    for (const o of s.keys()) {
      const l = a.get(o);
      l && (e[l] = () => {
        var h;
        return (h = this.linkService.eventBus) == null || h.dispatch("dispatcheventinsandbox", {
          source: this,
          detail: {
            id: n,
            name: o
          }
        }), !1;
      });
    }
    r && (e.title = r), e.onclick || (e.onclick = () => !1), m(this, As, ba).call(this);
  }
  _bindResetFormAction(e, s) {
    const n = e.onclick;
    if (n || (e.href = this.linkService.getAnchorUrl("")), m(this, As, ba).call(this), !this._fieldObjects) {
      j('_bindResetFormAction - "resetForm" action not supported, ensure that the `fieldObjects` parameter is provided.'), n || (e.onclick = () => !1);
      return;
    }
    e.onclick = () => {
      var d;
      n == null || n();
      const {
        fields: r,
        refs: a,
        include: o
      } = s, l = [];
      if (r.length !== 0 || a.length !== 0) {
        const f = new Set(a);
        for (const y of r) {
          const A = this._fieldObjects.get(y) || [];
          for (const {
            id: w
          } of A)
            f.add(w);
        }
        const b = /* @__PURE__ */ new Map();
        for (const y of this._fieldObjects.values())
          for (const {
            id: A,
            kidIds: w
          } of y)
            w && b.set(A, w);
        for (const y of f)
          for (const A of b.get(y) || [])
            f.add(A);
        for (const y of this._fieldObjects.values())
          for (const A of y)
            f.has(A.id) === o && l.push(A);
      } else
        for (const f of this._fieldObjects.values())
          l.push(...f);
      const h = this.annotationStorage, c = [];
      for (const f of l) {
        const {
          id: b
        } = f;
        switch (c.push(b), f.type) {
          case "text": {
            const A = f.defaultValue || "";
            h.setValue(b, {
              value: A
            });
            break;
          }
          case "checkbox":
          case "radiobutton": {
            const A = f.defaultValue === f.exportValues;
            h.setValue(b, {
              value: A
            });
            break;
          }
          case "combobox":
          case "listbox": {
            const A = f.defaultValue || "";
            h.setValue(b, {
              value: A
            });
            break;
          }
          default:
            continue;
        }
        const y = document.querySelector(`[data-element-id="${b}"]`);
        if (y) {
          if (!ol.has(y)) {
            j(`_bindResetFormAction - element not allowed: ${b}`);
            continue;
          }
        } else continue;
        y.dispatchEvent(new Event("resetform"));
      }
      return this.enableScripting && ((d = this.linkService.eventBus) == null || d.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: "app",
          ids: c,
          name: "ResetForm"
        }
      })), !1;
    };
  }
}
As = new WeakSet(), ba = function() {
  this.container.setAttribute("data-internal-link", "");
}, y0 = function(e, s, n, r = "", a = null) {
  e.href = this.linkService.getAnchorUrl(""), n.description ? e.title = n.description : r && (e.title = r);
  const o = async () => {
    var h;
    const l = await this.linkService.getAttachmentContent(s);
    l && ((h = this.downloadManager) == null || h.openOrDownloadData(l, n.filename, a));
  };
  e.onclick = () => (o(), !1), m(this, As, ba).call(this);
}, A0 = function(e, s, n = "") {
  e.href = this.linkService.getAnchorUrl(""), e.onclick = () => (this.linkService.executeSetOCGState(s), !1), n && (e.title = n), m(this, As, ba).call(this);
};
class cS extends dt {
  constructor(t) {
    super(t, {
      isRenderable: !0
    });
  }
  render() {
    this.container.classList.add("textAnnotation");
    const t = document.createElement("img");
    return t.src = this.imageResourcesPath + "annotation-" + this.data.name.toLowerCase() + ".svg", t.setAttribute("data-l10n-id", "pdfjs-text-annotation-type"), t.setAttribute("data-l10n-args", JSON.stringify({
      type: this.data.name
    })), !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.append(t), this.container;
  }
}
class cl extends dt {
  render() {
    return this.container;
  }
  _getKeyModifier(t) {
    return ot.platform.isMac ? t.metaKey : t.ctrlKey;
  }
  _setEventListener(t, e, s, n, r) {
    s.includes("mouse") ? t.addEventListener(s, (a) => {
      var o;
      (o = this.linkService.eventBus) == null || o.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: this.data.id,
          name: n,
          value: r(a),
          shift: a.shiftKey,
          modifier: this._getKeyModifier(a)
        }
      });
    }) : t.addEventListener(s, (a) => {
      var o;
      if (s === "blur") {
        if (!e.focused || !a.relatedTarget)
          return;
        e.focused = !1;
      } else if (s === "focus") {
        if (e.focused)
          return;
        e.focused = !0;
      }
      r && ((o = this.linkService.eventBus) == null || o.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: this.data.id,
          name: n,
          value: r(a)
        }
      }));
    });
  }
  _setEventListeners(t, e, s, n) {
    const {
      actions: r
    } = this.data;
    for (const [a, o] of s)
      (o === "Action" || r != null && r.has(o)) && ((o === "Focus" || o === "Blur") && (e || (e = {
        focused: !1
      })), this._setEventListener(t, e, a, o, n), o === "Focus" && !(r != null && r.has("Blur")) ? this._setEventListener(t, e, "blur", "Blur", null) : o === "Blur" && !(r != null && r.has("Focus")) && this._setEventListener(t, e, "focus", "Focus", null));
  }
  _setTextStyle(t) {
    const e = ["left", "center", "right"], {
      fontColor: s
    } = this.data.defaultAppearanceData, n = this.data.defaultAppearanceData.fontSize || oS, r = t.style;
    let a;
    const o = 2, l = (h) => Math.round(10 * h) / 10;
    if (this.data.multiLine) {
      const h = Math.abs(this.data.rect[3] - this.data.rect[1] - o), c = Math.round(h / /* inlined export .LINE_FACTOR */
      (1.35 * n)) || 1, d = h / c;
      a = Math.min(n, l(d / /* inlined export .LINE_FACTOR */
      1.35));
    } else {
      const h = Math.abs(this.data.rect[3] - this.data.rect[1] - o);
      a = Math.min(n, l(h / /* inlined export .LINE_FACTOR */
      1.35));
    }
    r.fontSize = `calc(${a}px * var(--total-scale-factor))`, r.color = I.makeHexColor(...s), this.data.textAlignment !== null && !this.data.comb && (r.textAlign = e[this.data.textAlignment]);
  }
  _setRequired(t, e) {
    e ? t.setAttribute("required", !0) : t.removeAttribute("required"), t.setAttribute("aria-required", e);
  }
}
class dS extends cl {
  constructor(t) {
    const e = t.renderForms || t.data.hasOwnCanvas || !t.data.hasAppearance && !!t.data.fieldValue;
    super(t, {
      isRenderable: e
    });
  }
  setPropertyOnSiblings(t, e, s, n) {
    const r = this.annotationStorage;
    for (const a of this._getElementsByName(t.name, t.id))
      a.domElement && (a.domElement[e] = s), r.setValue(a.id, {
        [n]: s
      });
  }
  render() {
    var n, r;
    const t = this.annotationStorage, e = this.data.id;
    this.container.classList.add("textWidgetAnnotation");
    let s = null;
    if (this.renderForms) {
      const a = t.getValue(e, {
        value: this.data.fieldValue
      });
      let o = a.value || "";
      const l = t.getValue(e, {
        charLimit: this.data.maxLen
      }).charLimit;
      l && o.length > l && (o = o.slice(0, l));
      let h = a.formattedValue || ((n = this.data.textContent) == null ? void 0 : n.join(`
`)) || null;
      h && this.data.comb && (h = h.replaceAll(/\s+/g, ""));
      const c = {
        userValue: o,
        formattedValue: h,
        lastCommittedValue: null,
        commitKey: 1,
        focused: !1
      };
      this.data.multiLine ? (s = document.createElement("textarea"), s.textContent = h ?? o, this.data.doNotScroll && (s.style.overflowY = "hidden")) : (s = document.createElement("input"), s.type = this.data.password ? "password" : "text", s.setAttribute("value", h ?? o), this.data.doNotScroll && (s.style.overflowX = "hidden")), this.data.hasOwnCanvas && (this.container.classList.add("hasOwnCanvas"), t.has(e) && this.container.classList.add("sandboxModified")), ol.add(s), this.contentElement = s, s.setAttribute("data-element-id", e), s.disabled = this.data.readOnly, s.name = this.data.fieldName, s.tabIndex = 0;
      const {
        datetimeFormat: d,
        datetimeType: f,
        timeStep: b
      } = this.data, y = !!f && this.enableScripting;
      d && (s.title = d), this._setRequired(s, this.data.required), l && (s.maxLength = l), s.addEventListener("input", (w) => {
        t.setValue(e, {
          value: w.target.value
        }), this.setPropertyOnSiblings(s, "value", w.target.value, "value"), c.formattedValue = null;
      }), s.addEventListener("resetform", (w) => {
        const v = this.data.defaultFieldValue ?? "";
        s.value = c.userValue = v, c.formattedValue = null;
      });
      let A = (w) => {
        const {
          formattedValue: v
        } = c;
        v != null && (w.target.value = v), w.target.scrollLeft = 0;
      };
      if (this.enableScripting && this.hasJSActions) {
        s.addEventListener("focus", (v) => {
          var E;
          if (c.focused)
            return;
          const {
            target: S
          } = v;
          if (y && (S.type = f, b && (S.step = b)), c.userValue) {
            const C = c.userValue;
            if (y)
              if (f === "time") {
                const x = new Date(C), T = [x.getHours(), x.getMinutes(), x.getSeconds()];
                S.value = T.map((k) => k.toString().padStart(2, "0")).join(":");
              } else
                S.value = new Date(C - lS).toISOString().split(f === "date" ? "T" : ".", 1)[0];
            else
              S.value = C;
          }
          c.lastCommittedValue = S.value, c.commitKey = 1, (E = this.data.actions) != null && E.has("Focus") || (c.focused = !0);
        }), s.addEventListener("updatefromsandbox", (v) => {
          this.container.classList.add("sandboxModified");
          const S = {
            value(E) {
              c.userValue = E.detail.value ?? "", y || t.setValue(e, {
                value: c.userValue.toString()
              }), E.target.value = c.userValue;
            },
            formattedValue(E) {
              const {
                formattedValue: C
              } = E.detail;
              c.formattedValue = C, C != null && E.target !== document.activeElement && (E.target.value = C);
              const x = {
                formattedValue: C
              };
              y && (x.value = C), t.setValue(e, x);
            },
            selRange(E) {
              E.target.setSelectionRange(...E.detail.selRange);
            },
            charLimit: (E) => {
              var k;
              const {
                charLimit: C
              } = E.detail, {
                target: x
              } = E;
              if (C === 0) {
                x.removeAttribute("maxLength");
                return;
              }
              x.setAttribute("maxLength", C);
              let T = c.userValue;
              !T || T.length <= C || (T = T.slice(0, C), x.value = c.userValue = T, t.setValue(e, {
                value: T
              }), (k = this.linkService.eventBus) == null || k.dispatch("dispatcheventinsandbox", {
                source: this,
                detail: {
                  id: e,
                  name: "Keystroke",
                  value: T,
                  willCommit: !0,
                  commitKey: 1,
                  selStart: x.selectionStart,
                  selEnd: x.selectionEnd
                }
              }));
            }
          };
          this._dispatchEventFromSandbox(S, v);
        }), s.addEventListener("keydown", (v) => {
          var C;
          c.commitKey = 1;
          let S = -1;
          if (v.key === "Escape" ? S = 0 : v.key === "Enter" && !this.data.multiLine ? S = 2 : v.key === "Tab" && (c.commitKey = 3), S === -1)
            return;
          const {
            value: E
          } = v.target;
          c.lastCommittedValue !== E && (c.lastCommittedValue = E, c.userValue = E, (C = this.linkService.eventBus) == null || C.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: E,
              willCommit: !0,
              commitKey: S,
              selStart: v.target.selectionStart,
              selEnd: v.target.selectionEnd
            }
          }));
        });
        const w = A;
        A = null, s.addEventListener("blur", (v) => {
          var C, x;
          if (!c.focused || !v.relatedTarget)
            return;
          (C = this.data.actions) != null && C.has("Blur") || (c.focused = !1);
          const {
            target: S
          } = v;
          let {
            value: E
          } = S;
          if (y) {
            if (E && f === "time") {
              const T = E.split(":").map((k) => parseInt(k, 10));
              E = new Date(2e3, 0, 1, T[0], T[1], T[2] || 0).valueOf(), S.step = "";
            } else
              E.includes("T") || (E = `${E}T00:00`), E = new Date(E).valueOf();
            S.type = "text";
          }
          c.userValue = E, c.lastCommittedValue !== E && ((x = this.linkService.eventBus) == null || x.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: E,
              willCommit: !0,
              commitKey: c.commitKey,
              selStart: v.target.selectionStart,
              selEnd: v.target.selectionEnd
            }
          })), w(v);
        }), (r = this.data.actions) != null && r.has("Keystroke") && s.addEventListener("beforeinput", (v) => {
          var P;
          c.lastCommittedValue = null;
          const {
            data: S,
            target: E
          } = v, {
            value: C,
            selectionStart: x,
            selectionEnd: T
          } = E;
          let k = x, M = T;
          switch (v.inputType) {
            case "deleteWordBackward": {
              const D = /\w/;
              for (; k > 0 && !D.test(C[k - 1]); )
                k--;
              for (; k > 0 && D.test(C[k - 1]); )
                k--;
              break;
            }
            case "deleteWordForward": {
              const D = C.substring(x).match(/^\W*\w*/);
              D && (M += D[0].length);
              break;
            }
            case "deleteContentBackward":
              x === T && (k -= 1);
              break;
            case "deleteContentForward":
              x === T && (M += 1);
              break;
          }
          v.preventDefault(), (P = this.linkService.eventBus) == null || P.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: C,
              change: S || "",
              willCommit: !1,
              selStart: k,
              selEnd: M
            }
          });
        }), this._setEventListeners(s, c, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (v) => v.target.value);
      }
      if (A && s.addEventListener("blur", A), this.data.comb) {
        const v = (this.data.rect[2] - this.data.rect[0]) / l;
        s.classList.add("comb"), s.style.setProperty("--comb-width", `calc(${v}px * var(--total-scale-factor))`);
        const S = this.data.textAlignment;
        if (S === 1 || S === 2) {
          const E = () => {
            const C = l - s.value.length;
            s.style.setProperty("--comb-offset", `${S === 1 ? C >> 1 : C}`);
          };
          E();
          for (const C of ["input", "blur", "resetform", "updatefromsandbox"])
            s.addEventListener(C, E);
        }
      }
    } else
      s = document.createElement("div"), s.textContent = this.data.fieldValue, s.style.verticalAlign = "middle", s.style.display = "table-cell", this.data.hasOwnCanvas && (s.hidden = !0);
    return this._setTextStyle(s), this._setBackgroundColor(s), this._setDefaultPropertiesFromJS(s), this.container.append(s), this.container;
  }
}
class uS extends cl {
  constructor(t) {
    super(t, {
      isRenderable: !!t.data.hasOwnCanvas
    });
  }
}
class fS extends cl {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    const t = this.annotationStorage, e = this.data, s = e.id;
    let n = t.getValue(s, {
      value: e.exportValue === e.fieldValue
    }).value;
    typeof n == "string" && (n = n !== "Off", t.setValue(s, {
      value: n
    })), this.container.classList.add("buttonWidgetAnnotation", "checkBox");
    const r = document.createElement("input");
    return ol.add(r), r.setAttribute("data-element-id", s), r.disabled = e.readOnly, this._setRequired(r, this.data.required), r.type = "checkbox", r.name = e.fieldName, n && r.setAttribute("checked", !0), r.setAttribute("exportValue", e.exportValue), r.tabIndex = 0, r.addEventListener("change", (a) => {
      const {
        name: o,
        checked: l
      } = a.target;
      for (const h of this._getElementsByName(o, s)) {
        const c = l && h.exportValue === e.exportValue;
        h.domElement && (h.domElement.checked = c), t.setValue(h.id, {
          value: c
        });
      }
      t.setValue(s, {
        value: l
      });
    }), r.addEventListener("resetform", (a) => {
      const o = e.defaultFieldValue || "Off";
      a.target.checked = o === e.exportValue;
    }), this.enableScripting && this.hasJSActions && (r.addEventListener("updatefromsandbox", (a) => {
      const o = {
        value(l) {
          l.target.checked = l.detail.value !== "Off", t.setValue(s, {
            value: l.target.checked
          });
        }
      };
      this._dispatchEventFromSandbox(o, a);
    }), this._setEventListeners(r, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (a) => a.target.checked)), this._setDefaultPropertiesFromJS(r), this.container.append(r), this.container;
  }
}
class pS extends cl {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    this.container.classList.add("buttonWidgetAnnotation", "radioButton");
    const t = this.annotationStorage, e = this.data, s = e.id;
    let n = t.getValue(s, {
      value: e.buttonValue !== null && e.fieldValue === e.buttonValue
    }).value;
    if (typeof n == "string" && (n = n !== e.buttonValue, t.setValue(s, {
      value: n
    })), n)
      for (const a of this._getElementsByName(e.fieldName, s))
        t.setValue(a.id, {
          value: !1
        });
    const r = document.createElement("input");
    if (ol.add(r), r.setAttribute("data-element-id", s), r.disabled = e.readOnly, this._setRequired(r, this.data.required), r.type = "radio", r.name = e.fieldName, n && r.setAttribute("checked", !0), r.tabIndex = 0, r.addEventListener("change", (a) => {
      const {
        name: o,
        checked: l
      } = a.target;
      for (const h of this._getElementsByName(o, s))
        t.setValue(h.id, {
          value: !1
        });
      t.setValue(s, {
        value: l
      });
    }), r.addEventListener("resetform", (a) => {
      const o = e.defaultFieldValue;
      a.target.checked = o != null && o === e.buttonValue;
    }), this.enableScripting && this.hasJSActions) {
      const a = e.buttonValue;
      r.addEventListener("updatefromsandbox", (o) => {
        const l = {
          value: (h) => {
            const c = a === h.detail.value;
            for (const d of this._getElementsByName(h.target.name)) {
              const f = c && d.id === s;
              d.domElement && (d.domElement.checked = f), t.setValue(d.id, {
                value: f
              });
            }
          }
        };
        this._dispatchEventFromSandbox(l, o);
      }), this._setEventListeners(r, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (o) => o.target.checked);
    }
    return this._setDefaultPropertiesFromJS(r), this.container.append(r), this.container;
  }
}
class gS extends Gb {
  constructor(t) {
    super(t, {
      ignoreBorder: t.data.hasAppearance
    });
  }
  render() {
    const t = super.render();
    t.classList.add("buttonWidgetAnnotation", "pushButton");
    const e = t.lastChild;
    return this.enableScripting && this.hasJSActions && e && (this._setDefaultPropertiesFromJS(e), e.addEventListener("updatefromsandbox", (s) => {
      this._dispatchEventFromSandbox({}, s);
    })), t;
  }
}
class mS extends cl {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    this.container.classList.add("choiceWidgetAnnotation");
    const t = this.annotationStorage, e = this.data.id, s = t.getValue(e, {
      value: this.data.fieldValue
    }), n = document.createElement("select");
    ol.add(n), n.setAttribute("data-element-id", e), n.disabled = this.data.readOnly, this._setRequired(n, this.data.required), n.name = this.data.fieldName, n.tabIndex = 0;
    let r = this.data.combo && this.data.options.length > 0;
    this.data.combo || (n.size = this.data.options.length, this.data.multiSelect && (n.multiple = !0)), n.addEventListener("resetform", (d) => {
      const f = this.data.defaultFieldValue;
      for (const b of n.options)
        b.selected = b.value === f;
    });
    const a = (d, f) => {
      const b = f.replaceAll(" ", " ");
      d.textContent = b, b !== f && d.setAttribute("display-value", f);
    };
    for (const d of this.data.options) {
      const f = document.createElement("option");
      a(f, d.displayValue), f.value = d.exportValue, s.value.includes(d.exportValue) && (f.setAttribute("selected", !0), r = !1), n.append(f);
    }
    let o = null;
    if (r) {
      const d = document.createElement("option");
      d.value = " ", d.setAttribute("hidden", !0), d.setAttribute("selected", !0), n.prepend(d), o = () => {
        d.remove(), n.removeEventListener("input", o), o = null;
      }, n.addEventListener("input", o);
    }
    const l = (d) => {
      const f = d ? "value" : "textContent", {
        options: b,
        multiple: y
      } = n;
      return y ? Array.prototype.filter.call(b, (A) => A.selected).map((A) => A[f]) : b.selectedIndex === -1 ? null : b[b.selectedIndex][f];
    };
    let h = l(!1);
    const c = (d) => {
      const f = d.target.options;
      return Array.prototype.map.call(f, (b) => ({
        displayValue: b.getAttribute("display-value") || b.textContent,
        exportValue: b.value
      }));
    };
    return this.enableScripting && this.hasJSActions ? (n.addEventListener("updatefromsandbox", (d) => {
      const f = {
        value(b) {
          o == null || o();
          const y = b.detail.value, A = new Set(Array.isArray(y) ? y : [y]);
          for (const w of n.options)
            w.selected = A.has(w.value);
          t.setValue(e, {
            value: l(!0)
          }), h = l(!1);
        },
        multipleSelection(b) {
          n.multiple = !0;
        },
        remove(b) {
          const y = n.options, A = b.detail.remove;
          y[A].selected = !1, n.remove(A), y.length > 0 && Array.prototype.findIndex.call(y, (v) => v.selected) === -1 && (y[0].selected = !0), t.setValue(e, {
            value: l(!0),
            items: c(b)
          }), h = l(!1);
        },
        clear(b) {
          for (; n.length !== 0; )
            n.remove(0);
          t.setValue(e, {
            value: null,
            items: []
          }), h = l(!1);
        },
        insert(b) {
          const {
            index: y,
            displayValue: A,
            exportValue: w
          } = b.detail.insert, v = n.children[y], S = document.createElement("option");
          a(S, A), S.value = w, v ? v.before(S) : n.append(S), t.setValue(e, {
            value: l(!0),
            items: c(b)
          }), h = l(!1);
        },
        items(b) {
          const {
            items: y
          } = b.detail;
          for (; n.length !== 0; )
            n.remove(0);
          for (const A of y) {
            const {
              displayValue: w,
              exportValue: v
            } = A, S = document.createElement("option");
            a(S, w), S.value = v, n.append(S);
          }
          n.options.length > 0 && (n.options[0].selected = !0), t.setValue(e, {
            value: l(!0),
            items: c(b)
          }), h = l(!1);
        },
        indices(b) {
          const y = new Set(b.detail.indices);
          for (const A of b.target.options)
            A.selected = y.has(A.index);
          t.setValue(e, {
            value: l(!0)
          }), h = l(!1);
        },
        editable(b) {
          b.target.disabled = !b.detail.editable;
        }
      };
      this._dispatchEventFromSandbox(f, d);
    }), n.addEventListener("input", (d) => {
      var y;
      const f = l(!0), b = l(!1);
      t.setValue(e, {
        value: f
      }), d.preventDefault(), (y = this.linkService.eventBus) == null || y.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: e,
          name: "Keystroke",
          value: h,
          change: b,
          changeEx: f,
          willCommit: !1,
          commitKey: 1,
          keyDown: !1
        }
      });
    }), this._setEventListeners(n, null, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"], ["input", "Action"], ["input", "Validate"]], (d) => d.target.value)) : n.addEventListener("input", function(d) {
      t.setValue(e, {
        value: l(!0)
      });
    }), this.data.combo && this._setTextStyle(n), this._setBackgroundColor(n), this._setDefaultPropertiesFromJS(n), this.container.append(n), this.container;
  }
}
var vu, Rm;
class Om extends dt {
  constructor(e) {
    const {
      data: s,
      elements: n,
      parent: r
    } = e, a = !!r._commentManager;
    super(e, {
      isRenderable: !a && dt._hasPopupData(s)
    });
    g(this, vu);
    if (this.elements = n, a && dt._hasPopupData(s)) {
      const o = this.popup = m(this, vu, Rm).call(this);
      for (const l of n)
        l.popup = o;
    } else
      this.popup = null;
  }
  render() {
    const {
      container: e
    } = this;
    e.classList.add("popupAnnotation"), e.role = "comment";
    const s = this.popup = m(this, vu, Rm).call(this), n = [];
    for (const r of this.elements)
      r.popup = s, r.container.ariaHasPopup = "dialog", n.push(r.data.id), r.addHighlightArea();
    return this.container.setAttribute("aria-controls", n.map((r) => `${ml}${r}`).join(",")), this.container;
  }
}
vu = new WeakSet(), Rm = function() {
  return new bS({
    container: this.container,
    color: this.data.color,
    titleObj: this.data.titleObj,
    modificationDate: this.data.modificationDate || this.data.creationDate,
    contentsObj: this.data.contentsObj,
    richText: this.data.richText,
    rect: this.data.rect,
    parentRect: this.data.parentRect || null,
    parent: this.parent,
    elements: this.elements,
    open: this.data.open,
    commentManager: this.parent._commentManager
  });
};
var os, Hr, Gp, $p, Dh, Ih, zt, Ni, Ur, Fo, Fh, Lh, Bi, ls, In, Fn, Gt, Ln, zr, Su, On, Oh, Lo, Gr, oe, $r, J, Nf, Nm, Bm, Hm, Bf, Um, w0, v0, S0, E0, Hf, Uf, zm;
class bS {
  constructor({
    container: t,
    color: e,
    elements: s,
    titleObj: n,
    modificationDate: r,
    contentsObj: a,
    richText: o,
    parent: l,
    rect: h,
    parentRect: c,
    open: d,
    commentManager: f = null
  }) {
    g(this, J);
    g(this, os, null);
    g(this, Hr, m(this, J, S0).bind(this));
    g(this, Gp, m(this, J, zm).bind(this));
    g(this, $p, m(this, J, Uf).bind(this));
    g(this, Dh, m(this, J, Hf).bind(this));
    g(this, Ih, null);
    g(this, zt, null);
    g(this, Ni, null);
    g(this, Ur, null);
    g(this, Fo, null);
    g(this, Fh, null);
    g(this, Lh, null);
    g(this, Bi, !1);
    g(this, ls, null);
    g(this, In, null);
    g(this, Fn, null);
    g(this, Gt, null);
    g(this, Ln, null);
    g(this, zr, null);
    g(this, Su, null);
    g(this, On, null);
    g(this, Oh, null);
    g(this, Lo, null);
    g(this, Gr, !1);
    g(this, oe, null);
    g(this, $r, null);
    u(this, zt, t), u(this, Oh, n), u(this, Ni, a), u(this, On, o), u(this, Fh, l), u(this, Ih, e), u(this, Su, h), u(this, Lh, c), u(this, Fo, s), u(this, os, f), u(this, oe, s[0]), u(this, Ur, lp.toDateObject(r)), this.trigger = s.flatMap((b) => b.getElementsToTriggerPopup()), f || (m(this, J, Nf).call(this), i(this, zt).hidden = !0, d && m(this, J, Hf).call(this));
  }
  renderCommentButton() {
    if (i(this, Gt)) {
      i(this, Gt).parentNode || i(this, oe).container.after(i(this, Gt));
      return;
    }
    if (i(this, Ln) || m(this, J, Nm).call(this), !i(this, Ln))
      return;
    const {
      signal: t
    } = u(this, In, new AbortController()), e = i(this, oe).hasOwnCommentButton, s = () => {
      i(this, os).toggleCommentPopup(this, !0, void 0, !e);
    }, n = () => {
      i(this, os).toggleCommentPopup(this, !1, !0, !e);
    }, r = () => {
      i(this, os).toggleCommentPopup(this, !1, !1);
    };
    if (e) {
      u(this, Gt, i(this, oe).container);
      for (const a of this.trigger)
        a.ariaHasPopup = "dialog", a.ariaControls = "commentPopup", a.addEventListener("keydown", i(this, Hr), {
          signal: t
        }), a.addEventListener("click", s, {
          signal: t
        }), a.addEventListener("pointerenter", n, {
          signal: t
        }), a.addEventListener("pointerleave", r, {
          signal: t
        }), a.classList.add("popupTriggerArea");
    } else {
      const a = u(this, Gt, document.createElement("button"));
      a.className = "annotationCommentButton";
      const o = i(this, oe).container;
      a.style.zIndex = parseInt(o.style.zIndex, 10) + 1, a.tabIndex = 0, a.ariaHasPopup = "dialog", a.ariaControls = "commentPopup", a.setAttribute("data-l10n-id", "pdfjs-show-comment-button"), m(this, J, Hm).call(this), m(this, J, Bm).call(this), a.addEventListener("keydown", i(this, Hr), {
        signal: t
      }), a.addEventListener("click", s, {
        signal: t
      }), a.addEventListener("pointerenter", n, {
        signal: t
      }), a.addEventListener("pointerleave", r, {
        signal: t
      }), o.after(a);
    }
  }
  get commentButtonColor() {
    const {
      color: t,
      opacity: e
    } = i(this, oe).commentData;
    return t ? i(this, Fh)._commentManager.makeCommentColor(t, e) : null;
  }
  focusCommentButton() {
    setTimeout(() => {
      var t;
      (t = i(this, Gt)) == null || t.focus();
    }, 0);
  }
  getData() {
    const {
      richText: t,
      color: e,
      opacity: s,
      creationDate: n,
      modificationDate: r
    } = i(this, oe).commentData;
    return {
      contentsObj: {
        str: this.comment
      },
      richText: t,
      color: e,
      opacity: s,
      creationDate: n,
      modificationDate: r
    };
  }
  get elementBeforePopup() {
    return i(this, Gt);
  }
  get comment() {
    return i(this, $r) || u(this, $r, i(this, oe).commentText), i(this, $r);
  }
  set comment(t) {
    t !== this.comment && (i(this, oe).commentText = u(this, $r, t));
  }
  focus() {
    var t;
    (t = i(this, oe).container) == null || t.focus();
  }
  get parentBoundingClientRect() {
    return i(this, oe).layer.getBoundingClientRect();
  }
  setCommentButtonStates({
    selected: t,
    hasPopup: e
  }) {
    i(this, Gt) && (i(this, Gt).classList.toggle("selected", t), i(this, Gt).ariaExpanded = e);
  }
  setSelectedCommentButton(t) {
    i(this, Gt).classList.toggle("selected", t);
  }
  get commentPopupPosition() {
    if (i(this, zr))
      return i(this, zr);
    const {
      x: t,
      y: e,
      height: s
    } = i(this, Gt).getBoundingClientRect(), {
      x: n,
      y: r,
      width: a,
      height: o
    } = i(this, oe).layer.getBoundingClientRect();
    return [(t - n) / a, (e + s - r) / o];
  }
  set commentPopupPosition(t) {
    u(this, zr, t);
  }
  hasDefaultPopupPosition() {
    return i(this, zr) === null;
  }
  get commentButtonPosition() {
    return i(this, Ln);
  }
  get commentButtonWidth() {
    return i(this, Gt).getBoundingClientRect().width / this.parentBoundingClientRect.width;
  }
  editComment(t) {
    const [e, s] = i(this, zr) || this.commentButtonPosition.map((h) => h / 100), n = this.parentBoundingClientRect, {
      x: r,
      y: a,
      width: o,
      height: l
    } = n;
    i(this, os).showDialog(null, this, r + e * o, a + s * l, {
      ...t,
      parentDimensions: n
    });
  }
  render() {
    var s, n;
    if (i(this, ls))
      return;
    const t = u(this, ls, document.createElement("div"));
    if (t.className = "popup", i(this, Ih)) {
      const r = t.style.outlineColor = I.makeHexColor(...i(this, Ih));
      t.style.backgroundColor = `color-mix(in srgb, ${r} 30%, white)`;
    }
    const e = document.createElement("span");
    if (e.className = "header", (s = i(this, Oh)) != null && s.str) {
      const r = document.createElement("span");
      r.className = "title", e.append(r), {
        dir: r.dir,
        str: r.textContent
      } = i(this, Oh);
    }
    if (t.append(e), i(this, Ur)) {
      const r = document.createElement("time");
      r.className = "popupDate", r.setAttribute("data-l10n-id", "pdfjs-annotation-date-time-string"), r.setAttribute("data-l10n-args", JSON.stringify({
        dateObj: i(this, Ur).valueOf()
      })), r.dateTime = i(this, Ur).toISOString(), e.append(r);
    }
    By({
      html: i(this, J, Bf) || i(this, Ni).str,
      dir: (n = i(this, Ni)) == null ? void 0 : n.dir,
      className: "popupContent"
    }, t), i(this, zt).append(t);
  }
  updateEdited({
    rect: t,
    popup: e,
    deleted: s
  }) {
    var n;
    if (i(this, os)) {
      s ? (this.remove(), u(this, $r, null)) : e && (e.deleted ? this.remove() : (m(this, J, Hm).call(this), u(this, $r, e.text))), t && (u(this, Ln, null), m(this, J, Nm).call(this), m(this, J, Bm).call(this));
      return;
    }
    if (s || e != null && e.deleted) {
      this.remove();
      return;
    }
    m(this, J, Nf).call(this), i(this, Lo) || u(this, Lo, {
      contentsObj: i(this, Ni),
      richText: i(this, On)
    }), t && u(this, Fn, null), e && e.text && (u(this, On, m(this, J, v0).call(this, e.text)), u(this, Ur, lp.toDateObject(e.date)), u(this, Ni, null)), (n = i(this, ls)) == null || n.remove(), u(this, ls, null);
  }
  resetEdited() {
    var t;
    i(this, Lo) && ({
      contentsObj: rt(this, Ni)._,
      richText: rt(this, On)._
    } = i(this, Lo), u(this, Lo, null), (t = i(this, ls)) == null || t.remove(), u(this, ls, null), u(this, Fn, null));
  }
  remove() {
    var t, e, s;
    if ((t = i(this, In)) == null || t.abort(), u(this, In, null), (e = i(this, ls)) == null || e.remove(), u(this, ls, null), u(this, Gr, !1), u(this, Bi, !1), (s = i(this, Gt)) == null || s.remove(), u(this, Gt, null), this.trigger)
      for (const n of this.trigger)
        n.classList.remove("popupTriggerArea");
  }
  forceHide() {
    u(this, Gr, this.isVisible), i(this, Gr) && (i(this, zt).hidden = !0);
  }
  maybeShow() {
    i(this, os) || (m(this, J, Nf).call(this), i(this, Gr) && (i(this, ls) || m(this, J, Uf).call(this), u(this, Gr, !1), i(this, zt).hidden = !1));
  }
  get isVisible() {
    return !i(this, os) && i(this, zt).hidden === !1;
  }
}
os = new WeakMap(), Hr = new WeakMap(), Gp = new WeakMap(), $p = new WeakMap(), Dh = new WeakMap(), Ih = new WeakMap(), zt = new WeakMap(), Ni = new WeakMap(), Ur = new WeakMap(), Fo = new WeakMap(), Fh = new WeakMap(), Lh = new WeakMap(), Bi = new WeakMap(), ls = new WeakMap(), In = new WeakMap(), Fn = new WeakMap(), Gt = new WeakMap(), Ln = new WeakMap(), zr = new WeakMap(), Su = new WeakMap(), On = new WeakMap(), Oh = new WeakMap(), Lo = new WeakMap(), Gr = new WeakMap(), oe = new WeakMap(), $r = new WeakMap(), J = new WeakSet(), Nf = function() {
  var e;
  if (i(this, In))
    return;
  u(this, In, new AbortController());
  const {
    signal: t
  } = i(this, In);
  for (const s of this.trigger)
    s.addEventListener("click", i(this, Dh), {
      signal: t
    }), s.addEventListener("pointerenter", i(this, $p), {
      signal: t
    }), s.addEventListener("pointerleave", i(this, Gp), {
      signal: t
    }), s.classList.add("popupTriggerArea");
  for (const s of i(this, Fo))
    (e = s.container) == null || e.addEventListener("keydown", i(this, Hr), {
      signal: t
    });
}, Nm = function() {
  const t = i(this, Fo).find((e) => e.hasCommentButton);
  t && u(this, Ln, t._normalizePoint(t.commentButtonPosition));
}, Bm = function() {
  if (i(this, oe).extraPopupElement && !i(this, oe).editor)
    return;
  i(this, Gt) || this.renderCommentButton();
  const [t, e] = i(this, Ln), {
    style: s
  } = i(this, Gt);
  s.left = `calc(${t}%)`, s.top = `calc(${e}% - var(--comment-button-dim))`;
}, Hm = function() {
  i(this, oe).extraPopupElement || (i(this, Gt) || this.renderCommentButton(), i(this, Gt).style.backgroundColor = this.commentButtonColor || "");
}, Bf = function() {
  const t = i(this, On), e = i(this, Ni);
  return t != null && t.str && (!(e != null && e.str) || e.str === t.str) && i(this, On).html || null;
}, Um = function() {
  var t, e, s;
  return ((s = (e = (t = i(this, J, Bf)) == null ? void 0 : t.attributes) == null ? void 0 : e.style) == null ? void 0 : s.fontSize) || 0;
}, w0 = function() {
  var t, e, s;
  return ((s = (e = (t = i(this, J, Bf)) == null ? void 0 : t.attributes) == null ? void 0 : e.style) == null ? void 0 : s.color) || null;
}, v0 = function(t) {
  const e = [], s = {
    str: t,
    html: {
      name: "div",
      attributes: {
        dir: "auto"
      },
      children: [{
        name: "p",
        children: e
      }]
    }
  }, n = {
    style: {
      color: i(this, J, w0),
      fontSize: i(this, J, Um) ? `calc(${i(this, J, Um)}px * var(--total-scale-factor))` : ""
    }
  };
  for (const r of t.split(`
`))
    e.push({
      name: "span",
      value: r,
      attributes: n
    });
  return s;
}, S0 = function(t) {
  t.altKey || t.shiftKey || t.ctrlKey || t.metaKey || (t.key === "Enter" || t.key === "Escape" && i(this, Bi)) && m(this, J, Hf).call(this);
}, E0 = function() {
  if (i(this, Fn) !== null)
    return;
  const {
    page: {
      view: t
    },
    viewport: {
      rawDims: {
        pageWidth: e,
        pageHeight: s,
        pageX: n,
        pageY: r
      }
    }
  } = i(this, Fh);
  let a = !!i(this, Lh), o = a ? i(this, Lh) : i(this, Su);
  for (const y of i(this, Fo))
    if (!o || I.intersect(y.data.rect, o) !== null) {
      o = y.data.rect, a = !0;
      break;
    }
  const l = I.normalizeRect([o[0], t[3] - o[1] + t[1], o[2], t[3] - o[3] + t[1]]), c = a ? o[2] - o[0] + 5 : 0, d = l[0] + c, f = l[1];
  u(this, Fn, [100 * (d - n) / e, 100 * (f - r) / s]);
  const {
    style: b
  } = i(this, zt);
  b.left = `${i(this, Fn)[0]}%`, b.top = `${i(this, Fn)[1]}%`;
}, Hf = function() {
  if (i(this, os)) {
    i(this, os).toggleCommentPopup(this, !1);
    return;
  }
  u(this, Bi, !i(this, Bi)), i(this, Bi) ? (m(this, J, Uf).call(this), i(this, zt).addEventListener("click", i(this, Dh)), i(this, zt).addEventListener("keydown", i(this, Hr))) : (m(this, J, zm).call(this), i(this, zt).removeEventListener("click", i(this, Dh)), i(this, zt).removeEventListener("keydown", i(this, Hr)));
}, Uf = function() {
  i(this, ls) || this.render(), this.isVisible ? i(this, Bi) && i(this, zt).classList.add("focused") : (m(this, J, E0).call(this), i(this, zt).hidden = !1, i(this, zt).style.zIndex = parseInt(i(this, zt).style.zIndex, 10) + 1e3);
}, zm = function() {
  i(this, zt).classList.remove("focused"), !(i(this, Bi) || !this.isVisible) && (i(this, zt).hidden = !0, i(this, zt).style.zIndex = parseInt(i(this, zt).style.zIndex, 10) - 1e3);
};
class C0 extends dt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.textContent = t.data.textContent, this.textPosition = t.data.textPosition, this.annotationEditorType = X.FREETEXT;
  }
  render() {
    if (this.container.classList.add("freeTextAnnotation"), this.textContent) {
      const t = this.contentElement = document.createElement("div");
      t.classList.add("annotationTextContent"), t.setAttribute("role", "comment");
      for (const e of this.textContent) {
        const s = document.createElement("span");
        s.textContent = e, t.append(s);
      }
      this.container.append(t);
    }
    return !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this._editOnDoubleClick(), this.container;
  }
}
var Eu;
class yS extends dt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, Eu, null);
  }
  render() {
    this.container.classList.add("lineAnnotation");
    const {
      data: e,
      width: s,
      height: n
    } = this, r = dt._svgFactory, a = r.create(s, n, !0), o = u(this, Eu, r.createElement("svg:line"));
    return o.setAttribute("x1", e.rect[2] - e.lineCoordinates[0]), o.setAttribute("y1", e.rect[3] - e.lineCoordinates[1]), o.setAttribute("x2", e.rect[2] - e.lineCoordinates[2]), o.setAttribute("y2", e.rect[3] - e.lineCoordinates[3]), o.setAttribute("stroke-width", e.borderStyle.width || 1), o.setAttribute("stroke", "transparent"), o.setAttribute("fill", "transparent"), a.append(o), this.container.append(a), !e.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return i(this, Eu);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
Eu = new WeakMap();
var Cu;
class AS extends dt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, Cu, null);
  }
  render() {
    this.container.classList.add("squareAnnotation");
    const {
      data: e,
      width: s,
      height: n
    } = this, r = dt._svgFactory, a = r.create(s, n, !0), o = e.borderStyle.width, l = u(this, Cu, r.createElement("svg:rect"));
    return l.setAttribute("x", o / 2), l.setAttribute("y", o / 2), l.setAttribute("width", s - o), l.setAttribute("height", n - o), l.setAttribute("stroke-width", o || 1), l.setAttribute("stroke", "transparent"), l.setAttribute("fill", "transparent"), a.append(l), this.container.append(a), !e.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return i(this, Cu);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
Cu = new WeakMap();
var xu;
class wS extends dt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, xu, null);
  }
  render() {
    this.container.classList.add("circleAnnotation");
    const {
      data: e,
      width: s,
      height: n
    } = this, r = dt._svgFactory, a = r.create(s, n, !0), o = e.borderStyle.width, l = u(this, xu, r.createElement("svg:ellipse"));
    return l.setAttribute("cx", s / 2), l.setAttribute("cy", n / 2), l.setAttribute("rx", s / 2 - o / 2), l.setAttribute("ry", n / 2 - o / 2), l.setAttribute("stroke-width", o || 1), l.setAttribute("stroke", "transparent"), l.setAttribute("fill", "transparent"), a.append(l), this.container.append(a), !e.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return i(this, xu);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
xu = new WeakMap();
var Tu;
class x0 extends dt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, Tu, null);
    this.containerClassName = "polylineAnnotation", this.svgElementName = "svg:polyline";
  }
  render() {
    this.container.classList.add(this.containerClassName);
    const {
      data: {
        rect: e,
        vertices: s,
        borderStyle: n,
        popupRef: r
      },
      width: a,
      height: o
    } = this;
    if (!s)
      return this.container;
    const l = dt._svgFactory, h = l.create(a, o, !0);
    let c = [];
    for (let f = 0, b = s.length; f < b; f += 2) {
      const y = s[f] - e[0], A = e[3] - s[f + 1];
      c.push(`${y},${A}`);
    }
    c = c.join(" ");
    const d = u(this, Tu, l.createElement(this.svgElementName));
    return d.setAttribute("points", c), d.setAttribute("stroke-width", n.width || 1), d.setAttribute("stroke", "transparent"), d.setAttribute("fill", "transparent"), h.append(d), this.container.append(h), !r && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return i(this, Tu);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
Tu = new WeakMap();
class vS extends x0 {
  constructor(t) {
    super(t), this.containerClassName = "polygonAnnotation", this.svgElementName = "svg:polygon";
  }
}
class SS extends dt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    return this.container.classList.add("caretAnnotation"), !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
}
var _u, Oo, ku, Gm;
class $b extends dt {
  constructor(e) {
    super(e, {
      isRenderable: !0,
      ignoreBorder: !0
    });
    g(this, ku);
    g(this, _u, null);
    g(this, Oo, []);
    this.containerClassName = "inkAnnotation", this.svgElementName = "svg:polyline", this.annotationEditorType = this.data.it === "InkHighlight" ? X.HIGHLIGHT : X.INK;
  }
  render() {
    this.container.classList.add(this.containerClassName);
    const {
      data: {
        rect: e,
        rotation: s,
        inkLists: n,
        borderStyle: r,
        popupRef: a
      }
    } = this, {
      transform: o,
      width: l,
      height: h
    } = m(this, ku, Gm).call(this, s, e), c = dt._svgFactory, d = c.create(l, h, !0), f = u(this, _u, c.createElement("svg:g"));
    d.append(f), f.setAttribute("stroke-width", r.width || 1), f.setAttribute("stroke-linecap", "round"), f.setAttribute("stroke-linejoin", "round"), f.setAttribute("stroke-miterlimit", 10), f.setAttribute("stroke", "transparent"), f.setAttribute("fill", "transparent"), f.setAttribute("transform", o);
    for (const b of n) {
      const y = c.createElement(this.svgElementName);
      i(this, Oo).push(y), y.setAttribute("points", b.join(",")), f.append(y);
    }
    return !a && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.append(d), this._editOnDoubleClick(), this.container;
  }
  updateEdited(e) {
    super.updateEdited(e);
    const {
      thickness: s,
      points: n,
      rect: r
    } = e, a = i(this, _u);
    if (s >= 0 && a.setAttribute("stroke-width", s || 1), n)
      for (let o = 0, l = i(this, Oo).length; o < l; o++)
        i(this, Oo)[o].setAttribute("points", n[o].join(","));
    if (r) {
      const {
        transform: o,
        width: l,
        height: h
      } = m(this, ku, Gm).call(this, this.data.rotation, r);
      a.parentElement.setAttribute("viewBox", `0 0 ${l} ${h}`), a.setAttribute("transform", o);
    }
  }
  getElementsToTriggerPopup() {
    return i(this, Oo);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
_u = new WeakMap(), Oo = new WeakMap(), ku = new WeakSet(), Gm = function(e, s) {
  switch (e) {
    case 90:
      return {
        transform: `rotate(90) translate(${-s[0]},${s[1]}) scale(1,-1)`,
        width: s[3] - s[1],
        height: s[2] - s[0]
      };
    case 180:
      return {
        transform: `rotate(180) translate(${-s[2]},${s[1]}) scale(1,-1)`,
        width: s[2] - s[0],
        height: s[3] - s[1]
      };
    case 270:
      return {
        transform: `rotate(270) translate(${-s[2]},${s[3]}) scale(1,-1)`,
        width: s[3] - s[1],
        height: s[2] - s[0]
      };
    default:
      return {
        transform: `translate(${-s[0]},${s[3]}) scale(1,-1)`,
        width: s[2] - s[0],
        height: s[3] - s[1]
      };
  }
};
class T0 extends dt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    }), this.annotationEditorType = X.HIGHLIGHT;
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("highlightAnnotation"), this._editOnDoubleClick(), t) {
      const s = document.createElement("mark");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class ES extends dt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("underlineAnnotation"), t) {
      const s = document.createElement("u");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class CS extends dt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("squigglyAnnotation"), t) {
      const s = document.createElement("u");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class xS extends dt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("strikeoutAnnotation"), t) {
      const s = document.createElement("s");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class _0 extends dt {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.annotationEditorType = X.STAMP;
  }
  render() {
    return this.container.classList.add("stampAnnotation"), this.container.setAttribute("role", "img"), !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this._editOnDoubleClick(), this.container;
  }
}
var Pu, Mu, $m;
class TS extends dt {
  constructor(e) {
    var r;
    super(e, {
      isRenderable: !0
    });
    g(this, Mu);
    g(this, Pu, null);
    const {
      fileId: s,
      file: n
    } = this.data;
    this.filename = n.filename, this.content = n.content, this.fileId = s, (r = this.linkService.eventBus) == null || r.dispatch("fileattachmentannotation", {
      source: this,
      attachmentId: this.fileId,
      ...n
    });
  }
  render() {
    this.container.classList.add("fileAttachmentAnnotation");
    const {
      container: e,
      data: s
    } = this;
    let n;
    s.hasAppearance || s.fillAlpha === 0 ? n = document.createElement("div") : (n = document.createElement("img"), n.src = `${this.imageResourcesPath}annotation-${/paperclip/i.test(s.name) ? "paperclip" : "pushpin"}.svg`, s.fillAlpha && s.fillAlpha < 1 && (n.style = `filter: opacity(${Math.round(s.fillAlpha * 100)}%);`)), n.addEventListener("dblclick", m(this, Mu, $m).bind(this)), u(this, Pu, n);
    const {
      isMac: r
    } = ot.platform;
    return e.addEventListener("keydown", (a) => {
      a.key === "Enter" && (r ? a.metaKey : a.ctrlKey) && m(this, Mu, $m).call(this);
    }), !s.popupRef && this.hasPopupData ? (this.hasOwnCommentButton = !0, this._createPopup()) : n.classList.add("popupTriggerArea"), e.append(n), e;
  }
  getElementsToTriggerPopup() {
    return i(this, Pu);
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
Pu = new WeakMap(), Mu = new WeakSet(), $m = async function() {
  var a;
  const {
    fileId: e,
    filename: s,
    content: n
  } = this, r = await this.linkService.getAttachmentContent(e) || n;
  r && ((a = this.downloadManager) == null || a.openOrDownloadData(r, s));
};
var Rh, Ro, Rn, ll, P0, jm;
class k0 extends dt {
  constructor(e) {
    super(e, {
      isRenderable: !!e.data.richMedia
    });
    g(this, ll);
    g(this, Rh, new AbortController());
    g(this, Ro, null);
    g(this, Rn, null);
  }
  render() {
    this.container.classList.add("mediaAnnotation");
    const {
      filename: e
    } = this.data.richMedia, s = document.createElement("button");
    return s.className = "mediaPlayButton", s.type = "button", s.title = s.ariaLabel = e, s.addEventListener("click", () => m(this, ll, P0).call(this, s), {
      signal: i(this, Rh).signal
    }), this.container.append(s), this.container;
  }
  destroy() {
    i(this, Rh).abort(), i(this, Rn) && (i(this, Rn).pause(), i(this, Rn).removeAttribute("src"), i(this, Rn).load(), u(this, Rn, null)), m(this, ll, jm).call(this);
  }
}
Rh = new WeakMap(), Ro = new WeakMap(), Rn = new WeakMap(), ll = new WeakSet(), P0 = async function(e) {
  const {
    fileId: s,
    filename: n,
    contentType: r
  } = this.data.richMedia;
  e.disabled = !0;
  let a;
  try {
    a = await this.linkService.getAttachmentContent(s);
  } catch {
    return;
  } finally {
    e.disabled = !1;
  }
  if (!a || !e.isConnected)
    return;
  const {
    signal: o
  } = i(this, Rh), l = new Blob([a], {
    type: r
  });
  if (!/^(?:video|audio)\//.test(l.type))
    return;
  const h = URL.createObjectURL(l);
  u(this, Ro, h);
  const c = l.type.startsWith("audio/"), d = document.createElement(c ? "audio" : "video");
  if (u(this, Rn, d), d.className = "mediaContent", this._setBackgroundColor(d), d.src = h, d.title = n, d.controls = !0, d.autoplay = !0, d.tabIndex = 0, c) {
    let f = !1, b = !1;
    const y = () => {
      d.controls = f || b;
    };
    this.container.addEventListener("pointerenter", () => {
      f = !0, y();
    }, {
      signal: o
    }), this.container.addEventListener("pointerleave", () => {
      f = !1, y();
    }, {
      signal: o
    }), this.container.addEventListener("focusin", () => {
      b = !0, y();
    }, {
      signal: o
    }), this.container.addEventListener("focusout", () => {
      b = !1, y();
    }, {
      signal: o
    });
  }
  d.addEventListener("emptied", () => m(this, ll, jm).call(this, h), {
    once: !0,
    signal: o
  }), e.replaceWith(d), d.play().catch(() => {
  });
}, jm = function(e = i(this, Ro)) {
  e && e === i(this, Ro) && (URL.revokeObjectURL(e), u(this, Ro, null));
};
var jr, No, Nh, Nn, Bh, Bo, Ce, Du, Ki, zf, Gf;
const Zb = class Zb {
  constructor({
    div: t,
    accessibilityManager: e,
    annotationCanvasMap: s,
    annotationEditorUIManager: n,
    page: r,
    viewport: a,
    structTreeLayer: o,
    commentManager: l,
    linkService: h,
    annotationStorage: c
  }) {
    g(this, Ki);
    g(this, jr, null);
    g(this, No, null);
    g(this, Nh, null);
    g(this, Nn, /* @__PURE__ */ new Map());
    g(this, Bh, null);
    g(this, Bo, null);
    g(this, Ce, []);
    g(this, Du, !1);
    _(this, "zIndex", 0);
    this.div = t, u(this, jr, e), u(this, No, s), u(this, Bh, o || null), u(this, Bo, h || null), u(this, Nh, c || new Bb()), this.page = r, this.viewport = a, this._annotationEditorUIManager = n, this._commentManager = l || null;
  }
  hasEditableAnnotations() {
    return i(this, Nn).size > 0;
  }
  async render(t) {
    var l;
    const {
      annotations: e,
      optionalContentConfig: s
    } = t, n = this.div;
    nl(n, this.viewport);
    const r = /* @__PURE__ */ new Map(), a = [], o = {
      data: null,
      layer: n,
      linkService: i(this, Bo),
      downloadManager: t.downloadManager,
      imageResourcesPath: t.imageResourcesPath || "",
      renderForms: t.renderForms !== !1,
      annotationStorage: i(this, Nh),
      enableComment: t.enableComment === !0,
      enableAnnotationEditing: t.enableAnnotationEditing !== !1,
      enableScripting: t.enableScripting === !0,
      hasJSActions: t.hasJSActions,
      fieldObjects: t.fieldObjects,
      parent: this,
      elements: null
    };
    for (const h of e) {
      if (h.noHTML)
        continue;
      const c = h.annotationType === It.POPUP;
      if (c) {
        const b = r.get(h.id);
        if (!b)
          continue;
        if (!this._commentManager) {
          a.push(h);
          continue;
        }
        o.elements = b;
      } else if (h.rect[2] === h.rect[0] || h.rect[3] === h.rect[1])
        continue;
      o.data = h;
      const d = Cg.create(o);
      if (!d.isRenderable)
        continue;
      c || (i(this, Ce).push(d), h.popupRef && r.getOrInsertComputed(h.popupRef, gc).push(d));
      const f = d.render();
      h.hidden && (f.style.visibility = "hidden"), d.updateOC(s), d._isEditable && (i(this, Nn).set(d.data.id, d), (l = this._annotationEditorUIManager) == null || l.renderAnnotationElement(d));
    }
    await m(this, Ki, zf).call(this);
    for (const h of a) {
      const c = o.elements = r.get(h.id);
      o.data = h;
      const d = Cg.create(o);
      if (!d.isRenderable)
        continue;
      const f = d.render();
      d.contentElement.id = `${ml}${h.id}`, h.hidden && (f.style.visibility = "hidden"), c.at(-1).container.after(f);
    }
    m(this, Ki, Gf).call(this);
  }
  async addLinkAnnotations(t) {
    const e = {
      data: null,
      layer: this.div,
      linkService: i(this, Bo),
      parent: this
    };
    for (const s of t) {
      s.borderStyle || (s.borderStyle = Zb._defaultBorderStyle), e.data = s;
      const n = Cg.create(e);
      n.isRenderable && (n.render(), n.contentElement.id = `${ml}${s.id}`, i(this, Ce).push(n));
    }
    await m(this, Ki, zf).call(this);
  }
  update({
    viewport: t,
    optionalContentConfig: e
  }) {
    const s = this.div;
    this.viewport = t, nl(s, {
      rotation: t.rotation
    });
    for (const n of i(this, Ce))
      n.updateOC(e);
    m(this, Ki, Gf).call(this), s.hidden = !1;
  }
  destroy() {
    var t, e;
    for (const s of i(this, Ce))
      (t = s.destroy) == null || t.call(s), (e = i(this, jr)) == null || e.removePointerInTextLayer(s.contentElement);
    i(this, Ce).length = 0, i(this, Nn).clear(), this.div.replaceChildren();
  }
  refreshCanvases() {
    m(this, Ki, Gf).call(this);
  }
  getEditableAnnotations() {
    return i(this, Nn).values();
  }
  getEditableAnnotation(t) {
    return i(this, Nn).get(t);
  }
  addFakeAnnotation(t) {
    const {
      div: e
    } = this, {
      id: s,
      rotation: n
    } = t, r = new hS({
      data: {
        id: s,
        rect: t.getPDFRect(),
        rotation: n
      },
      editor: t,
      layer: e,
      parent: this,
      enableComment: !!this._commentManager,
      linkService: i(this, Bo),
      annotationStorage: i(this, Nh)
    });
    return r.render(), r.contentElement.id = `${ml}${s}`, r.createOrUpdatePopup(), i(this, Ce).push(r), r;
  }
  removeAnnotation(t) {
    var n;
    const e = i(this, Ce).findIndex((r) => r.data.id === t);
    if (e < 0)
      return;
    const [s] = i(this, Ce).splice(e, 1);
    (n = i(this, jr)) == null || n.removePointerInTextLayer(s.contentElement);
  }
  updateFakeAnnotations(t) {
    if (t.length !== 0) {
      for (const e of t)
        e.updateFakeAnnotationElement(this);
      m(this, Ki, zf).call(this);
    }
  }
  togglePointerEvents(t = !1) {
    this.div.classList.toggle("disabled", !t);
  }
  static get _defaultBorderStyle() {
    return L(this, "_defaultBorderStyle", Object.freeze({
      width: 1,
      rawWidth: 1,
      style: fl.SOLID,
      dashArray: [3],
      horizontalCornerRadius: 0,
      verticalCornerRadius: 0
    }));
  }
};
jr = new WeakMap(), No = new WeakMap(), Nh = new WeakMap(), Nn = new WeakMap(), Bh = new WeakMap(), Bo = new WeakMap(), Ce = new WeakMap(), Du = new WeakMap(), Ki = new WeakSet(), zf = async function() {
  var s, n, r, a;
  if (i(this, Ce).length === 0)
    return;
  this.div.replaceChildren();
  const t = [];
  if (!i(this, Du)) {
    u(this, Du, !0);
    for (const {
      contentElement: o,
      data: {
        hidden: l,
        id: h,
        oc: c
      }
    } of i(this, Ce)) {
      const d = o.id = `${ml}${h}`, f = o.localName === "a" && !l && !c;
      t.push((s = i(this, Bh)) == null ? void 0 : s.getAriaAttributes(d, {
        enableLinkOwnership: f
      }).then((b) => {
        if (b)
          for (const [y, A] of b)
            o.setAttribute(y, A);
      }));
    }
  }
  i(this, Ce).sort(({
    data: {
      rect: [o, l, h, c]
    }
  }, {
    data: {
      rect: [d, f, b, y]
    }
  }) => {
    if (o === h && l === c)
      return 1;
    if (d === b && f === y)
      return -1;
    const A = c, w = l, v = (l + c) / 2, S = y, E = f, C = (f + y) / 2;
    if (v >= S && C <= w)
      return -1;
    if (C >= A && v <= E)
      return 1;
    const x = (o + h) / 2, T = (d + b) / 2;
    return x - T;
  });
  const e = document.createDocumentFragment();
  for (const o of i(this, Ce))
    e.append(o.container), this._commentManager ? (r = ((n = o.extraPopupElement) == null ? void 0 : n.popup) || o.popup) == null || r.renderCommentButton() : o.extraPopupElement && e.append(o.extraPopupElement.render());
  if (this.div.append(e), await Promise.all(t), i(this, jr)) {
    const o = await ((a = i(this, Bh)) == null ? void 0 : a.getAnnotationIds());
    for (const {
      contentElement: l
    } of i(this, Ce))
      o != null && o.has(l.id) || i(this, jr).addPointerInTextLayer(l, !1);
  }
}, Gf = function() {
  var e;
  if (!i(this, No))
    return;
  const t = this.div;
  for (const [s, n] of i(this, No)) {
    const r = t.querySelector(`[data-annotation-id="${s}"]`);
    if (!r)
      continue;
    if (Array.isArray(n))
      for (const c of n)
        c.className = "annotationContent", c.ariaHidden = !0;
    else
      n.className = "annotationContent", n.ariaHidden = !0;
    const a = [];
    for (const c of r.children)
      c.nodeName === "CANVAS" && a.push(c);
    for (const c of a)
      c.remove();
    const o = Array.isArray(n) ? n[0] : n, {
      firstChild: l
    } = r;
    if (l ? l.classList.contains("annotationContent") ? l.after(o) : l.before(o) : r.append(o), Array.isArray(n)) {
      let c = o;
      for (let d = 1, f = n.length; d < f; d++)
        c.after(n[d]), c = n[d];
    }
    i(this, No).delete(s);
    const h = i(this, Nn).get(s);
    h && (h._hasNoCanvas ? ((e = this._annotationEditorUIManager) == null || e.setMissingCanvas(s, r.id, n), h._hasNoCanvas = !1) : h.canvas = n);
  }
};
let Vm = Zb;
const ff = /\r\n?|\n/g;
var hs, Iu, Ho, cs, Kt, M0, D0, I0, $f, Yn, jf, Vf, F0, Xm, L0;
const Ct = class Ct extends bt {
  constructor(e) {
    super({
      ...e,
      name: "freeTextEditor"
    });
    g(this, Kt);
    g(this, hs, "");
    g(this, Iu, `${this.id}-editor`);
    g(this, Ho, null);
    g(this, cs);
    _(this, "_colorPicker", null);
    this.color = e.color || Ct._defaultColor || bt._defaultLineColor, u(this, cs, e.fontSize || Ct._defaultFontSize), this.annotationElementId || this._uiManager.a11yAlert(bt._l10nAlert.freetext), this.canAddComment = !1;
  }
  static get _keyboardManager() {
    const e = Ct.prototype, s = (a) => a.isEmpty(), n = al.TRANSLATE_SMALL, r = al.TRANSLATE_BIG;
    return L(this, "_keyboardManager", new rl([[["ctrl+s", "mac+meta+s", "ctrl+p", "mac+meta+p"], e.commitOrRemove, {
      bubbles: !0
    }], [["ctrl+Enter", "mac+meta+Enter"], e.commitOrRemove], [["Escape"], e.commitOrRemove], [["ArrowLeft"], e._translateEmpty, {
      args: [-n, 0],
      checker: s
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], e._translateEmpty, {
      args: [-r, 0],
      checker: s
    }], [["ArrowRight"], e._translateEmpty, {
      args: [n, 0],
      checker: s
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], e._translateEmpty, {
      args: [r, 0],
      checker: s
    }], [["ArrowUp"], e._translateEmpty, {
      args: [0, -n],
      checker: s
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], e._translateEmpty, {
      args: [0, -r],
      checker: s
    }], [["ArrowDown"], e._translateEmpty, {
      args: [0, n],
      checker: s
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], e._translateEmpty, {
      args: [0, r],
      checker: s
    }]]));
  }
  static initialize(e, s) {
    bt.initialize(e, s);
    const n = getComputedStyle(document.documentElement);
    this._internalPadding = parseFloat(n.getPropertyValue("--freetext-padding"));
  }
  static updateDefaultParams(e, s) {
    switch (e) {
      case tt.FREETEXT_SIZE:
        Ct._defaultFontSize = s;
        break;
      case tt.FREETEXT_COLOR:
        Ct._defaultColor = s;
        break;
    }
  }
  updateParams(e, s) {
    switch (e) {
      case tt.FREETEXT_SIZE:
        m(this, Kt, M0).call(this, s);
        break;
      case tt.FREETEXT_COLOR:
        m(this, Kt, D0).call(this, s);
        break;
    }
  }
  static get defaultPropertiesToUpdate() {
    return [[tt.FREETEXT_SIZE, Ct._defaultFontSize], [tt.FREETEXT_COLOR, Ct._defaultColor || bt._defaultLineColor]];
  }
  get propertiesToUpdate() {
    return [[tt.FREETEXT_SIZE, i(this, cs)], [tt.FREETEXT_COLOR, this.color]];
  }
  get toolbarButtons() {
    return this._colorPicker || (this._colorPicker = new fp(this)), [["colorPicker", this._colorPicker]];
  }
  get colorType() {
    return tt.FREETEXT_COLOR;
  }
  onUpdatedColor() {
    var e;
    this.editorDiv.style.color = this.color, (e = this._colorPicker) == null || e.update(this.color), super.onUpdatedColor();
  }
  _translateEmpty(e, s) {
    this._uiManager.translateSelectedEditors(e, s, !0);
  }
  getInitialTranslation() {
    const e = this.parentScale;
    return [-Ct._internalPadding * e, -(Ct._internalPadding + i(this, cs)) * e];
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (this.isAttachedToDOM || this.parent.add(this)));
  }
  enableEditMode() {
    if (!super.enableEditMode())
      return !1;
    this.overlayDiv.classList.remove("enabled"), this.editorDiv.contentEditable = !0, this._isDraggable = !1, this.div.removeAttribute("aria-activedescendant"), u(this, Ho, new AbortController());
    const e = this._uiManager.combinedSignal(i(this, Ho));
    return this.editorDiv.addEventListener("keydown", this.editorDivKeydown.bind(this), {
      signal: e
    }), this.editorDiv.addEventListener("focus", this.editorDivFocus.bind(this), {
      signal: e
    }), this.editorDiv.addEventListener("blur", this.editorDivBlur.bind(this), {
      signal: e
    }), this.editorDiv.addEventListener("input", this.editorDivInput.bind(this), {
      signal: e
    }), this.editorDiv.addEventListener("paste", this.editorDivPaste.bind(this), {
      signal: e
    }), !0;
  }
  disableEditMode() {
    var e;
    return super.disableEditMode() ? (this.overlayDiv.classList.add("enabled"), this.editorDiv.contentEditable = !1, this.div.setAttribute("aria-activedescendant", i(this, Iu)), this._isDraggable = !0, (e = i(this, Ho)) == null || e.abort(), u(this, Ho, null), this.div.focus({
      preventScroll: !0
    }), this.isEditing = !1, this.parent.div.classList.add("freetextEditing"), !0) : !1;
  }
  focusin(e) {
    this._focusEventsAllowed && (super.focusin(e), e.target !== this.editorDiv && this.editorDiv.focus());
  }
  onceAdded(e) {
    var s;
    this.width || (this.enableEditMode(), e && this.editorDiv.focus(), (s = this._initialOptions) != null && s.isCentered && this.center(), this._initialOptions = null);
  }
  isEmpty() {
    return !this.editorDiv || this.editorDiv.innerText.trim() === "";
  }
  remove() {
    this.isEditing = !1, this.parent && (this.parent.setEditingState(!0), this.parent.div.classList.add("freetextEditing")), super.remove();
  }
  commit() {
    if (!this.isInEditMode())
      return;
    super.commit(), this.disableEditMode();
    const e = i(this, hs), s = u(this, hs, m(this, Kt, I0).call(this).trimEnd());
    if (e === s)
      return;
    const n = (r) => {
      if (u(this, hs, r), !r) {
        this.remove();
        return;
      }
      m(this, Kt, Vf).call(this), this._uiManager.rebuild(this), m(this, Kt, $f).call(this);
    };
    this.addCommands({
      cmd: () => {
        n(s);
      },
      undo: () => {
        n(e);
      },
      mustExec: !1
    }), m(this, Kt, $f).call(this);
  }
  shouldGetKeyboardEvents() {
    return this.isInEditMode();
  }
  enterInEditMode() {
    this.enableEditMode(), this.editorDiv.focus();
  }
  keydown(e) {
    e.target === this.div && e.key === "Enter" && (this.enterInEditMode(), e.preventDefault());
  }
  editorDivKeydown(e) {
    Ct._keyboardManager.exec(this, e);
  }
  editorDivFocus(e) {
    this.isEditing = !0;
  }
  editorDivBlur(e) {
    this.isEditing = !1;
  }
  editorDivInput(e) {
    this.parent.div.classList.toggle("freetextEditing", this.isEmpty());
  }
  disableEditing() {
    this.editorDiv.setAttribute("role", "comment"), this.editorDiv.removeAttribute("aria-multiline");
  }
  enableEditing() {
    this.editorDiv.setAttribute("role", "textbox"), this.editorDiv.setAttribute("aria-multiline", !0);
  }
  get canChangeContent() {
    return !0;
  }
  render() {
    if (this.div)
      return this.div;
    let e, s;
    (this._isCopy || this.annotationElementId) && (e = this.x, s = this.y), super.render(), this.editorDiv = document.createElement("div"), this.editorDiv.className = "internal", this.editorDiv.setAttribute("id", i(this, Iu)), this.editorDiv.setAttribute("data-l10n-id", "pdfjs-free-text2"), this.editorDiv.setAttribute("data-l10n-attrs", "default-content"), this.enableEditing(), this.editorDiv.contentEditable = !0;
    const {
      style: n
    } = this.editorDiv;
    if (n.fontSize = `calc(${i(this, cs)}px * var(--total-scale-factor))`, n.color = this.color, this.div.append(this.editorDiv), this.overlayDiv = document.createElement("div"), this.overlayDiv.classList.add("overlay", "enabled"), this.div.append(this.overlayDiv), this._isCopy || this.annotationElementId) {
      const [r, a] = this.parentDimensions;
      if (this.annotationElementId) {
        const {
          position: o
        } = this._initialData;
        let [l, h] = this.getInitialTranslation();
        [l, h] = this.pageTranslationToScreen(l, h);
        const [c, d] = this.pageDimensions, [f, b] = this.pageTranslation;
        let y, A;
        switch (this.rotation) {
          case 0:
            y = e + (o[0] - f) / c, A = s + this.height - (o[1] - b) / d;
            break;
          case 90:
            y = e + (o[0] - f) / c, A = s - (o[1] - b) / d, [l, h] = [h, -l];
            break;
          case 180:
            y = e - this.width + (o[0] - f) / c, A = s - (o[1] - b) / d, [l, h] = [-l, -h];
            break;
          case 270:
            y = e + (o[0] - f - this.height * d) / c, A = s + (o[1] - b - this.width * c) / d, [l, h] = [-h, l];
            break;
        }
        this.setAt(y * r, A * a, l, h);
      } else
        this._moveAfterPaste(e, s);
      m(this, Kt, Vf).call(this), this._isDraggable = !0, this.editorDiv.contentEditable = !1;
    } else
      this._isDraggable = !1, this.editorDiv.contentEditable = !0;
    return this.div;
  }
  editorDivPaste(e) {
    var y, A, w;
    const s = e.clipboardData || window.clipboardData, {
      types: n
    } = s;
    if (n.length === 1 && n[0] === "text/plain")
      return;
    e.preventDefault();
    const r = m(y = Ct, Yn, Xm).call(y, s.getData("text") || "").replaceAll(ff, `
`);
    if (!r)
      return;
    const a = window.getSelection();
    if (!a.rangeCount)
      return;
    this.editorDiv.normalize(), a.deleteFromDocument();
    const o = a.getRangeAt(0);
    if (!r.includes(`
`)) {
      o.insertNode(document.createTextNode(r)), this.editorDiv.normalize(), a.collapseToStart();
      return;
    }
    const {
      startContainer: l,
      startOffset: h
    } = o, c = [], d = [];
    if (l.nodeType === Node.TEXT_NODE) {
      const v = l.parentElement;
      if (d.push(l.nodeValue.slice(h).replaceAll(ff, "")), v !== this.editorDiv) {
        let S = c;
        for (const E of this.editorDiv.childNodes) {
          if (E === v) {
            S = d;
            continue;
          }
          S.push(m(A = Ct, Yn, jf).call(A, E));
        }
      }
      c.push(l.nodeValue.slice(0, h).replaceAll(ff, ""));
    } else if (l === this.editorDiv) {
      let v = c, S = 0;
      for (const E of this.editorDiv.childNodes)
        S++ === h && (v = d), v.push(m(w = Ct, Yn, jf).call(w, E));
    }
    u(this, hs, `${c.join(`
`)}${r}${d.join(`
`)}`), m(this, Kt, Vf).call(this);
    const f = new Range();
    let b = Math.sumPrecise(c.map((v) => v.length));
    for (const {
      firstChild: v
    } of this.editorDiv.childNodes)
      if (v.nodeType === Node.TEXT_NODE) {
        const S = v.nodeValue.length;
        if (b <= S) {
          f.setStart(v, b), f.setEnd(v, b);
          break;
        }
        b -= S;
      }
    a.removeAllRanges(), a.addRange(f);
  }
  get contentDiv() {
    return this.editorDiv;
  }
  getPDFRect() {
    const e = Ct._internalPadding * this.parentScale;
    return this.getRect(e, e);
  }
  static async deserialize(e, s, n) {
    var o;
    let r = null;
    if (e instanceof C0) {
      const {
        data: {
          defaultAppearanceData: {
            fontSize: l,
            fontColor: h
          },
          rect: c,
          rotation: d,
          id: f,
          popupRef: b,
          richText: y,
          contentsObj: A,
          creationDate: w,
          modificationDate: v
        },
        textContent: S,
        textPosition: E,
        parent: {
          page: {
            pageNumber: C
          }
        }
      } = e;
      if (!(S != null && S.length))
        return null;
      r = e = {
        annotationType: X.FREETEXT,
        color: Array.from(h),
        fontSize: l,
        value: S.join(`
`),
        position: E,
        pageIndex: C - 1,
        rect: c.slice(0),
        rotation: d,
        annotationElementId: f,
        id: f,
        deleted: !1,
        popupRef: b,
        comment: (A == null ? void 0 : A.str) || null,
        richText: y,
        creationDate: w,
        modificationDate: v
      };
    }
    const a = await super.deserialize(e, s, n);
    return u(a, cs, e.fontSize), a.color = I.makeHexColor(...e.color), u(a, hs, m(o = Ct, Yn, Xm).call(o, e.value)), a._initialData = r, e.comment && a.setCommentData(e), a;
  }
  serialize(e = !1) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const s = bt._colorManager.convert(this.isAttachedToDOM ? getComputedStyle(this.editorDiv).color : this.color), n = Object.assign(super.serialize(e), {
      color: s,
      fontSize: i(this, cs),
      value: m(this, Kt, F0).call(this)
    });
    return this.addComment(n), e ? (n.isCopy = !0, n) : this.annotationElementId && !m(this, Kt, L0).call(this, n) ? null : (n.id = this.annotationElementId, n);
  }
  renderAnnotationElement(e) {
    const s = super.renderAnnotationElement(e);
    if (!s)
      return null;
    const {
      style: n
    } = s;
    n.fontSize = `calc(${i(this, cs)}px * var(--total-scale-factor))`, n.color = this.color, s.replaceChildren();
    for (const r of i(this, hs).split(`
`)) {
      const a = document.createElement("div");
      a.append(r ? document.createTextNode(r) : document.createElement("br")), s.append(a);
    }
    return e.updateEdited({
      rect: this.getPDFRect(),
      popup: this._uiManager.hasCommentManager() || this.hasEditedComment ? this.comment : {
        text: i(this, hs)
      }
    }), s;
  }
  resetAnnotationElement(e) {
    super.resetAnnotationElement(e), e.resetEdited();
  }
};
hs = new WeakMap(), Iu = new WeakMap(), Ho = new WeakMap(), cs = new WeakMap(), Kt = new WeakSet(), M0 = function(e) {
  const s = (r) => {
    this.editorDiv.style.fontSize = `calc(${r}px * var(--total-scale-factor))`, this.translate(0, -(r - i(this, cs)) * this.parentScale), u(this, cs, r), m(this, Kt, $f).call(this);
  }, n = i(this, cs);
  this.addCommands({
    cmd: s.bind(this, e),
    undo: s.bind(this, n),
    post: this._uiManager.updateUI.bind(this._uiManager, this),
    mustExec: !0,
    type: tt.FREETEXT_SIZE,
    overwriteIfSameType: !0,
    keepUndo: !0
  });
}, D0 = function(e) {
  const s = (r) => {
    this.color = r, this.onUpdatedColor();
  }, n = this.color;
  this.addCommands({
    cmd: s.bind(this, e),
    undo: s.bind(this, n),
    post: this._uiManager.updateUI.bind(this._uiManager, this),
    mustExec: !0,
    type: tt.FREETEXT_COLOR,
    overwriteIfSameType: !0,
    keepUndo: !0
  });
}, I0 = function() {
  var n;
  const e = [];
  this.editorDiv.normalize();
  let s = null;
  for (const r of this.editorDiv.childNodes)
    (s == null ? void 0 : s.nodeType) === Node.TEXT_NODE && r.nodeName === "BR" || (e.push(m(n = Ct, Yn, jf).call(n, r)), s = r);
  return e.join(`
`);
}, $f = function() {
  const [e, s] = this.parentDimensions;
  let n;
  if (this.isAttachedToDOM)
    n = this.div.getBoundingClientRect();
  else {
    const {
      currentLayer: r,
      div: a
    } = this, o = a.style.display, l = a.classList.contains("hidden");
    a.classList.remove("hidden"), a.style.display = "hidden", r.div.append(this.div), n = a.getBoundingClientRect(), a.remove(), a.style.display = o, a.classList.toggle("hidden", l);
  }
  this.rotation % 180 === this.parentRotation % 180 ? (this.width = n.width / e, this.height = n.height / s) : (this.width = n.height / e, this.height = n.width / s), this.fixAndSetPosition();
}, Yn = new WeakSet(), jf = function(e) {
  return (e.nodeType === Node.TEXT_NODE ? e.nodeValue : e.innerText).replaceAll(ff, "");
}, Vf = function() {
  if (this.editorDiv.replaceChildren(), !!i(this, hs))
    for (const e of i(this, hs).split(`
`)) {
      const s = document.createElement("div");
      s.append(e ? document.createTextNode(e) : document.createElement("br")), this.editorDiv.append(s);
    }
}, F0 = function() {
  return i(this, hs).replaceAll(" ", " ");
}, Xm = function(e) {
  return e.replaceAll(" ", " ");
}, L0 = function(e) {
  const {
    value: s,
    fontSize: n,
    color: r,
    pageIndex: a
  } = this._initialData;
  return this.hasEditedComment || this._hasBeenMoved || e.value !== s || e.fontSize !== n || e.color.some((o, l) => o !== r[l]) || e.pageIndex !== a;
}, g(Ct, Yn), _(Ct, "_freeTextDefaultContent", ""), _(Ct, "_internalPadding", 0), _(Ct, "_defaultColor", null), _(Ct, "_defaultFontSize", 10), _(Ct, "_type", "freetext"), _(Ct, "_editorType", X.FREETEXT);
let Wm = Ct;
var Uo;
class jb {
  constructor() {
    g(this, Uo, /* @__PURE__ */ Object.create(null));
  }
  updateProperty(t, e) {
    this[t] = e, this.updateSVGProperty(t, e);
  }
  updateProperties(t) {
    if (t)
      for (const [e, s] of Object.entries(t))
        e.startsWith("_") || this.updateProperty(e, s);
  }
  updateSVGProperty(t, e) {
    i(this, Uo)[t] = e;
  }
  toSVGProperties() {
    const t = i(this, Uo);
    return u(this, Uo, /* @__PURE__ */ Object.create(null)), {
      root: t
    };
  }
  reset() {
    u(this, Uo, /* @__PURE__ */ Object.create(null));
  }
  updateAll(t = this) {
    this.updateProperties(t);
  }
  clone() {
    it("Not implemented");
  }
}
Uo = new WeakMap();
var Hh, Uh, Yt, zo, Go, zh, V, Ym, Km, qm, Qm, Bc, Jm, Zm, tb, Hc, O0, Wf, Uc, gl;
const q = class q extends bt {
  constructor(e) {
    super(e);
    g(this, V);
    g(this, Hh, null);
    g(this, Uh);
    _(this, "_clipPathId", null);
    _(this, "_colorPicker", null);
    _(this, "_drawId", null);
    _(this, "_drawOutlines", null);
    _(this, "_focusDrawId", null);
    u(this, Uh, e.mustBeCommitted || !1), this._addOutlines(e);
  }
  onUpdatedColor() {
    var e;
    (e = this._colorPicker) == null || e.update(this.color), super.onUpdatedColor();
  }
  onUpdatedOpacity() {
    var e, s;
    (s = (e = this._colorPicker) == null ? void 0 : e.updateOpacity) == null || s.call(e, this.opacity);
  }
  _addOutlines(e) {
    e.drawOutlines && (m(this, V, Ym).call(this, e), m(this, V, Hc).call(this));
  }
  static _mergeSVGProperties(e, s) {
    const n = new Set(Object.keys(e));
    for (const [r, a] of Object.entries(s))
      n.has(r) ? Object.assign(e[r], a) : e[r] = a;
    return e;
  }
  static getDefaultDrawingOptions(e) {
    it("Not implemented");
  }
  static get typesMap() {
    it("Not implemented");
  }
  static get isDrawer() {
    return !0;
  }
  static get _hasClipPath() {
    return !1;
  }
  static get _hasDrawClass() {
    return !0;
  }
  static get supportMultipleDrawings() {
    return !1;
  }
  get _drawRotation() {
    return this.rotation;
  }
  get _opacityName() {
    return this.constructor.typesMap.get(this.opacityType);
  }
  static updateDefaultParams(e, s) {
    const n = this.typesMap.get(e);
    n && this._defaultDrawingOptions.updateProperty(n, s), this._currentParent && (i(q, Yt).updateProperty(n, s), this._currentParent.drawLayer.updateProperties(this._currentDrawId, this._defaultDrawingOptions.toSVGProperties()));
  }
  updateParams(e, s) {
    const n = this.constructor.typesMap.get(e);
    n && this._updateProperty(e, n, s);
  }
  static get defaultPropertiesToUpdate() {
    const e = [], s = this._defaultDrawingOptions;
    for (const [n, r] of this.typesMap)
      e.push([n, s[r]]);
    return e;
  }
  get propertiesToUpdate() {
    const e = [], {
      _drawingOptions: s
    } = this;
    for (const [n, r] of this.constructor.typesMap)
      e.push([n, s[r]]);
    return e;
  }
  _updateProperty(e, s, n) {
    const r = this._drawingOptions, a = r[s], o = (l) => {
      var c;
      r.updateProperty(s, l);
      const h = this._drawOutlines.updateProperty(s, l);
      h && m(this, V, Uc).call(this, h), (c = this.parent) == null || c.drawLayer.updateProperties(this._drawId, r.toSVGProperties()), e === this.colorType ? this.onUpdatedColor() : e === this.opacityType && this.onUpdatedOpacity();
    };
    this.addCommands({
      cmd: o.bind(this, n),
      undo: o.bind(this, a),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: e,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  _updateColorAndOpacity(e, s, n = this.colorAndOpacityType) {
    const r = this.constructor.typesMap.get(this.colorType), a = this._opacityName, o = this._drawingOptions, l = o[r], h = o[a], c = (d, f) => {
      var b;
      o.updateProperty(r, d), o.updateProperty(a, f), this._drawOutlines.updateProperty(r, d), this._drawOutlines.updateProperty(a, f), (b = this.parent) == null || b.drawLayer.updateProperties(this._drawId, o.toSVGProperties()), this.onUpdatedColor(), this.onUpdatedOpacity();
    };
    this.addCommands({
      cmd: c.bind(this, e, s),
      undo: c.bind(this, l, h),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: n,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  _onResizing() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, q._mergeSVGProperties(this._drawOutlines.getPathResizingSVGProperties(m(this, V, Wf).call(this)), {
      bbox: m(this, V, gl).call(this)
    }));
  }
  _onResized() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, q._mergeSVGProperties(this._drawOutlines.getPathResizedSVGProperties(m(this, V, Wf).call(this)), {
      bbox: m(this, V, gl).call(this)
    })), m(this, V, Qm).call(this);
  }
  _onTranslating(e, s) {
    var n;
    (n = this.parent) == null || n.drawLayer.updateProperties(this._drawId, {
      bbox: m(this, V, gl).call(this)
    });
  }
  _onTranslated() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, q._mergeSVGProperties(this._drawOutlines.getPathTranslatedSVGProperties(m(this, V, Wf).call(this), this.parentDimensions), {
      bbox: m(this, V, gl).call(this)
    }));
  }
  _onStartDragging() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, {
      rootClass: {
        moving: !0
      }
    });
  }
  _onStopDragging() {
    var e;
    (e = this.parent) == null || e.drawLayer.updateProperties(this._drawId, {
      rootClass: {
        moving: !1
      }
    });
  }
  get _mustBeDisabledOnCommit() {
    return !0;
  }
  commit() {
    super.commit(), this._mustBeDisabledOnCommit && (this.disableEditMode(), this.disableEditing());
  }
  disableEditing() {
    super.disableEditing(), this.div.classList.toggle("disabled", !0);
  }
  enableEditing() {
    super.enableEditing(), this.div.classList.toggle("disabled", !1);
  }
  getBaseTranslation() {
    return [0, 0];
  }
  get isResizable() {
    return !0;
  }
  onceAdded(e) {
    !this.annotationElementId && this._drawId !== null && this.parent.addUndoableEditor(this), this._isDraggable = !0, i(this, Uh) && (u(this, Uh, !1), this.commit(), this.parent.setSelected(this), e && this.isOnScreen && this.div.focus());
  }
  remove() {
    this._uiManager.removeShouldRescale(this), m(this, V, tb).call(this), super.remove();
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (m(this, V, Hc).call(this), m(this, V, Uc).call(this, this._drawOutlines.box), this.isAttachedToDOM || this.parent.add(this)));
  }
  setParent(e) {
    var n;
    let s = !1;
    this.parent && !e ? (this._uiManager.removeShouldRescale(this), m(this, V, tb).call(this)) : e && (this._uiManager.addShouldRescale(this), m(this, V, Hc).call(this, e), s = !this.parent && ((n = this.div) == null ? void 0 : n.classList.contains("selectedEditor"))), super.setParent(e), m(this, V, Jm).call(this), s && this.select();
  }
  rotate(e = this.parentRotation) {
    if (!this.parent || this._drawId === null)
      return;
    const s = (e - this._drawRotation + 360) % 360;
    this.parent.drawLayer.updateProperties(this._drawId, q._mergeSVGProperties({
      bbox: m(this, V, gl).call(this, e)
    }, this._drawOutlines.updateRotation(s))), m(this, V, Qm).call(this, s);
  }
  show(e = this._isVisible) {
    super.show(e), m(this, V, Jm).call(this);
  }
  select() {
    super.select(), m(this, V, Bc).call(this, {
      hovered: !1,
      selected: !0
    });
  }
  unselect() {
    super.unselect(), m(this, V, Bc).call(this, {
      selected: !1
    });
  }
  pointerover() {
    this.isSelected || m(this, V, Bc).call(this, {
      hovered: !0
    });
  }
  pointerleave() {
    this.isSelected || m(this, V, Bc).call(this, {
      hovered: !1
    });
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    const e = this._drawOutlines.updateParentDimensions(this.parentDimensions, this.parent.scale);
    e && m(this, V, Uc).call(this, e);
  }
  static onScaleChangingWhenDrawing() {
  }
  render() {
    if (this.div)
      return this.div;
    let e, s;
    this._isCopy && (e = this.x, s = this.y);
    const n = super.render();
    this.constructor._hasDrawClass && n.classList.add("draw");
    const r = u(this, Hh, document.createElement("div"));
    return n.append(r), r.setAttribute("aria-hidden", "true"), r.className = "internal", this._clipPathId && (r.style.clipPath = this._clipPathId), jy(this, r, ["pointerover", "pointerleave"]), this.setDims(), this._uiManager.addShouldRescale(this), this.disableEditing(), this._isCopy && this._moveAfterPaste(e, s), n;
  }
  static createDrawerInstance(e) {
    it("Not implemented");
  }
  static _getDrawingTarget(e, {
    target: s
  }) {
    return s;
  }
  static _getPointerCoords({
    offsetX: e,
    offsetY: s,
    clientX: n,
    clientY: r
  }, a = null) {
    if (!a)
      return [e, s];
    let o = n - a.clientX, l = r - a.clientY;
    switch (this._currentParent.viewport.rotation) {
      case 90:
        [o, l] = [l, -o];
        break;
      case 180:
        [o, l] = [-o, -l];
        break;
      case 270:
        [o, l] = [-l, o];
        break;
    }
    return [a.offsetX + o, a.offsetY + l];
  }
  static _addDrawingListeners(e, s) {
  }
  static _endDrawingSession(e = !1) {
    return this._currentParent.endDrawingSession(e);
  }
  static startDrawing(e, s, n, r) {
    var C;
    const {
      pointerId: a,
      pointerType: o
    } = r;
    if (Ae.isInitializedAndDifferentPointerType(o))
      return;
    const l = this._getDrawingTarget(e, r), [h, c] = this._getPointerCoords(r), {
      viewport: {
        rotation: d
      }
    } = e, {
      x: f,
      y: b,
      width: y,
      height: A
    } = l.getBoundingClientRect(), w = u(q, zo, new AbortController()), v = e.combinedSignal(w);
    if (Ae.setPointer(o, a), window.addEventListener("pointerup", (x) => {
      Ae.isSamePointerIdOrRemove(x.pointerId) && this._endDraw(x);
    }, {
      signal: v
    }), window.addEventListener("pointercancel", (x) => {
      Ae.isSamePointerIdOrRemove(x.pointerId) && this._endDrawingSession();
    }, {
      signal: v
    }), window.addEventListener("pointerdown", (x) => {
      Ae.isSamePointerType(x.pointerType) && (Ae.initializeAndAddPointerId(x.pointerId), i(q, Yt).isCancellable() && (i(q, Yt).removeLastElement(), i(q, Yt).isEmpty() ? this._endDrawingSession(!0) : this._endDraw(null)));
    }, {
      capture: !0,
      passive: !1,
      signal: v
    }), window.addEventListener("contextmenu", di, {
      signal: v
    }), l.addEventListener("pointermove", this._drawMove.bind(this), {
      signal: v
    }), l.addEventListener("touchmove", (x) => {
      Ae.isSameTimeStamp(x.timeStamp) && te(x);
    }, {
      signal: v
    }), this._addDrawingListeners(l, v), e.toggleDrawing(), (C = s._editorUndoBar) == null || C.hide(), i(q, Yt)) {
      e.drawLayer.updateProperties(this._currentDrawId, i(q, Yt).startNew(h, c, y, A, d, r.timeStamp));
      return;
    }
    s.updateUIForDefaultProperties(this), u(q, Yt, this.createDrawerInstance({
      x: h,
      y: c,
      box: [f, b, y, A],
      rotation: d,
      parent: e,
      isLTR: n,
      timeStamp: r.timeStamp
    })), u(q, Go, this.getDefaultDrawingOptions()), this._currentParent = e;
    const {
      id: S,
      clipPathId: E
    } = e.drawLayer.draw(this._mergeSVGProperties(i(q, Go).toSVGProperties(), i(q, Yt).defaultSVGProperties), !0, this._hasClipPath);
    this._currentDrawId = S, u(q, zh, this._hasClipPath ? E : null);
  }
  static _drawMove(e) {
    var r;
    if (Ae.isSameTimeStamp(e.timeStamp), !i(q, Yt) || !Ae.isSamePointerId(e.pointerId))
      return;
    if (Ae.isUsingMultiplePointers()) {
      this._endDraw(e);
      return;
    }
    let s;
    const n = (r = e.getCoalescedEvents) == null ? void 0 : r.call(e);
    if (n != null && n.length) {
      const a = [], o = [];
      for (const l of n)
        a.push(...this._getPointerCoords(l, e)), o.push(l.timeStamp);
      s = i(q, Yt).addPoints(a, o);
    } else
      s = i(q, Yt).add(...this._getPointerCoords(e), e.timeStamp);
    this._currentParent.drawLayer.updateProperties(this._currentDrawId, s), Ae.setTimeStamp(e.timeStamp), te(e);
  }
  static _cleanup(e) {
    e && (this._currentDrawId = -1, this._currentParent = null, u(q, Yt, null), u(q, Go, null), u(q, zh, null), Ae.clearTimeStamp()), i(q, zo) && (i(q, zo).abort(), u(q, zo, null), Ae.clearPointerIds());
  }
  static _endDraw(e) {
    const s = this._currentParent;
    if (s) {
      if (s.toggleDrawing(!0), this._cleanup(!1), s.drawLayer.updateProperties(this._currentDrawId, (e == null ? void 0 : e.target) === s.div ? i(q, Yt).end(...this._getPointerCoords(e), e.timeStamp) : i(q, Yt).end()), this.supportMultipleDrawings) {
        const n = i(q, Yt), r = this._currentDrawId, a = n.getLastElement();
        s.addCommands({
          cmd: () => {
            s.drawLayer.updateProperties(r, n.setLastElement(a));
          },
          undo: () => {
            s.drawLayer.updateProperties(r, n.removeLastElement());
          },
          mustExec: !1,
          type: tt.DRAW_STEP
        });
        return;
      }
      this.endDrawing(!1);
    }
  }
  static endDrawing(e) {
    const s = this._currentParent;
    if (!s)
      return null;
    if (s.toggleDrawing(!0), s.cleanUndoStack(tt.DRAW_STEP), !i(q, Yt).isEmpty()) {
      const {
        pageDimensions: [n, r],
        scale: a
      } = s, o = s.createAndAddNewEditor({
        offsetX: 0,
        offsetY: 0
      }, !1, {
        drawId: this._currentDrawId,
        clipPathId: i(q, zh),
        drawOutlines: i(q, Yt).getOutlines(n * a, r * a, a, this._INNER_MARGIN),
        drawingOptions: i(q, Go),
        mustBeCommitted: !e
      });
      return this._cleanup(!0), o;
    }
    return s.drawLayer.remove(this._currentDrawId), this._cleanup(!0), null;
  }
  createDrawingOptions(e) {
  }
  static deserializeDraw(e, s, n, r, a, o, l) {
    it("Not implemented");
  }
  static async deserialize(e, s, n) {
    var d, f;
    const {
      rawDims: {
        pageWidth: r,
        pageHeight: a,
        pageX: o,
        pageY: l
      }
    } = s.viewport, h = this.deserializeDraw(o, l, r, a, this._INNER_MARGIN, e, n), c = await super.deserialize(e, s, n);
    return c.createDrawingOptions(e), m(d = c, V, Ym).call(d, {
      drawOutlines: h
    }), m(f = c, V, Hc).call(f), c.onScaleChanging(), c.rotate(), c;
  }
  serializeDraw(e) {
    const [s, n] = this.pageTranslation, [r, a] = this.pageDimensions;
    return this._drawOutlines.serialize([s, n, r, a], e);
  }
  renderAnnotationElement(e) {
    return e.updateEdited({
      rect: this.getPDFRect()
    }), null;
  }
  static canCreateNewEmptyEditor() {
    return !1;
  }
};
Hh = new WeakMap(), Uh = new WeakMap(), Yt = new WeakMap(), zo = new WeakMap(), Go = new WeakMap(), zh = new WeakMap(), V = new WeakSet(), Ym = function({
  drawOutlines: e,
  drawId: s,
  drawingOptions: n,
  clipPathId: r
}) {
  this._drawOutlines = e, this._drawingOptions || (this._drawingOptions = n), this.annotationElementId || this._uiManager.a11yAlert(bt._l10nAlert[this.editorType]), s >= 0 ? (this._drawId = s, this._clipPathId = r ?? null, this.parent.drawLayer.finalizeDraw(s, e.defaultProperties), m(this, V, qm).call(this, this.parent)) : this._drawId = m(this, V, Km).call(this, e, this.parent), m(this, V, Uc).call(this, e.box);
}, Km = function(e, s) {
  const {
    id: n,
    clipPathId: r
  } = s.drawLayer.draw(q._mergeSVGProperties(this._drawingOptions.toSVGProperties(), e.defaultSVGProperties), !1, this.constructor._hasClipPath);
  return this.constructor._hasClipPath && (this._clipPathId = r), m(this, V, qm).call(this, s), n;
}, qm = function(e) {
  const s = this._drawOutlines.getFocusSVGProperties(i(this, V, Zm));
  s && (this._focusDrawId = e.drawLayer.drawOutline(s, this._drawOutlines.focusMustRemoveSelfIntersections));
}, Qm = function(e = i(this, V, Zm)) {
  var s;
  this._focusDrawId !== null && ((s = this.parent) == null || s.drawLayer.updateProperties(this._focusDrawId, this._drawOutlines.getFocusSVGProperties(e)));
}, Bc = function(e) {
  var s;
  this._focusDrawId !== null && ((s = this.parent) == null || s.drawLayer.updateProperties(this._focusDrawId, {
    rootClass: e
  }));
}, Jm = function() {
  const {
    parent: e,
    _drawId: s,
    _focusDrawId: n,
    _isVisible: r
  } = this;
  if (!e || s === null)
    return;
  const a = {
    hidden: !r
  };
  e.drawLayer.updateProperties(s, {
    rootClass: a
  }), n !== null && e.drawLayer.updateProperties(n, {
    rootClass: a
  });
}, Zm = function() {
  return (this.parentRotation - this._drawRotation + 360) % 360;
}, tb = function() {
  if (this._drawId === null || !this.parent)
    return;
  const {
    drawLayer: e
  } = this.parent;
  e.remove(this._drawId), this._drawId = null, this._focusDrawId !== null && (e.remove(this._focusDrawId), this._focusDrawId = null), this._drawingOptions.reset();
}, Hc = function(e = this.parent) {
  if (!(this._drawId !== null && this.parent === e)) {
    if (this._drawId !== null) {
      const {
        drawLayer: s
      } = this.parent;
      s.updateParent(this._drawId, e.drawLayer), this._focusDrawId !== null && s.updateParent(this._focusDrawId, e.drawLayer);
      return;
    }
    this._drawingOptions.updateAll(), this._drawId = m(this, V, Km).call(this, this._drawOutlines, e), this._clipPathId && i(this, Hh) && (i(this, Hh).style.clipPath = this._clipPathId);
  }
}, O0 = function([e, s, n, r]) {
  const {
    parentDimensions: [a, o],
    _drawRotation: l
  } = this;
  switch (l) {
    case 90:
      return [s, 1 - e, n * (o / a), r * (a / o)];
    case 180:
      return [1 - e, 1 - s, n, r];
    case 270:
      return [1 - s, e, n * (o / a), r * (a / o)];
    default:
      return [e, s, n, r];
  }
}, Wf = function() {
  const {
    x: e,
    y: s,
    width: n,
    height: r,
    parentDimensions: [a, o],
    _drawRotation: l
  } = this;
  switch (l) {
    case 90:
      return [1 - s, e, n * (a / o), r * (o / a)];
    case 180:
      return [1 - e, 1 - s, n, r];
    case 270:
      return [s, 1 - e, n * (a / o), r * (o / a)];
    default:
      return [e, s, n, r];
  }
}, Uc = function(e) {
  [this.x, this.y, this.width, this.height] = m(this, V, O0).call(this, e), this.div && (this.fixAndSetPosition(), this.setDims()), this._onResized();
}, gl = function(e = this.parentRotation) {
  const {
    x: s,
    y: n,
    width: r,
    height: a,
    _drawRotation: o,
    parentDimensions: [l, h]
  } = this;
  switch ((o * 4 + e) / 90) {
    case 1:
      return [1 - n - a, s, a, r];
    case 2:
      return [1 - s - r, 1 - n - a, r, a];
    case 3:
      return [n, 1 - s - r, a, r];
    case 4:
      return [s, n - r * (l / h), a * (h / l), r * (l / h)];
    case 5:
      return [1 - n, s, r * (l / h), a * (h / l)];
    case 6:
      return [1 - s - a * (h / l), 1 - n, a * (h / l), r * (l / h)];
    case 7:
      return [n - r * (l / h), 1 - s - a * (h / l), r * (l / h), a * (h / l)];
    case 8:
      return [s - r, n - a, r, a];
    case 9:
      return [1 - n, s - r, a, r];
    case 10:
      return [1 - s, 1 - n, r, a];
    case 11:
      return [n - a, 1 - s, a, r];
    case 12:
      return [s - a * (h / l), n, a * (h / l), r * (l / h)];
    case 13:
      return [1 - n - r * (l / h), s - a * (h / l), r * (l / h), a * (h / l)];
    case 14:
      return [1 - s, 1 - n - r * (l / h), a * (h / l), r * (l / h)];
    case 15:
      return [n, 1 - s, r * (l / h), a * (h / l)];
    default:
      return [s, n, r, a];
  }
}, _(q, "_currentDrawId", -1), _(q, "_currentParent", null), g(q, Yt, null), g(q, zo, null), g(q, Go, null), g(q, zh, null), _(q, "_INNER_MARGIN", 3);
let ed = q;
class U {
  constructor() {
    _(this, "focusOutline", null);
  }
  toSVGPath() {
    it("Abstract method `toSVGPath` must be implemented.");
  }
  get box() {
    it("Abstract getter `box` must be implemented.");
  }
  serialize(t, e) {
    it("Abstract method `serialize` must be implemented.");
  }
  get defaultSVGProperties() {
    it("Abstract getter `defaultSVGProperties` must be implemented.");
  }
  get defaultProperties() {
    return this.defaultSVGProperties;
  }
  getFocusSVGProperties(t) {
    return null;
  }
  get focusMustRemoveSelfIntersections() {
    return !1;
  }
  updateProperty(t, e) {
    return null;
  }
  updateParentDimensions(t, e) {
    return null;
  }
  serializeQuadPoints(t, e) {
    return null;
  }
  updateRotation(t) {
    return {};
  }
  getPathResizingSVGProperties(t) {
    return {};
  }
  getPathResizedSVGProperties(t) {
    return {};
  }
  getPathTranslatedSVGProperties(t, e) {
    return {};
  }
  static _rotateBox([t, e, s, n], r) {
    switch (r) {
      case 90:
        return [1 - e - n, t, n, s];
      case 180:
        return [1 - t - s, 1 - e - n, s, n];
      case 270:
        return [e, 1 - t - s, n, s];
    }
    return [t, e, s, n];
  }
  static _rescale(t, e, s, n, r, a) {
    a || (a = new Float32Array(t.length));
    for (let o = 0, l = t.length; o < l; o += 2)
      a[o] = e + t[o] * n, a[o + 1] = s + t[o + 1] * r;
    return a;
  }
  static _rescaleAndSwap(t, e, s, n, r, a) {
    a || (a = new Float32Array(t.length));
    for (let o = 0, l = t.length; o < l; o += 2)
      a[o] = e + t[o + 1] * n, a[o + 1] = s + t[o] * r;
    return a;
  }
  static _translate(t, e, s, n) {
    n || (n = new Float32Array(t.length));
    for (let r = 0, a = t.length; r < a; r += 2)
      n[r] = e + t[r], n[r + 1] = s + t[r + 1];
    return n;
  }
  static svgRound(t) {
    return Math.round(t * 1e4);
  }
  static _normalizePoint(t, e, s, n, r, a = []) {
    switch (r) {
      case 90:
        a[0] = 1 - e / s, a[1] = t / n;
        break;
      case 180:
        a[0] = 1 - t / s, a[1] = 1 - e / n;
        break;
      case 270:
        a[0] = e / s, a[1] = 1 - t / n;
        break;
      default:
        a[0] = t / s, a[1] = e / n;
        break;
    }
    return a;
  }
  static createBezierPoints(t, e, s, n, r, a, o = []) {
    return o.push((t + 5 * s) / 6, (e + 5 * n) / 6, (5 * s + r) / 6, (5 * n + a) / 6, (s + r) / 2, (n + a) / 2), o;
  }
}
_(U, "PRECISION", 1e-4);
var ds, Hs, Gh, $h, ei, Z, $o, jo, Fu, Lu, jh, Vh, Hi, Ou, jp, Vp, ee, zc, R0, N0, B0, H0, U0, z0;
const rn = class rn {
  constructor(t, e, s, n, r, a, o = 0) {
    g(this, ee);
    g(this, ds);
    g(this, Hs, []);
    g(this, Gh);
    g(this, $h);
    g(this, ei, []);
    g(this, Z, new Float32Array(18));
    g(this, $o);
    g(this, jo);
    g(this, Fu);
    g(this, Lu);
    g(this, jh);
    g(this, Vh);
    g(this, Hi, []);
    u(this, ds, s), u(this, Vh, r * n), u(this, $h, a), i(this, Z).set([NaN, NaN, NaN, NaN, t, e], 6), u(this, Gh, o), u(this, Lu, i(rn, Ou) * n), u(this, Fu, i(rn, Vp) * n), u(this, jh, n), i(this, Hi).push(t, e);
  }
  isEmpty() {
    return isNaN(i(this, Z)[8]);
  }
  isCancellable() {
    return i(this, Hi).length <= 10;
  }
  removeLastElement() {
    return i(this, Z).fill(NaN), i(this, ei).length = i(this, Hs).length = i(this, Hi).length = 0, {
      path: {
        d: ""
      }
    };
  }
  add(t, e) {
    var P;
    u(this, $o, t), u(this, jo, e);
    const [s, n, r, a] = i(this, ds);
    let [o, l, h, c] = i(this, Z).subarray(8, 12);
    const d = t - h, f = e - c, b = Math.hypot(d, f);
    if (b < i(this, Fu))
      return !1;
    const y = b - i(this, Lu), A = y / b, w = A * d, v = A * f;
    let S = o, E = l;
    o = h, l = c, h += w, c += v, (P = i(this, Hi)) == null || P.push(t, e);
    const C = -v / y, x = w / y, T = C * i(this, Vh), k = x * i(this, Vh);
    return i(this, Z).set(i(this, Z).subarray(2, 8), 0), i(this, Z).set([h + T, c + k], 4), i(this, Z).set(i(this, Z).subarray(14, 18), 12), i(this, Z).set([h - T, c - k], 16), isNaN(i(this, Z)[6]) ? (i(this, ei).length === 0 && (i(this, Z).set([o + T, l + k], 2), i(this, ei).push(NaN, NaN, NaN, NaN, (o + T - s) / r, (l + k - n) / a), i(this, Z).set([o - T, l - k], 14), i(this, Hs).push(NaN, NaN, NaN, NaN, (o - T - s) / r, (l - k - n) / a)), i(this, Z).set([S, E, o, l, h, c], 6), !this.isEmpty()) : (i(this, Z).set([S, E, o, l, h, c], 6), Math.abs(Math.atan2(E - l, S - o) - Math.atan2(v, w)) < Math.PI / 2 ? ([o, l, h, c] = i(this, Z).subarray(2, 6), i(this, ei).push(NaN, NaN, NaN, NaN, ((o + h) / 2 - s) / r, ((l + c) / 2 - n) / a), [o, l, S, E] = i(this, Z).subarray(14, 18), i(this, Hs).push(NaN, NaN, NaN, NaN, ((S + o) / 2 - s) / r, ((E + l) / 2 - n) / a), !0) : ([S, E, o, l, h, c] = i(this, Z).subarray(0, 6), i(this, ei).push(((S + 5 * o) / 6 - s) / r, ((E + 5 * l) / 6 - n) / a, ((5 * o + h) / 6 - s) / r, ((5 * l + c) / 6 - n) / a, ((o + h) / 2 - s) / r, ((l + c) / 2 - n) / a), [h, c, o, l, S, E] = i(this, Z).subarray(12, 18), i(this, Hs).push(((S + 5 * o) / 6 - s) / r, ((E + 5 * l) / 6 - n) / a, ((5 * o + h) / 6 - s) / r, ((5 * l + c) / 6 - n) / a, ((o + h) / 2 - s) / r, ((l + c) / 2 - n) / a), !0));
  }
  toSVGPath() {
    if (this.isEmpty())
      return "";
    const t = i(this, ei), e = i(this, Hs);
    if (isNaN(i(this, Z)[6]) && !this.isEmpty())
      return m(this, ee, R0).call(this);
    const s = [];
    s.push(`M${t[4]} ${t[5]}`);
    for (let n = 6; n < t.length; n += 6)
      isNaN(t[n]) ? s.push(`L${t[n + 4]} ${t[n + 5]}`) : s.push(`C${t[n]} ${t[n + 1]} ${t[n + 2]} ${t[n + 3]} ${t[n + 4]} ${t[n + 5]}`);
    m(this, ee, B0).call(this, s);
    for (let n = e.length - 6; n >= 6; n -= 6)
      isNaN(e[n]) ? s.push(`L${e[n + 4]} ${e[n + 5]}`) : s.push(`C${e[n]} ${e[n + 1]} ${e[n + 2]} ${e[n + 3]} ${e[n + 4]} ${e[n + 5]}`);
    return m(this, ee, N0).call(this, s), s.join(" ");
  }
  newFreeDrawOutline(t, e, s, n, r, a) {
    return new G0(t, e, s, n, r, a);
  }
  getOutlines() {
    var d;
    const t = i(this, ei), e = i(this, Hs), s = i(this, Z), [n, r, a, o] = i(this, ds), l = new Float32Array((((d = i(this, Hi)) == null ? void 0 : d.length) ?? 0) + 2);
    for (let f = 0, b = l.length - 2; f < b; f += 2)
      l[f] = (i(this, Hi)[f] - n) / a, l[f + 1] = (i(this, Hi)[f + 1] - r) / o;
    if (l[l.length - 2] = (i(this, $o) - n) / a, l[l.length - 1] = (i(this, jo) - r) / o, isNaN(s[6]) && !this.isEmpty())
      return m(this, ee, H0).call(this, l);
    const h = new Float32Array(i(this, ei).length + 24 + i(this, Hs).length);
    let c = t.length;
    for (let f = 0; f < c; f += 2) {
      if (isNaN(t[f])) {
        h[f] = h[f + 1] = NaN;
        continue;
      }
      h[f] = t[f], h[f + 1] = t[f + 1];
    }
    c = m(this, ee, z0).call(this, h, c);
    for (let f = e.length - 6; f >= 6; f -= 6)
      for (let b = 0; b < 6; b += 2) {
        if (isNaN(e[f + b])) {
          h[c] = h[c + 1] = NaN, c += 2;
          continue;
        }
        h[c] = e[f + b], h[c + 1] = e[f + b + 1], c += 2;
      }
    return m(this, ee, U0).call(this, h, c), this.newFreeDrawOutline(h, l, i(this, ds), i(this, jh), i(this, Gh), i(this, $h));
  }
};
ds = new WeakMap(), Hs = new WeakMap(), Gh = new WeakMap(), $h = new WeakMap(), ei = new WeakMap(), Z = new WeakMap(), $o = new WeakMap(), jo = new WeakMap(), Fu = new WeakMap(), Lu = new WeakMap(), jh = new WeakMap(), Vh = new WeakMap(), Hi = new WeakMap(), Ou = new WeakMap(), jp = new WeakMap(), Vp = new WeakMap(), ee = new WeakSet(), zc = function() {
  const t = i(this, Z).subarray(4, 6), e = i(this, Z).subarray(16, 18), [s, n, r, a] = i(this, ds);
  return [(i(this, $o) + (t[0] - e[0]) / 2 - s) / r, (i(this, jo) + (t[1] - e[1]) / 2 - n) / a, (i(this, $o) + (e[0] - t[0]) / 2 - s) / r, (i(this, jo) + (e[1] - t[1]) / 2 - n) / a];
}, R0 = function() {
  const [t, e, s, n] = i(this, ds), [r, a, o, l] = m(this, ee, zc).call(this);
  return `M${(i(this, Z)[2] - t) / s} ${(i(this, Z)[3] - e) / n} L${(i(this, Z)[4] - t) / s} ${(i(this, Z)[5] - e) / n} L${r} ${a} L${o} ${l} L${(i(this, Z)[16] - t) / s} ${(i(this, Z)[17] - e) / n} L${(i(this, Z)[14] - t) / s} ${(i(this, Z)[15] - e) / n} Z`;
}, N0 = function(t) {
  const e = i(this, Hs);
  t.push(`L${e[4]} ${e[5]} Z`);
}, B0 = function(t) {
  const [e, s, n, r] = i(this, ds), a = i(this, Z).subarray(4, 6), o = i(this, Z).subarray(16, 18), [l, h, c, d] = m(this, ee, zc).call(this);
  t.push(`L${(a[0] - e) / n} ${(a[1] - s) / r} L${l} ${h} L${c} ${d} L${(o[0] - e) / n} ${(o[1] - s) / r}`);
}, H0 = function(t) {
  const e = i(this, Z), [s, n, r, a] = i(this, ds), [o, l, h, c] = m(this, ee, zc).call(this), d = new Float32Array(36);
  return d.set([NaN, NaN, NaN, NaN, (e[2] - s) / r, (e[3] - n) / a, NaN, NaN, NaN, NaN, (e[4] - s) / r, (e[5] - n) / a, NaN, NaN, NaN, NaN, o, l, NaN, NaN, NaN, NaN, h, c, NaN, NaN, NaN, NaN, (e[16] - s) / r, (e[17] - n) / a, NaN, NaN, NaN, NaN, (e[14] - s) / r, (e[15] - n) / a], 0), this.newFreeDrawOutline(d, t, i(this, ds), i(this, jh), i(this, Gh), i(this, $h));
}, U0 = function(t, e) {
  const s = i(this, Hs);
  return t.set([NaN, NaN, NaN, NaN, s[4], s[5]], e), e += 6;
}, z0 = function(t, e) {
  const s = i(this, Z).subarray(4, 6), n = i(this, Z).subarray(16, 18), [r, a, o, l] = i(this, ds), [h, c, d, f] = m(this, ee, zc).call(this);
  return t.set([NaN, NaN, NaN, NaN, (s[0] - r) / o, (s[1] - a) / l, NaN, NaN, NaN, NaN, h, c, NaN, NaN, NaN, NaN, d, f, NaN, NaN, NaN, NaN, (n[0] - r) / o, (n[1] - a) / l], e), e += 24;
}, g(rn, Ou, 8), g(rn, jp, 2), g(rn, Vp, i(rn, Ou) + i(rn, jp));
let pp = rn;
var Wh, Ui, Bn, Ru, si, Nu, Rt, Wp, $0;
class G0 extends U {
  constructor(e, s, n, r, a, o) {
    super();
    g(this, Wp);
    g(this, Wh);
    g(this, Ui, new Float32Array(4));
    g(this, Bn);
    g(this, Ru);
    g(this, si);
    g(this, Nu);
    g(this, Rt);
    u(this, Rt, e), u(this, si, s), u(this, Wh, n), u(this, Nu, r), u(this, Bn, a), u(this, Ru, o), this.firstPoint = [NaN, NaN], this.lastPoint = [NaN, NaN], m(this, Wp, $0).call(this, o);
    const [l, h, c, d] = i(this, Ui);
    for (let f = 0, b = e.length; f < b; f += 2)
      e[f] = (e[f] - l) / c, e[f + 1] = (e[f + 1] - h) / d;
    for (let f = 0, b = s.length; f < b; f += 2)
      s[f] = (s[f] - l) / c, s[f + 1] = (s[f + 1] - h) / d;
  }
  toSVGPath() {
    const e = [`M${i(this, Rt)[4]} ${i(this, Rt)[5]}`];
    for (let s = 6, n = i(this, Rt).length; s < n; s += 6) {
      if (isNaN(i(this, Rt)[s])) {
        e.push(`L${i(this, Rt)[s + 4]} ${i(this, Rt)[s + 5]}`);
        continue;
      }
      e.push(`C${i(this, Rt)[s]} ${i(this, Rt)[s + 1]} ${i(this, Rt)[s + 2]} ${i(this, Rt)[s + 3]} ${i(this, Rt)[s + 4]} ${i(this, Rt)[s + 5]}`);
    }
    return e.push("Z"), e.join(" ");
  }
  serialize([e, s, n, r], a) {
    const o = n - e, l = r - s;
    let h, c;
    switch (a) {
      case 0:
        h = U._rescale(i(this, Rt), e, r, o, -l), c = U._rescale(i(this, si), e, r, o, -l);
        break;
      case 90:
        h = U._rescaleAndSwap(i(this, Rt), e, s, o, l), c = U._rescaleAndSwap(i(this, si), e, s, o, l);
        break;
      case 180:
        h = U._rescale(i(this, Rt), n, s, -o, l), c = U._rescale(i(this, si), n, s, -o, l);
        break;
      case 270:
        h = U._rescaleAndSwap(i(this, Rt), n, r, -o, -l), c = U._rescaleAndSwap(i(this, si), n, r, -o, -l);
        break;
    }
    return {
      outline: Array.from(h),
      points: [Array.from(c)]
    };
  }
  get box() {
    return i(this, Ui);
  }
  newOutliner(e, s, n, r, a, o, l = 0) {
    return new pp(e, s, n, r, a, o, l);
  }
  updateThickness(e) {
    const s = this.getNewOutline(e);
    return u(this, Rt, i(s, Rt)), u(this, si, i(s, si)), i(this, Ui).set(i(s, Ui)), this.firstPoint = s.firstPoint, this.lastPoint = s.lastPoint, i(this, Ui);
  }
  getNewOutline(e, s) {
    const [n, r, a, o] = i(this, Ui), [l, h, c, d] = i(this, Wh), f = a * c, b = o * d, y = n * c + l, A = r * d + h, w = i(this, si), v = this.newOutliner(w[0] * f + y, w[1] * b + A, i(this, Wh), i(this, Nu), e, i(this, Ru), s ?? i(this, Bn));
    for (let S = 2, E = w.length; S < E; S += 2)
      v.add(w[S] * f + y, w[S + 1] * b + A);
    return v.getOutlines();
  }
}
Wh = new WeakMap(), Ui = new WeakMap(), Bn = new WeakMap(), Ru = new WeakMap(), si = new WeakMap(), Nu = new WeakMap(), Rt = new WeakMap(), Wp = new WeakSet(), $0 = function(e) {
  const s = i(this, Rt);
  let n = s[4], r = s[5];
  const a = [n, r, n, r];
  let o = n, l = r, h = n, c = r;
  const d = e ? Math.max : Math.min, f = new Float32Array(4);
  for (let y = 6, A = s.length; y < A; y += 6) {
    const w = s[y + 4], v = s[y + 5];
    isNaN(s[y]) ? (I.pointBoundingBox(w, v, a), l > v ? (o = w, l = v) : l === v && (o = d(o, w)), c < v ? (h = w, c = v) : c === v && (h = d(h, w))) : (f.set(Yi, 0), I.bezierBoundingBox(n, r, ...s.slice(y, y + 6), f), I.rectBoundingBox(...f, a), l > f[1] ? (o = f[0], l = f[1]) : l === f[1] && (o = d(o, f[0])), c < f[3] ? (h = f[2], c = f[3]) : c === f[3] && (h = d(h, f[2]))), n = w, r = v;
  }
  const b = i(this, Ui);
  b[0] = a[0] - i(this, Bn), b[1] = a[1] - i(this, Bn), b[2] = a[2] - a[0] + 2 * i(this, Bn), b[3] = a[3] - a[1] + 2 * i(this, Bn), this.firstPoint = [o, l], this.lastPoint = [h, c];
};
function j0(p) {
  return {
    bbox: p.box,
    root: {
      viewBox: "0 0 1 1"
    },
    rootClass: {
      highlight: !0,
      free: p.isFree
    },
    path: {
      d: p.toSVGPath()
    }
  };
}
function V0(p, t) {
  const {
    focusOutline: e
  } = p;
  return {
    bbox: U._rotateBox(e.box, t),
    root: {
      "data-main-rotation": t
    },
    rootClass: {
      highlightOutline: !0,
      free: p.isFree
    },
    path: {
      d: e.toSVGPath()
    }
  };
}
var Bu, Hu, Uu, Vr, ii, Be, W0, Xf, X0, Y0, sb;
class eb {
  constructor(t, e = 0, s = 0, n = !0) {
    g(this, Be);
    g(this, Bu);
    g(this, Hu);
    g(this, Uu);
    g(this, Vr, []);
    g(this, ii, []);
    const r = Yi.slice(), a = 10 ** -4;
    for (const {
      x: A,
      y: w,
      width: v,
      height: S
    } of t) {
      const E = Math.floor((A - e) / a) * a, C = Math.ceil((A + v + e) / a) * a, x = Math.floor((w - e) / a) * a, T = Math.ceil((w + S + e) / a) * a, k = [E, x, T, !0], M = [C, x, T, !1];
      i(this, Vr).push(k, M), I.rectBoundingBox(E, x, C, T, r);
    }
    const o = r[2] - r[0] + 2 * s, l = r[3] - r[1] + 2 * s, h = r[0] - s, c = r[1] - s;
    let d = n ? -1 / 0 : 1 / 0, f = 1 / 0;
    const b = i(this, Vr).at(n ? -1 : -2), y = [b[0], b[2]];
    for (const A of i(this, Vr)) {
      const [w, v, S, E] = A;
      !E && n ? v < f ? (f = v, d = w) : v === f && (d = Math.max(d, w)) : E && !n && (v < f ? (f = v, d = w) : v === f && (d = Math.min(d, w))), A[0] = (w - h) / o, A[1] = (v - c) / l, A[2] = (S - c) / l;
    }
    u(this, Bu, new Float32Array([h, c, o, l])), u(this, Hu, [d, f]), u(this, Uu, y);
  }
  getOutlines() {
    i(this, Vr).sort((e, s) => e[0] - s[0] || e[1] - s[1] || e[2] - s[2]);
    const t = [];
    for (const e of i(this, Vr))
      e[3] ? (t.push(...m(this, Be, sb).call(this, e)), m(this, Be, X0).call(this, e)) : (m(this, Be, Y0).call(this, e), t.push(...m(this, Be, sb).call(this, e)));
    return m(this, Be, W0).call(this, t);
  }
}
Bu = new WeakMap(), Hu = new WeakMap(), Uu = new WeakMap(), Vr = new WeakMap(), ii = new WeakMap(), Be = new WeakSet(), W0 = function(t) {
  const e = [], s = /* @__PURE__ */ new Set();
  for (const r of t) {
    const [a, o, l] = r;
    e.push([a, o, r], [a, l, r]);
  }
  e.sort((r, a) => r[1] - a[1] || r[0] - a[0]);
  for (let r = 0, a = e.length; r < a; r += 2) {
    const o = e[r][2], l = e[r + 1][2];
    o.push(l), l.push(o), s.add(o), s.add(l);
  }
  const n = [];
  for (; s.size > 0; ) {
    const r = s.values().next().value;
    let [a, o, l, h, c] = r;
    s.delete(r);
    let d = a, f = o;
    const b = [a, l];
    for (n.push(b); ; ) {
      let y;
      if (s.has(h))
        y = h;
      else if (s.has(c))
        y = c;
      else
        break;
      s.delete(y), [a, o, l, h, c] = y, d !== a && (b.push(d, f, a, f === o ? o : l), d = a), f = f === o ? l : o;
    }
    b.push(d, f);
  }
  return new ib(n, i(this, Bu), i(this, Hu), i(this, Uu));
}, Xf = function(t) {
  const e = i(this, ii);
  let s = 0, n = e.length - 1;
  for (; s <= n; ) {
    const r = s + n >> 1, a = e[r][0];
    if (a === t)
      return r;
    a < t ? s = r + 1 : n = r - 1;
  }
  return n + 1;
}, X0 = function([, t, e]) {
  const s = m(this, Be, Xf).call(this, t);
  i(this, ii).splice(s, 0, [t, e]);
}, Y0 = function([, t, e]) {
  const s = m(this, Be, Xf).call(this, t);
  for (let n = s; n < i(this, ii).length; n++) {
    const [r, a] = i(this, ii)[n];
    if (r !== t)
      break;
    if (r === t && a === e) {
      i(this, ii).splice(n, 1);
      return;
    }
  }
  for (let n = s - 1; n >= 0; n--) {
    const [r, a] = i(this, ii)[n];
    if (r !== t)
      break;
    if (r === t && a === e) {
      i(this, ii).splice(n, 1);
      return;
    }
  }
}, sb = function(t) {
  const [e, s, n] = t, r = [[e, s, n]], a = m(this, Be, Xf).call(this, n);
  for (let o = 0; o < a; o++) {
    const [l, h] = i(this, ii)[o];
    for (let c = 0, d = r.length; c < d; c++) {
      const [, f, b] = r[c];
      if (!(h <= f || b <= l)) {
        if (f >= l) {
          if (b > h)
            r[c][1] = h;
          else {
            if (d === 1)
              return [];
            r.splice(c, 1), c--, d--;
          }
          continue;
        }
        r[c][2] = l, b > h && r.push([e, h, b]);
      }
    }
  }
  return r;
};
var zu, Gu, Xh;
class ib extends U {
  constructor(e, s, n, r) {
    super();
    g(this, zu);
    g(this, Gu, null);
    g(this, Xh);
    u(this, Xh, e), u(this, zu, s), this.firstPoint = n, this.lastPoint = r;
  }
  static build(e, s) {
    const n = new eb(e, 1e-3).getOutlines();
    return u(n, Gu, e), n.focusOutline = new eb(e, 25e-4, 1e-3, s).getOutlines(), n;
  }
  get isFree() {
    return !1;
  }
  get defaultSVGProperties() {
    return j0(this);
  }
  getFocusSVGProperties(e) {
    return V0(this, e);
  }
  updateRotation(e) {
    return {
      root: {
        "data-main-rotation": e
      }
    };
  }
  serializeQuadPoints([e, s], [n, r]) {
    const a = i(this, Gu), o = new Float32Array(a.length * 8);
    let l = 0;
    for (const {
      x: h,
      y: c,
      width: d,
      height: f
    } of a) {
      const b = h * n + e, y = (1 - c) * r + s;
      o[l] = o[l + 4] = b, o[l + 1] = o[l + 3] = y, o[l + 2] = o[l + 6] = b + d * n, o[l + 5] = o[l + 7] = y - f * r, l += 8;
    }
    return o;
  }
  toSVGPath() {
    const e = [];
    for (const s of i(this, Xh)) {
      let [n, r] = s;
      e.push(`M${n} ${r}`);
      for (let a = 2; a < s.length; a += 2) {
        const o = s[a], l = s[a + 1];
        o === n ? (e.push(`V${l}`), r = l) : l === r && (e.push(`H${o}`), n = o);
      }
      e.push("Z");
    }
    return e.join(" ");
  }
  serialize([e, s, n, r], a) {
    const o = [], l = n - e, h = r - s;
    for (const c of i(this, Xh)) {
      const d = new Array(c.length);
      for (let f = 0; f < c.length; f += 2)
        d[f] = e + c[f] * l, d[f + 1] = r - c[f + 1] * h;
      o.push(d);
    }
    return o;
  }
  get box() {
    return i(this, zu);
  }
}
zu = new WeakMap(), Gu = new WeakMap(), Xh = new WeakMap();
class Vb extends pp {
  newFreeDrawOutline(t, e, s, n, r, a) {
    return new nb(t, e, s, n, r, a);
  }
}
var us, $u;
class _S {
  constructor(t, e, s, n, r, a, o) {
    g(this, us);
    g(this, $u);
    u(this, us, new Vb(t, e, s, n, r, a, o)), u(this, $u, r);
  }
  add(t, e) {
    return i(this, us).add(t, e) ? {
      path: {
        d: i(this, us).toSVGPath()
      }
    } : null;
  }
  addPoints(t) {
    let e = !1;
    for (let s = 0, n = t.length; s < n; s += 2)
      e = i(this, us).add(t[s], t[s + 1]) || e;
    return e ? {
      path: {
        d: i(this, us).toSVGPath()
      }
    } : null;
  }
  end(t, e) {
    return t === void 0 ? null : this.add(t, e);
  }
  isEmpty() {
    return i(this, us).isEmpty();
  }
  isCancellable() {
    return i(this, us).isCancellable();
  }
  removeLastElement() {
    return i(this, us).removeLastElement();
  }
  updateProperty(t, e) {
    return null;
  }
  getOutlines() {
    const t = i(this, us).getOutlines();
    return t.buildFocusOutline(2 * i(this, $u)), t;
  }
  get defaultSVGProperties() {
    return {
      bbox: [0, 0, 1, 1],
      root: {
        viewBox: "0 0 1 1"
      },
      rootClass: {
        highlight: !0,
        free: !0
      },
      path: {
        d: i(this, us).toSVGPath()
      }
    };
  }
}
us = new WeakMap(), $u = new WeakMap();
var Xp;
const Yp = class Yp extends G0 {
  newOutliner(t, e, s, n, r, a, o = 0) {
    return new Vb(t, e, s, n, r, a, o);
  }
  get isFree() {
    return !0;
  }
  buildFocusOutline(t) {
    this.focusOutline = this.getNewOutline(t / 2 + i(Yp, Xp), 25e-4);
  }
  get defaultSVGProperties() {
    return j0(this);
  }
  getFocusSVGProperties(t) {
    return V0(this, t);
  }
  get focusMustRemoveSelfIntersections() {
    return !0;
  }
  updateRotation(t) {
    return {
      root: {
        "data-main-rotation": t
      }
    };
  }
  updateProperty(t, e) {
    if (t !== "thickness")
      return null;
    const s = this.updateThickness(e / 2);
    return this.buildFocusOutline(e), s;
  }
  getPathResizedSVGProperties() {
    return {
      path: {
        d: this.toSVGPath()
      }
    };
  }
};
Xp = new WeakMap(), g(Yp, Xp, 1.5);
let nb = Yp;
class Wb extends jb {
  constructor(t = null) {
    super(), super.updateProperties(t);
  }
  updateSVGProperty(t, e) {
    t !== "thickness" && super.updateSVGProperty(t, e);
  }
  clone() {
    const t = new Wb();
    return t.updateAll(this), t;
  }
}
var Yh, ju, Vu, Wu, Xu, Kh, vs, rb, K0, Yf, q0;
const De = class De extends ed {
  constructor(e) {
    var s;
    super({
      ...e,
      name: "highlightEditor"
    });
    g(this, vs);
    g(this, Yh, null);
    g(this, ju, 0);
    g(this, Vu, null);
    g(this, Wu, 0);
    g(this, Xu, "");
    g(this, Kh, "");
    u(this, Yh, e.anchorNode || null), u(this, ju, e.anchorOffset || 0), u(this, Vu, e.focusNode || null), u(this, Wu, e.focusOffset || 0), u(this, Xu, e.methodOfCreation || ((s = this._drawOutlines) != null && s.isFree ? "main_toolbar" : "")), u(this, Kh, e.text || ""), this._isDraggable = !1, this.defaultL10nId = "pdfjs-editor-highlight-editor", this.rotate();
  }
  static get _keyboardManager() {
    const e = De.prototype;
    return L(this, "_keyboardManager", new rl([[["ArrowLeft"], e._moveCaret, {
      args: [0]
    }], [["ArrowRight"], e._moveCaret, {
      args: [1]
    }], [["ArrowUp"], e._moveCaret, {
      args: [2]
    }], [["ArrowDown"], e._moveCaret, {
      args: [3]
    }]]));
  }
  static initialize(e, s) {
    var n;
    bt.initialize(e, s), this._defaultDrawingOptions || (this._defaultDrawingOptions = new Wb({
      fill: ((n = s.highlightColors) == null ? void 0 : n.values().next().value) || "#fff066",
      "fill-opacity": De._DEFAULT_OPACITY,
      thickness: De._DEFAULT_THICKNESS
    }));
  }
  static getDefaultDrawingOptions(e) {
    const s = this._defaultDrawingOptions.clone();
    return s.updateProperties(e), s;
  }
  static get typesMap() {
    return L(this, "typesMap", /* @__PURE__ */ new Map([[tt.HIGHLIGHT_COLOR, "fill"], [tt.HIGHLIGHT_THICKNESS, "thickness"]]));
  }
  static get isDrawer() {
    return !1;
  }
  static get _hasClipPath() {
    return !0;
  }
  static get _hasDrawClass() {
    return !1;
  }
  _addOutlines(e) {
    const {
      boxes: s,
      drawOutlines: n
    } = e;
    !s && !n || (this._drawingOptions || (this._drawingOptions = e.drawingOptions || De.getDefaultDrawingOptions()), s && (e = {
      ...e,
      drawOutlines: ib.build(s, this._uiManager.direction === "ltr")
    }), super._addOutlines(e));
  }
  get colorType() {
    return tt.HIGHLIGHT_COLOR;
  }
  get color() {
    return this._drawingOptions.fill;
  }
  get opacity() {
    return this._drawingOptions["fill-opacity"];
  }
  get _opacityName() {
    return "fill-opacity";
  }
  get _drawRotation() {
    var e;
    return (e = this._drawOutlines) != null && e.isFree ? this.rotation : 0;
  }
  get isResizable() {
    return !1;
  }
  get _mustBeDisabledOnCommit() {
    return !1;
  }
  get _mustFixPosition() {
    var e;
    return !((e = this._drawOutlines) != null && e.isFree);
  }
  get telemetryInitialData() {
    return {
      action: "added",
      type: this._drawOutlines.isFree ? "free_highlight" : "highlight",
      color: this._uiManager.getNonHCMColorName(this.color),
      thickness: this._drawingOptions.thickness,
      methodOfCreation: i(this, Xu)
    };
  }
  get telemetryFinalData() {
    return {
      type: "highlight",
      color: this._uiManager.getNonHCMColorName(this.color)
    };
  }
  static computeTelemetryFinalData(e) {
    return {
      numberOfColors: e.get("color").size
    };
  }
  translateInPage(e, s) {
  }
  get toolbarPosition() {
    return m(this, vs, rb).call(this, this._drawOutlines.focusOutline.lastPoint);
  }
  get commentButtonPosition() {
    return m(this, vs, rb).call(this, this._drawOutlines.firstPoint);
  }
  updateParams(e, s) {
    switch (e) {
      case tt.HIGHLIGHT_COLOR:
        this._updateColorAndOpacity(s, De._DEFAULT_OPACITY, e), this._reportTelemetry({
          action: "color_changed",
          color: this._uiManager.getNonHCMColorName(s)
        }, !0);
        break;
      case tt.HIGHLIGHT_THICKNESS:
        super.updateParams(e, s), this._reportTelemetry({
          action: "thickness_changed",
          thickness: s
        }, !0);
        break;
    }
  }
  get propertiesToUpdate() {
    const e = super.propertiesToUpdate;
    return e.push([tt.HIGHLIGHT_FREE, this._drawOutlines.isFree]), e;
  }
  get toolbarButtons() {
    return this._uiManager.highlightColors ? (this._colorPicker = new up({
      editor: this
    }), [["colorPicker", this._colorPicker]]) : super.toolbarButtons;
  }
  fixAndSetPosition() {
    return super.fixAndSetPosition(this._drawRotation);
  }
  getRect(e, s) {
    return super.getRect(e, s, this._drawRotation);
  }
  onceAdded(e) {
    this.annotationElementId || this.parent.addUndoableEditor(this), e && this.div.focus();
  }
  remove() {
    this._reportTelemetry({
      action: "deleted"
    }), super.remove();
  }
  render() {
    if (this.div)
      return this.div;
    const e = super.render();
    return i(this, Kh) && (e.setAttribute("aria-label", i(this, Kh)), e.setAttribute("role", "mark")), this._drawOutlines.isFree ? e.classList.add("free") : e.addEventListener("keydown", m(this, vs, K0).bind(this), {
      signal: this._uiManager._signal
    }), this.enableEditing(), e;
  }
  _moveCaret(e) {
    switch (this.parent.unselect(this), e) {
      case 0:
      case 2:
        m(this, vs, Yf).call(this, !0);
        break;
      case 1:
      case 3:
        m(this, vs, Yf).call(this, !1);
        break;
    }
  }
  unselect() {
    super.unselect(), this._drawOutlines.isFree || m(this, vs, Yf).call(this, !1);
  }
  static createDrawerInstance({
    x: e,
    y: s,
    box: n,
    parent: r,
    isLTR: a
  }) {
    return new _S(e, s, n, r.scale, this._defaultDrawingOptions.thickness / 2, a, 1e-3);
  }
  static _getDrawingTarget(e, {
    target: s
  }) {
    return s.closest(".textLayer");
  }
  static _getPointerCoords({
    x: e,
    y: s
  }) {
    return [e, s];
  }
  static _addDrawingListeners(e, s) {
    e.classList.add("free"), s.addEventListener("abort", () => e.classList.remove("free"), {
      once: !0
    }), window.addEventListener("blur", () => this._endDraw(null), {
      signal: s
    }), window.addEventListener("pointerdown", te, {
      capture: !0,
      passive: !1,
      signal: s
    });
  }
  static _endDrawingSession(e = !1) {
    return this.endDrawing(e);
  }
  createDrawingOptions({
    color: e,
    opacity: s,
    thickness: n
  }) {
    const {
      _defaultDrawingOptions: r,
      _DEFAULT_OPACITY: a
    } = De;
    this._drawingOptions = De.getDefaultDrawingOptions({
      fill: I.makeHexColor(...e),
      "fill-opacity": s || a,
      thickness: n || r.thickness
    });
  }
  static deserializeDraw(e, s, n, r, a, o, l) {
    const {
      quadPoints: h
    } = o;
    if (h) {
      const y = [];
      for (let A = 0, w = h.length; A < w; A += 8)
        y.push({
          x: (h[A] - e) / n,
          y: 1 - (h[A + 1] - s) / r,
          width: (h[A + 2] - h[A]) / n,
          height: (h[A + 1] - h[A + 5]) / r
        });
      return ib.build(y, l.direction === "ltr");
    }
    const c = o.thickness || this._defaultDrawingOptions.thickness, d = (o.inkLists || o.outlines.points)[0], f = new Vb(d[0] - e, r - (d[1] - s), [0, 0, n, r], 1, c / 2, !0, 1e-3);
    for (let y = 0, A = d.length; y < A; y += 2)
      f.add(d[y] - e, r - (d[y + 1] - s));
    const b = f.getOutlines();
    return b.buildFocusOutline(c), b;
  }
  static async deserialize(e, s, n) {
    let r = null;
    if (e instanceof T0) {
      const {
        data: {
          quadPoints: o,
          rect: l,
          rotation: h,
          id: c,
          color: d,
          opacity: f,
          popupRef: b,
          richText: y,
          contentsObj: A,
          creationDate: w,
          modificationDate: v
        },
        parent: {
          page: {
            pageNumber: S
          }
        }
      } = e;
      r = e = {
        annotationType: X.HIGHLIGHT,
        color: Array.from(d),
        opacity: f,
        quadPoints: o,
        pageIndex: S - 1,
        rect: l.slice(0),
        rotation: h,
        annotationElementId: c,
        id: c,
        deleted: !1,
        popupRef: b,
        richText: y,
        comment: (A == null ? void 0 : A.str) || null,
        creationDate: w,
        modificationDate: v
      };
    } else if (e instanceof $b) {
      const {
        data: {
          inkLists: o,
          rect: l,
          rotation: h,
          id: c,
          color: d,
          borderStyle: {
            rawWidth: f
          },
          popupRef: b,
          richText: y,
          contentsObj: A,
          creationDate: w,
          modificationDate: v
        },
        parent: {
          page: {
            pageNumber: S
          }
        }
      } = e;
      r = e = {
        annotationType: X.HIGHLIGHT,
        color: Array.from(d),
        thickness: f,
        inkLists: o,
        pageIndex: S - 1,
        rect: l.slice(0),
        rotation: h,
        annotationElementId: c,
        id: c,
        deleted: !1,
        popupRef: b,
        richText: y,
        comment: (A == null ? void 0 : A.str) || null,
        creationDate: w,
        modificationDate: v
      };
    }
    const a = await super.deserialize(e, s, n);
    return a._initialData = r, e.comment && a.setCommentData(e), a;
  }
  serialize(e = !1) {
    if (this.isEmpty() || e)
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const s = super.serialize(e);
    return Object.assign(s, {
      color: bt._colorManager.convert(this._uiManager.getNonHCMColor(this.color)),
      opacity: this.opacity,
      thickness: this._drawingOptions.thickness,
      quadPoints: this._drawOutlines.serializeQuadPoints(this.pageTranslation, this.pageDimensions),
      outlines: this._drawOutlines.serialize(s.rect, this._drawRotation)
    }), this.addComment(s), this.annotationElementId && !m(this, vs, q0).call(this, s) ? null : (s.id = this.annotationElementId, s);
  }
  renderAnnotationElement(e) {
    return this.deleted ? (e.hide(), null) : (e.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    }), null);
  }
};
Yh = new WeakMap(), ju = new WeakMap(), Vu = new WeakMap(), Wu = new WeakMap(), Xu = new WeakMap(), Kh = new WeakMap(), vs = new WeakSet(), rb = function([e, s]) {
  const [n, r, a, o] = this._drawOutlines.box;
  return [(e - n) / a, (s - r) / o];
}, K0 = function(e) {
  De._keyboardManager.exec(this, e);
}, Yf = function(e) {
  if (!i(this, Yh))
    return;
  const s = window.getSelection();
  e ? s.setPosition(i(this, Yh), i(this, ju)) : s.setPosition(i(this, Vu), i(this, Wu));
}, q0 = function(e) {
  const {
    color: s
  } = this._initialData;
  return this.hasEditedComment || e.color.some((n, r) => n !== s[r]);
}, _(De, "_DEFAULT_OPACITY", 1), _(De, "_DEFAULT_THICKNESS", 12), _(De, "_defaultDrawingOptions", null), _(De, "_type", "highlight"), _(De, "_editorType", X.HIGHLIGHT);
let gp = De;
var qh, Kp, qp, Qp, Wr, Yu, Vo, Gs, Kf, qf, Q0;
const _s = class _s {
  constructor(t, e, s) {
    g(this, Gs);
    g(this, Wr);
    g(this, Yu);
    g(this, Vo);
    u(this, Wr, [t, e, s]), u(this, Yu, u(this, Vo, s));
  }
  add(t, e, s) {
    const n = i(this, Wr), r = n.at(-1);
    s = s > r ? s : r + i(_s, Qp), n.push(t, e, s);
    const a = m(this, Gs, Kf).call(this, s - i(_s, qh), !0), o = m(this, Gs, qf).call(this, i(this, Vo) - i(_s, qh));
    return o >= n.length / 2 && (n.copyWithin(0, o), n.length -= o), a;
  }
  get pendingPoints() {
    return m(this, Gs, Kf).call(this, 1 / 0, !1);
  }
  end() {
    return m(this, Gs, Kf).call(this, 1 / 0, !0);
  }
};
qh = new WeakMap(), Kp = new WeakMap(), qp = new WeakMap(), Qp = new WeakMap(), Wr = new WeakMap(), Yu = new WeakMap(), Vo = new WeakMap(), Gs = new WeakSet(), Kf = function(t, e) {
  const s = i(this, Wr), n = i(this, Yu), r = s.at(-1), a = [], o = i(this, Vo);
  for (let l = m(this, Gs, qf).call(this, o) + 3; l < s.length; l += 3) {
    const h = s[l - 1], c = s[l + 2] - h, d = Math.min(Math.ceil(c / i(_s, Kp)), i(_s, qp));
    for (let f = 1; f <= d; f++) {
      const b = f === d ? s[l + 2] : h + c * f / d;
      if (b <= o)
        continue;
      if (b > t)
        return a;
      const y = Math.min(i(_s, qh), b - n, r - b);
      m(this, Gs, Q0).call(this, b - y, b + y, a), e && u(this, Vo, b);
    }
  }
  return a;
}, qf = function(t) {
  const e = i(this, Wr);
  let s = 0, n = e.length / 3 - 1;
  for (; s < n; ) {
    const r = s + n + 1 >> 1;
    e[3 * r + 2] <= t ? s = r : n = r - 1;
  }
  return 3 * s;
}, Q0 = function(t, e, s) {
  const n = i(this, Wr), r = m(this, Gs, qf).call(this, t);
  let a = 0, o = 0, l = 0;
  for (let h = r; h < n.length - 3 && n[h + 2] < e; h += 3) {
    const c = n[h], d = n[h + 1], f = n[h + 2], b = n[h + 5], y = Math.max(f, t), A = Math.min(b, e);
    if (A <= y)
      continue;
    const w = A - y, v = (y + A - 2 * f) / (b - f);
    a += w * (c + v * (n[h + 3] - c) / 2), o += w * (d + v * (n[h + 4] - d) / 2), l += w;
  }
  l === 0 ? s.push(n[r], n[r + 1]) : s.push(a / l, o / l);
}, g(_s, qh, 10), g(_s, Kp, 1e3 / 180), g(_s, qp, 100), g(_s, Qp, 1e-3);
let ab = _s;
function Wn(p, t) {
  return `${U.svgRound(p[t])} ${U.svgRound(p[t + 1])}`;
}
function J0(p, t, e) {
  for (let s = e, n = t.length; s < n; s += 6)
    p.push(`C${Wn(t, s)} ${Wn(t, s + 2)} ${Wn(t, s + 4)}`);
}
function Qf(p) {
  const t = `M${Wn(p, 4)}`;
  if (p.length === 6)
    return `${t}Z`;
  if (p.length === 12 && isNaN(p[6]))
    return `${t}L${Wn(p, 10)}`;
  const e = [t];
  return J0(e, p, 6), e.join("");
}
var ni, Wo, pe, xe, Xo, ri, Qh, ai, Jh, Zh, fs, zi, Yo, Ko, qo, lt, ob, lb, Jf, hb, cb, db, ub, fb, pb;
class kS {
  constructor(t, e, s, n, r, a, o) {
    g(this, lt);
    g(this, ni, new Float64Array(6));
    g(this, Wo, new Float64Array(2));
    g(this, pe);
    g(this, xe);
    g(this, Xo);
    g(this, ri, null);
    g(this, Qh);
    g(this, ai);
    g(this, Jh, 1);
    g(this, Zh, new Float64Array(2));
    g(this, fs, "");
    g(this, zi, 0);
    g(this, Yo, new af());
    g(this, Ko);
    g(this, qo);
    u(this, Ko, s), u(this, qo, n), u(this, Xo, r), u(this, Qh, a), u(this, xe, []), m(this, lt, ob).call(this, t, e, o);
  }
  updateProperty(t, e) {
    t === "stroke-width" && u(this, Qh, e);
  }
  isEmpty() {
    var t;
    return !((t = i(this, xe)) != null && t.length);
  }
  isCancellable() {
    return i(this, Jh) <= 5;
  }
  add(t, e, s) {
    return m(this, lt, Jf).call(this, t, e, s), {
      path: {
        d: m(this, lt, pb).call(this)
      }
    };
  }
  addPoints(t, e) {
    for (let s = 0, n = t.length; s < n; s += 2)
      m(this, lt, Jf).call(this, t[s], t[s + 1], e == null ? void 0 : e[s / 2]);
    return {
      path: {
        d: m(this, lt, pb).call(this)
      }
    };
  }
  end(t, e, s) {
    return i(this, pe) && t !== void 0 && m(this, lt, Jf).call(this, t, e, s), m(this, lt, fb).call(this), {
      path: {
        d: i(this, fs)
      }
    };
  }
  startNew(t, e, s, n, r, a) {
    u(this, Ko, s), u(this, qo, n), u(this, Xo, r);
    const o = i(this, xe).at(-1);
    return o && (o.line = new Float32Array(o.line), o.points = new Float32Array(o.points)), m(this, lt, ob).call(this, t, e, a), null;
  }
  getLastElement() {
    return i(this, xe).at(-1);
  }
  setLastElement(t) {
    return i(this, xe) ? (i(this, xe).push(t), u(this, fs, i(this, fs) + Qf(t.line)), {
      path: {
        d: i(this, fs)
      }
    }) : i(this, Yo).setLastElement(t);
  }
  removeLastElement() {
    return i(this, xe) ? (u(this, pe, u(this, ai, u(this, ri, null))), i(this, xe).pop(), u(this, fs, i(this, xe).map(({
      line: t
    }) => Qf(t)).join("")), {
      path: {
        d: i(this, fs)
      }
    }) : i(this, Yo).removeLastElement();
  }
  getOutlines(t, e, s, n) {
    m(this, lt, fb).call(this);
    const r = i(this, xe).at(-1);
    return r.line = new Float32Array(r.line), r.points = new Float32Array(r.points), i(this, Yo).build(i(this, xe), t, e, s, i(this, Xo), i(this, Qh), n), u(this, ni, null), u(this, pe, null), u(this, xe, null), u(this, fs, null), i(this, Yo);
  }
  get defaultSVGProperties() {
    return {
      root: {
        viewBox: "0 0 10000 10000"
      },
      rootClass: {
        draw: !0
      },
      bbox: [0, 0, 1, 1]
    };
  }
}
ni = new WeakMap(), Wo = new WeakMap(), pe = new WeakMap(), xe = new WeakMap(), Xo = new WeakMap(), ri = new WeakMap(), Qh = new WeakMap(), ai = new WeakMap(), Jh = new WeakMap(), Zh = new WeakMap(), fs = new WeakMap(), zi = new WeakMap(), Yo = new WeakMap(), Ko = new WeakMap(), qo = new WeakMap(), lt = new WeakSet(), ob = function(t, e, s) {
  [t, e] = m(this, lt, lb).call(this, t, e);
  const n = u(this, pe, [NaN, NaN, NaN, NaN, t, e]);
  u(this, ai, [t, e]), i(this, xe).push({
    line: n,
    points: i(this, ai)
  }), i(this, ni).set(n, 0), u(this, zi, 0), u(this, Jh, 1), i(this, Zh).set(i(this, Wo)), u(this, ri, s === void 0 ? null : new ab(t, e, s));
}, lb = function(t, e) {
  return U._normalizePoint(t, e, i(this, Ko), i(this, qo), i(this, Xo), i(this, Wo));
}, Jf = function(t, e, s) {
  [t, e] = m(this, lt, lb).call(this, t, e);
  const [n, r] = i(this, Zh);
  m(this, lt, hb).call(this, t, e, n, r) || (rt(this, Jh)._++, i(this, Zh).set(i(this, Wo))), i(this, ri) ? m(this, lt, cb).call(this, i(this, ri).add(t, e, s)) : m(this, lt, db).call(this, t, e);
}, hb = function(t, e, s, n) {
  return Math.hypot(i(this, Ko) * (t - s), i(this, qo) * (e - n)) <= 2;
}, cb = function(t) {
  for (let e = 0, s = t.length; e < s; e += 2)
    m(this, lt, db).call(this, t[e], t[e + 1]);
}, db = function(t, e) {
  const [, , s, n, r, a] = i(this, ni);
  m(this, lt, hb).call(this, t, e, r, a) || (i(this, ai).push(t, e), isNaN(s) ? i(this, pe).push(NaN, NaN, NaN, NaN, t, e) : (isNaN(i(this, ni)[0]) && i(this, pe).splice(6, 6), U.createBezierPoints(s, n, r, a, t, e, i(this, pe))), i(this, ni).copyWithin(0, 2), i(this, ni)[4] = t, i(this, ni)[5] = e);
}, ub = function() {
  const t = i(this, pe);
  if (i(this, ai).length < 6 || i(this, zi) === t.length)
    return;
  const e = [i(this, fs)];
  i(this, zi) === 0 && (e.push(`M${Wn(t, 4)}`), u(this, zi, 6)), J0(e, t, i(this, zi)), u(this, fs, e.join("")), u(this, zi, t.length);
}, fb = function() {
  if (i(this, pe)) {
    if (i(this, ri) && (m(this, lt, cb).call(this, i(this, ri).end()), u(this, ri, null)), i(this, ai).length < 6)
      u(this, fs, i(this, fs) + Qf(i(this, pe)));
    else {
      const [, , t, e, s, n] = i(this, ni);
      U.createBezierPoints(t, e, s, n, s, n, i(this, pe)), m(this, lt, ub).call(this);
    }
    u(this, pe, u(this, ai, null));
  }
}, pb = function() {
  var s;
  m(this, lt, ub).call(this);
  const t = [i(this, fs)];
  i(this, zi) === 0 && (t.push(`M${Wn(i(this, pe), 4)}`), i(this, ai).length === 4 && t.push(`L${Wn(i(this, pe), 10)}`));
  let e = (s = i(this, ri)) == null ? void 0 : s.pendingPoints;
  e != null && e.length || (e = i(this, Wo));
  for (let n = 0, r = e.length; n < r; n += 2)
    t.push(`L${Wn(e, n)}`);
  return t.join("");
};
var Fe, Ku, qu, ps, Gi, $i, tc, ec, Qo, ge, en, Z0, tw, ew;
class af extends U {
  constructor() {
    super(...arguments);
    g(this, ge);
    g(this, Fe);
    g(this, Ku, 0);
    g(this, qu);
    g(this, ps);
    g(this, Gi);
    g(this, $i);
    g(this, tc);
    g(this, ec);
    g(this, Qo);
  }
  build(e, s, n, r, a, o, l) {
    u(this, Gi, s), u(this, $i, n), u(this, tc, r), u(this, ec, a), u(this, Qo, o), u(this, qu, l ?? 0), u(this, ps, e), m(this, ge, tw).call(this);
  }
  get thickness() {
    return i(this, Qo);
  }
  setLastElement(e) {
    return i(this, ps).push(e), {
      path: {
        d: this.toSVGPath()
      }
    };
  }
  removeLastElement() {
    return i(this, ps).pop(), {
      path: {
        d: this.toSVGPath()
      }
    };
  }
  toSVGPath() {
    return i(this, ps).map(({
      line: e
    }) => Qf(e)).join("");
  }
  serialize([e, s, n, r], a) {
    const o = [], l = [], [h, c, d, f] = m(this, ge, Z0).call(this);
    let b, y, A, w, v, S, E, C, x;
    switch (i(this, ec)) {
      case 0:
        x = U._rescale, b = e, y = s + r, A = n, w = -r, v = e + h * n, S = s + (1 - c - f) * r, E = e + (h + d) * n, C = s + (1 - c) * r;
        break;
      case 90:
        x = U._rescaleAndSwap, b = e, y = s, A = n, w = r, v = e + c * n, S = s + h * r, E = e + (c + f) * n, C = s + (h + d) * r;
        break;
      case 180:
        x = U._rescale, b = e + n, y = s, A = -n, w = r, v = e + (1 - h - d) * n, S = s + c * r, E = e + (1 - h) * n, C = s + (c + f) * r;
        break;
      case 270:
        x = U._rescaleAndSwap, b = e + n, y = s + r, A = -n, w = -r, v = e + (1 - c - f) * n, S = s + (1 - h - d) * r, E = e + (1 - c) * n, C = s + (1 - h) * r;
        break;
    }
    for (const {
      line: T,
      points: k
    } of i(this, ps))
      o.push(x(T, b, y, A, w, a ? new Array(T.length) : null)), l.push(x(k, b, y, A, w, a ? new Array(k.length) : null));
    return {
      lines: o,
      points: l,
      rect: [v, S, E, C]
    };
  }
  static deserialize(e, s, n, r, a, {
    paths: {
      lines: o,
      points: l
    },
    rotation: h,
    thickness: c
  }) {
    const d = [];
    let f, b, y, A, w;
    switch (h) {
      case 0:
        w = U._rescale, f = -e / n, b = s / r + 1, y = 1 / n, A = -1 / r;
        break;
      case 90:
        w = U._rescaleAndSwap, f = -s / r, b = -e / n, y = 1 / r, A = 1 / n;
        break;
      case 180:
        w = U._rescale, f = e / n + 1, b = -s / r, y = -1 / n, A = 1 / r;
        break;
      case 270:
        w = U._rescaleAndSwap, f = s / r + 1, b = e / n + 1, y = -1 / r, A = -1 / n;
        break;
    }
    if (!o) {
      o = [];
      for (const S of l) {
        const E = S.length;
        if (E === 2) {
          o.push(new Float32Array([NaN, NaN, NaN, NaN, S[0], S[1]]));
          continue;
        }
        if (E === 4) {
          o.push(new Float32Array([NaN, NaN, NaN, NaN, S[0], S[1], NaN, NaN, NaN, NaN, S[2], S[3]]));
          continue;
        }
        const C = new Float32Array(3 * E);
        o.push(C);
        let [x, T, k, M] = S.subarray(0, 4);
        C.set([NaN, NaN, NaN, NaN, x, T], 0);
        for (let P = 4; P <= E; P += 2) {
          const D = Math.min(P, E - 2), H = S[D], Y = S[D + 1];
          C.set(U.createBezierPoints(x, T, k, M, H, Y), (P - 2) * 3), [x, T, k, M] = [k, M, H, Y];
        }
      }
    }
    for (let S = 0, E = o.length; S < E; S++)
      d.push({
        line: w(o[S].map((C) => C ?? NaN), f, b, y, A),
        points: w(l[S].map((C) => C ?? NaN), f, b, y, A)
      });
    const v = new this.prototype.constructor();
    return v.build(d, n, r, 1, h, c, a), v;
  }
  get box() {
    return i(this, Fe);
  }
  updateProperty(e, s) {
    return e === "stroke-width" ? m(this, ge, ew).call(this, s) : null;
  }
  updateParentDimensions([e, s], n) {
    const [r, a] = m(this, ge, en).call(this);
    u(this, Gi, e), u(this, $i, s), u(this, tc, n);
    const [o, l] = m(this, ge, en).call(this), h = o - r, c = l - a, d = i(this, Fe);
    return d[0] -= h, d[1] -= c, d[2] += 2 * h, d[3] += 2 * c, d;
  }
  updateRotation(e) {
    return u(this, Ku, e), {
      path: {
        transform: this.rotationTransform
      }
    };
  }
  get viewBox() {
    return i(this, Fe).map(U.svgRound).join(" ");
  }
  get defaultProperties() {
    const [e, s] = i(this, Fe);
    return {
      root: {
        viewBox: this.viewBox
      },
      path: {
        "transform-origin": `${U.svgRound(e)} ${U.svgRound(s)}`
      }
    };
  }
  get rotationTransform() {
    const [, , e, s] = i(this, Fe);
    let n = 0, r = 0, a = 0, o = 0, l = 0, h = 0;
    switch (i(this, Ku)) {
      case 90:
        r = s / e, a = -e / s, l = e;
        break;
      case 180:
        n = -1, o = -1, l = e, h = s;
        break;
      case 270:
        r = -s / e, a = e / s, h = s;
        break;
      default:
        return "";
    }
    return `matrix(${n} ${r} ${a} ${o} ${U.svgRound(l)} ${U.svgRound(h)})`;
  }
  getPathResizingSVGProperties([e, s, n, r]) {
    const [a, o] = m(this, ge, en).call(this), [l, h, c, d] = i(this, Fe);
    if (Math.abs(c - a) <= U.PRECISION || Math.abs(d - o) <= U.PRECISION) {
      const w = e + n / 2 - (l + c / 2), v = s + r / 2 - (h + d / 2);
      return {
        path: {
          "transform-origin": `${U.svgRound(e)} ${U.svgRound(s)}`,
          transform: `${this.rotationTransform} translate(${w} ${v})`
        }
      };
    }
    const f = (n - 2 * a) / (c - 2 * a), b = (r - 2 * o) / (d - 2 * o), y = c / n, A = d / r;
    return {
      path: {
        "transform-origin": `${U.svgRound(l)} ${U.svgRound(h)}`,
        transform: `${this.rotationTransform} scale(${y} ${A}) translate(${U.svgRound(a)} ${U.svgRound(o)}) scale(${f} ${b}) translate(${U.svgRound(-a)} ${U.svgRound(-o)})`
      }
    };
  }
  getPathResizedSVGProperties([e, s, n, r]) {
    const [a, o] = m(this, ge, en).call(this), l = i(this, Fe), [h, c, d, f] = l;
    if (l[0] = e, l[1] = s, l[2] = n, l[3] = r, Math.abs(d - a) <= U.PRECISION || Math.abs(f - o) <= U.PRECISION) {
      const v = e + n / 2 - (h + d / 2), S = s + r / 2 - (c + f / 2);
      for (const {
        line: E,
        points: C
      } of i(this, ps))
        U._translate(E, v, S, E), U._translate(C, v, S, C);
      return {
        root: {
          viewBox: this.viewBox
        },
        path: {
          "transform-origin": `${U.svgRound(e)} ${U.svgRound(s)}`,
          transform: this.rotationTransform || null,
          d: this.toSVGPath()
        }
      };
    }
    const b = (n - 2 * a) / (d - 2 * a), y = (r - 2 * o) / (f - 2 * o), A = -b * (h + a) + e + a, w = -y * (c + o) + s + o;
    if (b !== 1 || y !== 1 || A !== 0 || w !== 0)
      for (const {
        line: v,
        points: S
      } of i(this, ps))
        U._rescale(v, A, w, b, y, v), U._rescale(S, A, w, b, y, S);
    return {
      root: {
        viewBox: this.viewBox
      },
      path: {
        "transform-origin": `${U.svgRound(e)} ${U.svgRound(s)}`,
        transform: this.rotationTransform || null,
        d: this.toSVGPath()
      }
    };
  }
  getPathTranslatedSVGProperties([e, s], n) {
    const [r, a] = n, o = i(this, Fe), l = e - o[0], h = s - o[1];
    if (i(this, Gi) === r && i(this, $i) === a)
      for (const {
        line: c,
        points: d
      } of i(this, ps))
        U._translate(c, l, h, c), U._translate(d, l, h, d);
    else {
      const c = i(this, Gi) / r, d = i(this, $i) / a;
      u(this, Gi, r), u(this, $i, a);
      for (const {
        line: f,
        points: b
      } of i(this, ps))
        U._rescale(f, l, h, c, d, f), U._rescale(b, l, h, c, d, b);
      o[2] *= c, o[3] *= d;
    }
    return o[0] = e, o[1] = s, {
      root: {
        viewBox: this.viewBox
      },
      path: {
        d: this.toSVGPath(),
        "transform-origin": `${U.svgRound(e)} ${U.svgRound(s)}`
      }
    };
  }
  get defaultSVGProperties() {
    const e = i(this, Fe);
    return {
      root: {
        viewBox: this.viewBox
      },
      rootClass: {
        draw: !0
      },
      path: {
        d: this.toSVGPath(),
        "transform-origin": `${U.svgRound(e[0])} ${U.svgRound(e[1])}`,
        transform: this.rotationTransform || null
      },
      bbox: e
    };
  }
}
Fe = new WeakMap(), Ku = new WeakMap(), qu = new WeakMap(), ps = new WeakMap(), Gi = new WeakMap(), $i = new WeakMap(), tc = new WeakMap(), ec = new WeakMap(), Qo = new WeakMap(), ge = new WeakSet(), en = function(e = i(this, Qo)) {
  const s = i(this, qu) + e / 2 * i(this, tc);
  return i(this, ec) % 180 === 0 ? [s / i(this, Gi), s / i(this, $i)] : [s / i(this, $i), s / i(this, Gi)];
}, Z0 = function() {
  const [e, s, n, r] = i(this, Fe), [a, o] = m(this, ge, en).call(this, 0);
  return [e + a, s + o, n - 2 * a, r - 2 * o];
}, tw = function() {
  const e = u(this, Fe, va.slice());
  for (const {
    line: r
  } of i(this, ps)) {
    if (r.length <= 12) {
      for (let l = 4, h = r.length; l < h; l += 6)
        I.pointBoundingBox(r[l], r[l + 1], e);
      continue;
    }
    let a = r[4], o = r[5];
    for (let l = 6, h = r.length; l < h; l += 6) {
      const [c, d, f, b, y, A] = r.subarray(l, l + 6);
      I.bezierBoundingBox(a, o, c, d, f, b, y, A, e), a = y, o = A;
    }
  }
  const [s, n] = m(this, ge, en).call(this);
  e[0] = vt(e[0] - s, 0, 1), e[1] = vt(e[1] - n, 0, 1), e[2] = vt(e[2] + s, 0, 1), e[3] = vt(e[3] + n, 0, 1), e[2] -= e[0], e[3] -= e[1];
}, ew = function(e) {
  const [s, n] = m(this, ge, en).call(this);
  u(this, Qo, e);
  const [r, a] = m(this, ge, en).call(this), [o, l] = [r - s, a - n], h = i(this, Fe);
  return h[0] -= o, h[1] -= l, h[2] += 2 * o, h[3] += 2 * l, h;
};
class pg extends jb {
  constructor(t) {
    super(), this._viewParameters = t, super.updateProperties({
      fill: "none",
      stroke: bt._defaultLineColor,
      "stroke-opacity": 1,
      "stroke-width": 1,
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-miterlimit": 10
    });
  }
  updateSVGProperty(t, e) {
    t === "stroke-width" && (e ?? (e = this["stroke-width"]), e *= this._viewParameters.realScale), super.updateSVGProperty(t, e);
  }
  clone() {
    const t = new pg(this._viewParameters);
    return t.updateAll(this), t;
  }
}
var Jp, sw;
const yl = class yl extends ed {
  constructor(e) {
    super({
      ...e,
      name: "inkEditor"
    });
    g(this, Jp);
    this._willKeepAspectRatio = !0, this.defaultL10nId = "pdfjs-editor-ink-editor";
  }
  static initialize(e, s) {
    bt.initialize(e, s), this._defaultDrawingOptions = new pg(s.viewParameters);
  }
  static getDefaultDrawingOptions(e) {
    const s = this._defaultDrawingOptions.clone();
    return s.updateProperties(e), s;
  }
  static get supportMultipleDrawings() {
    return !0;
  }
  static get typesMap() {
    return L(this, "typesMap", /* @__PURE__ */ new Map([[tt.INK_THICKNESS, "stroke-width"], [tt.INK_COLOR, "stroke"], [tt.INK_OPACITY, "stroke-opacity"]]));
  }
  static createDrawerInstance({
    x: e,
    y: s,
    box: [, , n, r],
    rotation: a,
    timeStamp: o
  }) {
    return new kS(e, s, n, r, a, this._defaultDrawingOptions["stroke-width"], o);
  }
  static deserializeDraw(e, s, n, r, a, o) {
    return af.deserialize(e, s, n, r, a, o);
  }
  static async deserialize(e, s, n) {
    let r = null;
    if (e instanceof $b) {
      const {
        data: {
          inkLists: o,
          rect: l,
          rotation: h,
          id: c,
          color: d,
          opacity: f,
          borderStyle: {
            rawWidth: b
          },
          popupRef: y,
          richText: A,
          contentsObj: w,
          creationDate: v,
          modificationDate: S
        },
        parent: {
          page: {
            pageNumber: E
          }
        }
      } = e;
      r = e = {
        annotationType: X.INK,
        color: Array.from(d),
        thickness: b,
        opacity: f,
        paths: {
          points: o
        },
        boxes: null,
        pageIndex: E - 1,
        rect: l.slice(0),
        rotation: h,
        annotationElementId: c,
        id: c,
        deleted: !1,
        popupRef: y,
        richText: A,
        comment: (w == null ? void 0 : w.str) || null,
        creationDate: v,
        modificationDate: S
      };
    }
    const a = await super.deserialize(e, s, n);
    return a._initialData = r, e.comment && a.setCommentData(e), a;
  }
  get toolbarButtons() {
    return this._colorPicker || (this._colorPicker = new fp(this)), [["colorPicker", this._colorPicker]];
  }
  get colorType() {
    return tt.INK_COLOR;
  }
  get colorAndOpacityType() {
    return tt.INK_COLOR_AND_OPACITY;
  }
  get opacityType() {
    return tt.INK_OPACITY;
  }
  updateParams(e, s) {
    if (e === tt.INK_COLOR_AND_OPACITY) {
      this._updateColorAndOpacity(s.color, s.opacity);
      return;
    }
    super.updateParams(e, s);
  }
  static updateDefaultParams(e, s) {
    if (e === tt.INK_COLOR_AND_OPACITY) {
      super.updateDefaultParams(tt.INK_COLOR, s.color), super.updateDefaultParams(tt.INK_OPACITY, s.opacity);
      return;
    }
    super.updateDefaultParams(e, s);
  }
  get color() {
    return this._drawingOptions.stroke;
  }
  get opacity() {
    return this._drawingOptions["stroke-opacity"];
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    super.onScaleChanging();
    const {
      _drawId: e,
      _drawingOptions: s,
      parent: n
    } = this;
    s.updateSVGProperty("stroke-width"), n.drawLayer.updateProperties(e, s.toSVGProperties());
  }
  static onScaleChangingWhenDrawing() {
    const e = this._currentParent;
    e && (super.onScaleChangingWhenDrawing(), this._defaultDrawingOptions.updateSVGProperty("stroke-width"), e.drawLayer.updateProperties(this._currentDrawId, this._defaultDrawingOptions.toSVGProperties()));
  }
  createDrawingOptions({
    color: e,
    thickness: s,
    opacity: n
  }) {
    this._drawingOptions = yl.getDefaultDrawingOptions({
      stroke: I.makeHexColor(...e),
      "stroke-width": s,
      "stroke-opacity": n
    });
  }
  serialize(e = !1) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const {
      lines: s,
      points: n
    } = this.serializeDraw(e), {
      _drawingOptions: {
        stroke: r,
        "stroke-opacity": a,
        "stroke-width": o
      }
    } = this, l = Object.assign(super.serialize(e), {
      color: bt._colorManager.convert(r),
      opacity: a,
      thickness: o,
      paths: {
        lines: s,
        points: n
      }
    });
    return this.addComment(l), e ? (l.isCopy = !0, l) : this.annotationElementId && !m(this, Jp, sw).call(this, l) ? null : (l.id = this.annotationElementId, l);
  }
  renderAnnotationElement(e) {
    if (this.deleted)
      return e.hide(), null;
    const {
      points: s,
      rect: n
    } = this.serializeDraw(!1);
    return e.updateEdited({
      rect: n,
      thickness: this._drawingOptions["stroke-width"],
      points: s,
      popup: this.comment
    }), null;
  }
};
Jp = new WeakSet(), sw = function(e) {
  const {
    color: s,
    thickness: n,
    opacity: r,
    pageIndex: a
  } = this._initialData;
  return this.hasEditedComment || this._hasBeenMoved || this._hasBeenResized || e.color.some((o, l) => o !== s[l]) || e.thickness !== n || e.opacity !== r || e.pageIndex !== a;
}, _(yl, "_type", "ink"), _(yl, "_editorType", X.INK), _(yl, "_defaultDrawingOptions", null);
let gb = yl;
class mb extends af {
  toSVGPath() {
    let t = super.toSVGPath();
    return t.endsWith("Z") || (t += "Z"), t;
  }
}
const pf = 8, wc = 3;
var Jo, ht, bb, oi, iw, nw, yb, Zf, rw, aw, ow, Ab, wb, lw;
class Vn {
  static extractContoursFromText(t, {
    fontFamily: e,
    fontStyle: s,
    fontWeight: n
  }, r, a, o, l) {
    let h = new OffscreenCanvas(1, 1), c = h.getContext("2d", {
      alpha: !1
    });
    const d = 200, f = c.font = `${s} ${n} ${d}px ${e}`, {
      actualBoundingBoxLeft: b,
      actualBoundingBoxRight: y,
      actualBoundingBoxAscent: A,
      actualBoundingBoxDescent: w,
      fontBoundingBoxAscent: v,
      fontBoundingBoxDescent: S,
      width: E
    } = c.measureText(t), C = 1.5, x = Math.ceil(Math.max(Math.abs(b) + Math.abs(y) || 0, E) * C), T = Math.ceil(Math.max(Math.abs(A) + Math.abs(w) || d, Math.abs(v) + Math.abs(S) || d) * C);
    h = new OffscreenCanvas(x, T), c = h.getContext("2d", {
      alpha: !0,
      willReadFrequently: !0
    }), c.font = f, c.filter = "grayscale(1)", c.fillStyle = "white", c.fillRect(0, 0, x, T), c.fillStyle = "black", c.fillText(t, x * (C - 1) / 2, T * (3 - C) / 2);
    const k = m(this, ht, Ab).call(this, c.getImageData(0, 0, x, T).data), M = m(this, ht, ow).call(this, k), P = m(this, ht, wb).call(this, M), D = m(this, ht, yb).call(this, k, x, T, P);
    return this.processDrawnLines({
      lines: {
        curves: D,
        width: x,
        height: T
      },
      pageWidth: r,
      pageHeight: a,
      rotation: o,
      innerMargin: l,
      mustSmooth: !0,
      areContours: !0
    });
  }
  static process(t, e, s, n, r) {
    const [a, o, l] = m(this, ht, lw).call(this, t), [h, c] = m(this, ht, aw).call(this, a, o, l, Math.hypot(o, l) * i(this, Jo).sigmaSFactor, i(this, Jo).sigmaR, i(this, Jo).kernelSize), d = m(this, ht, wb).call(this, c), f = m(this, ht, yb).call(this, h, o, l, d);
    return this.processDrawnLines({
      lines: {
        curves: f,
        width: o,
        height: l
      },
      pageWidth: e,
      pageHeight: s,
      rotation: n,
      innerMargin: r,
      mustSmooth: !0,
      areContours: !0
    });
  }
  static processDrawnLines({
    lines: t,
    pageWidth: e,
    pageHeight: s,
    rotation: n,
    innerMargin: r,
    mustSmooth: a,
    areContours: o
  }) {
    n % 180 !== 0 && ([e, s] = [s, e]);
    const {
      curves: l,
      width: h,
      height: c
    } = t, d = t.thickness ?? 0, f = [], b = Math.min(e / h, s / c), y = b / e, A = b / s, w = [];
    for (const {
      points: S
    } of l) {
      const E = a ? m(this, ht, rw).call(this, S) : S;
      if (!E)
        continue;
      w.push(E);
      const C = E.length, x = new Float32Array(C), T = new Float32Array(3 * (C === 2 ? 2 : C - 2));
      if (f.push({
        line: T,
        points: x
      }), C === 2) {
        x[0] = E[0] * y, x[1] = E[1] * A, T.set([NaN, NaN, NaN, NaN, x[0], x[1]], 0);
        continue;
      }
      let [k, M, P, D] = E;
      k *= y, M *= A, P *= y, D *= A, x.set([k, M, P, D], 0), T.set([NaN, NaN, NaN, NaN, k, M], 0);
      for (let H = 4; H < C; H += 2) {
        const Y = x[H] = E[H] * y, Q = x[H + 1] = E[H + 1] * A;
        T.set(U.createBezierPoints(k, M, P, D, Y, Q), (H - 2) * 3), [k, M, P, D] = [P, D, Y, Q];
      }
    }
    if (f.length === 0)
      return null;
    const v = o ? new mb() : new af();
    return v.build(f, e, s, 1, n, o ? 0 : d, r), {
      outline: v,
      newCurves: w,
      areContours: o,
      thickness: d,
      width: h,
      height: c
    };
  }
  static async compressSignature({
    outlines: t,
    areContours: e,
    thickness: s,
    width: n,
    height: r
  }) {
    let a = 1 / 0, o = -1 / 0, l = 0;
    for (const S of t) {
      l += S.length;
      for (let E = 2, C = S.length; E < C; E++) {
        const x = S[E] - S[E - 2];
        a = Math.min(a, x), o = Math.max(o, x);
      }
    }
    let h;
    a >= -128 && o <= 127 ? h = Int8Array : a >= -32768 && o <= 32767 ? h = Int16Array : h = Int32Array;
    const c = t.length, d = pf + wc * c, f = new Uint32Array(d);
    let b = 0;
    f[b++] = d * Uint32Array.BYTES_PER_ELEMENT + (l - 2 * c) * h.BYTES_PER_ELEMENT, f[b++] = 0, f[b++] = n, f[b++] = r, f[b++] = e ? 0 : 1, f[b++] = Math.max(0, Math.floor(s ?? 0)), f[b++] = c, f[b++] = h.BYTES_PER_ELEMENT;
    for (const S of t)
      f[b++] = S.length - 2, f[b++] = S[0], f[b++] = S[1];
    const y = new CompressionStream("deflate-raw"), A = y.writable.getWriter();
    await A.ready, A.write(f);
    const w = h.prototype.constructor;
    for (const S of t) {
      const E = new w(S.length - 2);
      for (let C = 2, x = S.length; C < x; C++)
        E[C - 2] = S[C] - S[C - 2];
      A.write(E);
    }
    return A.close(), (await new Response(y.readable).bytes()).toBase64();
  }
  static async decompressSignature(t) {
    try {
      const e = Uint8Array.fromBase64(t), {
        readable: s,
        writable: n
      } = new DecompressionStream("deflate-raw"), r = n.getWriter();
      await r.ready, r.write(e).then(async () => {
        await r.ready, await r.close();
      }).catch(() => {
      });
      let a = null, o = 0;
      for await (const E of s)
        a || (a = new Uint8Array(new Uint32Array(E.buffer, 0, 4)[0])), a.set(E, o), o += E.length;
      const l = new Uint32Array(a.buffer, 0, a.length >> 2), h = l[1];
      if (h !== 0)
        throw new Error(`Invalid version: ${h}`);
      const c = l[2], d = l[3], f = l[4] === 0, b = l[5], y = l[6], A = l[7], w = [], v = (pf + wc * y) * Uint32Array.BYTES_PER_ELEMENT;
      let S;
      switch (A) {
        case Int8Array.BYTES_PER_ELEMENT:
          S = new Int8Array(a.buffer, v);
          break;
        case Int16Array.BYTES_PER_ELEMENT:
          S = new Int16Array(a.buffer, v);
          break;
        case Int32Array.BYTES_PER_ELEMENT:
          S = new Int32Array(a.buffer, v);
          break;
      }
      o = 0;
      for (let E = 0; E < y; E++) {
        const C = l[wc * E + pf], x = new Float32Array(C + 2);
        w.push(x);
        for (let T = 0; T < wc - 1; T++)
          x[T] = l[wc * E + pf + T + 1];
        for (let T = 0; T < C; T++)
          x[T + 2] = x[T] + S[o++];
      }
      return {
        areContours: f,
        thickness: b,
        outlines: w,
        width: c,
        height: d
      };
    } catch (e) {
      return j(`decompressSignature: ${e}`), null;
    }
  }
}
Jo = new WeakMap(), ht = new WeakSet(), bb = function(t, e, s, n) {
  return s -= t, n -= e, s === 0 ? n > 0 ? 0 : 4 : s === 1 ? n + 6 : 2 - n;
}, oi = new WeakMap(), iw = function(t, e, s, n, r, a, o) {
  const l = m(this, ht, bb).call(this, s, n, r, a);
  for (let h = 0; h < 8; h++) {
    const c = (-h + l - o + 16) % 8, d = i(this, oi)[2 * c], f = i(this, oi)[2 * c + 1];
    if (t[(s + d) * e + (n + f)] !== 0)
      return c;
  }
  return -1;
}, nw = function(t, e, s, n, r, a, o) {
  const l = m(this, ht, bb).call(this, s, n, r, a);
  for (let h = 0; h < 8; h++) {
    const c = (h + l + o + 16) % 8, d = i(this, oi)[2 * c], f = i(this, oi)[2 * c + 1];
    if (t[(s + d) * e + (n + f)] !== 0)
      return c;
  }
  return -1;
}, yb = function(t, e, s, n) {
  const r = t.length, a = new Int32Array(r);
  for (let c = 0; c < r; c++)
    a[c] = t[c] <= n ? 1 : 0;
  for (let c = 1; c < s - 1; c++)
    a[c * e] = a[c * e + e - 1] = 0;
  for (let c = 0; c < e; c++)
    a[c] = a[e * s - 1 - c] = 0;
  let o = 1, l;
  const h = [];
  for (let c = 1; c < s - 1; c++) {
    l = 1;
    for (let d = 1; d < e - 1; d++) {
      const f = c * e + d, b = a[f];
      if (b === 0)
        continue;
      let y = c, A = d;
      if (b === 1 && a[f - 1] === 0)
        o += 1, A -= 1;
      else if (b >= 1 && a[f + 1] === 0)
        o += 1, A += 1, b > 1 && (l = b);
      else {
        b !== 1 && (l = Math.abs(b));
        continue;
      }
      const w = [d, c], v = A === d + 1, S = {
        isHole: v,
        points: w,
        id: o,
        parent: 0
      };
      h.push(S);
      let E;
      for (const H of h)
        if (H.id === l) {
          E = H;
          break;
        }
      E ? E.isHole ? S.parent = v ? E.parent : l : S.parent = v ? l : E.parent : S.parent = v ? l : 0;
      const C = m(this, ht, iw).call(this, a, e, c, d, y, A, 0);
      if (C === -1) {
        a[f] = -o, a[f] !== 1 && (l = Math.abs(a[f]));
        continue;
      }
      let x = i(this, oi)[2 * C], T = i(this, oi)[2 * C + 1];
      const k = c + x, M = d + T;
      y = k, A = M;
      let P = c, D = d;
      for (; ; ) {
        const H = m(this, ht, nw).call(this, a, e, P, D, y, A, 1);
        x = i(this, oi)[2 * H], T = i(this, oi)[2 * H + 1];
        const Y = P + x, Q = D + T;
        w.push(Q, Y);
        const K = P * e + D;
        if (a[K + 1] === 0 ? a[K] = -o : a[K] === 1 && (a[K] = o), Y === c && Q === d && P === k && D === M) {
          a[f] !== 1 && (l = Math.abs(a[f]));
          break;
        } else
          y = P, A = D, P = Y, D = Q;
      }
    }
  }
  return h;
}, Zf = function(t, e, s, n) {
  if (s - e <= 4) {
    for (let k = e; k < s - 2; k += 2)
      n.push(t[k], t[k + 1]);
    return;
  }
  const r = t[e], a = t[e + 1], o = t[s - 4] - r, l = t[s - 3] - a, h = Math.hypot(o, l), c = o / h, d = l / h, f = c * a - d * r, b = l / o, y = 1 / h, A = Math.atan(b), w = Math.cos(A), v = Math.sin(A), S = y * (Math.abs(w) + Math.abs(v)), E = y * (1 - S + S ** 2), C = Math.max(Math.atan(Math.abs(v + w) * E), Math.atan(Math.abs(v - w) * E));
  let x = 0, T = e;
  for (let k = e + 2; k < s - 2; k += 2) {
    const M = Math.abs(f - c * t[k + 1] + d * t[k]);
    M > x && (T = k, x = M);
  }
  x > (h * C) ** 2 ? (m(this, ht, Zf).call(this, t, e, T + 2, n), m(this, ht, Zf).call(this, t, T, s, n)) : n.push(r, a);
}, rw = function(t) {
  const e = [], s = t.length;
  return m(this, ht, Zf).call(this, t, 0, s, e), e.push(t[s - 2], t[s - 1]), e.length <= 4 ? null : e;
}, aw = function(t, e, s, n, r, a) {
  const o = new Float32Array(a ** 2), l = -2 * n ** 2, h = a >> 1;
  for (let A = 0; A < a; A++) {
    const w = (A - h) ** 2;
    for (let v = 0; v < a; v++)
      o[A * a + v] = Math.exp((w + (v - h) ** 2) / l);
  }
  const c = new Float32Array(256), d = -2 * r ** 2;
  for (let A = 0; A < 256; A++)
    c[A] = Math.exp(A ** 2 / d);
  const f = t.length, b = new Uint8Array(f), y = new Uint32Array(256);
  for (let A = 0; A < s; A++)
    for (let w = 0; w < e; w++) {
      const v = A * e + w, S = t[v];
      let E = 0, C = 0;
      for (let T = 0; T < a; T++) {
        const k = A + T - h;
        if (!(k < 0 || k >= s))
          for (let M = 0; M < a; M++) {
            const P = w + M - h;
            if (P < 0 || P >= e)
              continue;
            const D = t[k * e + P], H = o[T * a + M] * c[Math.abs(D - S)];
            E += D * H, C += H;
          }
      }
      const x = b[v] = Math.round(E / C);
      y[x]++;
    }
  return [b, y];
}, ow = function(t) {
  const e = new Uint32Array(256);
  for (const s of t)
    e[s]++;
  return e;
}, Ab = function(t) {
  const e = t.length, s = new Uint8ClampedArray(e >> 2);
  let n = -1 / 0, r = 1 / 0;
  for (let o = 0, l = s.length; o < l; o++) {
    const h = s[o] = t[o << 2];
    n = Math.max(n, h), r = Math.min(r, h);
  }
  const a = 255 / (n - r);
  for (let o = 0, l = s.length; o < l; o++)
    s[o] = (s[o] - r) * a;
  return s;
}, wb = function(t) {
  let e, s = -1 / 0, n = -1 / 0;
  const r = t.findIndex((l) => l !== 0);
  let a = r, o = r;
  for (e = r; e < 256; e++) {
    const l = t[e];
    l > s && (e - a > n && (n = e - a, o = e - 1), s = l, a = e);
  }
  for (e = o - 1; e >= 0 && !(t[e] > t[e + 1]); e--)
    ;
  return e;
}, lw = function(t) {
  const e = t, {
    width: s,
    height: n
  } = t, {
    maxDim: r
  } = i(this, Jo);
  let a = s, o = n;
  if (s > r || n > r) {
    let f = s, b = n, y = Math.log2(Math.max(s, n) / r);
    const A = Math.floor(y);
    y = y === A ? A - 1 : A;
    for (let v = 0; v < y; v++) {
      a = Math.ceil(f / 2), o = Math.ceil(b / 2);
      const S = new OffscreenCanvas(a, o);
      S.getContext("2d").drawImage(t, 0, 0, f, b, 0, 0, a, o), f = a, b = o, t !== e && t.close(), t = S.transferToImageBitmap();
    }
    const w = Math.min(r / a, r / o);
    a = Math.round(a * w), o = Math.round(o * w);
  }
  const h = new OffscreenCanvas(a, o).getContext("2d", {
    willReadFrequently: !0
  });
  h.fillStyle = "white", h.fillRect(0, 0, a, o), h.filter = "grayscale(1)", h.drawImage(t, 0, 0, t.width, t.height, 0, 0, a, o);
  const c = h.getImageData(0, 0, a, o).data;
  return [m(this, ht, Ab).call(this, c), a, o];
}, g(Vn, ht), g(Vn, Jo, {
  maxDim: 512,
  sigmaSFactor: 0.02,
  sigmaR: 25,
  kernelSize: 16
}), g(Vn, oi, new Int32Array([0, 1, -1, 1, -1, 0, -1, -1, 0, -1, 1, -1, 1, 0, 1, 1]));
class Xb extends jb {
  constructor() {
    super(), super.updateProperties({
      fill: bt._defaultLineColor,
      "stroke-width": 0
    });
  }
  clone() {
    const t = new Xb();
    return t.updateAll(this), t;
  }
}
class Yb extends pg {
  constructor(t) {
    super(t), super.updateProperties({
      stroke: bt._defaultLineColor,
      "stroke-width": 1
    });
  }
  clone() {
    const t = new Yb(this._viewParameters);
    return t.updateAll(this), t;
  }
}
var Xr, ji, Yr, Zo, sc;
const Je = class Je extends ed {
  constructor(e) {
    super({
      ...e,
      mustBeCommitted: !0,
      name: "signatureEditor"
    });
    g(this, Xr, !1);
    g(this, ji, null);
    g(this, Yr, null);
    g(this, Zo, null);
    g(this, sc, !1);
    this._willKeepAspectRatio = !0, u(this, Yr, e.signatureData || null), u(this, ji, null), this.defaultL10nId = "pdfjs-editor-signature-editor1";
  }
  static initialize(e, s) {
    bt.initialize(e, s), this._defaultDrawingOptions = new Xb(), this._defaultDrawnSignatureOptions = new Yb(s.viewParameters);
  }
  static getDefaultDrawingOptions(e) {
    const s = this._defaultDrawingOptions.clone();
    return s.updateProperties(e), s;
  }
  static get supportMultipleDrawings() {
    return !1;
  }
  static get typesMap() {
    return L(this, "typesMap", /* @__PURE__ */ new Map());
  }
  static get isDrawer() {
    return !1;
  }
  get telemetryFinalData() {
    return {
      type: "signature",
      hasDescription: !!i(this, ji)
    };
  }
  static computeTelemetryFinalData(e) {
    const s = e.get("hasDescription");
    return {
      hasAltText: s.get(!0) ?? 0,
      hasNoAltText: s.get(!1) ?? 0
    };
  }
  get isResizable() {
    return !0;
  }
  onceAdded(e) {
    u(this, sc, this._drawId === null), super.onceAdded(e);
  }
  onScaleChanging() {
    this._drawId !== null && super.onScaleChanging();
  }
  render() {
    if (this.div)
      return this.div;
    let e, s;
    const {
      _isCopy: n
    } = this;
    if (n && (this._isCopy = !1, e = this.x, s = this.y), super.render(), this._drawId === null)
      if (i(this, Yr)) {
        const {
          lines: r,
          mustSmooth: a,
          areContours: o,
          description: l,
          uuid: h,
          heightInPage: c
        } = i(this, Yr), {
          rawDims: {
            pageWidth: d,
            pageHeight: f
          },
          rotation: b
        } = this.parent.viewport, y = Vn.processDrawnLines({
          lines: r,
          pageWidth: d,
          pageHeight: f,
          rotation: b,
          innerMargin: Je._INNER_MARGIN,
          mustSmooth: a,
          areContours: o
        });
        this.addSignature(y, c, l, h);
      } else
        this.div.setAttribute("data-l10n-args", JSON.stringify({
          description: ""
        })), this.div.hidden = !0, this._uiManager.getSignature(this);
    else
      this.div.setAttribute("data-l10n-args", JSON.stringify({
        description: i(this, ji) || ""
      }));
    return n && (this._isCopy = !0, this._moveAfterPaste(e, s)), this.div;
  }
  setUuid(e) {
    u(this, Zo, e), this.addEditToolbar();
  }
  getUuid() {
    return i(this, Zo);
  }
  get description() {
    return i(this, ji);
  }
  set description(e) {
    u(this, ji, e), this.div && (this.div.setAttribute("data-l10n-args", JSON.stringify({
      description: e
    })), super.addEditToolbar().then((s) => {
      s == null || s.updateEditSignatureButton(e);
    }));
  }
  getSignaturePreview() {
    const {
      newCurves: e,
      areContours: s,
      thickness: n,
      width: r,
      height: a
    } = i(this, Yr), o = Math.max(r, a), l = Vn.processDrawnLines({
      lines: {
        curves: e.map((h) => ({
          points: h
        })),
        thickness: n,
        width: r,
        height: a
      },
      pageWidth: o,
      pageHeight: o,
      rotation: 0,
      innerMargin: 0,
      mustSmooth: !1,
      areContours: s
    });
    return {
      areContours: s,
      outline: l.outline
    };
  }
  get toolbarButtons() {
    return this._uiManager.signatureManager ? [["editSignature", this._uiManager.signatureManager]] : super.toolbarButtons;
  }
  addSignature(e, s, n, r) {
    const {
      x: a,
      y: o
    } = this, {
      outline: l
    } = u(this, Yr, e);
    u(this, Xr, l instanceof mb), this.description = n;
    let h;
    i(this, Xr) ? h = Je.getDefaultDrawingOptions() : (h = Je._defaultDrawnSignatureOptions.clone(), h.updateProperties({
      "stroke-width": l.thickness
    })), this._addOutlines({
      drawOutlines: l,
      drawingOptions: h
    });
    const [, c] = this.pageDimensions;
    let d = s / c;
    d = d >= 1 ? 0.5 : d, this.width *= d / this.height, this.width >= 1 && (d *= 0.9 / this.width, this.width = 0.9), this.height = d, this.setDims(), this.x = a, this.y = o, this.center(), this._onResized(), this.onScaleChanging(), this.rotate(), this._uiManager.addToAnnotationStorage(this), this.setUuid(r), this._reportTelemetry({
      action: "pdfjs.signature.inserted",
      data: {
        hasBeenSaved: !!r,
        hasDescription: !!n
      }
    }), this.div.hidden = !1, i(this, sc) && (u(this, sc, !1), this.parent.addUndoableEditor(this));
  }
  getFromImage(e) {
    const {
      rawDims: {
        pageWidth: s,
        pageHeight: n
      },
      rotation: r
    } = this.parent.viewport;
    return Vn.process(e, s, n, r, Je._INNER_MARGIN);
  }
  getFromText(e, s) {
    const {
      rawDims: {
        pageWidth: n,
        pageHeight: r
      },
      rotation: a
    } = this.parent.viewport;
    return Vn.extractContoursFromText(e, s, n, r, a, Je._INNER_MARGIN);
  }
  getDrawnSignature(e) {
    const {
      rawDims: {
        pageWidth: s,
        pageHeight: n
      },
      rotation: r
    } = this.parent.viewport;
    return Vn.processDrawnLines({
      lines: e,
      pageWidth: s,
      pageHeight: n,
      rotation: r,
      innerMargin: Je._INNER_MARGIN,
      mustSmooth: !1,
      areContours: !1
    });
  }
  createDrawingOptions({
    areContours: e,
    thickness: s
  }) {
    e ? this._drawingOptions = Je.getDefaultDrawingOptions() : (this._drawingOptions = Je._defaultDrawnSignatureOptions.clone(), this._drawingOptions.updateProperties({
      "stroke-width": s
    }));
  }
  serialize(e = !1) {
    if (this.isEmpty())
      return null;
    const {
      lines: s,
      points: n
    } = this.serializeDraw(e), {
      _drawingOptions: {
        "stroke-width": r
      }
    } = this, a = Object.assign(super.serialize(e), {
      isSignature: !0,
      areContours: i(this, Xr),
      color: [0, 0, 0],
      thickness: i(this, Xr) ? 0 : r
    });
    return this.addComment(a), e ? (a.paths = {
      lines: s,
      points: n
    }, a.uuid = i(this, Zo), a.isCopy = !0) : a.lines = s, i(this, ji) && (a.accessibilityData = {
      type: "Figure",
      alt: i(this, ji)
    }), a;
  }
  static deserializeDraw(e, s, n, r, a, o) {
    return o.areContours ? mb.deserialize(e, s, n, r, a, o) : af.deserialize(e, s, n, r, a, o);
  }
  static async deserialize(e, s, n) {
    var a;
    const r = await super.deserialize(e, s, n);
    return u(r, Xr, e.areContours), r.description = ((a = e.accessibilityData) == null ? void 0 : a.alt) || "", u(r, Zo, e.uuid), r;
  }
};
Xr = new WeakMap(), ji = new WeakMap(), Yr = new WeakMap(), Zo = new WeakMap(), sc = new WeakMap(), _(Je, "_type", "signature"), _(Je, "_editorType", X.SIGNATURE), _(Je, "_defaultDrawingOptions", null);
let vb = Je;
var Pt, le, Kr, Hn, qr, ic, Un, tl, Vi, gs, nc, st, Gc, $c, tp, ep, sp, Eb, ip, hw;
class Sb extends bt {
  constructor(e) {
    super({
      ...e,
      name: "stampEditor"
    });
    g(this, st);
    g(this, Pt, null);
    g(this, le, null);
    g(this, Kr, null);
    g(this, Hn, null);
    g(this, qr, null);
    g(this, ic, "");
    g(this, Un, null);
    g(this, tl, !1);
    g(this, Vi, null);
    g(this, gs, !1);
    g(this, nc, !1);
    u(this, Hn, e.bitmapUrl), u(this, qr, e.bitmapFile), this.defaultL10nId = "pdfjs-editor-stamp-editor";
  }
  static initialize(e, s) {
    bt.initialize(e, s);
  }
  static isHandlingMimeForPasting(e) {
    return Lg.has(e);
  }
  static paste(e, s) {
    s.pasteEditor({
      mode: X.STAMP
    }, {
      bitmapFile: e.getAsFile()
    });
  }
  altTextFinish() {
    this._uiManager.useNewAltTextFlow && (this.div.hidden = !1), super.altTextFinish();
  }
  get telemetryFinalData() {
    var e;
    return {
      type: "stamp",
      hasAltText: !!((e = this.altTextData) != null && e.altText)
    };
  }
  static computeTelemetryFinalData(e) {
    const s = e.get("hasAltText");
    return {
      hasAltText: s.get(!0) ?? 0,
      hasNoAltText: s.get(!1) ?? 0
    };
  }
  async mlGuessAltText(e = null, s = !0) {
    if (this.hasAltTextData())
      return null;
    const {
      mlManager: n
    } = this._uiManager;
    if (!n)
      throw new Error("No ML.");
    if (!await n.isEnabledFor("altText"))
      throw new Error("ML isn't enabled for alt text.");
    const {
      data: r,
      width: a,
      height: o
    } = e || this.copyCanvas(null, null, !0).imageData, l = await n.guess({
      name: "altText",
      request: {
        data: r,
        width: a,
        height: o,
        channels: r.length / (a * o)
      }
    });
    if (!l)
      throw new Error("No response from the AI service.");
    if (l.error)
      throw new Error("Error from the AI service.");
    if (l.cancel)
      return null;
    if (!l.output)
      throw new Error("No valid response from the AI service.");
    const h = l.output;
    return await this.setGuessedAltText(h), s && !this.hasAltTextData() && (this.altTextData = {
      alt: h,
      decorative: !1
    }), h;
  }
  remove() {
    var e;
    i(this, le) && (u(this, Pt, null), this._uiManager.imageManager.deleteId(i(this, le)), (e = i(this, Un)) == null || e.remove(), u(this, Un, null), i(this, Vi) && (clearTimeout(i(this, Vi)), u(this, Vi, null))), super.remove();
  }
  rebuild() {
    if (!this.parent) {
      i(this, le) && m(this, st, tp).call(this);
      return;
    }
    super.rebuild(), this.div !== null && (i(this, le) && i(this, Un) === null && m(this, st, tp).call(this), this.isAttachedToDOM || this.parent.add(this));
  }
  onceAdded(e) {
    this._isDraggable = !0, e && this.div.focus();
  }
  isEmpty() {
    return !(i(this, Kr) || i(this, Pt) || i(this, Hn) || i(this, qr) || i(this, le) || i(this, tl));
  }
  get toolbarButtons() {
    return [["altText", this.createAltText()]];
  }
  get isResizable() {
    return !0;
  }
  render() {
    if (this.div)
      return this.div;
    let e, s;
    return this._isCopy && (e = this.x, s = this.y), super.render(), this.div.hidden = !0, this.createAltText(), i(this, tl) || (i(this, Pt) ? m(this, st, ep).call(this) : m(this, st, tp).call(this)), this._isCopy && this._moveAfterPaste(e, s), this._uiManager.addShouldRescale(this), this.div;
  }
  setCanvas(e, s) {
    const {
      id: n,
      bitmap: r
    } = this._uiManager.imageManager.getFromCanvas(e, s);
    s.remove(), n && this._uiManager.imageManager.isValidId(n) && (u(this, le, n), r && u(this, Pt, r), u(this, tl, !1), m(this, st, ep).call(this));
  }
  _onResized() {
    this.onScaleChanging();
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    i(this, Vi) !== null && clearTimeout(i(this, Vi)), u(this, Vi, setTimeout(() => {
      u(this, Vi, null), m(this, st, Eb).call(this);
    }, 200));
  }
  copyCanvas(e, s, n = !1) {
    e || (e = 224);
    const {
      width: r,
      height: a
    } = i(this, Pt), o = new ws();
    let l = i(this, Pt), h = r, c = a, d = null;
    if (s) {
      if (r > s || a > s) {
        const k = Math.min(s / r, s / a);
        h = Math.floor(r * k), c = Math.floor(a * k);
      }
      d = document.createElement("canvas");
      const b = d.width = Math.ceil(h * o.sx), y = d.height = Math.ceil(c * o.sy);
      i(this, gs) || (l = m(this, st, sp).call(this, b, y));
      const A = d.getContext("2d");
      A.filter = this._uiManager.hcmFilter;
      let w = "white", v = "#cfcfd8";
      this._uiManager.hcmFilter !== "none" ? v = "black" : Ow.isDarkMode && (w = "#8f8f9d", v = "#42414d");
      const S = 15, E = S * o.sx, C = S * o.sy, x = new OffscreenCanvas(E * 2, C * 2), T = x.getContext("2d");
      T.fillStyle = w, T.fillRect(0, 0, E * 2, C * 2), T.fillStyle = v, T.fillRect(0, 0, E, C), T.fillRect(E, C, E, C), A.fillStyle = A.createPattern(x, "repeat"), A.fillRect(0, 0, b, y), A.drawImage(l, 0, 0, l.width, l.height, 0, 0, b, y);
    }
    let f = null;
    if (n) {
      let b, y;
      if (o.symmetric && l.width < e && l.height < e)
        b = l.width, y = l.height;
      else if (l = i(this, Pt), r > e || a > e) {
        const v = Math.min(e / r, e / a);
        b = Math.floor(r * v), y = Math.floor(a * v), i(this, gs) || (l = m(this, st, sp).call(this, b, y));
      }
      const w = new OffscreenCanvas(b, y).getContext("2d", {
        willReadFrequently: !0
      });
      w.drawImage(l, 0, 0, l.width, l.height, 0, 0, b, y), f = {
        width: b,
        height: y,
        data: w.getImageData(0, 0, b, y).data
      };
    }
    return {
      canvas: d,
      width: h,
      height: c,
      imageData: f
    };
  }
  static async deserialize(e, s, n) {
    var w;
    let r = null, a = !1;
    if (e instanceof _0) {
      const {
        data: {
          rect: v,
          rotation: S,
          id: E,
          structParent: C,
          popupRef: x,
          richText: T,
          contentsObj: k,
          creationDate: M,
          modificationDate: P
        },
        container: D,
        parent: {
          page: {
            pageNumber: H
          }
        },
        canvas: Y
      } = e;
      let Q, K;
      Y ? (delete e.canvas, {
        id: Q,
        bitmap: K
      } = n.imageManager.getFromCanvas(D.id, Y), Y.remove()) : (a = !0, e._hasNoCanvas = !0);
      const et = ((w = await s._structTree.getAriaAttributes(`${ml}${E}`)) == null ? void 0 : w.get("aria-label")) || "";
      r = e = {
        annotationType: X.STAMP,
        bitmapId: Q,
        bitmap: K,
        pageIndex: H - 1,
        rect: v.slice(0),
        rotation: S,
        annotationElementId: E,
        id: E,
        deleted: !1,
        accessibilityData: {
          decorative: !1,
          altText: et
        },
        isSvg: !1,
        structParent: C,
        popupRef: x,
        richText: T,
        comment: (k == null ? void 0 : k.str) || null,
        creationDate: M,
        modificationDate: P
      };
    }
    const o = await super.deserialize(e, s, n), {
      rect: l,
      bitmap: h,
      bitmapUrl: c,
      bitmapId: d,
      isSvg: f,
      accessibilityData: b
    } = e;
    a ? (n.addMissingCanvas(e.id, o), u(o, tl, !0)) : d && n.imageManager.isValidId(d) ? (u(o, le, d), h && u(o, Pt, h)) : u(o, Hn, c), u(o, gs, f);
    const [y, A] = o.pageDimensions;
    return o.width = (l[2] - l[0]) / y, o.height = (l[3] - l[1]) / A, b && (o.altTextData = b), o._initialData = r, e.comment && o.setCommentData(e), u(o, nc, !!r), o;
  }
  serialize(e = !1, s = null) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const n = Object.assign(super.serialize(e), {
      bitmapId: i(this, le),
      isSvg: i(this, gs)
    });
    if (this.addComment(n), e)
      return n.bitmapUrl = m(this, st, ip).call(this, !0), n.accessibilityData = this.serializeAltText(!0), n.isCopy = !0, n;
    const {
      decorative: r,
      altText: a
    } = this.serializeAltText(!1);
    if (!r && a && (n.accessibilityData = {
      type: "Figure",
      alt: a
    }), this.annotationElementId) {
      const l = m(this, st, hw).call(this, n);
      if (l.isSame)
        return null;
      if (l.isSameAltText)
        delete n.accessibilityData;
      else {
        const h = this._initialData.structParent ?? -1;
        n.accessibilityData ? n.accessibilityData.structParent = h : h >= 0 && (n.accessibilityData = {
          type: "Figure",
          alt: "",
          structParent: h
        });
      }
      return n.id = this.annotationElementId, delete n.bitmapId, n;
    }
    if (s === null)
      return n;
    s.stamps || (s.stamps = /* @__PURE__ */ new Map());
    const o = i(this, gs) ? (n.rect[2] - n.rect[0]) * (n.rect[3] - n.rect[1]) : null;
    if (!s.stamps.has(i(this, le)))
      s.stamps.set(i(this, le), {
        area: o,
        serialized: n
      }), n.bitmap = m(this, st, ip).call(this, !1);
    else if (i(this, gs)) {
      const l = s.stamps.get(i(this, le));
      o > l.area && (l.area = o, l.serialized.bitmap.close(), l.serialized.bitmap = m(this, st, ip).call(this, !1));
    }
    return n;
  }
  renderAnnotationElement(e) {
    return this.deleted ? (e.hide(), null) : (e.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    }), null);
  }
}
Pt = new WeakMap(), le = new WeakMap(), Kr = new WeakMap(), Hn = new WeakMap(), qr = new WeakMap(), ic = new WeakMap(), Un = new WeakMap(), tl = new WeakMap(), Vi = new WeakMap(), gs = new WeakMap(), nc = new WeakMap(), st = new WeakSet(), Gc = function(e, s = !1) {
  if (!e) {
    this.remove();
    return;
  }
  u(this, Pt, e.bitmap), s || (u(this, le, e.id), u(this, gs, e.isSvg)), e.file && u(this, ic, e.file.name), m(this, st, ep).call(this);
}, $c = function() {
  if (u(this, Kr, null), this._uiManager.enableWaiting(!1), !!i(this, Un)) {
    if (this._uiManager.useNewAltTextWhenAddingImage && this._uiManager.useNewAltTextFlow && i(this, Pt)) {
      this.addEditToolbar().then(() => {
        this._editToolbar.hide(), this._uiManager.editAltText(this, !0);
      });
      return;
    }
    if (!this._uiManager.useNewAltTextWhenAddingImage && this._uiManager.useNewAltTextFlow && i(this, Pt)) {
      this._reportTelemetry({
        action: "pdfjs.image.image_added",
        data: {
          alt_text_modal: !1,
          alt_text_type: "empty"
        }
      });
      try {
        this.mlGuessAltText();
      } catch {
      }
    }
    this.div.focus();
  }
}, tp = function() {
  if (i(this, le)) {
    this._uiManager.enableWaiting(!0), this._uiManager.imageManager.getFromId(i(this, le)).then((n) => m(this, st, Gc).call(this, n, !0)).finally(() => m(this, st, $c).call(this));
    return;
  }
  if (i(this, Hn)) {
    const n = i(this, Hn);
    u(this, Hn, null), this._uiManager.enableWaiting(!0), u(this, Kr, this._uiManager.imageManager.getFromUrl(n).then((r) => m(this, st, Gc).call(this, r)).finally(() => m(this, st, $c).call(this)));
    return;
  }
  if (i(this, qr)) {
    const n = i(this, qr);
    u(this, qr, null), this._uiManager.enableWaiting(!0), u(this, Kr, this._uiManager.imageManager.getFromFile(n).then((r) => m(this, st, Gc).call(this, r)).finally(() => m(this, st, $c).call(this)));
    return;
  }
  const e = document.createElement("input");
  e.type = "file", e.accept = Lg.keys().join(",");
  const s = this._uiManager._signal;
  u(this, Kr, new Promise((n) => {
    e.addEventListener("change", async () => {
      if (!e.files || e.files.length === 0)
        this.remove();
      else {
        this._uiManager.enableWaiting(!0);
        const r = await this._uiManager.imageManager.getFromFile(e.files[0]);
        this._reportTelemetry({
          action: "pdfjs.image.image_selected",
          data: {
            alt_text_modal: this._uiManager.useNewAltTextFlow
          }
        }), m(this, st, Gc).call(this, r);
      }
      n();
    }, {
      signal: s
    }), e.addEventListener("cancel", () => {
      this.remove(), n();
    }, {
      signal: s
    });
  }).finally(() => m(this, st, $c).call(this))), e.click();
}, ep = function() {
  var h;
  const {
    div: e
  } = this;
  let {
    width: s,
    height: n
  } = i(this, Pt);
  const [r, a] = this.pageDimensions, o = 0.75;
  if (this.width)
    s = this.width * r, n = this.height * a;
  else if (s > o * r || n > o * a) {
    const c = Math.min(o * r / s, o * a / n);
    s *= c, n *= c;
  }
  this._uiManager.enableWaiting(!1);
  const l = u(this, Un, document.createElement("canvas"));
  l.setAttribute("role", "img"), this.addContainer(l), this.width = s / r, this.height = n / a, this.setDims(), (h = this._initialOptions) != null && h.isCentered ? this.center() : this.fixAndSetPosition(), this._initialOptions = null, (!this._uiManager.useNewAltTextWhenAddingImage || !this._uiManager.useNewAltTextFlow || this.annotationElementId) && (e.hidden = !1), m(this, st, Eb).call(this), i(this, nc) || (this.parent.addUndoableEditor(this), u(this, nc, !0)), this._reportTelemetry({
    action: "inserted_image"
  }), i(this, ic) && this.div.setAttribute("aria-description", i(this, ic)), this.annotationElementId || this._uiManager.a11yAlert(bt._l10nAlert.stamp);
}, sp = function(e, s) {
  const {
    width: n,
    height: r
  } = i(this, Pt);
  let a = n, o = r, l = i(this, Pt);
  for (; a > 2 * e || o > 2 * s; ) {
    const h = a, c = o;
    a > 2 * e && (a = Math.ceil(a / 2)), o > 2 * s && (o = Math.ceil(o / 2));
    const d = new OffscreenCanvas(a, o);
    d.getContext("2d").drawImage(l, 0, 0, h, c, 0, 0, a, o), l = d.transferToImageBitmap();
  }
  return l;
}, Eb = function() {
  const [e, s] = this.parentDimensions, {
    width: n,
    height: r
  } = this, a = new ws(), o = Math.ceil(n * e * a.sx), l = Math.ceil(r * s * a.sy), h = i(this, Un);
  if (!h || h.width === o && h.height === l)
    return;
  h.width = o, h.height = l;
  const c = i(this, gs) ? i(this, Pt) : m(this, st, sp).call(this, o, l), d = h.getContext("2d");
  d.filter = this._uiManager.hcmFilter, d.drawImage(c, 0, 0, c.width, c.height, 0, 0, o, l);
}, ip = function(e) {
  if (e) {
    if (i(this, gs)) {
      const r = this._uiManager.imageManager.getSvgUrl(i(this, le));
      if (r)
        return r;
    }
    const s = document.createElement("canvas");
    return {
      width: s.width,
      height: s.height
    } = i(this, Pt), s.getContext("2d").drawImage(i(this, Pt), 0, 0), s.toDataURL();
  }
  if (i(this, gs)) {
    const [s, n] = this.pageDimensions, r = Math.round(this.width * s * la.PDF_TO_CSS_UNITS), a = Math.round(this.height * n * la.PDF_TO_CSS_UNITS), o = new OffscreenCanvas(r, a);
    return o.getContext("2d").drawImage(i(this, Pt), 0, 0, i(this, Pt).width, i(this, Pt).height, 0, 0, r, a), o.transferToImageBitmap();
  }
  return structuredClone(i(this, Pt));
}, hw = function(e) {
  var o;
  const {
    pageIndex: s,
    accessibilityData: {
      altText: n
    }
  } = this._initialData, r = e.pageIndex === s, a = (((o = e.accessibilityData) == null ? void 0 : o.alt) || "") === n;
  return {
    isSame: !this.hasEditedComment && !this._hasBeenMoved && !this._hasBeenResized && r && a,
    isSameAltText: a
  };
}, _(Sb, "_type", "stamp"), _(Sb, "_editorType", X.STAMP);
var el, rc, Qr, Jr, zn, Xe, Zr, ac, oc, li, Gn, Ye, $n, ta, lc, B, ea, yt, xb, cw, mi, Tb, _b, np;
const js = class js {
  constructor({
    uiManager: t,
    pageIndex: e,
    div: s,
    structTreeLayer: n,
    accessibilityManager: r,
    annotationLayer: a,
    drawLayer: o,
    textLayer: l,
    viewport: h,
    l10n: c
  }) {
    g(this, yt);
    g(this, el);
    g(this, rc, !1);
    g(this, Qr, null);
    g(this, Jr, null);
    g(this, zn, null);
    g(this, Xe, /* @__PURE__ */ new Map());
    g(this, Zr, !1);
    g(this, ac, !1);
    g(this, oc, !1);
    g(this, li, null);
    g(this, Gn, null);
    g(this, Ye, null);
    g(this, $n, null);
    g(this, ta, null);
    g(this, lc, -1);
    g(this, B);
    const d = [...i(js, ea).values()];
    if (!js._initialized) {
      js._initialized = !0;
      for (const f of d)
        f.initialize(c, t);
    }
    t.registerEditorTypes(d), u(this, B, t), this.pageIndex = e, this.div = s, u(this, el, r), u(this, Qr, a), this.viewport = h, u(this, Ye, l), this.drawLayer = o, this._structTree = n, i(this, B).addLayer(this);
  }
  get isEmpty() {
    return i(this, Xe).size === 0;
  }
  get isInvisible() {
    return this.isEmpty && i(this, B).getMode() === X.NONE;
  }
  updateToolbar(t) {
    i(this, B).updateToolbar(t);
  }
  updateMode(t = i(this, B).getMode()) {
    switch (m(this, yt, np).call(this), t) {
      case X.NONE:
        this.div.classList.toggle("nonEditing", !0), this.disableTextSelection(), this.togglePointerEvents(!1), this.toggleAnnotationLayerPointerEvents(!0), this.disableClick();
        return;
      case X.INK:
        this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
        break;
      case X.HIGHLIGHT:
        this.enableTextSelection(), this.togglePointerEvents(!1), this.disableClick();
        break;
      default:
        this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
    }
    this.toggleAnnotationLayerPointerEvents(!1);
    const {
      classList: e
    } = this.div;
    if (e.toggle("nonEditing", !1), t === X.POPUP)
      e.toggle("commentEditing", !0);
    else {
      e.toggle("commentEditing", !1);
      for (const s of i(js, ea).values())
        e.toggle(`${s._type}Editing`, t === s._editorType);
    }
    this.div.hidden = !1;
  }
  hasTextLayer(t) {
    var e;
    return t === ((e = i(this, Ye)) == null ? void 0 : e.div);
  }
  setEditingState(t) {
    i(this, B).setEditingState(t);
  }
  addCommands(t) {
    i(this, B).addCommands(t);
  }
  cleanUndoStack(t) {
    i(this, B).cleanUndoStack(t);
  }
  toggleDrawing(t = !1) {
    this.div.classList.toggle("drawing", !t);
  }
  togglePointerEvents(t = !1) {
    this.div.classList.toggle("disabled", !t);
  }
  toggleAnnotationLayerPointerEvents(t = !1) {
    var e;
    (e = i(this, Qr)) == null || e.togglePointerEvents(t);
  }
  async enable() {
    var s;
    u(this, oc, !0), this.div.tabIndex = 0, this.togglePointerEvents(!0), this.div.classList.toggle("nonEditing", !1), (s = i(this, ta)) == null || s.abort(), u(this, ta, null);
    const t = /* @__PURE__ */ new Set();
    for (const n of i(this, yt, xb))
      n.enableEditing(), n.show(!0), n.annotationElementId && (i(this, B).removeChangedExistingAnnotation(n), t.add(n.annotationElementId));
    const e = i(this, Qr);
    if (e)
      for (const n of e.getEditableAnnotations()) {
        if (n.hide(), i(this, B).isDeletedAnnotationElement(n.data.id) || t.has(n.data.id))
          continue;
        const r = await this.deserialize(n);
        r && (this.addOrRebuild(r), r.enableEditing());
      }
    u(this, oc, !1), i(this, B)._eventBus.dispatch("editorsrendered", {
      source: this,
      pageNumber: this.pageIndex + 1
    });
  }
  disable() {
    var n;
    if (u(this, ac, !0), this.div.tabIndex = -1, this.togglePointerEvents(!1), this.div.classList.toggle("nonEditing", !0), i(this, Ye) && !i(this, ta)) {
      u(this, ta, new AbortController());
      const r = i(this, B).combinedSignal(i(this, ta));
      i(this, Ye).div.addEventListener("pointerdown", (a) => {
        const {
          clientX: l,
          clientY: h,
          timeStamp: c
        } = a, d = i(this, lc);
        if (c - d > 500) {
          u(this, lc, c);
          return;
        }
        u(this, lc, -1);
        const {
          classList: f
        } = this.div;
        f.toggle("getElements", !0);
        const b = document.elementsFromPoint(l, h);
        if (f.toggle("getElements", !1), !this.div.contains(b[0]))
          return;
        let y;
        const A = new RegExp(`^${dc}[0-9]+$`);
        for (const v of b)
          if (A.test(v.id)) {
            y = v.id;
            break;
          }
        if (!y)
          return;
        const w = i(this, Xe).get(y);
        (w == null ? void 0 : w.annotationElementId) === null && (te(a), w.dblclick(a));
      }, {
        signal: r,
        capture: !0
      });
    }
    const t = i(this, Qr), e = [];
    if (t) {
      const r = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map();
      for (const o of i(this, yt, xb)) {
        if (o.disableEditing(), !o.annotationElementId) {
          e.push(o);
          continue;
        }
        if (o.serialize() !== null) {
          r.set(o.annotationElementId, o);
          continue;
        } else
          a.set(o.annotationElementId, o);
        (n = this.getEditableAnnotation(o.annotationElementId)) == null || n.show(), o.remove();
      }
      for (const o of t.getEditableAnnotations()) {
        const {
          id: l
        } = o.data;
        if (i(this, B).isDeletedAnnotationElement(l)) {
          o.updateEdited({
            deleted: !0
          });
          continue;
        }
        let h = a.get(l);
        if (h) {
          h.resetAnnotationElement(o), h.show(!1), o.show();
          continue;
        }
        h = r.get(l), h && (i(this, B).addChangedExistingAnnotation(h), h.renderAnnotationElement(o) && h.show(!1)), o.show();
      }
    }
    m(this, yt, np).call(this), this.isEmpty && (this.div.hidden = !0);
    const {
      classList: s
    } = this.div;
    for (const r of i(js, ea).values())
      s.remove(`${r._type}Editing`);
    this.disableTextSelection(), this.toggleAnnotationLayerPointerEvents(!0), t == null || t.updateFakeAnnotations(e), u(this, ac, !1);
  }
  getEditableAnnotation(t) {
    var e;
    return ((e = i(this, Qr)) == null ? void 0 : e.getEditableAnnotation(t)) || null;
  }
  setActiveEditor(t) {
    i(this, B).getActive() !== t && i(this, B).setActiveEditor(t);
  }
  enableTextSelection() {
    var t;
    if (this.div.tabIndex = -1, (t = i(this, Ye)) != null && t.div && !i(this, $n)) {
      u(this, $n, new AbortController());
      const e = i(this, B).combinedSignal(i(this, $n));
      i(this, Ye).div.addEventListener("pointerdown", m(this, yt, cw).bind(this), {
        signal: e
      }), i(this, Ye).div.classList.add("highlighting");
    }
  }
  disableTextSelection() {
    var t;
    this.div.tabIndex = 0, (t = i(this, Ye)) != null && t.div && i(this, $n) && (i(this, $n).abort(), u(this, $n, null), i(this, Ye).div.classList.remove("highlighting"));
  }
  enableClick() {
    if (i(this, Jr))
      return;
    u(this, Jr, new AbortController());
    const t = i(this, B).combinedSignal(i(this, Jr));
    this.div.addEventListener("pointerdown", this.pointerdown.bind(this), {
      signal: t
    });
    const e = this.pointerup.bind(this);
    this.div.addEventListener("pointerup", e, {
      signal: t
    }), this.div.addEventListener("pointercancel", e, {
      signal: t
    });
  }
  disableClick() {
    var t;
    (t = i(this, Jr)) == null || t.abort(), u(this, Jr, null);
  }
  attach(t) {
    i(this, Xe).set(t.id, t);
    const {
      annotationElementId: e
    } = t;
    e && i(this, B).isDeletedAnnotationElement(e) && i(this, B).removeDeletedAnnotationElement(t);
  }
  detach(t) {
    var e;
    i(this, Xe).delete(t.id), (e = i(this, el)) == null || e.removePointerInTextLayer(t.contentDiv), !i(this, ac) && t.annotationElementId && i(this, B).addDeletedAnnotationElement(t);
  }
  remove(t) {
    this.detach(t), i(this, B).removeEditor(t), t.div.remove(), t.isAttachedToDOM = !1;
  }
  changeParent(t) {
    var e;
    t.parent !== this && (t.parent && t.annotationElementId && (i(this, B).addDeletedAnnotationElement(t), bt.deleteAnnotationElement(t), t.annotationElementId = null), this.attach(t), (e = t.parent) == null || e.detach(t), t.setParent(this), t.div && t.isAttachedToDOM && (t.div.remove(), this.div.append(t.div)));
  }
  add(t) {
    if (!(t.parent === this && t.isAttachedToDOM)) {
      if (this.changeParent(t), i(this, B).addEditor(t), this.attach(t), !t.isAttachedToDOM) {
        const e = t.render();
        this.div.append(e), t.isAttachedToDOM = !0;
      }
      t.fixAndSetPosition(), t.onceAdded(!i(this, oc)), i(this, B).addToAnnotationStorage(t), t._reportTelemetry(t.telemetryInitialData);
    }
  }
  moveEditorInDOM(t) {
    var s;
    if (!t.isAttachedToDOM)
      return;
    const {
      activeElement: e
    } = document;
    t.div.contains(e) && !i(this, zn) && (t._focusEventsAllowed = !1, u(this, zn, setTimeout(() => {
      u(this, zn, null), t.div.contains(document.activeElement) ? t._focusEventsAllowed = !0 : (t.div.addEventListener("focusin", () => {
        t._focusEventsAllowed = !0;
      }, {
        once: !0,
        signal: i(this, B)._signal
      }), e.focus());
    }, 0))), t._structTreeParentId = (s = i(this, el)) == null ? void 0 : s.moveElementInDOM(this.div, t.div, t.contentDiv, !0);
  }
  addOrRebuild(t) {
    t.needsToBeRebuilt() ? (t.parent || (t.parent = this), t.rebuild(), t.show()) : this.add(t);
  }
  addUndoableEditor(t) {
    const e = () => t._uiManager.rebuild(t), s = () => {
      t.remove();
    };
    this.addCommands({
      cmd: e,
      undo: s,
      mustExec: !1
    });
  }
  getEditorByUID(t) {
    for (const e of i(this, Xe).values())
      if (e.uid === t)
        return e;
    return null;
  }
  combinedSignal(t) {
    return i(this, B).combinedSignal(t);
  }
  canCreateNewEmptyEditor() {
    var t;
    return (t = i(this, yt, mi)) == null ? void 0 : t.canCreateNewEmptyEditor();
  }
  async pasteEditor(t, e) {
    this.updateToolbar(t), await i(this, B).updateMode(t.mode);
    const {
      offsetX: s,
      offsetY: n
    } = m(this, yt, _b).call(this), r = i(this, B).getId(), a = m(this, yt, Tb).call(this, {
      parent: this,
      id: r,
      x: s,
      y: n,
      uiManager: i(this, B),
      isCentered: !0,
      ...e
    });
    a && this.add(a);
  }
  async deserialize(t) {
    var e;
    return await ((e = i(js, ea).get(t.annotationType ?? t.annotationEditorType)) == null ? void 0 : e.deserialize(t, this, i(this, B))) || null;
  }
  createAndAddNewEditor(t, e, s = {}) {
    const n = i(this, B).getId(), r = m(this, yt, Tb).call(this, {
      parent: this,
      id: n,
      x: t.offsetX,
      y: t.offsetY,
      uiManager: i(this, B),
      isCentered: e,
      ...s
    });
    return r && this.add(r), r;
  }
  get boundingClientRect() {
    return this.div.getBoundingClientRect();
  }
  addNewEditor(t = {}) {
    this.createAndAddNewEditor(m(this, yt, _b).call(this), !0, t);
  }
  setSelected(t) {
    i(this, B).setSelected(t);
  }
  toggleSelected(t) {
    i(this, B).toggleSelected(t);
  }
  unselect(t) {
    i(this, B).unselect(t);
  }
  pointerup(t) {
    var n;
    const {
      isMac: e
    } = ot.platform;
    if (t.button !== 0 || t.ctrlKey && e || t.target !== this.div || !i(this, Zr) || (u(this, Zr, !1), (n = i(this, yt, mi)) != null && n.isDrawer && i(this, yt, mi).supportMultipleDrawings))
      return;
    if (!i(this, rc)) {
      u(this, rc, !0);
      return;
    }
    const s = i(this, B).getMode();
    if (s === X.STAMP || s === X.POPUP || s === X.SIGNATURE) {
      i(this, B).unselectAll();
      return;
    }
    this.createAndAddNewEditor(t, !1);
  }
  pointerdown(t) {
    var n;
    if (i(this, B).getMode() === X.HIGHLIGHT && this.enableTextSelection(), i(this, Zr)) {
      u(this, Zr, !1);
      return;
    }
    const {
      isMac: e
    } = ot.platform;
    if (t.button !== 0 || t.ctrlKey && e || t.target !== this.div)
      return;
    if (u(this, Zr, !0), (n = i(this, yt, mi)) != null && n.isDrawer) {
      this.startDrawingSession(t);
      return;
    }
    const s = i(this, B).getActive();
    u(this, rc, !s || s.isEmpty());
  }
  startDrawingSession(t) {
    if (this.div.focus({
      preventScroll: !0
    }), i(this, li)) {
      i(this, yt, mi).startDrawing(this, i(this, B), !1, t);
      return;
    }
    i(this, B).setCurrentDrawingSession(this), u(this, li, new AbortController());
    const e = i(this, B).combinedSignal(i(this, li));
    this.div.addEventListener("blur", ({
      relatedTarget: s
    }) => {
      s && !this.div.contains(s) && (u(this, Gn, null), this.commitOrRemove());
    }, {
      signal: e
    }), i(this, yt, mi).startDrawing(this, i(this, B), !1, t);
  }
  pause(t) {
    if (t) {
      const {
        activeElement: e
      } = document;
      this.div.contains(e) && u(this, Gn, e);
      return;
    }
    i(this, Gn) && setTimeout(() => {
      var e;
      (e = i(this, Gn)) == null || e.focus(), u(this, Gn, null);
    }, 0);
  }
  endDrawingSession(t = !1) {
    return i(this, li) ? (i(this, B).setCurrentDrawingSession(null), i(this, li).abort(), u(this, li, null), u(this, Gn, null), i(this, yt, mi).endDrawing(t)) : null;
  }
  findNewParent(t, e, s) {
    const n = i(this, B).findParent(e, s);
    return n === null || n === this ? !1 : (n.changeParent(t), !0);
  }
  commitOrRemove() {
    return i(this, li) ? (this.endDrawingSession(), !0) : !1;
  }
  onScaleChanging() {
    i(this, li) && i(this, yt, mi).onScaleChangingWhenDrawing(this);
  }
  destroy() {
    var t, e;
    this.commitOrRemove(), ((t = i(this, B).getActive()) == null ? void 0 : t.parent) === this && (i(this, B).commitOrRemove(), i(this, B).setActiveEditor(null)), i(this, zn) && (clearTimeout(i(this, zn)), u(this, zn, null));
    for (const s of i(this, Xe).values())
      (e = i(this, el)) == null || e.removePointerInTextLayer(s.contentDiv), s.setParent(null), s.isAttachedToDOM = !1, s.div.remove();
    this.div = null, i(this, Xe).clear(), i(this, B).removeLayer(this);
  }
  async render({
    viewport: t
  }) {
    this.viewport = t, nl(this.div, t);
    for (const e of i(this, B).getEditors(this.pageIndex))
      this.add(e), e.rebuild();
    await i(this, B).findClonesForPage(this), this.div.hidden = this.isEmpty, this.updateMode();
  }
  update({
    viewport: t
  }) {
    i(this, B).commitOrRemove(), m(this, yt, np).call(this);
    const e = this.viewport.rotation, s = t.rotation;
    if (this.viewport = t, nl(this.div, {
      rotation: s
    }), e !== s)
      for (const n of i(this, Xe).values())
        n.rotate(s);
  }
  get pageDimensions() {
    const {
      pageWidth: t,
      pageHeight: e
    } = this.viewport.rawDims;
    return [t, e];
  }
  get scale() {
    return i(this, B).viewParameters.realScale;
  }
};
el = new WeakMap(), rc = new WeakMap(), Qr = new WeakMap(), Jr = new WeakMap(), zn = new WeakMap(), Xe = new WeakMap(), Zr = new WeakMap(), ac = new WeakMap(), oc = new WeakMap(), li = new WeakMap(), Gn = new WeakMap(), Ye = new WeakMap(), $n = new WeakMap(), ta = new WeakMap(), lc = new WeakMap(), B = new WeakMap(), ea = new WeakMap(), yt = new WeakSet(), xb = function() {
  return i(this, Xe).size !== 0 ? i(this, Xe).values() : i(this, B).getEditors(this.pageIndex);
}, cw = function(t) {
  i(this, B).unselectAll();
  const {
    target: e
  } = t;
  if (e === i(this, Ye).div || (e.getAttribute("role") === "img" || e.classList.contains("endOfContent") || e.classList.contains("textLayerImages") || e.classList.contains("textLayerImagePlaceholder")) && i(this, Ye).div.contains(e)) {
    const {
      isMac: s
    } = ot.platform;
    if (t.button !== 0 || t.ctrlKey && s)
      return;
    i(this, B).showAllEditors("highlight", !0, !0), gp.startDrawing(this, i(this, B), i(this, B).direction === "ltr", t), t.preventDefault();
  }
}, mi = function() {
  return i(js, ea).get(i(this, B).getMode());
}, Tb = function(t) {
  const e = i(this, yt, mi);
  return e ? new e.prototype.constructor(t) : null;
}, _b = function() {
  const {
    x: t,
    y: e,
    width: s,
    height: n
  } = this.boundingClientRect, r = Math.max(0, t), a = Math.max(0, e), o = Math.min(window.innerWidth, t + s), l = Math.min(window.innerHeight, e + n), h = (r + o) / 2 - t, c = (a + l) / 2 - e, [d, f] = this.viewport.rotation % 180 === 0 ? [h, c] : [c, h];
  return {
    offsetX: d,
    offsetY: f
  };
}, np = function() {
  for (const t of i(this, Xe).values())
    t.isEmpty() && t.remove();
}, _(js, "_initialized", !1), g(js, ea, new Map([Wm, gb, Sb, gp, vb].map((t) => [t._editorType, t])));
let Cb = js;
function PS(p, t) {
  return p === t ? 0 : p.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
}
function gf(p) {
  var t;
  return p ? p.nodeType === Node.ELEMENT_NODE ? p.closest(".textLayer") : ((t = p.parentElement) == null ? void 0 : t.closest(".textLayer")) || null : null;
}
function MS(p, t, e, s) {
  if (p === e)
    return t <= s;
  const n = p.compareDocumentPosition(e);
  return n & Node.DOCUMENT_POSITION_FOLLOWING ? !0 : n & Node.DOCUMENT_POSITION_PRECEDING ? !1 : null;
}
function Py(p, t, e) {
  if (p.nodeType !== Node.ELEMENT_NODE || !p.classList.contains("textLayer") || t !== p.childNodes.length)
    return {
      container: p,
      offset: t
    };
  let s = p.lastChild;
  return (s == null ? void 0 : s.nodeType) === Node.ELEMENT_NODE && s.classList.contains("endOfContent") && (s = s.previousSibling), !s || !e.contains(s) ? null : s.nodeType === Node.TEXT_NODE ? {
    container: s,
    offset: s.textContent.length
  } : {
    container: s,
    offset: s.childNodes.length
  };
}
var Le, Oe, Us, Qu, Ju, sl, il, Zu, Zp, sa, ia, na, ra, jn, _e, Pb, Mb, dw, rp, uw, Qi, Db, fw, Ib;
const $ = class $ {
  constructor({
    filterFactory: t = null,
    pageColors: e = null,
    pageIndex: s,
    textLayer: n = null
  }) {
    g(this, Qi);
    g(this, Le, null);
    g(this, Oe, /* @__PURE__ */ new Map());
    g(this, Us, null);
    g(this, Qu, null);
    g(this, Ju, null);
    g(this, sl, null);
    g(this, il, /* @__PURE__ */ new Map());
    if (this.pageIndex = s, u(this, Qu, t), u(this, Ju, e), n) {
      const r = i($, jn).get(n);
      if (r != null && r.selectionDiv && (r.selectionDiv.remove(), i($, ia).delete(r.selectionDiv)), i($, jn).set(n, {
        drawLayer: this
      }), i($, ra).add(n), u(this, Us, n), u(this, sl, new MutationObserver((a) => {
        var o, l, h;
        if (!(!i(this, Le) || !((o = i(this, Us)) != null && o.isConnected) || !m(l = $, _e, Mb).call(l))) {
          for (const {
            addedNodes: c
          } of a)
            for (const d of c)
              if (d.nodeType === Node.ELEMENT_NODE && d.classList.contains("endOfContent")) {
                m(h = $, _e, rp).call(h);
                return;
              }
        }
      })), i(this, sl).observe(n, {
        childList: !0
      }), i($, sa) === null) {
        u($, sa, new AbortController());
        const {
          signal: a
        } = i($, sa);
        document.addEventListener("selectionchange", m($, _e, rp).bind($), {
          signal: a
        }), document.addEventListener("pointerdown", () => {
          u($, na, !0);
        }, {
          signal: a
        }), document.addEventListener("pointerup", () => {
          u($, na, !1);
        }, {
          signal: a
        }), window.addEventListener("blur", () => {
          u($, na, !1);
        }, {
          signal: a
        });
      }
    }
  }
  setParent(t) {
    var e, s, n;
    if (!i(this, Le)) {
      u(this, Le, t), (e = i(this, Us)) != null && e.isConnected && m(s = $, _e, Mb).call(s) && m(n = $, _e, rp).call(n);
      return;
    }
    if (i(this, Le) !== t) {
      if (i(this, Oe).size > 0)
        for (const r of i(this, Oe).values())
          r.remove(), t.append(r);
      u(this, Le, t);
    }
  }
  static get _svgFactory() {
    return L(this, "_svgFactory", new zb());
  }
  draw(t, e = !1, s = !1) {
    const n = rt($, Zu)._++, r = m(this, Qi, Db).call(this), a = $._svgFactory.createElement("defs");
    r.append(a);
    const o = $._svgFactory.createElement("path");
    a.append(o);
    const l = `path_${n}`;
    o.setAttribute("id", l), o.setAttribute("vector-effect", "non-scaling-stroke"), e && i(this, il).set(n, o);
    const h = s ? m(this, Qi, fw).call(this, a, l) : null, c = $._svgFactory.createElement("use");
    return r.append(c), c.setAttribute("href", `#${l}`), this.updateProperties(r, t), i(this, Oe).set(n, r), {
      id: n,
      clipPathId: `url(#${h})`
    };
  }
  drawOutline(t, e) {
    const s = rt($, Zu)._++, n = m(this, Qi, Db).call(this), r = $._svgFactory.createElement("defs");
    n.append(r);
    const a = $._svgFactory.createElement("path");
    r.append(a);
    const o = `path_${s}`;
    a.setAttribute("id", o), a.setAttribute("vector-effect", "non-scaling-stroke");
    let l;
    if (e) {
      const d = $._svgFactory.createElement("mask");
      r.append(d), l = `mask_${s}`, d.setAttribute("id", l), d.setAttribute("maskUnits", "objectBoundingBox");
      const f = $._svgFactory.createElement("rect");
      d.append(f), f.setAttribute("width", "1"), f.setAttribute("height", "1"), f.setAttribute("fill", "white");
      const b = $._svgFactory.createElement("use");
      d.append(b), b.setAttribute("href", `#${o}`), b.setAttribute("stroke", "none"), b.setAttribute("fill", "black"), b.setAttribute("fill-rule", "nonzero"), b.classList.add("mask");
    }
    const h = $._svgFactory.createElement("use");
    n.append(h), h.setAttribute("href", `#${o}`), l && h.setAttribute("mask", `url(#${l})`);
    const c = h.cloneNode();
    return n.append(c), h.classList.add("mainOutline"), c.classList.add("secondaryOutline"), this.updateProperties(n, t), i(this, Oe).set(s, n), s;
  }
  finalizeDraw(t, e) {
    i(this, il).delete(t), this.updateProperties(t, e);
  }
  updateProperties(t, e) {
    var l;
    if (!e)
      return;
    const {
      root: s,
      bbox: n,
      rootClass: r,
      path: a
    } = e, o = typeof t == "number" ? i(this, Oe).get(t) : t;
    if (o) {
      if (s && m(this, Qi, Ib).call(this, o, s), n && m(l = $, _e, uw).call(l, o, n), r) {
        const {
          classList: h
        } = o;
        for (const [c, d] of Object.entries(r))
          h.toggle(c, d);
      }
      if (a) {
        const c = o.firstElementChild.firstElementChild;
        m(this, Qi, Ib).call(this, c, a);
      }
    }
  }
  updateParent(t, e) {
    if (e === this)
      return;
    const s = i(this, Oe).get(t);
    s && (i(e, Le).append(s), i(this, Oe).delete(t), i(e, Oe).set(t, s));
  }
  remove(t) {
    i(this, il).delete(t), i(this, Le) !== null && (i(this, Oe).get(t).remove(), i(this, Oe).delete(t));
  }
  destroy() {
    var t, e, s;
    u(this, Le, null);
    for (const n of i(this, Oe).values())
      n.remove();
    if (i(this, Oe).clear(), i(this, il).clear(), (t = i(this, sl)) == null || t.disconnect(), u(this, sl, null), i(this, Us)) {
      const n = i($, jn).get(i(this, Us));
      (n == null ? void 0 : n.drawLayer) === this && (m(e = $, _e, Pb).call(e, i(this, Us)), i($, jn).delete(i(this, Us)), i($, ra).delete(i(this, Us)), i($, ra).size === 0 && ((s = i($, sa)) == null || s.abort(), u($, sa, null), u($, na, !1))), u(this, Us, null);
    }
  }
};
Le = new WeakMap(), Oe = new WeakMap(), Us = new WeakMap(), Qu = new WeakMap(), Ju = new WeakMap(), sl = new WeakMap(), il = new WeakMap(), Zu = new WeakMap(), Zp = new WeakMap(), sa = new WeakMap(), ia = new WeakMap(), na = new WeakMap(), ra = new WeakMap(), jn = new WeakMap(), _e = new WeakSet(), Pb = function(t) {
  const e = i(this, jn).get(t);
  e != null && e.selectionDiv && (e.selectionDiv.remove(), i(this, ia).delete(e.selectionDiv), e.selectionDiv = null, e.path = null);
}, Mb = function() {
  const t = document.getSelection();
  return !!t && !t.isCollapsed;
}, dw = function() {
  return i(this, ra).keys().filter((t) => t.isConnected).toArray().sort(PS);
}, rp = function() {
  var a;
  const t = document.getSelection();
  if (!t || t.isCollapsed) {
    for (const o of i(this, ia))
      o.remove();
    i(this, ia).clear();
    return;
  }
  const e = /* @__PURE__ */ new WeakMap(), s = m(this, _e, dw).call(this), n = [];
  for (let o = 0, l = t.rangeCount; o < l; o++) {
    const h = t.getRangeAt(o);
    if (h.collapsed)
      continue;
    let {
      startContainer: c,
      startOffset: d,
      endContainer: f,
      endOffset: b
    } = h, y = gf(c), A = gf(f);
    const w = y === null, v = A === null;
    if (i(this, na) && w !== v)
      return;
    if (t.rangeCount === 1) {
      const {
        anchorNode: C,
        anchorOffset: x,
        focusNode: T,
        focusOffset: k
      } = t, M = gf(C), P = gf(T), D = MS(C, x, T, k);
      M && P && D !== null && (D ? (c = C, d = x, y = M, f = T, b = k, A = P) : (c = T, d = k, y = P, f = C, b = x, A = M));
    }
    const S = s.filter((C) => h.intersectsNode(C));
    if (S.length === 0)
      continue;
    let E = !1;
    if (y || (y = S[0], c = y, d = 0, E = !0), A || (A = S.at(-1), f = A, b = A.childNodes.length, E = !0), f.nodeType === Node.ELEMENT_NODE) {
      if (f.classList.contains("endOfContent")) {
        const C = f.previousSibling;
        if (!C)
          continue;
        f = C, b = C.nodeType === Node.TEXT_NODE ? C.textContent.length : C.childNodes.length;
      } else if (f.classList.contains("textLayer") && f.childNodes.length === b) {
        const C = Py(f, b, A);
        if (!C)
          continue;
        f = C.container, b = C.offset;
      }
    }
    if (c.nodeType === Node.ELEMENT_NODE) {
      const C = Py(c, d, y);
      if (!C)
        continue;
      c = C.container, d = C.offset;
    }
    if (y === A && !E && S.includes(y)) {
      n.push([h, y]);
      continue;
    }
    for (const C of S) {
      const x = C.firstChild;
      if (!x)
        continue;
      const T = document.createRange();
      if (C === y ? T.setStart(c, d) : T.setStartBefore(x), C === A)
        T.setEnd(f, b);
      else {
        const k = C.lastChild;
        if (!k)
          continue;
        if (k.nodeType === Node.ELEMENT_NODE && k.classList.contains("endOfContent")) {
          const M = k.previousSibling;
          if (!M)
            continue;
          T.setEndAfter(M);
        } else
          T.setEndAfter(k);
      }
      T.collapsed || n.push([T, C]);
    }
  }
  const r = new Set(n.map((o) => o[1]));
  for (const o of i(this, ra))
    r.has(o) || m(this, _e, Pb).call(this, o);
  for (const [o, l] of n) {
    const h = i($, jn).get(l);
    if (!h)
      continue;
    let c = e.get(l);
    if (!c) {
      const A = l.getBoundingClientRect();
      c = (w, v, S, E) => ({
        x: (w - A.x) / A.width,
        y: (v - A.y) / A.height,
        width: S / A.width,
        height: E / A.height
      }), e.set(l, c);
    }
    const d = [];
    for (let {
      x: A,
      y: w,
      width: v,
      height: S
    } of o.getClientRects())
      v === 0 || S === 0 || ({
        x: A,
        y: w,
        width: v,
        height: S
      } = c(A, w, v, S), !(v === 1 && S === 1) && d.push(`M${A} ${w} h${v} v${S} h-${v} Z`));
    if (d.length === 0)
      continue;
    const f = h.drawLayer;
    let b = h.selectionDiv, y = h.path;
    if (!b) {
      const A = `clip_selection_${rt($, Zp)._++}`;
      b = document.createElement("div"), b.className = "selection", b.style.clipPath = `url(#${A})`;
      const w = (a = i(f, Qu)) == null ? void 0 : a.createSelectionStyle(i(f, Ju));
      if (w)
        for (const [E, C] of Object.entries(w))
          b.style.setProperty(E, C);
      const v = $._svgFactory.create(1, 1, !0);
      v.setAttribute("aria-hidden", "true"), v.setAttribute("width", "100%"), v.setAttribute("height", "100%");
      const S = $._svgFactory.createElement("clipPath");
      S.setAttribute("id", A), S.setAttribute("clipPathUnits", "objectBoundingBox"), y = $._svgFactory.createElement("path"), S.append(y), v.append(S), b.append(v), h.path = y, h.selectionDiv = b;
    }
    i(f, Le) && b.parentNode !== i(f, Le) && (i(f, Le).append(b), i(this, ia).add(b)), y.setAttribute("d", d.join(" "));
  }
}, uw = function(t, [e, s, n, r]) {
  const {
    style: a
  } = t;
  a.top = `${100 * s}%`, a.left = `${100 * e}%`, a.width = `${100 * n}%`, a.height = `${100 * r}%`;
}, Qi = new WeakSet(), Db = function() {
  const t = $._svgFactory.create(1, 1, !0);
  return i(this, Le).append(t), t.setAttribute("aria-hidden", "true"), t;
}, fw = function(t, e) {
  const s = $._svgFactory.createElement("clipPath");
  t.append(s);
  const n = `clip_${e}`;
  s.setAttribute("id", n), s.setAttribute("clipPathUnits", "objectBoundingBox");
  const r = $._svgFactory.createElement("use");
  return s.append(r), r.setAttribute("href", `#${e}`), r.classList.add("clip"), n;
}, Ib = function(t, e) {
  for (const [s, n] of Object.entries(e))
    n === null ? t.removeAttribute(s) : t.setAttribute(s, n);
}, g($, _e), g($, Zu, 0), g($, Zp, 0), g($, sa, null), g($, ia, /* @__PURE__ */ new Set()), g($, na, !1), g($, ra, /* @__PURE__ */ new Set()), g($, jn, /* @__PURE__ */ new WeakMap());
let kb = $;
function mf(p) {
  return `${(p * 100).toFixed(2)}%`;
}
var hc, tf, ef, cc, Wi, Xi, sf, tg, pw;
const Kc = class Kc {
  constructor(t, e, s, n) {
    g(this, tg);
    g(this, hc, []);
    g(this, tf, /* @__PURE__ */ new Map());
    g(this, ef, null);
    g(this, cc, 0);
    g(this, Wi, 0);
    g(this, Xi, 0);
    u(this, cc, t), u(this, hc, e), u(this, Wi, s.rawDims.pageWidth), u(this, Xi, s.rawDims.pageHeight), u(this, ef, n);
  }
  render() {
    const t = document.createElement("div");
    t.className = "textLayerImages";
    for (let e = 0; e < i(this, hc).length; e += 6) {
      const s = m(this, tg, pw).call(this, i(this, hc).subarray(e, e + 6));
      s && t.append(s);
    }
    return t.addEventListener("contextmenu", (e) => {
      var v;
      if (!(e.target instanceof HTMLCanvasElement))
        return;
      const s = e.target, n = i(this, tf).get(s);
      if (!n)
        return;
      const r = (v = i(Kc, sf)) == null ? void 0 : v.deref();
      if (r === s)
        return;
      r && (r.width = 0, r.height = 0), u(Kc, sf, new WeakRef(s));
      const {
        inverseTransform: a,
        x1: o,
        y1: l,
        width: h,
        height: c
      } = n, d = i(this, ef).call(this), f = Math.ceil(o * d.width), b = Math.ceil(l * d.height), y = Math.floor((o + h / i(this, Wi)) * d.width), A = Math.floor((l + c / i(this, Xi)) * d.height);
      s.width = y - f, s.height = A - b;
      const w = s.getContext("2d");
      w.setTransform(...a), w.translate(-f, -b), w.drawImage(d, 0, 0);
    }), t;
  }
};
hc = new WeakMap(), tf = new WeakMap(), ef = new WeakMap(), cc = new WeakMap(), Wi = new WeakMap(), Xi = new WeakMap(), sf = new WeakMap(), tg = new WeakSet(), pw = function([t, e, s, n, r, a]) {
  const o = Math.hypot((r - t) * i(this, Wi), (a - e) * i(this, Xi)), l = Math.hypot((s - t) * i(this, Wi), (n - e) * i(this, Xi));
  if (o < i(this, cc) || l < i(this, cc))
    return null;
  const h = [(r - t) * i(this, Wi) / o, (a - e) * i(this, Xi) / o, (s - t) * i(this, Wi) / l, (n - e) * i(this, Xi) / l, 0, 0], c = I.inverseTransform(h), d = document.createElement("canvas");
  return d.className = "textLayerImagePlaceholder", d.width = 0, d.height = 0, Object.assign(d.style, {
    opacity: 0,
    position: "absolute",
    left: mf(t),
    top: mf(e),
    width: mf(o / i(this, Wi)),
    height: mf(l / i(this, Xi)),
    transformOrigin: "0% 0%",
    transform: `matrix(${h.join(",")})`
  }), i(this, tf).set(d, {
    inverseTransform: c,
    width: o,
    height: l,
    x1: t,
    y1: e
  }), d;
}, g(Kc, sf, null);
let Fb = Kc;
globalThis._pdfjsTestingUtils = {
  HighlightOutliner: eb
};
globalThis.pdfjsLib = {
  AbortException: oa,
  AnnotationEditorLayer: Cb,
  AnnotationEditorParamsType: tt,
  AnnotationEditorType: X,
  AnnotationEditorUIManager: al,
  AnnotationLayer: Vm,
  AnnotationMode: tr,
  AnnotationType: It,
  applyOpacity: kw,
  build: rS,
  ColorPicker: up,
  createValidAbsoluteUrl: Ly,
  CSSConstants: Rw,
  DOMSVGFactory: zb,
  DrawLayer: kb,
  FeatureTest: ot,
  fetchData: Rb,
  findContrastColor: Pw,
  getDocument: f0,
  getFilenameFromUrl: Iw,
  getPdfFilenameFromUrl: Fw,
  getRGB: nf,
  getRGBA: mc,
  getUuid: Ry,
  GlobalWorkerOptions: Te,
  ImageKind: bf,
  InvalidPDFException: kg,
  isDataScheme: rg,
  isPdfFile: Nb,
  isValidExplicitDest: Vw,
  makeArr: gc,
  makeMap: op,
  makeObj: Mg,
  makeSet: _w,
  MathClamp: vt,
  noContextMenu: di,
  normalizeUnicode: xw,
  OPS: an,
  OutputScale: ws,
  PasswordException: _g,
  PasswordResponses: Aw,
  PDFDataRangeTransport: p0,
  PDFDateString: lp,
  PDFWorker: td,
  PermissionFlag: yw,
  PixelsPerInch: la,
  RenderingCancelledException: Lb,
  renderRichText: By,
  ResponseException: ap,
  setLayerDimensions: nl,
  shadow: L,
  SignatureExtractor: Vn,
  stopEvent: te,
  SupportedImageMimeTypes: Lg,
  TextLayer: Zc,
  TextLayerImages: Fb,
  TouchManager: rA,
  updateUrlHash: Oy,
  Util: I,
  VerbosityLevel: eg,
  version: nS,
  XfaLayer: Ob
};
function My(p, t) {
  const e = p.text.trim();
  return !e || e.length > 100 || p.fontSize < t * 1.22 || p.fontSize < 9 || e.split(/\s+/).length > 20 || /[.,;:]$/.test(e) ? !1 : /[A-Za-z\u00C0-\u024F]/.test(e);
}
function DS(p) {
  const t = /* @__PURE__ */ new Map();
  for (const n of p) {
    if (!n.text.trim()) continue;
    const r = Math.round(n.fontSize * 2) / 2;
    t.set(r, (t.get(r) || 0) + 1);
  }
  let e = 0, s = 10;
  return t.forEach((n, r) => {
    (n > e || n === e && r > s) && (e = n, s = r);
  }), s;
}
function gw(p) {
  const t = p.filter((l) => l.text.trim().length > 0);
  if (t.length === 0) return "";
  const e = DS(t);
  let s = 0;
  for (const l of t)
    My(l, e) && (s = Math.max(s, l.fontSize));
  const n = [];
  let r = [], a = null;
  const o = () => {
    r.length > 0 && (n.push(r.join(" ")), r = []);
  };
  for (const l of t) {
    const h = l.text.trim();
    if (My(l, e)) {
      o();
      const d = s > 0 && l.fontSize >= s - 0.5 ? "#" : "##";
      n.push(`${d} ${h}`), a = l.y;
      continue;
    }
    const c = a === null ? 0 : a - l.y;
    a !== null && c > e * 1.85 && o(), r.push(h.replace(/\s+/g, " ").trim()), a = l.y;
  }
  return o(), n.filter((l) => l.trim().length >= 2).join(`

`).replace(/\n{3,}/g, `

`).trim();
}
function IS(p) {
  return gw(p).replace(/^#{1,6}\s+/gm, "").replace(/\n{2,}/g, `
`).trim();
}
Te.workerSrc = chrome.runtime.getURL("vendor/pdf.worker.min.mjs");
const FS = 100;
function LS(p) {
  const t = atob(p), e = new Uint8Array(t.length);
  for (let s = 0; s < t.length; s++)
    e[s] = t.charCodeAt(s);
  return e;
}
async function OS(p) {
  const t = f0({ data: p }), e = await t.promise, s = e.numPages, n = Math.min(s, FS), r = [];
  for (let a = 1; a <= n; a++) {
    const o = await e.getPage(a), l = await o.getTextContent();
    let h = "", c = 10, d = 0, f = !1;
    const b = () => {
      f && (r.push({ text: h.trim(), fontSize: c, y: d }), h = "", f = !1);
    };
    for (const y of l.items) {
      if (!("str" in y)) continue;
      const A = y.str, w = y.transform[3] || 10, v = y.transform[5];
      h.trim().length === 0 && !f && (c = w, d = v), h += A, f = !0, y.hasEOL && b();
    }
    b(), o.cleanup();
  }
  try {
    await t.destroy();
  } catch {
  }
  return { lines: r, pageCount: s, truncated: n < s };
}
var Iy;
typeof chrome < "u" && ((Iy = chrome.runtime) != null && Iy.onMessage) && chrome.runtime.onMessage.addListener(
  (p, t, e) => (p == null ? void 0 : p.type) !== "EXTRACT_PDF_TEXT" ? !1 : ((async () => {
    try {
      if (!p.dataBase64 || typeof p.dataBase64 != "string") {
        e({ success: !1, error: { code: "EMPTY_CONTENT", message: "No PDF data received." } });
        return;
      }
      const s = LS(p.dataBase64);
      if (s.length < 200) {
        e({ success: !1, error: { code: "EMPTY_CONTENT", message: "PDF file appears to be empty." } });
        return;
      }
      const { lines: n, pageCount: r, truncated: a } = await OS(s), o = gw(n), l = IS(n);
      if (l.length < 120) {
        e({
          success: !1,
          error: {
            code: "EMPTY_CONTENT",
            message: "This PDF contains little or no extractable text (it may be a scanned image-only document)."
          }
        });
        return;
      }
      e({ success: !0, markdown: o, cleanedText: l, pageCount: r, truncated: a });
    } catch (s) {
      console.error("Idiot Summary offscreen PDF extraction error:", s), e({
        success: !1,
        error: {
          code: "PDF_PARSE_FAILED",
          message: (s == null ? void 0 : s.message) || "Failed to parse the PDF document."
        }
      });
    }
  })(), !0)
);
